-- phpMyAdmin SQL Dump
-- version 3.4.10.1deb1
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Окт 23 2014 г., 11:31
-- Версия сервера: 5.5.37
-- Версия PHP: 5.5.12-2+deb.sury.org~precise+1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `techvuz`
--

-- --------------------------------------------------------

--
-- Структура таблицы `account_types`
--

DROP TABLE IF EXISTS `account_types`;
CREATE TABLE IF NOT EXISTS `account_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=7 ;

--
-- Дамп данных таблицы `account_types`
--

INSERT INTO `account_types` (`id`, `title`, `created_at`, `updated_at`) VALUES
(1, 'Расчетный', '2014-10-23 10:41:42', '2014-10-23 10:41:42'),
(2, 'Валютный', '2014-10-23 10:41:42', '2014-10-23 10:41:42'),
(3, 'Текущий', '2014-10-23 10:41:42', '2014-10-23 10:41:42'),
(4, 'Временный', '2014-10-23 10:41:42', '2014-10-23 10:41:42'),
(5, 'Транзитный', '2014-10-23 10:41:42', '2014-10-23 10:41:42'),
(6, 'Депозитный', '2014-10-23 10:41:42', '2014-10-23 10:41:42');

-- --------------------------------------------------------

--
-- Структура таблицы `actions`
--

DROP TABLE IF EXISTS `actions`;
CREATE TABLE IF NOT EXISTS `actions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `group_id` int(10) unsigned DEFAULT NULL,
  `module` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `action` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `actions_group_id_index` (`group_id`),
  KEY `actions_module_index` (`module`),
  KEY `actions_action_index` (`action`),
  KEY `actions_status_index` (`status`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=27 ;

--
-- Дамп данных таблицы `actions`
--

INSERT INTO `actions` (`id`, `group_id`, `module`, `action`, `status`) VALUES
(1, 3, 'dictionaries', 'dicval_view', 1),
(2, 3, 'dictionaries', 'dicval_create', 1),
(3, 3, 'dictionaries', 'dicval_edit', 1),
(4, 3, 'dictionaries', 'dicval_delete', 1),
(5, 3, 'dictionaries', 'dicval_restore', 1),
(6, 3, 'dictionaries', 'dicval_entity_view', 1),
(7, 3, 'dictionaries', 'hidden', 1),
(8, 3, 'education', 'view', 1),
(9, 3, 'education', 'create', 1),
(10, 3, 'education', 'edit', 1),
(11, 3, 'education', 'delete', 1),
(12, 3, 'galleries', 'create', 1),
(13, 3, 'galleries', 'edit', 1),
(14, 3, 'galleries', 'delete', 1),
(15, 3, 'logging', 'logging', 1),
(16, 3, 'news', 'view', 1),
(17, 3, 'news', 'create', 1),
(18, 3, 'news', 'edit', 1),
(19, 3, 'news', 'delete', 1),
(20, 3, 'pages', 'view', 1),
(21, 3, 'pages', 'create', 1),
(22, 3, 'pages', 'edit', 1),
(23, 3, 'pages', 'delete', 1),
(24, 3, 'pages', 'page_restore', 1),
(25, 3, 'pages', 'settings', 1),
(26, 3, 'seo', 'edit', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `chapters`
--

DROP TABLE IF EXISTS `chapters`;
CREATE TABLE IF NOT EXISTS `chapters` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `course_id` int(10) unsigned DEFAULT NULL,
  `order` int(10) unsigned DEFAULT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `hours` int(10) unsigned DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `chapters_course_id_index` (`course_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `courses`
--

DROP TABLE IF EXISTS `courses`;
CREATE TABLE IF NOT EXISTS `courses` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `direction_id` int(10) unsigned DEFAULT NULL,
  `order` int(10) unsigned DEFAULT NULL,
  `code` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `price` float(8,2) unsigned DEFAULT '0.00',
  `discount` tinyint(4) DEFAULT '0',
  `hours` int(10) unsigned DEFAULT '0',
  `libraries` int(10) unsigned DEFAULT '0',
  `curriculum` int(10) unsigned DEFAULT '0',
  `metodical` int(10) unsigned DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `courses_direction_id_index` (`direction_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=19 ;

--
-- Дамп данных таблицы `courses`
--

INSERT INTO `courses` (`id`, `direction_id`, `order`, `code`, `title`, `description`, `price`, `discount`, `hours`, `libraries`, `curriculum`, `metodical`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 'C-1', 'Схемы планировочной организации земельного участка, в том числе на особо опасных, технически сложных и уникальных объектах.', '', 3000.00, 0, 72, 0, 0, 0, '2014-10-23 10:41:44', '2014-10-23 10:41:44'),
(2, 1, 2, 'C-2', 'Внутренние системы и сети электроснабжения, слаботочные системы, диспетчеризация, автоматизация, управление инженерными системами, в том числе на особо опасных, технически сложных и уникальных объектах.', '', 3000.00, 0, 72, 0, 0, 0, '2014-10-23 10:41:44', '2014-10-23 10:41:44'),
(3, 1, 3, 'C-3', 'Обоснование радиационной и ядерной защиты, в том числе на особо опасных, технически сложных и уникальных объектах ', '', 3000.00, 0, 72, 0, 0, 0, '2014-10-23 10:41:44', '2014-10-23 10:41:44'),
(4, 2, 1, 'П-1', 'Схемы планировочной организации земельного участка, в том числе на особо опасных, технически сложных и уникальных объектах.', '', 3000.00, 0, 72, 0, 0, 0, '2014-10-23 10:41:44', '2014-10-23 10:41:44'),
(5, 2, 2, 'П-2', 'Внутренние системы и сети электроснабжения, слаботочные системы, диспетчеризация, автоматизация, управление инженерными системами, в том числе на особо опасных, технически сложных и уникальных объектах.', '', 3000.00, 0, 72, 0, 0, 0, '2014-10-23 10:41:44', '2014-10-23 10:41:44'),
(6, 2, 3, 'П-3', 'Обоснование радиационной и ядерной защиты, в том числе на особо опасных, технически сложных и уникальных объектах ', '', 3000.00, 0, 72, 0, 0, 0, '2014-10-23 10:41:44', '2014-10-23 10:41:44'),
(7, 3, 1, 'ИЗ-1', 'Схемы планировочной организации земельного участка, в том числе на особо опасных, технически сложных и уникальных объектах.', '', 3000.00, 0, 72, 0, 0, 0, '2014-10-23 10:41:44', '2014-10-23 10:41:44'),
(8, 3, 2, 'ИЗ-2', 'Внутренние системы и сети электроснабжения, слаботочные системы, диспетчеризация, автоматизация, управление инженерными системами, в том числе на особо опасных, технически сложных и уникальных объектах.', '', 3000.00, 0, 72, 0, 0, 0, '2014-10-23 10:41:44', '2014-10-23 10:41:44'),
(9, 3, 3, 'ИЗ-3', 'Обоснование радиационной и ядерной защиты, в том числе на особо опасных, технически сложных и уникальных объектах ', '', 3000.00, 0, 72, 0, 0, 0, '2014-10-23 10:41:44', '2014-10-23 10:41:44'),
(10, 4, 1, 'ПБ-1', 'Схемы планировочной организации земельного участка, в том числе на особо опасных, технически сложных и уникальных объектах.', '', 3000.00, 0, 72, 0, 0, 0, '2014-10-23 10:41:44', '2014-10-23 10:41:44'),
(11, 4, 2, 'ПБ-2', 'Внутренние системы и сети электроснабжения, слаботочные системы, диспетчеризация, автоматизация, управление инженерными системами, в том числе на особо опасных, технически сложных и уникальных объектах.', '', 3000.00, 0, 72, 0, 0, 0, '2014-10-23 10:41:44', '2014-10-23 10:41:44'),
(12, 4, 3, 'ПБ-3', 'Обоснование радиационной и ядерной защиты, в том числе на особо опасных, технически сложных и уникальных объектах ', '', 3000.00, 0, 72, 0, 0, 0, '2014-10-23 10:41:44', '2014-10-23 10:41:44'),
(13, 5, 1, 'ИО-1', 'Схемы планировочной организации земельного участка, в том числе на особо опасных, технически сложных и уникальных объектах.', '', 3000.00, 0, 72, 0, 0, 0, '2014-10-23 10:41:44', '2014-10-23 10:41:44'),
(14, 5, 2, 'ИО-2', 'Внутренние системы и сети электроснабжения, слаботочные системы, диспетчеризация, автоматизация, управление инженерными системами, в том числе на особо опасных, технически сложных и уникальных объектах.', '', 3000.00, 0, 72, 0, 0, 0, '2014-10-23 10:41:44', '2014-10-23 10:41:44'),
(15, 5, 3, 'ИО-3', 'Обоснование радиационной и ядерной защиты, в том числе на особо опасных, технически сложных и уникальных объектах ', '', 3000.00, 0, 72, 0, 0, 0, '2014-10-23 10:41:44', '2014-10-23 10:41:44'),
(16, 6, 1, 'КГЗ-1', 'Схемы планировочной организации земельного участка, в том числе на особо опасных, технически сложных и уникальных объектах.', '', 3000.00, 0, 72, 0, 0, 0, '2014-10-23 10:41:44', '2014-10-23 10:41:44'),
(17, 6, 2, 'КГЗ-2', 'Внутренние системы и сети электроснабжения, слаботочные системы, диспетчеризация, автоматизация, управление инженерными системами, в том числе на особо опасных, технически сложных и уникальных объектах.', '', 3000.00, 0, 72, 0, 0, 0, '2014-10-23 10:41:44', '2014-10-23 10:41:44'),
(18, 6, 3, 'КГЗ-3', 'Обоснование радиационной и ядерной защиты, в том числе на особо опасных, технически сложных и уникальных объектах ', '', 3000.00, 0, 72, 0, 0, 0, '2014-10-23 10:41:44', '2014-10-23 10:41:44');

-- --------------------------------------------------------

--
-- Структура таблицы `dictionary`
--

DROP TABLE IF EXISTS `dictionary`;
CREATE TABLE IF NOT EXISTS `dictionary` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entity` tinyint(1) unsigned DEFAULT NULL,
  `icon_class` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `hide_slug` tinyint(1) unsigned DEFAULT NULL,
  `make_slug_from_name` tinyint(1) unsigned DEFAULT NULL,
  `name_title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pagination` int(10) unsigned NOT NULL DEFAULT '0',
  `view_access` smallint(5) unsigned DEFAULT NULL,
  `sort_by` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sort_order_reverse` smallint(5) unsigned NOT NULL DEFAULT '0',
  `sortable` smallint(5) unsigned NOT NULL DEFAULT '1',
  `order` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `dictionary_slug_unique` (`slug`),
  KEY `dictionary_name_index` (`name`),
  KEY `dictionary_entity_index` (`entity`),
  KEY `dictionary_view_access_index` (`view_access`),
  KEY `dictionary_order_index` (`order`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=6 ;

--
-- Дамп данных таблицы `dictionary`
--

INSERT INTO `dictionary` (`id`, `slug`, `name`, `entity`, `icon_class`, `hide_slug`, `make_slug_from_name`, `name_title`, `pagination`, `view_access`, `sort_by`, `sort_order_reverse`, `sortable`, `order`, `created_at`, `updated_at`) VALUES
(1, 'actions-types', 'Типы событий', 1, 'fa-bolt', 1, 1, 'Название типа события', 0, 1, NULL, 0, 1, 0, '2014-10-23 10:41:42', '2014-10-23 10:41:42'),
(2, 'actions-history', 'История событий', 1, 'fa-bell', 1, 1, '', 30, 1, 'created_at', 1, 0, 0, '2014-10-23 10:41:42', '2014-10-23 10:41:42'),
(3, 'reviews', 'Отзывы', 1, 'fa-comments-o', 1, 1, 'Имя пользователя оставившего отзыв', 30, 0, 'created_at', 1, 1, 0, '2014-10-23 10:41:42', '2014-10-23 10:41:42'),
(4, 'information-baners', 'Инф.банеры', 1, 'fa-info', 1, 1, 'Название банера', 30, 0, 'created_at', 1, 1, 0, '2014-10-23 10:41:42', '2014-10-23 10:41:42'),
(5, 'order-documents', 'Документы', 1, 'fa-clipboard', 1, 1, 'Название документа', 0, 2, 'name', 0, 1, 0, '2014-10-23 10:41:42', '2014-10-23 10:41:42');

-- --------------------------------------------------------

--
-- Структура таблицы `dictionary_fields_values`
--

DROP TABLE IF EXISTS `dictionary_fields_values`;
CREATE TABLE IF NOT EXISTS `dictionary_fields_values` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `dicval_id` int(10) unsigned DEFAULT NULL,
  `language` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `dictionary_fields_values_dicval_id_index` (`dicval_id`),
  KEY `dictionary_fields_values_language_index` (`language`),
  KEY `dictionary_fields_values_key_index` (`key`),
  KEY `dictionary_fields_values_value_index` (`value`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `dictionary_textfields_values`
--

DROP TABLE IF EXISTS `dictionary_textfields_values`;
CREATE TABLE IF NOT EXISTS `dictionary_textfields_values` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `dicval_id` int(10) unsigned DEFAULT NULL,
  `language` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `value` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `dictionary_textfields_values_dicval_id_index` (`dicval_id`),
  KEY `dictionary_textfields_values_language_index` (`language`),
  KEY `dictionary_textfields_values_key_index` (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `dictionary_values`
--

DROP TABLE IF EXISTS `dictionary_values`;
CREATE TABLE IF NOT EXISTS `dictionary_values` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `version_of` int(10) unsigned DEFAULT NULL,
  `dic_id` int(10) unsigned DEFAULT NULL,
  `slug` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `order` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `dictionary_values_version_of_index` (`version_of`),
  KEY `dictionary_values_dic_id_index` (`dic_id`),
  KEY `dictionary_values_slug_index` (`slug`),
  KEY `dictionary_values_order_index` (`order`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=36 ;

--
-- Дамп данных таблицы `dictionary_values`
--

INSERT INTO `dictionary_values` (`id`, `version_of`, `dic_id`, `slug`, `name`, `order`, `created_at`, `updated_at`) VALUES
(1, NULL, 1, 'directions.store', 'Добавлено направление', 0, '2014-10-23 10:41:42', '2014-10-23 10:41:42'),
(2, NULL, 1, 'directions.update', 'Обновлено направление', 1, '2014-10-23 10:41:42', '2014-10-23 10:41:42'),
(3, NULL, 1, 'directions.destroy', 'Удалено направление', 2, '2014-10-23 10:41:42', '2014-10-23 10:41:42'),
(4, NULL, 1, 'courses.store', 'Добавлен курс', 3, '2014-10-23 10:41:42', '2014-10-23 10:41:42'),
(5, NULL, 1, 'courses.update', 'Обновлен курс', 4, '2014-10-23 10:41:42', '2014-10-23 10:41:42'),
(6, NULL, 1, 'courses.destroy', 'Удален курс', 5, '2014-10-23 10:41:42', '2014-10-23 10:41:42'),
(7, NULL, 1, 'chapters.store', 'Добавлена глава', 6, '2014-10-23 10:41:42', '2014-10-23 10:41:42'),
(8, NULL, 1, 'chapters.update', 'Обновлена глава', 7, '2014-10-23 10:41:42', '2014-10-23 10:41:42'),
(9, NULL, 1, 'chapters.destroy', 'Удалена глава', 8, '2014-10-23 10:41:42', '2014-10-23 10:41:42'),
(10, NULL, 1, 'lectures.store', 'Добавлена лекция', 9, '2014-10-23 10:41:42', '2014-10-23 10:41:42'),
(11, NULL, 1, 'lectures.update', 'Обновлена лекция', 10, '2014-10-23 10:41:42', '2014-10-23 10:41:42'),
(12, NULL, 1, 'lectures.destroy', 'Удалена лекция', 11, '2014-10-23 10:41:42', '2014-10-23 10:41:42'),
(13, NULL, 1, 'testing.index', 'Добавлен тест', 12, '2014-10-23 10:41:42', '2014-10-23 10:41:42'),
(14, NULL, 1, 'testing.destroy', 'Удален тест', 13, '2014-10-23 10:41:42', '2014-10-23 10:41:42'),
(15, NULL, 1, 'dobavlen-otzuv', 'Добавлен отзыв', 14, '2014-10-23 10:41:42', '2014-10-23 10:41:42'),
(16, NULL, 1, 'otredaktirovan-otzuv', 'Обновлен отзыв', 15, '2014-10-23 10:41:42', '2014-10-23 10:41:42'),
(17, NULL, 1, 'udalen-otzuv', 'Удален отзыв', 16, '2014-10-23 10:41:42', '2014-10-23 10:41:42'),
(18, NULL, 1, 'dobavlena-novost', 'Добавлена новость', 17, '2014-10-23 10:41:42', '2014-10-23 10:41:42'),
(19, NULL, 1, 'otredaktirovana-novost', 'Обновлена новость', 18, '2014-10-23 10:41:42', '2014-10-23 10:41:42'),
(20, NULL, 1, 'udalena-novost', 'Удалена новость', 19, '2014-10-23 10:41:42', '2014-10-23 10:41:42'),
(21, NULL, 1, 'otredaktirovan-document', 'Обновлен документ', 20, '2014-10-23 10:41:42', '2014-10-23 10:41:42'),
(22, NULL, 1, 'payment-order-number-store', 'Добавлен платеж', 21, '2014-10-23 10:41:42', '2014-10-23 10:41:42'),
(23, NULL, 1, 'payment-order-number-update', 'Обновлен платеж', 22, '2014-10-23 10:41:42', '2014-10-23 10:41:42'),
(24, NULL, 1, 'payment-order-number-delete', 'Удален платеж', 23, '2014-10-23 10:41:42', '2014-10-23 10:41:42'),
(25, NULL, 1, 'change-order-status', 'Изменен статус заказа', 24, '2014-10-23 10:41:42', '2014-10-23 10:41:42'),
(26, NULL, 1, 'moderator-company-profile-update', 'Изменен профиль компании', 25, '2014-10-23 10:41:42', '2014-10-23 10:41:42'),
(27, NULL, 1, 'moderator-company-profile-activated', 'Активирован аккаунт компании', 26, '2014-10-23 10:41:42', '2014-10-23 10:41:42'),
(28, NULL, 1, 'moderator-company-profile-approved', 'Подтвержден аккаунт компании', 27, '2014-10-23 10:41:42', '2014-10-23 10:41:42'),
(29, NULL, 1, 'moderator-listener-profile-update', 'Изменен профиль слушателя', 28, '2014-10-23 10:41:42', '2014-10-23 10:41:42'),
(30, NULL, 1, 'moderator-listener-profile-activated', 'Активирован аккаунт слушателя', 29, '2014-10-23 10:41:42', '2014-10-23 10:41:42'),
(31, NULL, 5, 'order-documents-contract', 'Договор', 1, '2014-10-23 10:41:42', '2014-10-23 10:41:42'),
(32, NULL, 5, 'order-documents-invoice', 'Счет', 2, '2014-10-23 10:41:42', '2014-10-23 10:41:42'),
(33, NULL, 5, 'order-documents-act', 'Акт', 3, '2014-10-23 10:41:42', '2014-10-23 10:41:42'),
(34, NULL, 5, 'order-documents-certificate-first', 'Сертификат первый ', 4, '2014-10-23 10:41:42', '2014-10-23 10:41:42'),
(35, NULL, 5, 'order-documents-certificate-second', 'Сертификат второй ', 5, '2014-10-23 10:41:42', '2014-10-23 10:41:42');

-- --------------------------------------------------------

--
-- Структура таблицы `dictionary_values_meta`
--

DROP TABLE IF EXISTS `dictionary_values_meta`;
CREATE TABLE IF NOT EXISTS `dictionary_values_meta` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `dicval_id` int(10) unsigned DEFAULT NULL,
  `language` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `dictionary_values_meta_dicval_id_index` (`dicval_id`),
  KEY `dictionary_values_meta_language_index` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `dictionary_values_rel`
--

DROP TABLE IF EXISTS `dictionary_values_rel`;
CREATE TABLE IF NOT EXISTS `dictionary_values_rel` (
  `dicval_parent_id` int(10) unsigned NOT NULL DEFAULT '0',
  `dicval_child_id` int(10) unsigned NOT NULL DEFAULT '0',
  `dicval_child_dic` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`dicval_parent_id`,`dicval_child_id`),
  KEY `dictionary_values_rel_dicval_parent_id_index` (`dicval_parent_id`),
  KEY `dictionary_values_rel_dicval_child_id_index` (`dicval_child_id`),
  KEY `dictionary_values_rel_dicval_child_dic_index` (`dicval_child_dic`(255))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `directions`
--

DROP TABLE IF EXISTS `directions`;
CREATE TABLE IF NOT EXISTS `directions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `order` int(10) unsigned DEFAULT NULL,
  `code` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `photo_id` int(10) unsigned DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `discount` tinyint(4) DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=7 ;

--
-- Дамп данных таблицы `directions`
--

INSERT INTO `directions` (`id`, `order`, `code`, `title`, `photo_id`, `description`, `discount`, `created_at`, `updated_at`) VALUES
(1, 1, 'С', 'Строительство', 1, '', 0, '2014-10-23 10:41:44', '2014-10-23 10:41:44'),
(2, 2, 'П', 'Проектирование', 2, '', 0, '2014-10-23 10:41:44', '2014-10-23 10:41:44'),
(3, 3, 'ИЗ', 'Инженерные изыскания', 3, '', 0, '2014-10-23 10:41:44', '2014-10-23 10:41:44'),
(4, 4, 'ПБ', 'Пожарная безопасность', 4, '', 0, '2014-10-23 10:41:44', '2014-10-23 10:41:44'),
(5, 5, 'ИО', 'Инженерное обеспечение', 5, '', 0, '2014-10-23 10:41:44', '2014-10-23 10:41:44'),
(6, 6, 'КГЗ', 'Конструкции гражданских зданий', 6, '', 0, '2014-10-23 10:41:44', '2014-10-23 10:41:44');

-- --------------------------------------------------------

--
-- Структура таблицы `galleries`
--

DROP TABLE IF EXISTS `galleries`;
CREATE TABLE IF NOT EXISTS `galleries` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `settings` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `groups`
--

DROP TABLE IF EXISTS `groups`;
CREATE TABLE IF NOT EXISTS `groups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `desc` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `dashboard` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `start_url` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `groups_name_unique` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=7 ;

--
-- Дамп данных таблицы `groups`
--

INSERT INTO `groups` (`id`, `name`, `desc`, `dashboard`, `start_url`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'Администраторы', 'admin', '', '2014-10-23 10:41:42', '2014-10-23 10:41:42'),
(2, 'user', 'Пользователи', '', '', '2014-10-23 10:41:42', '2014-10-23 10:41:42'),
(3, 'moderator', 'Модераторы', 'moderator', '', '2014-10-23 10:41:42', '2014-10-23 11:15:27'),
(4, 'organization', 'Юридическое лицо', 'organization', '', '2014-10-23 10:41:42', '2014-10-23 10:41:42'),
(5, 'listener', 'Сотрудник организаци', 'listener', '', '2014-10-23 10:41:42', '2014-10-23 10:41:42'),
(6, 'individual', 'Индивидуальный слуша', 'individual-listener', '', '2014-10-23 10:41:42', '2014-10-23 10:41:42');

-- --------------------------------------------------------

--
-- Структура таблицы `individuals`
--

DROP TABLE IF EXISTS `individuals`;
CREATE TABLE IF NOT EXISTS `individuals` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT '0',
  `fio` varchar(160) COLLATE utf8_unicode_ci DEFAULT NULL,
  `position` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `inn` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `postaddress` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `discount` tinyint(4) DEFAULT '0',
  `moderator_approve` tinyint(1) DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `individuals_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `lectures`
--

DROP TABLE IF EXISTS `lectures`;
CREATE TABLE IF NOT EXISTS `lectures` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `course_id` int(10) unsigned DEFAULT NULL,
  `chapter_id` int(10) unsigned DEFAULT NULL,
  `order` int(10) unsigned DEFAULT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `hours` int(10) unsigned DEFAULT '0',
  `document` int(10) unsigned DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `lectures_course_id_index` (`course_id`),
  KEY `lectures_chapter_id_index` (`chapter_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `listeners`
--

DROP TABLE IF EXISTS `listeners`;
CREATE TABLE IF NOT EXISTS `listeners` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT '0',
  `organization_id` int(10) unsigned DEFAULT '0',
  `fio` varchar(160) COLLATE utf8_unicode_ci DEFAULT NULL,
  `position` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `postaddress` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `education` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `place_work` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `year_study` varchar(4) COLLATE utf8_unicode_ci DEFAULT NULL,
  `specialty` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `listeners_user_id_index` (`user_id`),
  KEY `listeners_organization_id_index` (`organization_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `migrations`
--

INSERT INTO `migrations` (`migration`, `batch`) VALUES
('2014_01_01_100000_create_groups_table', 1),
('2014_01_01_100010_create_users_table', 1),
('2014_01_01_100020_create_modules_table', 1),
('2014_01_01_100030_create_actions_table', 1),
('2014_01_01_100040_create_session_table', 1),
('2014_01_01_100050_create_settings_table', 1),
('2014_01_01_100051_create_storages_table', 1),
('2014_01_01_100060_create_pages_tables', 1),
('2014_01_01_100070_create_news_tables', 1),
('2014_01_01_100080_create_galleries_table', 1),
('2014_01_01_100090_create_photos_table', 1),
('2014_01_01_100100_create_rel_mod_gallery_table', 1),
('2014_01_01_100110_create_seo_table', 1),
('2014_07_03_161130_create_dics_tables', 1),
('2014_09_02_161130_create_uploads_tables', 1),
('2014_09_02_161140_create_video_tables', 1),
('2014_09_04_150007_create_directions_table', 1),
('2014_09_04_151141_create_courses_table', 1),
('2014_09_08_113541_create_chapter_table', 1),
('2014_09_08_113712_create_lectures_table', 1),
('2014_09_09_113857_create_tests_table', 1),
('2014_09_09_134300_create_tests_questions_table', 1),
('2014_09_09_134539_create_tests_answers_table', 1),
('2014_09_12_111807_create_account_types_table', 1),
('2014_09_24_130138_create_organization_table', 1),
('2014_09_24_131546_create_individual_table', 1),
('2014_09_25_082127_create_listener_table', 1),
('2014_10_01_081703_create_password_reminders_table', 1),
('2014_10_03_124653_create_orders_table', 1),
('2014_10_03_125652_create_payment_status_table', 1),
('2014_10_09_121118_create_order_payments', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `modules`
--

DROP TABLE IF EXISTS `modules`;
CREATE TABLE IF NOT EXISTS `modules` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `on` tinyint(1) NOT NULL DEFAULT '0',
  `order` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=11 ;

--
-- Дамп данных таблицы `modules`
--

INSERT INTO `modules` (`id`, `name`, `on`, `order`, `created_at`, `updated_at`) VALUES
(1, 'system', 1, 0, '2014-10-23 10:41:42', '2014-10-23 10:41:42'),
(2, 'pages', 1, 0, '2014-10-23 10:41:42', '2014-10-23 10:41:42'),
(3, 'news', 1, 0, '2014-10-23 10:41:42', '2014-10-23 10:41:42'),
(4, 'galleries', 1, 0, '2014-10-23 10:41:42', '2014-10-23 10:41:42'),
(5, 'seo', 1, 0, '2014-10-23 10:41:42', '2014-10-23 10:41:42'),
(6, 'dictionaries', 1, 0, '2014-10-23 10:41:42', '2014-10-23 10:41:42'),
(7, 'education', 1, 0, '2014-10-23 10:41:42', '2014-10-23 10:41:42'),
(8, 'logging', 1, 0, '2014-10-23 11:13:23', '2014-10-23 11:13:23'),
(9, 'uploads', 1, 0, '2014-10-23 11:13:25', '2014-10-23 11:13:25'),
(10, 'video', 0, 0, '2014-10-23 11:13:26', '2014-10-23 11:15:34');

-- --------------------------------------------------------

--
-- Структура таблицы `news`
--

DROP TABLE IF EXISTS `news`;
CREATE TABLE IF NOT EXISTS `news` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `template` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `type_id` int(10) unsigned DEFAULT NULL,
  `publication` tinyint(1) unsigned DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `published_at` date NOT NULL,
  PRIMARY KEY (`id`),
  KEY `news_type_id_index` (`type_id`),
  KEY `news_publication_index` (`publication`),
  KEY `news_published_at_index` (`published_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `news_meta`
--

DROP TABLE IF EXISTS `news_meta`;
CREATE TABLE IF NOT EXISTS `news_meta` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `news_id` int(10) unsigned DEFAULT NULL,
  `language` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `title` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `preview` text COLLATE utf8_unicode_ci,
  `content` mediumtext COLLATE utf8_unicode_ci,
  `photo_id` int(10) unsigned DEFAULT NULL,
  `gallery_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `news_meta_news_id_index` (`news_id`),
  KEY `news_meta_language_index` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `orders`
--

DROP TABLE IF EXISTS `orders`;
CREATE TABLE IF NOT EXISTS `orders` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT '0',
  `number` int(10) unsigned DEFAULT '0',
  `completed` tinyint(1) DEFAULT '0',
  `payment_status` tinyint(3) unsigned DEFAULT '1',
  `payment_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `discount` tinyint(4) DEFAULT '0',
  `close_status` tinyint(1) DEFAULT '0',
  `close_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `archived` tinyint(1) DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `orders_user_id_index` (`user_id`),
  KEY `orders_payment_status_index` (`payment_status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `order_listeners`
--

DROP TABLE IF EXISTS `order_listeners`;
CREATE TABLE IF NOT EXISTS `order_listeners` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` int(10) unsigned DEFAULT '0',
  `course_id` int(10) unsigned DEFAULT '0',
  `user_id` int(10) unsigned DEFAULT '0',
  `price` float(8,2) unsigned DEFAULT '0.00',
  `access_status` tinyint(1) unsigned DEFAULT '0',
  `start_status` tinyint(1) unsigned DEFAULT '0',
  `over_status` tinyint(1) unsigned DEFAULT '0',
  `start_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `over_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `order_listeners_order_id_index` (`order_id`),
  KEY `order_listeners_course_id_index` (`course_id`),
  KEY `order_listeners_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `order_listener_tests`
--

DROP TABLE IF EXISTS `order_listener_tests`;
CREATE TABLE IF NOT EXISTS `order_listener_tests` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `order_listeners_id` int(10) unsigned DEFAULT '0',
  `chapter_id` int(10) unsigned DEFAULT '0',
  `test_id` int(10) unsigned DEFAULT '0',
  `data_results` text COLLATE utf8_unicode_ci,
  `result_attempt` tinyint(3) unsigned DEFAULT '0',
  `time_attempt` int(10) unsigned DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `order_listener_tests_order_listeners_id_index` (`order_listeners_id`),
  KEY `order_listener_tests_chapter_id_index` (`chapter_id`),
  KEY `order_listener_tests_test_id_index` (`test_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `order_payments`
--

DROP TABLE IF EXISTS `order_payments`;
CREATE TABLE IF NOT EXISTS `order_payments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` int(10) unsigned DEFAULT '0',
  `price` float(8,2) unsigned DEFAULT '0.00',
  `payment_number` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `payment_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `order_payments_order_id_index` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `organizations`
--

DROP TABLE IF EXISTS `organizations`;
CREATE TABLE IF NOT EXISTS `organizations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT '0',
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fio_manager` varchar(160) COLLATE utf8_unicode_ci DEFAULT NULL,
  `manager` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `statutory` varchar(160) COLLATE utf8_unicode_ci DEFAULT NULL,
  `inn` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `kpp` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `postaddress` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `account_type` smallint(5) unsigned DEFAULT '0',
  `account_number` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bank` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bik` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `discount` tinyint(4) DEFAULT '0',
  `moderator_approve` tinyint(1) DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `organizations_user_id_index` (`user_id`),
  KEY `organizations_account_type_index` (`account_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `pages`
--

DROP TABLE IF EXISTS `pages`;
CREATE TABLE IF NOT EXISTS `pages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `version_of` int(10) unsigned DEFAULT NULL,
  `name` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `slug` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `template` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `type_id` int(10) unsigned DEFAULT NULL,
  `publication` tinyint(1) unsigned DEFAULT '1',
  `start_page` tinyint(1) unsigned DEFAULT NULL,
  `in_menu` tinyint(1) unsigned DEFAULT NULL,
  `order` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `pages_version_of_index` (`version_of`),
  KEY `pages_slug_index` (`slug`),
  KEY `pages_type_id_index` (`type_id`),
  KEY `pages_publication_index` (`publication`),
  KEY `pages_start_page_index` (`start_page`),
  KEY `pages_in_menu_index` (`in_menu`),
  KEY `pages_order_index` (`order`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=7 ;

--
-- Дамп данных таблицы `pages`
--

INSERT INTO `pages` (`id`, `version_of`, `name`, `slug`, `template`, `type_id`, `publication`, `start_page`, `in_menu`, `order`, `created_at`, `updated_at`) VALUES
(1, NULL, 'Главная страница', 'glavnaya-stranica', 'index-page', NULL, 1, 1, NULL, NULL, '2014-09-25 06:44:13', '2014-10-08 11:44:48'),
(2, NULL, 'Оформление заявки', 'registration', 'by-slug', NULL, 1, NULL, NULL, NULL, '2014-09-25 06:45:04', '2014-09-25 06:46:20'),
(3, NULL, 'Каталог курсов', 'catalog', 'by-slug', NULL, 1, NULL, 1, NULL, '2014-10-01 11:39:57', '2014-10-01 11:39:57'),
(4, NULL, 'Как это работает', 'how-it-works', 'by-slug', NULL, 1, NULL, NULL, NULL, '2014-10-07 06:48:57', '2014-10-07 06:48:57'),
(5, NULL, 'Контакты', 'contacts', 'by-slug', NULL, 1, NULL, NULL, NULL, '2014-10-08 10:45:01', '2014-10-08 11:41:11'),
(6, NULL, 'О портале', 'about', 'by-slug', NULL, 1, NULL, NULL, NULL, '2014-10-09 03:59:01', '2014-10-09 03:59:01');

-- --------------------------------------------------------

--
-- Структура таблицы `pages_blocks`
--

DROP TABLE IF EXISTS `pages_blocks`;
CREATE TABLE IF NOT EXISTS `pages_blocks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `page_id` int(10) unsigned DEFAULT NULL,
  `name` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `slug` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `desc` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `template` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `order` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `pages_blocks_page_id_index` (`page_id`),
  KEY `pages_blocks_slug_index` (`slug`),
  KEY `pages_blocks_order_index` (`order`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=62 ;

--
-- Дамп данных таблицы `pages_blocks`
--

INSERT INTO `pages_blocks` (`id`, `page_id`, `name`, `slug`, `desc`, `template`, `order`, `created_at`, `updated_at`) VALUES
(1, 1, 'Название страницы', 'top_h2', NULL, NULL, 0, '2014-09-25 06:44:13', '2014-09-25 06:44:13'),
(2, 2, 'Название страницы', 'top_h2', NULL, NULL, 0, '2014-09-25 06:45:04', '2014-09-25 06:45:04'),
(3, 3, 'Название страницы', 'top_h2', NULL, NULL, 0, '2014-10-01 11:39:57', '2014-10-01 11:39:57'),
(4, 3, 'Описание страницы', 'top_desc', NULL, NULL, 1, '2014-10-01 11:39:57', '2014-10-01 11:39:57'),
(5, 2, 'Описание страницы', 'top_desc', NULL, NULL, 1, '2014-10-01 11:43:27', '2014-10-01 11:43:27'),
(6, 4, 'Название страницы', 'top_h2', NULL, NULL, 0, '2014-10-07 06:48:57', '2014-10-07 06:48:57'),
(7, 4, 'Описание страницы', 'top_desc', NULL, NULL, 1, '2014-10-07 06:48:57', '2014-10-07 06:48:57'),
(8, 4, 'Контент страницы', 'content', NULL, NULL, 2, '2014-10-07 06:55:58', '2014-10-07 06:55:58'),
(9, 5, 'Название страницы', 'top_h2', NULL, NULL, 0, '2014-10-08 10:45:01', '2014-10-15 10:37:36'),
(10, 5, 'Описание страницы', 'top_desc', NULL, NULL, 1, '2014-10-08 10:45:01', '2014-10-15 10:39:54'),
(11, 5, 'Адрес', 'address', NULL, NULL, 2, '2014-10-08 10:45:01', '2014-10-15 10:39:54'),
(12, 5, 'Контактные номера', 'phones', NULL, NULL, 3, '2014-10-08 10:45:01', '2014-10-15 10:39:54'),
(25, 5, 'Email адрес', 'email', NULL, NULL, 4, '2014-10-08 10:49:48', '2014-10-15 10:39:54'),
(26, 5, 'Банковские реквизиты (Название)', 'center_h2', NULL, NULL, 5, '2014-10-08 10:49:48', '2014-10-15 10:39:54'),
(27, 6, 'Название страницы', 'top_h2', NULL, NULL, 0, '2014-10-09 03:59:02', '2014-10-09 03:59:02'),
(28, 6, 'Описание страницы', 'top_desc', NULL, NULL, 1, '2014-10-09 03:59:02', '2014-10-09 03:59:02'),
(30, 1, 'Описание страницы', 'top_desc', NULL, NULL, 1, '2014-10-15 10:31:08', '2014-10-15 10:31:08'),
(31, 1, 'Преимущества название', 'benefits_title', NULL, NULL, 2, '2014-10-15 10:31:08', '2014-10-15 10:31:08'),
(32, 1, 'Преимущества описание', 'benefits_list', NULL, NULL, 3, '2014-10-15 10:31:08', '2014-10-15 10:31:25'),
(49, 5, 'ИНН', 'inn', NULL, NULL, 6, '2014-10-15 10:39:54', '2014-10-15 10:39:54'),
(50, 5, 'ОГРН', 'ogrn', NULL, NULL, 7, '2014-10-15 10:39:54', '2014-10-15 10:39:54'),
(51, 5, 'КПП', 'kpp', NULL, NULL, 8, '2014-10-15 10:39:54', '2014-10-15 10:39:54'),
(52, 5, 'ОКПО', 'okpo', NULL, NULL, 9, '2014-10-15 10:39:54', '2014-10-15 10:39:54'),
(53, 5, 'ОКАТО', 'okato', NULL, NULL, 10, '2014-10-15 10:39:54', '2014-10-15 10:39:54'),
(54, 5, 'ОКВЭД', 'pkved', NULL, NULL, 11, '2014-10-15 10:39:54', '2014-10-15 10:39:54'),
(55, 5, 'р/сч', 'rasschet', NULL, NULL, 12, '2014-10-15 10:39:54', '2014-10-15 10:39:54'),
(56, 5, 'к/сч', 'kschet', NULL, NULL, 13, '2014-10-15 10:39:54', '2014-10-15 10:39:54'),
(57, 5, 'Банк', 'bank', NULL, NULL, 14, '2014-10-15 10:39:54', '2014-10-15 10:39:54'),
(58, 5, 'БИК', 'bik', NULL, NULL, 15, '2014-10-15 10:39:54', '2014-10-15 10:39:54'),
(61, 6, 'Лицензии', 'center_h3', NULL, NULL, 2, '2014-10-15 10:43:32', '2014-10-15 10:44:02');

-- --------------------------------------------------------

--
-- Структура таблицы `pages_blocks_meta`
--

DROP TABLE IF EXISTS `pages_blocks_meta`;
CREATE TABLE IF NOT EXISTS `pages_blocks_meta` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `block_id` int(10) unsigned DEFAULT NULL,
  `name` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `content` text COLLATE utf8_unicode_ci,
  `language` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `template` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `pages_blocks_meta_block_id_index` (`block_id`),
  KEY `pages_blocks_meta_language_index` (`language`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=49 ;

--
-- Дамп данных таблицы `pages_blocks_meta`
--

INSERT INTO `pages_blocks_meta` (`id`, `block_id`, `name`, `content`, `language`, `template`, `created_at`, `updated_at`) VALUES
(1, 3, NULL, '<h2>Каталог курсов</h2>', 'ru', NULL, '2014-10-01 11:40:30', '2014-10-01 11:40:30'),
(2, 4, NULL, '<p>В данном каталоге мы предлагаем имеющиеся курсы различных направлений. Всего в вашем распоряжении 8 курсов, каждый из которых проводится с применением образовательных технологий  электронного обучения.</p>', 'ru', NULL, '2014-10-01 11:41:25', '2014-10-01 11:41:25'),
(3, 6, NULL, '<h2>Как это работает</h2>', 'ru', NULL, '2014-10-07 06:55:12', '2014-10-07 06:55:12'),
(4, 7, NULL, '<p>Для того чтобы начать обучение вам нужно выбрать юридическое или физическое лицо и пройти регистрацию, заполнив все поля.</p>', 'ru', NULL, '2014-10-07 06:55:25', '2014-10-07 06:55:38'),
(5, 8, NULL, '<ul class="htw-ul">\r\n	<li class="htw-li htw-num-1">\r\n	<h3 class="htw-head">                                 Оформление заявки                             </h3>\r\n	<div class="htw-text">\r\n		<ol>\r\n			<li><a href="/registration">Зарегистрируйте</a> заказчика (для юр. лиц)</li>\r\n			<li>Выберите <a href="/catalog">курсы</a></li>\r\n			<li>Зарегистрируйте слушатеей</li>\r\n			<li>Получите счет и договор</li>\r\n		</ol>\r\n	</div>\r\n	</li>\r\n	<li class="htw-li htw-num-2">\r\n	<h3 class="htw-head">                                 Оплата                             </h3>\r\n	<div class="htw-text">\r\n		                                 Счет Вы получите автоматически по завершении оформления заявки.                                 Совершить оплату Вы можете в любом банке. Доступ к лекциям открывается                                 в течение 1-2 дней после оплаты.\r\n	</div>\r\n	</li>\r\n	<li class="htw-li htw-num-3">\r\n	<h3 class="htw-head">                                 Обучение                             </h3>\r\n	<div class="htw-text">\r\n		                                 Слушатели обучаются в своих <a href="#">личных кабинетах</a>                                 на сайте. Для завершения обучения слушатели выполняют итоговое тестирование.\r\n	</div>\r\n	</li>\r\n	<li class="htw-li htw-num-4">\r\n	<h3 class="htw-head">                                 Получение удостоверения                             </h3>\r\n	<div class="htw-text">\r\n		                                 Как только слушатели успешно завершают обучение, мы выдаем удостоверения о повышении квалификации. Документы можно получить лично либо высылаются по месту нахождения заказчика курьерской службой, бесплатно!\r\n	</div>\r\n	</li>\r\n</ul>', 'ru', NULL, '2014-10-07 06:56:19', '2014-10-15 10:34:11'),
(6, 1, NULL, 'Повышение квалификации через Интернет<br/>с выдачей удостоверения установленного образца', 'ru', NULL, '2014-10-08 10:14:23', '2014-10-22 06:40:37'),
(7, 9, NULL, 'Контакты', 'ru', NULL, '2014-10-08 11:31:47', '2014-10-15 10:35:49'),
(11, 10, NULL, 'Негосударственное образовательное учреждение                          дополнительного профессионального образования                          «Центр качества строительства»', 'ru', NULL, '2014-10-08 11:47:08', '2014-10-15 10:36:06'),
(12, 2, NULL, 'Регистрация в системе', 'ru', NULL, '2014-10-09 03:29:47', '2014-10-15 10:55:59'),
(13, 5, NULL, '<p>\r\n	                         Уважаемый заказчик! Для оформления заявок на повышение                         квалификации Вам необходимо пройти систему регистрации.\r\n</p>', 'ru', NULL, '2014-10-09 03:29:54', '2014-10-15 10:56:12'),
(14, 27, NULL, 'О портале', 'ru', NULL, '2014-10-15 10:28:52', '2014-10-15 10:42:53'),
(15, 28, NULL, '<p class="margin-bottom-20">\r\n	                         Образовательный портал южно-окружного центра повышения                         квалификации – это система дистанционного обучения, предназначенная                         для повышения квалификации через Интернет с выдачей удостоверения государственного образца. Система позволяет организовать процесс                         обучения без отрыва от производства, с помощью электронных учебных курсов                         в дистанционной форме через сети Интернет.\r\n</p>\r\n<p class="margin-bottom-20">\r\n	                         Южно-окружной центр повышения квалификации и переподготовки кадров                         для строительного и жилищно-коммунального комплекса является образовательным учреждением дополнительного профессионального образования. Центр учрежден в 2012 году и находится в ведении Министерства Юстиции Российской Федерации. 2 апреля 2012 года центр был аккредитован региональной службой по надзору и контролю в сфере образования Ростовской области и получил лицензию на право осуществления образовательной  деятельности в сфере дополнительного профессионального образования.\r\n</p>', 'ru', NULL, '2014-10-15 10:28:58', '2014-10-15 10:43:07'),
(18, 30, NULL, '<p>\r\n	                          Система электронного обучения позволяет организовать образовательный процесс с помощью электронных учебных курсов в электронной форме через сети Интернет.\r\n</p>\r\n<p>\r\n	                          После окончания обучения и успешной сдачи итогового тестирования слушатели курсов в самые кратчайшие сроки получают удостоверение о повышении квалификации государственного образца.\r\n</p>', 'ru', NULL, '2014-10-15 10:32:01', '2014-10-22 06:27:30'),
(19, 31, NULL, '<h3>\r\n	Преимущества\r\n</h3>', 'ru', NULL, '2014-10-15 10:32:12', '2014-10-22 06:17:52'),
(20, 32, NULL, '<ul class="benefits-ul clearfix">\r\n	<li class="benefits-li benefit-num-1"><strong>Удобная система</strong> – подойдет для пользователей любого уровня подготовки.                         </li>\r\n	<li class="benefits-li benefit-num-2"><strong>Широкий набор образовательных программ</strong> – обязательно найдете то, что нужно именно вашей компании.                         </li>\r\n	<li class="benefits-li benefit-num-3"><strong>Дистанционное электронное образование</strong> – обучайтесь где и когда удобно.                          </li>\r\n	<li class="benefits-li benefit-num-4"><strong>Надежность</strong> – все программы составленны на основании текущих нормативных документах.                         </li>\r\n</ul>', 'ru', NULL, '2014-10-15 10:32:26', '2014-10-15 10:32:26'),
(21, 11, NULL, '344 092, г. Ростов-на-Дону,<br>\r\n                            пер. Соляной Спуск, 8-10<br>', 'ru', NULL, '2014-10-15 10:36:21', '2014-10-15 10:36:21'),
(22, 12, NULL, '<p>\r\n	8 (800) 299-07-14<br>\r\n	8 (800) 299-07-15\r\n</p>', 'ru', NULL, '2014-10-15 10:37:01', '2014-10-15 10:37:01'),
(23, 25, NULL, 'tehvuz@gmail.ru', 'ru', NULL, '2014-10-15 10:37:12', '2014-10-15 10:37:12'),
(29, 26, NULL, 'Банковские реквизиты', 'ru', NULL, '2014-10-15 10:37:48', '2014-10-15 10:37:48'),
(36, 49, NULL, '6164990260', 'ru', NULL, '2014-10-15 10:40:19', '2014-10-15 10:40:19'),
(37, 50, NULL, '1126100001720', 'ru', NULL, '2014-10-15 10:40:25', '2014-10-15 10:40:25'),
(38, 51, NULL, '616401001', 'ru', NULL, '2014-10-15 10:40:34', '2014-10-15 10:40:34'),
(39, 52, NULL, '38426411', 'ru', NULL, '2014-10-15 10:40:40', '2014-10-15 10:40:40'),
(40, 53, NULL, '60401372000', 'ru', NULL, '2014-10-15 10:40:48', '2014-10-15 10:40:48'),
(41, 54, NULL, 'ОКВЭД', 'ru', NULL, '2014-10-15 10:40:56', '2014-10-15 10:40:56'),
(42, 55, NULL, '4070381082605000000', 'ru', NULL, '2014-10-15 10:41:07', '2014-10-15 10:41:07'),
(43, 56, NULL, '30101810500000000207', 'ru', NULL, '2014-10-15 10:41:15', '2014-10-15 10:41:15'),
(44, 57, NULL, 'ОАО Альфа-Банк г.  Ростов-на-Дону', 'ru', NULL, '2014-10-15 10:41:25', '2014-10-15 10:41:25'),
(45, 58, NULL, '046015207', 'ru', NULL, '2014-10-15 10:41:32', '2014-10-15 10:41:32'),
(48, 61, NULL, 'Наши лицензии и сертификаты', 'ru', NULL, '2014-10-15 10:43:37', '2014-10-15 10:43:37');

-- --------------------------------------------------------

--
-- Структура таблицы `pages_meta`
--

DROP TABLE IF EXISTS `pages_meta`;
CREATE TABLE IF NOT EXISTS `pages_meta` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `page_id` int(10) unsigned DEFAULT NULL,
  `language` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `template` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `pages_meta_page_id_index` (`page_id`),
  KEY `pages_meta_language_index` (`language`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=7 ;

--
-- Дамп данных таблицы `pages_meta`
--

INSERT INTO `pages_meta` (`id`, `page_id`, `language`, `template`, `created_at`, `updated_at`) VALUES
(1, 1, 'ru', NULL, '2014-09-25 06:44:13', '2014-09-25 06:44:13'),
(2, 2, 'ru', NULL, '2014-09-25 06:45:04', '2014-09-25 06:45:04'),
(3, 3, 'ru', NULL, '2014-10-01 11:39:57', '2014-10-01 11:39:57'),
(4, 4, 'ru', NULL, '2014-10-07 06:48:57', '2014-10-07 06:48:57'),
(5, 5, 'ru', NULL, '2014-10-08 10:45:01', '2014-10-08 10:45:01'),
(6, 6, 'ru', NULL, '2014-10-09 03:59:01', '2014-10-09 03:59:01');

-- --------------------------------------------------------

--
-- Структура таблицы `password_reminders`
--

DROP TABLE IF EXISTS `password_reminders`;
CREATE TABLE IF NOT EXISTS `password_reminders` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  KEY `password_reminders_email_index` (`email`),
  KEY `password_reminders_token_index` (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `payment_status`
--

DROP TABLE IF EXISTS `payment_status`;
CREATE TABLE IF NOT EXISTS `payment_status` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `class` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=7 ;

--
-- Дамп данных таблицы `payment_status`
--

INSERT INTO `payment_status` (`id`, `title`, `class`, `created_at`, `updated_at`) VALUES
(1, 'Не оплачен', 'non-paid-order', '2014-10-23 10:41:42', '2014-10-23 10:41:42'),
(2, 'Оплачен', 'paid-order', '2014-10-23 10:41:42', '2014-10-23 10:41:42'),
(3, 'Частично оплачен', 'part-order', '2014-10-23 10:41:42', '2014-10-23 10:41:42'),
(4, 'Частично оплачен но доступ разрешен', 'part-order', '2014-10-23 10:41:42', '2014-10-23 10:41:42'),
(5, 'Не оплачен но доступ разрешен', 'non-paid-order', '2014-10-23 10:41:42', '2014-10-23 10:41:42'),
(6, 'Оплачен но доступ запрещен', 'paid-order', '2014-10-23 10:41:42', '2014-10-23 10:41:42');

-- --------------------------------------------------------

--
-- Структура таблицы `photos`
--

DROP TABLE IF EXISTS `photos`;
CREATE TABLE IF NOT EXISTS `photos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `gallery_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `photos_gallery_id_index` (`gallery_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=7 ;

--
-- Дамп данных таблицы `photos`
--

INSERT INTO `photos` (`id`, `name`, `gallery_id`, `created_at`, `updated_at`) VALUES
(1, '1412239689_1293.png', 0, '2014-10-02 04:48:09', '2014-10-02 04:48:09'),
(2, '1412239705_1367.png', 0, '2014-10-02 04:48:25', '2014-10-02 04:48:25'),
(3, '1412239721_1122.png', 0, '2014-10-02 04:48:41', '2014-10-02 04:48:41'),
(4, '1412239737_1059.png', 0, '2014-10-02 04:48:57', '2014-10-02 04:48:57'),
(5, '1412239752_1941.png', 0, '2014-10-02 04:49:12', '2014-10-02 04:49:12'),
(6, '1412239767_1820.png', 0, '2014-10-02 04:49:27', '2014-10-02 04:49:27');

-- --------------------------------------------------------

--
-- Структура таблицы `rel_mod_gallery`
--

DROP TABLE IF EXISTS `rel_mod_gallery`;
CREATE TABLE IF NOT EXISTS `rel_mod_gallery` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `module` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `unit_id` int(10) unsigned DEFAULT '0',
  `gallery_id` int(10) unsigned DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `rel_mod_gallery_module_index` (`module`),
  KEY `unit_id` (`module`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `seo`
--

DROP TABLE IF EXISTS `seo`;
CREATE TABLE IF NOT EXISTS `seo` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `module` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `unit_id` int(10) unsigned DEFAULT NULL,
  `language` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `title` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `keywords` text COLLATE utf8_unicode_ci,
  `url` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `h1` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `unit_id` (`module`),
  KEY `seo_module_index` (`module`),
  KEY `seo_unit_id_index` (`unit_id`),
  KEY `seo_language_index` (`language`),
  KEY `seo_url_index` (`url`(255))
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=21 ;

--
-- Дамп данных таблицы `seo`
--

INSERT INTO `seo` (`id`, `module`, `unit_id`, `language`, `title`, `description`, `keywords`, `url`, `h1`, `created_at`, `updated_at`) VALUES
(1, 'page_meta', 1, NULL, 'Главная страница', '', '', '', '', '2014-09-25 06:44:13', '2014-09-25 06:44:24'),
(2, 'page_meta', 2, NULL, 'Оформление заявки', '', '', 'registration', '', '2014-09-25 06:45:04', '2014-09-25 06:45:04'),
(3, 'page_meta', 3, NULL, 'Каталог курсов', '', '', 'catalog', '', '2014-10-01 11:39:57', '2014-10-01 11:39:57'),
(4, 'page_meta', 4, NULL, 'Как это работает', '', '', 'how-it-works', '', '2014-10-07 06:48:57', '2014-10-07 06:48:57'),
(5, 'Page', 5, 'ru', 'Контакты', '', '', 'contacts', '', '2014-10-08 10:45:01', '2014-10-08 10:45:01'),
(11, 'Page', 1, 'ru', '', '', '', '', '', '2014-10-08 11:44:48', '2014-10-08 11:44:48'),
(12, 'Page', 6, 'ru', 'О портале', '', '', 'about', '', '2014-10-09 03:59:01', '2014-10-09 03:59:01'),
(19, 'news_meta', 1, NULL, '', '', '', '', '', '2014-10-22 11:19:45', '2014-10-22 11:19:45'),
(20, 'news_meta', 2, NULL, '', '', '', '', '', '2014-10-22 13:12:24', '2014-10-22 13:12:24');

-- --------------------------------------------------------

--
-- Структура таблицы `sessions`
--

DROP TABLE IF EXISTS `sessions`;
CREATE TABLE IF NOT EXISTS `sessions` (
  `id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `payload` text COLLATE utf8_unicode_ci NOT NULL,
  `last_activity` int(11) NOT NULL,
  UNIQUE KEY `sessions_id_unique` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `sessions`
--

INSERT INTO `sessions` (`id`, `payload`, `last_activity`) VALUES
('0b0e43c86df31e458cbcb2828e6b158ed7819007', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiTmYxTzhYTHNlcmx4U3ByVFNZZTRFdVJ4clRpZ21TY1J0M1B1SnlNeCI7czo1OiJmbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjIyOiJQSFBERUJVR0JBUl9TVEFDS19EQVRBIjthOjA6e31zOjk6Il9zZjJfbWV0YSI7YTozOntzOjE6InUiO2k6MTQxNDA2MzU5MztzOjE6ImMiO2k6MTQxNDA2Mjg3NTtzOjE6ImwiO3M6MToiMCI7fX0=', 1414063593),
('428259e825cb7139f4a79cf2ad4366d1cd31c1aa', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiY1BCaVZXOUh5MDVTemhXNW9lcGpmeXdDS0xWTzR5Z0JMZURsVW0yRSI7czoyMjoiUEhQREVCVUdCQVJfU1RBQ0tfREFUQSI7YTowOnt9czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MTQwNjA5Nzg7czoxOiJjIjtpOjE0MTQwNjA5Nzg7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1414060981),
('f7bb16b3af876c5f67daae51c856e859b0a32d6e', 'YTo1OntzOjY6Il90b2tlbiI7czo0MDoiV2hLSHRtUTk0c3hSQWs5eHNrWUlPUllSYTE2WFFuVDdLY29yZGtzTyI7czo1OiJmbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjM4OiJsb2dpbl84MmU1ZDJjNTZiZGQwODExMzE4ZjBjZjA3OGI3OGJmYyI7czoxOiIyIjtzOjIyOiJQSFBERUJVR0JBUl9TVEFDS19EQVRBIjthOjA6e31zOjk6Il9zZjJfbWV0YSI7YTozOntzOjE6InUiO2k6MTQxNDA2MzUwMjtzOjE6ImMiO2k6MTQxNDA2MDk1MTtzOjE6ImwiO3M6MToiMCI7fX0=', 1414063502);

-- --------------------------------------------------------

--
-- Структура таблицы `settings`
--

DROP TABLE IF EXISTS `settings`;
CREATE TABLE IF NOT EXISTS `settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `value` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `settings`
--

INSERT INTO `settings` (`id`, `name`, `value`, `created_at`, `updated_at`) VALUES
(1, 'language', 'ru', '2014-10-23 10:41:42', '2014-10-23 10:41:42');

-- --------------------------------------------------------

--
-- Структура таблицы `storages`
--

DROP TABLE IF EXISTS `storages`;
CREATE TABLE IF NOT EXISTS `storages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `value` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `module` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `module` (`module`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `tests`
--

DROP TABLE IF EXISTS `tests`;
CREATE TABLE IF NOT EXISTS `tests` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `course_id` int(10) unsigned DEFAULT NULL,
  `chapter_id` int(10) unsigned DEFAULT NULL,
  `order` int(10) unsigned DEFAULT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `active` int(10) unsigned DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `tests_course_id_index` (`course_id`),
  KEY `tests_chapter_id_index` (`chapter_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `tests_answers`
--

DROP TABLE IF EXISTS `tests_answers`;
CREATE TABLE IF NOT EXISTS `tests_answers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `test_id` int(10) unsigned DEFAULT NULL,
  `test_question_id` int(10) unsigned DEFAULT NULL,
  `order` int(10) unsigned DEFAULT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `correct` int(10) unsigned DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `tests_answers_test_id_index` (`test_id`),
  KEY `tests_answers_test_question_id_index` (`test_question_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `tests_questions`
--

DROP TABLE IF EXISTS `tests_questions`;
CREATE TABLE IF NOT EXISTS `tests_questions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `test_id` int(10) unsigned DEFAULT NULL,
  `order` int(10) unsigned DEFAULT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `tests_questions_test_id_index` (`test_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `uploads`
--

DROP TABLE IF EXISTS `uploads`;
CREATE TABLE IF NOT EXISTS `uploads` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `path` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `original_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `filesize` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mimetype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mime1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mime2` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `module` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `unit_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `uploads_mime1_index` (`mime1`),
  KEY `uploads_mime2_index` (`mime2`),
  KEY `uploads_module_index` (`module`),
  KEY `uploads_unit_id_index` (`unit_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `group_id` smallint(5) unsigned DEFAULT '0',
  `name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `surname` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `active` smallint(5) unsigned DEFAULT '0',
  `password` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `photo` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `thumbnail` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `temporary_code` varchar(25) COLLATE utf8_unicode_ci DEFAULT NULL,
  `code_life` bigint(20) DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `group_id`, `name`, `surname`, `email`, `active`, `password`, `photo`, `thumbnail`, `temporary_code`, `code_life`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 1, 'Администратор', '', 'admin@techvuz.ru', 1, '$2y$10$ONMkQ74BgGu..PahJ8UZs.FGWBPTQHTxzMLmnonsL6WI.QaNWzFkm', '', '', '', 0, 'eTIkFkM06wHMxAbuEYarqSgdMXZswknSR6MtRSNNBQljpP63tgt08kPAzkZx', '2014-10-23 10:41:42', '2014-10-23 11:24:16'),
(2, 3, 'Модератор', '', 'moder@techvuz.ru', 1, '$2y$10$yR5S6zbBQfAnyuo8ejj99uAjNzW2/y5VBtmYG6jE1/y/OJ5GDsLz2', '', '', '', 0, '51uKMDhsqtIIHfk4szGK0WjAN0jrl8ZtdPy0CheBML3zbMhaS3QzE2Xlj97l', '2014-10-23 10:41:42', '2014-10-23 11:26:28');

-- --------------------------------------------------------

--
-- Дублирующая структура для представления `users_individuals`
--
DROP VIEW IF EXISTS `users_individuals`;
CREATE TABLE IF NOT EXISTS `users_individuals` (
`id` int(10) unsigned
,`email` varchar(100)
,`active` smallint(5) unsigned
,`created_at` timestamp
,`individual_id` int(10) unsigned
,`fio` varchar(160)
,`position` varchar(100)
,`inn` varchar(40)
,`postaddress` varchar(255)
,`phone` varchar(40)
,`discount` tinyint(4)
,`moderator_approve` tinyint(1)
);
-- --------------------------------------------------------

--
-- Дублирующая структура для представления `users_listeners`
--
DROP VIEW IF EXISTS `users_listeners`;
CREATE TABLE IF NOT EXISTS `users_listeners` (
`id` int(10) unsigned
,`email` varchar(100)
,`active` smallint(5) unsigned
,`created_at` timestamp
,`listener_id` int(10) unsigned
,`organization_id` int(10) unsigned
,`fio` varchar(160)
,`position` varchar(100)
,`postaddress` varchar(255)
,`phone` varchar(40)
,`education` varchar(100)
,`place_work` varchar(100)
,`year_study` varchar(4)
,`specialty` varchar(100)
);
-- --------------------------------------------------------

--
-- Дублирующая структура для представления `users_organizations`
--
DROP VIEW IF EXISTS `users_organizations`;
CREATE TABLE IF NOT EXISTS `users_organizations` (
`id` int(10) unsigned
,`email` varchar(100)
,`active` smallint(5) unsigned
,`created_at` timestamp
,`organization_id` int(10) unsigned
,`title` varchar(255)
,`fio_manager` varchar(160)
,`manager` varchar(100)
,`statutory` varchar(160)
,`inn` varchar(40)
,`kpp` varchar(40)
,`postaddress` varchar(255)
,`account_type_id` smallint(5) unsigned
,`account_number` varchar(40)
,`bank` varchar(255)
,`bik` varchar(40)
,`name` varchar(100)
,`phone` varchar(40)
,`discount` tinyint(4)
,`moderator_approve` tinyint(1)
,`account_type` varchar(50)
);
-- --------------------------------------------------------

--
-- Структура таблицы `videos`
--

DROP TABLE IF EXISTS `videos`;
CREATE TABLE IF NOT EXISTS `videos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `embed` text COLLATE utf8_unicode_ci,
  `image_id` int(11) DEFAULT NULL,
  `module` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `unit_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `videos_module_index` (`module`),
  KEY `videos_unit_id_index` (`unit_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура для представления `users_individuals`
--
DROP TABLE IF EXISTS `users_individuals`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `users_individuals` AS select `users`.`id` AS `id`,`users`.`email` AS `email`,`users`.`active` AS `active`,`users`.`created_at` AS `created_at`,`individuals`.`id` AS `individual_id`,`individuals`.`fio` AS `fio`,`individuals`.`position` AS `position`,`individuals`.`inn` AS `inn`,`individuals`.`postaddress` AS `postaddress`,`individuals`.`phone` AS `phone`,`individuals`.`discount` AS `discount`,`individuals`.`moderator_approve` AS `moderator_approve` from (`users` left join `individuals` on((`users`.`id` = `individuals`.`user_id`))) where (`users`.`group_id` = 6);

-- --------------------------------------------------------

--
-- Структура для представления `users_listeners`
--
DROP TABLE IF EXISTS `users_listeners`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `users_listeners` AS select `users`.`id` AS `id`,`users`.`email` AS `email`,`users`.`active` AS `active`,`users`.`created_at` AS `created_at`,`listeners`.`id` AS `listener_id`,`listeners`.`organization_id` AS `organization_id`,`listeners`.`fio` AS `fio`,`listeners`.`position` AS `position`,`listeners`.`postaddress` AS `postaddress`,`listeners`.`phone` AS `phone`,`listeners`.`education` AS `education`,`listeners`.`place_work` AS `place_work`,`listeners`.`year_study` AS `year_study`,`listeners`.`specialty` AS `specialty` from (`listeners` left join `users` on((`users`.`id` = `listeners`.`user_id`))) where (`users`.`group_id` = 5);

-- --------------------------------------------------------

--
-- Структура для представления `users_organizations`
--
DROP TABLE IF EXISTS `users_organizations`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `users_organizations` AS select `users`.`id` AS `id`,`users`.`email` AS `email`,`users`.`active` AS `active`,`users`.`created_at` AS `created_at`,`organizations`.`id` AS `organization_id`,`organizations`.`title` AS `title`,`organizations`.`fio_manager` AS `fio_manager`,`organizations`.`manager` AS `manager`,`organizations`.`statutory` AS `statutory`,`organizations`.`inn` AS `inn`,`organizations`.`kpp` AS `kpp`,`organizations`.`postaddress` AS `postaddress`,`organizations`.`account_type` AS `account_type_id`,`organizations`.`account_number` AS `account_number`,`organizations`.`bank` AS `bank`,`organizations`.`bik` AS `bik`,`organizations`.`name` AS `name`,`organizations`.`phone` AS `phone`,`organizations`.`discount` AS `discount`,`organizations`.`moderator_approve` AS `moderator_approve`,`account_types`.`title` AS `account_type` from ((`organizations` left join `users` on((`users`.`id` = `organizations`.`user_id`))) join `account_types` on((`organizations`.`account_type` = `account_types`.`id`))) where (`users`.`group_id` = 4);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
