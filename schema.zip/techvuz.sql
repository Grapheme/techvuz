-- phpMyAdmin SQL Dump
-- version 3.4.10.1deb1
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Ноя 05 2014 г., 16:14
-- Версия сервера: 5.5.37
-- Версия PHP: 5.5.12-2+deb.sury.org~precise+1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `techvuz`
--

-- --------------------------------------------------------

--
-- Структура таблицы `account_types`
--

DROP TABLE IF EXISTS `account_types`;
CREATE TABLE IF NOT EXISTS `account_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=7 ;

--
-- Дамп данных таблицы `account_types`
--

INSERT INTO `account_types` (`id`, `title`, `created_at`, `updated_at`) VALUES
(1, 'Расчетный', '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(2, 'Валютный', '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(3, 'Текущий', '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(4, 'Временный', '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(5, 'Транзитный', '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(6, 'Депозитный', '2014-10-29 08:18:38', '2014-10-29 08:18:38');

-- --------------------------------------------------------

--
-- Структура таблицы `actions`
--

DROP TABLE IF EXISTS `actions`;
CREATE TABLE IF NOT EXISTS `actions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `group_id` int(10) unsigned DEFAULT NULL,
  `module` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `action` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `actions_group_id_index` (`group_id`),
  KEY `actions_module_index` (`module`),
  KEY `actions_action_index` (`action`),
  KEY `actions_status_index` (`status`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=27 ;

--
-- Дамп данных таблицы `actions`
--

INSERT INTO `actions` (`id`, `group_id`, `module`, `action`, `status`) VALUES
(1, 3, 'dictionaries', 'dicval_view', 1),
(2, 3, 'dictionaries', 'dicval_create', 1),
(3, 3, 'dictionaries', 'dicval_edit', 1),
(4, 3, 'dictionaries', 'dicval_delete', 1),
(5, 3, 'dictionaries', 'dicval_restore', 1),
(6, 3, 'dictionaries', 'dicval_entity_view', 1),
(7, 3, 'dictionaries', 'hidden', 1),
(8, 3, 'education', 'view', 1),
(9, 3, 'education', 'create', 1),
(10, 3, 'education', 'edit', 1),
(11, 3, 'education', 'delete', 1),
(12, 3, 'galleries', 'create', 1),
(13, 3, 'galleries', 'edit', 1),
(14, 3, 'galleries', 'delete', 1),
(15, 3, 'logging', 'logging', 1),
(16, 3, 'news', 'view', 1),
(17, 3, 'news', 'create', 1),
(18, 3, 'news', 'edit', 1),
(19, 3, 'news', 'delete', 1),
(20, 3, 'pages', 'view', 1),
(21, 3, 'pages', 'create', 1),
(22, 3, 'pages', 'edit', 1),
(23, 3, 'pages', 'delete', 1),
(24, 3, 'pages', 'advanced', 1),
(25, 3, 'pages', 'page_restore', 1),
(26, 3, 'seo', 'edit', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `chapters`
--

DROP TABLE IF EXISTS `chapters`;
CREATE TABLE IF NOT EXISTS `chapters` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `course_id` int(10) unsigned DEFAULT NULL,
  `order` int(10) unsigned DEFAULT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `hours` int(10) unsigned DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `chapters_course_id_index` (`course_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=50 ;

--
-- Дамп данных таблицы `chapters`
--

INSERT INTO `chapters` (`id`, `course_id`, `order`, `title`, `description`, `hours`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 'Общая часть программы', '', 28, '2014-10-29 12:15:25', '2014-10-29 12:15:25'),
(2, 1, 2, 'Специализированная часть программы', '', 30, '2014-10-29 12:19:50', '2014-10-29 12:19:50'),
(3, 1, 3, 'Региональная часть программы', '', 10, '2014-10-29 12:21:37', '2014-10-29 12:21:37'),
(4, 2, 1, 'Общая часть программы ', '', 28, '2014-10-29 12:34:09', '2014-10-29 12:34:09'),
(5, 2, 2, 'Специализированная часть программы', '', 30, '2014-10-29 12:36:33', '2014-10-29 12:36:33'),
(6, 2, 3, 'Региональная часть программы', '', 10, '2014-10-29 12:39:39', '2014-10-29 12:39:39'),
(7, 3, 1, 'Общая часть программы', '', 28, '2014-10-29 12:42:16', '2014-10-29 12:42:16'),
(8, 3, 2, 'Специализированная часть программы', '', 30, '2014-10-29 12:44:14', '2014-10-29 12:44:14'),
(9, 3, 3, 'Региональная часть программы', '', 10, '2014-10-29 12:46:07', '2014-10-29 12:46:07'),
(10, 4, 1, 'Общая часть программы', '', 28, '2014-10-29 12:54:35', '2014-10-29 12:55:14'),
(11, 4, 2, 'Специализированная часть программы', '', 30, '2014-10-29 12:58:16', '2014-10-29 12:58:16'),
(12, 4, 3, 'Региональная часть программы', '', 10, '2014-10-29 13:17:16', '2014-10-29 13:17:16'),
(13, 5, 1, 'Общая часть программы', '', 28, '2014-10-29 13:21:32', '2014-10-29 13:21:32'),
(14, 5, 2, 'Специализированная часть программы', '', 30, '2014-10-29 13:29:28', '2014-10-29 13:29:28'),
(15, 5, 3, 'Региональная часть программы', '', 10, '2014-10-29 13:32:00', '2014-10-29 13:32:00'),
(16, 6, 1, 'Общая часть программы', '', 28, '2014-10-29 13:38:50', '2014-10-29 13:38:50'),
(17, 6, 2, 'Специализированная часть программы', '', 30, '2014-10-29 13:41:26', '2014-10-29 13:41:26'),
(18, 6, 3, 'Региональная часть программы', '', 10, '2014-10-29 13:42:46', '2014-10-29 13:42:46'),
(19, 7, 1, 'Общая часть программы', '', 6, '2014-10-29 13:54:20', '2014-10-29 13:54:20'),
(20, 7, 2, 'Специализированная часть программы', '', 30, '2014-10-29 14:01:56', '2014-10-29 14:01:56'),
(21, 7, 3, 'Региональная часть программы', '', 10, '2014-10-29 14:03:19', '2014-10-29 14:03:19'),
(22, 8, 1, 'Общая часть программы', '', 28, '2014-10-29 14:06:22', '2014-10-29 14:06:22'),
(23, 8, 2, 'Специализированная часть программы', '', 30, '2014-10-29 14:18:23', '2014-10-29 14:18:23'),
(24, 8, 3, 'Региональная часть программы ', '', 10, '2014-10-29 14:20:39', '2014-10-29 14:20:39'),
(25, 9, 1, 'Общая часть программы', '', 28, '2014-10-29 14:24:28', '2014-10-29 14:24:28'),
(26, 9, 2, 'Специализированная часть программы', '', 30, '2014-10-29 14:28:27', '2014-10-29 14:28:27'),
(27, 9, 3, 'Региональная часть программы', '', 10, '2014-10-29 14:29:47', '2014-10-29 14:29:47'),
(28, 10, 1, 'Общая часть программы', '', 28, '2014-10-29 14:35:00', '2014-10-29 14:35:00'),
(29, 10, 2, 'Специализированная часть программы', '', 30, '2014-10-29 14:37:41', '2014-10-29 14:37:41'),
(30, 10, 3, 'Региональная часть программы', '', 10, '2014-10-29 14:39:54', '2014-10-29 14:39:54'),
(31, 11, 1, 'Общая часть программы', '', 28, '2014-10-29 14:50:54', '2014-10-29 14:50:54'),
(32, 11, 2, 'Специализированная часть программы', '', 30, '2014-10-29 15:12:53', '2014-10-29 15:12:53'),
(33, 11, 3, 'Региональная часть программы', '', 10, '2014-10-29 15:14:07', '2014-10-29 15:14:07'),
(34, 12, 1, 'Общая часть программы', '', 28, '2014-10-29 15:17:23', '2014-10-29 15:17:23'),
(35, 12, 2, 'Специализированная часть программы', '', 30, '2014-10-29 15:18:49', '2014-10-29 15:18:49'),
(36, 12, 3, 'Региональная часть программы', '', 10, '2014-10-29 15:20:03', '2014-10-29 15:20:03'),
(37, 13, 1, 'Общая часть программы', '', 28, '2014-10-29 15:22:09', '2014-10-29 15:22:09'),
(38, 13, 2, 'Специализированная часть программы', '', 30, '2014-10-29 15:23:35', '2014-10-29 15:23:35'),
(39, 13, 3, 'Региональная часть программы', '', 10, '2014-10-29 15:25:49', '2014-10-29 15:25:49'),
(40, 14, 1, 'Общая часть программы', '', 28, '2014-10-29 15:28:17', '2014-10-29 15:28:17'),
(41, 14, 2, 'Специализированная часть программы', '', 30, '2014-10-29 15:30:59', '2014-10-29 15:30:59'),
(42, 14, 3, 'Региональная часть программы', '', 10, '2014-10-29 15:32:23', '2014-10-29 15:32:23'),
(43, 15, 1, 'Общая часть программы', '', 28, '2014-10-29 15:34:51', '2014-10-29 15:34:51'),
(44, 15, 2, 'Специализированная часть программы', '', 30, '2014-10-29 15:36:43', '2014-10-29 15:36:43'),
(45, 15, 3, 'Региональная часть программы', '', 10, '2014-10-29 15:37:48', '2014-10-29 15:37:48'),
(46, 16, 1, 'Общая часть программы', '', 30, '2014-10-29 15:39:50', '2014-10-29 15:39:50'),
(47, 16, 2, 'Специализированная часть программы', '', 38, '2014-10-29 15:42:10', '2014-10-29 15:42:10'),
(48, 17, 1, 'Общая часть программы', '', 30, '2014-10-29 15:43:39', '2014-10-29 15:43:39'),
(49, 17, 2, 'Специализированная часть программы', '', 38, '2014-10-29 15:45:24', '2014-10-29 15:45:24');

-- --------------------------------------------------------

--
-- Структура таблицы `courses`
--

DROP TABLE IF EXISTS `courses`;
CREATE TABLE IF NOT EXISTS `courses` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `direction_id` int(10) unsigned DEFAULT NULL,
  `order` int(10) unsigned DEFAULT NULL,
  `code` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `curriculum` text COLLATE utf8_unicode_ci,
  `price` float(8,2) unsigned DEFAULT '0.00',
  `discount` tinyint(4) DEFAULT '0',
  `hours` int(10) unsigned DEFAULT '0',
  `metodical` int(10) unsigned DEFAULT '0',
  `certificate` int(10) unsigned DEFAULT '0',
  `active` tinyint(1) unsigned DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `courses_direction_id_index` (`direction_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=18 ;

--
-- Дамп данных таблицы `courses`
--

INSERT INTO `courses` (`id`, `direction_id`, `order`, `code`, `title`, `description`, `curriculum`, `price`, `discount`, `hours`, `metodical`, `certificate`, `active`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 'БС-00', 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства', '', '<p style="text-align: center;">\r\n	<strong>Учебный план <br>\r\n	</strong><strong style="background-color: initial;">дополнительной профессиональной программы</strong>\r\n</p>\r\n<p style="text-align: center;">\r\n	<strong>БС-00 «Строительство, реконструкция, капитальный ремонт объектов капитального строительства»</strong>\r\n</p>\r\n<table>\r\n<tbody>\r\n<tr>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			<strong>№№ п</strong>\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<h4 style="text-align: center;"><strong>Наименование учебных   модулей</strong></h4>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			<strong>Всего часов</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			            1\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			            2\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			            3\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			<strong>Общая часть программы   (28 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			            1\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			            Модуль   №1. Законодательное и нормативное правовое обеспечение строительства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			            6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			            2\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			            Модуль   №2. Организация инвестиционно-строительных процессов\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			            6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			            3\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			            Модуль   №3. Экономика строительного производства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			            6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			            4\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			            Модуль №4. Государственный строительный надзор и строительный контроль\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			            10\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			            Промежуточная аттестация знаний по модулям общей части программы\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			            2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			<strong>Специализированная   часть программы (30 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			            5\r\n		</p>\r\n	</td>\r\n	<td>\r\n		       Модуль №5. Инновации в технологии выполнения общестроительных работ. Показатели и критерии качества выполнения общестроительных работ\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			            24\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			            6\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			            Модуль   №6. Техника безопасности строительного производства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			            6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			<strong>Региональная часть   программы (10 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			            7\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			            Модуль   №7. Региональные особенности организации строительства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			            8\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			            8\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			            Модуль   №8. Особенности выполнения строительных работ в региональных условиях осуществления   строительства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			            2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			            Итоговая аттестация знаний по модулям   общей, специализированной и региональной частей программы\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			            2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			<strong>Итого</strong>\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			<strong>72</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n</tbody>\r\n</table>', 4000.00, 0, 72, NULL, 36, 1, '2014-10-29 12:08:46', '2014-10-31 13:10:59'),
(2, 1, 2, 'БС-01', 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (выполнение геодезических, подготовительных и земляных работ, устройства оснований и фундаментов)', '', '<p style="text-align: center;">\r\n	<strong>Учебный план <br>\r\n	</strong><strong style="background-color: initial;">дополнительной профессиональной программы</strong>\r\n</p>\r\n<p style="text-align: center;">\r\n	<strong>БС-01 «Строительство, реконструкция, капитальный ремонт объектов капитального строительства (выполнение геодезических, подготовительных и земляных работ, устройства оснований и фундаментов)»</strong>\r\n</p>\r\n<table>\r\n<tbody>\r\n<tr>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			<strong>№№ п</strong>\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<h4 style="text-align: center;"><strong>Наименование учебных   модулей</strong></h4>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			<strong>Всего часов</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              1\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              3\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			<strong>Общая часть программы   (28 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              1\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №1. Законодательное и нормативное правовое обеспечение строительства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              2\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №2. Организация инвестиционно-строительных процессов\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              3\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №3. Экономика строительного производства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              4\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль №4. Государственный строительный надзор и строительный контроль\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              10\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			              Промежуточная аттестация знаний по модулям общей части программы\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			<strong>Специализированная   часть программы (30 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              5\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			Модуль №5. Инновации в технологии геодезических, подготовительных и земляных работ, устройства оснований и фундаментов. Показатели и критерии качества выполнения геодезических, подготовительных и земляных работ, устройства оснований и фундаментов\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              24\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              6\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №6. Техника безопасности строительного производства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			<strong>Региональная часть   программы (10 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              7\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №7. Региональные особенности организации строительства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              8\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              8\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №8. Особенности выполнения строительных работ в региональных условиях осуществления   строительства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			              Итоговая аттестация знаний по модулям   общей, специализированной и региональной частей программы\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			<strong>Итого</strong>\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			<strong>72</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n</tbody>\r\n</table>', 4000.00, 0, 72, NULL, 36, 1, '2014-10-29 12:33:23', '2014-10-31 14:51:25'),
(3, 1, 3, 'БС-02', 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (возведение бетонных и железобетонных конструкций)', '', '<p style="text-align: center;">\r\n	<strong>Учебный план <br>\r\n	</strong><strong style="background-color: initial;">дополнительной профессиональной программы</strong>\r\n</p>\r\n<p style="text-align: center;">\r\n	<strong>БС-02 «Строительство, реконструкция, капитальный ремонт объектов капитального строительства (возведение бетонных и железобетонных конструкций)»</strong>\r\n</p>\r\n<table>\r\n<tbody>\r\n<tr>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			<strong>№№ п</strong>\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<h4 style="text-align: center;"><strong>Наименование учебных   модулей</strong></h4>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			<strong>Всего часов</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              1\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              3\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			<strong>Общая часть программы   (28 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              1\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №1. Законодательное и нормативное правовое обеспечение строительства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              2\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №2. Организация инвестиционно-строительных процессов\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              3\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №3. Экономика строительного производства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              4\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль №4. Государственный строительный надзор и строительный контроль\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              10\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			              Промежуточная аттестация знаний по модулям общей части программы\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			<strong>Специализированная   часть программы (30 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              5\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			Модуль №5. Инновации в технологии возведения бетонных и железобетонных конструкций. Показатели и критерии качества возведения бетонных и железобетонных конструкций\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              24\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              6\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №6. Техника безопасности строительного производства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			<strong>Региональная часть   программы (10 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              7\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №7. Региональные особенности организации строительства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              8\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              8\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №8. Особенности выполнения строительных работ в региональных условиях осуществления   строительства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			              Итоговая аттестация знаний по модулям   общей, специализированной и региональной частей программы\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			<strong>Итого</strong>\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			<strong>72</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n</tbody>\r\n</table>', 4000.00, 0, 72, NULL, 36, 1, '2014-10-29 12:41:37', '2014-10-31 15:00:45'),
(4, 1, 4, 'БС-03', 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (возведение каменных, металлических и деревянных строительных конструкций)', '', '<p style="text-align: center;">\r\n	 <strong>Учебный план <br>\r\n	 </strong><strong style="background-color: initial;">дополнительной профессиональной программы</strong>\r\n</p>\r\n<p style="text-align: center;">\r\n	 <strong>БС-03 «Строительство, реконструкция, капитальный ремонт объектов капитального строительства (возведение каменных, металлических и деревянных строительных конструкций)»</strong>\r\n</p>\r\n<table>\r\n<tbody>\r\n<tr>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			 <strong>№№ п</strong>\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<h4 style="text-align: center;"><strong>Наименование учебных   модулей</strong></h4>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			 <strong>Всего часов</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			               1\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			               2\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			               3\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			 <strong>Общая часть программы   (28 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			               1\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			               Модуль   №1. Законодательное и нормативное правовое обеспечение строительства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			               6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			               2\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			               Модуль   №2. Организация инвестиционно-строительных процессов\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			               6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			               3\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			               Модуль   №3. Экономика строительного производства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			               6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			               4\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			               Модуль №4. Государственный строительный надзор и строительный контроль\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			               10\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			               Промежуточная аттестация знаний по модулям общей части программы\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			               2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			 <strong>Специализированная   часть программы (30 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			               5\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			 Модуль №5. Инновации в технологии возведения каменных, металлических и деревянных строительных конструкций. Показатели и критерии качества возведения каменных, металлических и деревянных строительных конструкций\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			               24\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			               6\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			               Модуль   №6. Техника безопасности строительного производства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			               6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			 <strong>Региональная часть   программы (10 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			               7\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			               Модуль   №7. Региональные особенности организации строительства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			               8\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			               8\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			               Модуль   №8. Особенности выполнения строительных работ в региональных условиях осуществления   строительства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			               2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			               Итоговая аттестация знаний по модулям   общей, специализированной и региональной частей программы\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			               2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			 <strong>Итого</strong>\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			 <strong>72</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n</tbody>\r\n</table>', 4000.00, 0, 72, NULL, 36, 1, '2014-10-29 12:48:42', '2014-10-31 15:03:21'),
(5, 1, 5, 'БС-04', 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (выполнение фасадных работ, устройство кровель, защита строительных конструкций, трубопроводов и оборудования)', '', '<p style="text-align: center;">\r\n	<strong>Учебный план <br>\r\n	</strong><strong style="background-color: initial;">дополнительной профессиональной программы</strong>\r\n</p>\r\n<p style="text-align: center;">\r\n	<strong>БС-04 «Строительство, реконструкция, капитальный ремонт объектов капитального строительства (выполнение фасадных работ, устройство кровель, защита строительных конструкций, трубопроводов и оборудования)»</strong>\r\n</p>\r\n<table>\r\n<tbody>\r\n<tr>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			<strong>№№ п</strong>\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<h4 style="text-align: center;"><strong>Наименование учебных   модулей</strong></h4>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			<strong>Всего часов</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              1\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              3\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			<strong>Общая часть программы   (28 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              1\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №1. Законодательное и нормативное правовое обеспечение строительства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              2\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №2. Организация инвестиционно-строительных процессов\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              3\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №3. Экономика строительного производства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              4\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль №4. Государственный строительный надзор и строительный контроль\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              10\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			              Промежуточная аттестация знаний по модулям общей части программы\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			<strong>Специализированная   часть программы (30 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              5\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			Модуль №5. Инновации в технологии обеспечения качества выполнения фасадных работ, устройства кровель, защиты строительных конструкций, трубопроводов и оборудования. Показатели и критерии качества выполнения фасадных работ, устройства кровель, защиты строительных конструкций, трубопроводов и оборудования\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              24\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              6\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №6. Техника безопасности строительного производства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			<strong>Региональная часть   программы (10 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              7\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №7. Региональные особенности организации строительства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              8\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              8\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №8. Особенности выполнения строительных работ в региональных условиях осуществления   строительства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			              Итоговая аттестация знаний по модулям   общей, специализированной и региональной частей программы\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			<strong>Итого</strong>\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			<strong>72</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n</tbody>\r\n</table>', 4000.00, 0, 72, NULL, 36, 1, '2014-10-29 13:20:47', '2014-10-31 15:12:20'),
(6, 1, 6, 'БС-05', 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (устройство инженерных систем и сетей)', '', '<p style="text-align: center;">\r\n	<strong>Учебный план <br>\r\n	</strong><strong style="background-color: initial;">дополнительной профессиональной программы</strong>\r\n</p>\r\n<p style="text-align: center;">\r\n	<strong>БС-05 «Строительство, реконструкция, капитальный ремонт объектов капитального строительства (устройство инженерных систем и сетей)»</strong>\r\n</p>\r\n<table>\r\n<tbody>\r\n<tr>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			<strong>№№ п</strong>\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<h4 style="text-align: center;"><strong>Наименование учебных   модулей</strong></h4>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			<strong>Всего часов</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              1\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              3\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			<strong>Общая часть программы   (28 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              1\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №1. Законодательное и нормативное правовое обеспечение строительства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              2\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №2. Организация инвестиционно-строительных процессов\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              3\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №3. Экономика строительного производства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              4\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль №4. Государственный строительный надзор и строительный контроль\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              10\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			              Промежуточная аттестация знаний по модулям общей части программы\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			<strong>Специализированная   часть программы (30 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              5\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			Модуль №5. Инновации в технологии устройства инженерных систем и сетей. Показатели и критерии качества устройства инженерных систем и сетей\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              24\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              6\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №6. Техника безопасности строительного производства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			<strong>Региональная часть   программы (10 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              7\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №7. Региональные особенности организации строительства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              8\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              8\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №8. Особенности выполнения строительных работ в региональных условиях осуществления   строительства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			              Итоговая аттестация знаний по модулям   общей, специализированной и региональной частей программы\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			<strong>Итого</strong>\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			<strong>72</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n</tbody>\r\n</table>', 4000.00, 0, 72, NULL, 36, 1, '2014-10-29 13:38:24', '2014-10-31 15:14:06'),
(7, 1, 7, 'БС-06', 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (устройство электрических сетей и линий связи)', '', '<p style="text-align: center;">\r\n	<strong>Учебный план <br>\r\n	</strong><strong style="background-color: initial;">дополнительной профессиональной программы</strong>\r\n</p>\r\n<p style="text-align: center;">\r\n	<strong>БС-06 «Строительство, реконструкция, капитальный ремонт объектов капитального строительства (устройство электрических сетей и линий связи)»</strong>\r\n</p>\r\n<table>\r\n<tbody>\r\n<tr>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			<strong>№№ п</strong>\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<h4 style="text-align: center;"><strong>Наименование учебных   модулей</strong></h4>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			<strong>Всего часов</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              1\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              3\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			<strong>Общая часть программы   (28 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              1\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №1. Законодательное и нормативное правовое обеспечение строительства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              2\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №2. Организация инвестиционно-строительных процессов\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              3\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №3. Экономика строительного производства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              4\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль №4. Государственный строительный надзор и строительный контроль\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              10\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			              Промежуточная аттестация знаний по модулям общей части программы\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			<strong>Специализированная   часть программы (30 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              5\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			Модуль №5. Инновации в технологии устройства электрических сетей и линий связи. Показатели и критерии качества устройства электрических сетей и линий связи\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              24\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              6\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №6. Техника безопасности строительного производства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			<strong>Региональная часть   программы (10 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              7\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №7. Региональные особенности организации строительства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              8\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              8\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №8. Особенности выполнения строительных работ в региональных условиях осуществления   строительства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			              Итоговая аттестация знаний по модулям   общей, специализированной и региональной частей программы\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			<strong>Итого</strong>\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			<strong>72</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n</tbody>\r\n</table>', 4000.00, 0, 72, NULL, 36, 1, '2014-10-29 13:45:11', '2014-10-31 15:15:43'),
(8, 1, 8, 'БС-07', 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (устройство объектов нефтяной и газовой промышленности, устройство скважин)', '', '<p style="text-align: center;">\r\n	<strong>Учебный план <br>\r\n	</strong><strong style="background-color: initial;">дополнительной профессиональной программы</strong>\r\n</p>\r\n<p style="text-align: center;">\r\n	<strong>БС-07 «Строительство, реконструкция, капитальный ремонт объектов капитального строительства (устройство объектов нефтяной и газовой промышленности, устройство скважин)»</strong>\r\n</p>\r\n<table>\r\n<tbody>\r\n<tr>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			<strong>№№ п</strong>\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<h4 style="text-align: center;"><strong>Наименование учебных   модулей</strong></h4>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			<strong>Всего часов</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              1\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              3\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			<strong>Общая часть программы   (28 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              1\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №1. Законодательное и нормативное правовое обеспечение строительства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              2\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №2. Организация инвестиционно-строительных процессов\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              3\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №3. Экономика строительного производства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              4\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль №4. Государственный строительный надзор и строительный контроль\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              10\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			              Промежуточная аттестация знаний по модулям общей части программы\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			<strong>Специализированная   часть программы (30 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              5\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			Модуль №5. Инновации в технологии устройства объектов нефтяной и газовой промышленности, устройства скважин. Показатели и критерии качества устройства объектов нефтяной и газовой промышленности, устройства скважин\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              24\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              6\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №6. Техника безопасности строительного производства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			<strong>Региональная часть   программы (10 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              7\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №7. Региональные особенности организации строительства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              8\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              8\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №8. Особенности выполнения строительных работ в региональных условиях осуществления   строительства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			              Итоговая аттестация знаний по модулям   общей, специализированной и региональной частей программы\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			<strong>Итого</strong>\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			<strong>72</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n</tbody>\r\n</table>', 4000.00, 0, 72, NULL, 36, 1, '2014-10-29 14:05:57', '2014-10-31 15:17:27');
INSERT INTO `courses` (`id`, `direction_id`, `order`, `code`, `title`, `description`, `curriculum`, `price`, `discount`, `hours`, `metodical`, `certificate`, `active`, `created_at`, `updated_at`) VALUES
(9, 1, 9, 'БС-08', 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (выполнение монтажных и пусконаладочных работ)', '', '<p style="text-align: center;">\r\n	 <strong>Учебный план <br>\r\n	 </strong><strong style="background-color: initial;">дополнительной профессиональной программы</strong>\r\n</p>\r\n<p style="text-align: center;">\r\n	 <strong>БС-08 «Строительство, реконструкция, капитальный ремонт объектов капитального строительства (выполнение монтажных и пусконаладочных работ)»</strong>\r\n</p>\r\n<table>\r\n<tbody>\r\n<tr>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			 <strong>№№ п</strong>\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<h4 style="text-align: center;"><strong>Наименование учебных   модулей</strong></h4>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			 <strong>Всего часов</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			               1\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			               2\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			               3\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			 <strong>Общая часть программы   (28 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			               1\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			               Модуль   №1. Законодательное и нормативное правовое обеспечение строительства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			               6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			               2\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			               Модуль   №2. Организация инвестиционно-строительных процессов\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			               6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			               3\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			               Модуль   №3. Экономика строительного производства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			               6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			               4\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			               Модуль №4. Государственный строительный надзор и строительный контроль\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			               10\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			               Промежуточная аттестация знаний по модулям общей части программы\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			               2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			 <strong>Специализированная   часть программы (30 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			               5\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			 Модуль №5. Инновации в технологии выполнения монтажных и пусконаладочных работ лифтового оборудования. Показатели и критерии качества выполнения монтажных и пусконаладочных работ лифтового оборудования\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			               24\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			               6\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			               Модуль   №6. Техника безопасности строительного производства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			               6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			 <strong>Региональная часть   программы (10 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			               7\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			               Модуль   №7. Региональные особенности организации строительства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			               8\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			               8\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			               Модуль   №8. Особенности выполнения строительных работ в региональных условиях осуществления   строительства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			               2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			               Итоговая аттестация знаний по модулям   общей, специализированной и региональной частей программы\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			               2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			 <strong>Итого</strong>\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			 <strong>72</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n</tbody>\r\n</table>', 4000.00, 0, 72, NULL, 36, 1, '2014-10-29 14:23:31', '2014-10-31 15:22:43'),
(10, 1, 10, 'БС-09', 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (устройство автомобильных дорог и аэродромов)', '', '<p style="text-align: center;">\r\n	<strong>Учебный план <br>\r\n	</strong><strong style="background-color: initial;">дополнительной профессиональной программы</strong>\r\n</p>\r\n<p style="text-align: center;">\r\n	<strong>БС-09 «Строительство, реконструкция, капитальный ремонт объектов капитального строительства (устройство автомобильных дорог и аэродромов)»</strong>\r\n</p>\r\n<table>\r\n<tbody>\r\n<tr>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			<strong>№№ п</strong>\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<h4 style="text-align: center;"><strong>Наименование учебных   модулей</strong></h4>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			<strong>Всего часов</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              1\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              3\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			<strong>Общая часть программы   (28 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              1\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №1. Законодательное и нормативное правовое обеспечение строительства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              2\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №2. Организация инвестиционно-строительных процессов\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              3\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №3. Экономика строительного производства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              4\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль №4. Государственный строительный надзор и строительный контроль\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              10\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			              Промежуточная аттестация знаний по модулям общей части программы\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			<strong>Специализированная   часть программы (30 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              5\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			Модуль №5. Инновации в технологии устройства автомобильных дорог и аэродромов. Показатели и критерии качества устройства автомобильных дорог и аэродромов\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              24\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              6\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №6. Техника безопасности строительного производства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			<strong>Региональная часть   программы (10 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              7\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №7. Региональные особенности организации строительства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              8\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              8\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №8. Особенности выполнения строительных работ в региональных условиях осуществления   строительства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			              Итоговая аттестация знаний по модулям   общей, специализированной и региональной частей программы\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			<strong>Итого</strong>\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			<strong>72</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n</tbody>\r\n</table>', 4000.00, 0, 72, NULL, 36, 1, '2014-10-29 14:32:22', '2014-10-31 15:24:31'),
(11, 1, 11, 'БС-10', 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (устройство железнодорожных и трамвайных путей)', '', '<p style="text-align: center;">\r\n	<strong>Учебный план <br>\r\n	</strong><strong style="background-color: initial;">дополнительной профессиональной программы</strong>\r\n</p>\r\n<p style="text-align: center;">\r\n	<strong>БС-10 «Строительство, реконструкция, капитальный ремонт объектов капитального строительства (устройство железнодорожных и трамвайных путей)»</strong>\r\n</p>\r\n<table>\r\n<tbody>\r\n<tr>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			<strong>№№ п</strong>\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<h4 style="text-align: center;"><strong>Наименование учебных   модулей</strong></h4>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			<strong>Всего часов</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              1\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              3\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			<strong>Общая часть программы   (28 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              1\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №1. Законодательное и нормативное правовое обеспечение строительства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              2\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №2. Организация инвестиционно-строительных процессов\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              3\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №3. Экономика строительного производства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              4\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль №4. Государственный строительный надзор и строительный контроль\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              10\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			              Промежуточная аттестация знаний по модулям общей части программы\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			<strong>Специализированная   часть программы (30 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              5\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			Модуль №5. Инновации в технологии устройства железнодорожных и трамвайных путей. Показатели и критерии качества устройства железнодорожных и трамвайных путей\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              24\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              6\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №6. Техника безопасности строительного производства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			<strong>Региональная часть   программы (10 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              7\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №7. Региональные особенности организации строительства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              8\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              8\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №8. Особенности выполнения строительных работ в региональных условиях осуществления   строительства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			              Итоговая аттестация знаний по модулям   общей, специализированной и региональной частей программы\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			<strong>Итого</strong>\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			<strong>72</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n</tbody>\r\n</table>', 4000.00, 0, 72, NULL, 36, 1, '2014-10-29 14:43:57', '2014-10-31 15:26:10'),
(12, 1, 12, 'БС-11', 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (устройство подземных сооружений, осуществление специальных земляных и буровзрывных работ при строительстве)', '', '<p style="text-align: center;">\r\n	<strong>Учебный план <br>\r\n	</strong><strong style="background-color: initial;">дополнительной профессиональной программы</strong>\r\n</p>\r\n<p style="text-align: center;">\r\n	<strong>БС-11 «Строительство, реконструкция, капитальный ремонт объектов капитального строительства (устройство подземных сооружений, осуществление специальных земляных и буровзрывных работ при строительстве)»</strong>\r\n</p>\r\n<table>\r\n<tbody>\r\n<tr>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			<strong>№№ п</strong>\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<h4 style="text-align: center;"><strong>Наименование учебных   модулей</strong></h4>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			<strong>Всего часов</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              1\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              3\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			<strong>Общая часть программы   (28 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              1\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №1. Законодательное и нормативное правовое обеспечение строительства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              2\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №2. Организация инвестиционно-строительных процессов\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              3\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №3. Экономика строительного производства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              4\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль №4. Государственный строительный надзор и строительный контроль\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              10\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			              Промежуточная аттестация знаний по модулям общей части программы\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			<strong>Специализированная   часть программы (30 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              5\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			Модуль №5. Инновации в технологии устройства подземных сооружений, осуществления специальных земляных и буровзрывных работ при строительстве. Показатели и критерии качества устройства подземных сооружений, осуществления специальных земляных и буровзрывных работ при строительстве\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              24\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              6\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №6. Техника безопасности строительного производства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			<strong>Региональная часть   программы (10 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              7\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №7. Региональные особенности организации строительства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              8\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              8\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №8. Особенности выполнения строительных работ в региональных условиях осуществления   строительства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			              Итоговая аттестация знаний по модулям   общей, специализированной и региональной частей программы\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			<strong>Итого</strong>\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			<strong>72</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n</tbody>\r\n</table>', 4000.00, 0, 72, NULL, 36, 1, '2014-10-29 15:16:51', '2014-10-31 15:35:59'),
(13, 1, 13, 'БС-12', 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (устройство мостов, эстакад и путепроводов)', '', '<p style="text-align: center;">\r\n	<strong>Учебный план <br>\r\n	</strong><strong style="background-color: initial;">дополнительной профессиональной программы</strong>\r\n</p>\r\n<p style="text-align: center;">\r\n	<strong>БС-12 «Строительство, реконструкция, капитальный ремонт объектов капитального строительства (устройство мостов, эстакад и путепроводов)»</strong>\r\n</p>\r\n<table>\r\n<tbody>\r\n<tr>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			<strong>№№ п</strong>\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<h4 style="text-align: center;"><strong>Наименование учебных   модулей</strong></h4>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			<strong>Всего часов</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              1\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              3\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			<strong>Общая часть программы   (28 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              1\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №1. Законодательное и нормативное правовое обеспечение строительства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              2\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №2. Организация инвестиционно-строительных процессов\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              3\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №3. Экономика строительного производства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              4\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль №4. Государственный строительный надзор и строительный контроль\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              10\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			              Промежуточная аттестация знаний по модулям общей части программы\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			<strong>Специализированная   часть программы (30 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              5\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			Модуль №5. Инновации в технологии устройства мостов, эстакад, путепроводов. Показатели и критерии качества устройства мостов, эстакад, путепроводов\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              24\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              6\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №6. Техника безопасности строительного производства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			<strong>Региональная часть   программы (10 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              7\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №7. Региональные особенности организации строительства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              8\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              8\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №8. Особенности выполнения строительных работ в региональных условиях осуществления   строительства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			              Итоговая аттестация знаний по модулям   общей, специализированной и региональной частей программы\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			<strong>Итого</strong>\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			<strong>72</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n</tbody>\r\n</table>', 4000.00, 0, 72, NULL, 36, 1, '2014-10-29 15:21:49', '2014-10-31 15:37:20'),
(14, 1, 14, 'БС-13', 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (выполнение гидротехнических, водолазных работ)', '', '<p style="text-align: center;">\r\n	<strong>Учебный план <br>\r\n	</strong><strong style="background-color: initial;">дополнительной профессиональной программы</strong>\r\n</p>\r\n<p style="text-align: center;">\r\n	<strong>БС-13 «Строительство, реконструкция, капитальный ремонт объектов капитального строительства (выполнение гидротехнических, водолазных работ)»</strong>\r\n</p>\r\n<table>\r\n<tbody>\r\n<tr>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			<strong>№№ п</strong>\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<h4 style="text-align: center;"><strong>Наименование учебных   модулей</strong></h4>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			<strong>Всего часов</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              1\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              3\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			<strong>Общая часть программы   (28 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              1\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №1. Законодательное и нормативное правовое обеспечение строительства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              2\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №2. Организация инвестиционно-строительных процессов\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              3\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №3. Экономика строительного производства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              4\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль №4. Государственный строительный надзор и строительный контроль\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              10\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			              Промежуточная аттестация знаний по модулям общей части программы\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			<strong>Специализированная   часть программы (30 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              5\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			Модуль №5. Инновации в технологии выполнения гидротехнических и водолазных работ. Показатели и критерии качества выполнения гидротехнических и водолазных работ\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              24\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              6\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №6. Техника безопасности строительного производства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			<strong>Региональная часть   программы (10 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              7\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №7. Региональные особенности организации строительства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              8\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              8\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №8. Особенности выполнения строительных работ в региональных условиях осуществления   строительства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			              Итоговая аттестация знаний по модулям   общей, специализированной и региональной частей программы\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			<strong>Итого</strong>\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			<strong>72</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n</tbody>\r\n</table>', 4000.00, 0, 72, NULL, 36, 1, '2014-10-29 15:27:53', '2014-10-31 15:39:09'),
(15, 1, 15, 'БС-14', 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (устройство промышленных печей и дымовых труб)', '', '<p style="text-align: center;">\r\n	<strong>Учебный план <br>\r\n	</strong><strong style="background-color: initial;">дополнительной профессиональной программы</strong>\r\n</p>\r\n<p style="text-align: center;">\r\n	<strong>БС-14 «Строительство, реконструкция, капитальный ремонт объектов капитального строительства (устройство промышленных печей и дымовых труб)»</strong>\r\n</p>\r\n<table>\r\n<tbody>\r\n<tr>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			<strong>№№ п</strong>\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<h4 style="text-align: center;"><strong>Наименование учебных   модулей</strong></h4>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			<strong>Всего часов</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              1\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              3\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			<strong>Общая часть программы   (28 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              1\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №1. Законодательное и нормативное правовое обеспечение строительства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              2\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №2. Организация инвестиционно-строительных процессов\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              3\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №3. Экономика строительного производства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              4\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль №4. Государственный строительный надзор и строительный контроль\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              10\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			              Промежуточная аттестация знаний по модулям общей части программы\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			<strong>Специализированная   часть программы (30 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              5\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			Модуль №5. Инновации в технологии устройства промышленных печей и домовых труб. Показатели и критерии качества устройства промышленных печей и дымовых труб\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              24\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              6\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №6. Техника безопасности строительного производства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			<strong>Региональная часть   программы (10 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              7\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №7. Региональные особенности организации строительства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              8\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              8\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №8. Особенности выполнения строительных работ в региональных условиях осуществления   строительства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			              Итоговая аттестация знаний по модулям   общей, специализированной и региональной частей программы\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			<strong>Итого</strong>\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			<strong>72</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n</tbody>\r\n</table>', 4000.00, 0, 72, NULL, 36, 1, '2014-10-29 15:34:16', '2014-10-31 15:46:56'),
(16, 1, 16, 'БС-15', 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (осуществление строительного контроля)', '', '<p style="text-align: center;">\r\n	<strong>Учебный план <br>\r\n	</strong><strong style="background-color: initial;">дополнительной профессиональной программы</strong>\r\n</p>\r\n<p style="text-align: center;">\r\n	<strong>БС-15 «Строительство, реконструкция, капитальный ремонт объектов капитального строительства (осуществление строительного контроля)»</strong>\r\n</p>\r\n<table>\r\n<tbody>\r\n<tr>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			<strong>№№ п</strong>\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<h4 style="text-align: center;"><strong>Наименование учебных   модулей</strong></h4>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			<strong>Всего часов</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              1\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              3\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			<strong>Общая часть программы   (30 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              1\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №1. Законодательное и нормативное правовое обеспечение строительства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              2\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №2. Организация инвестиционно-строительных процессов\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              3\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №3. Экономика строительного производства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              4\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль №4. Техника безопасности строительного производства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		5\r\n	</td>\r\n	<td>\r\n		Модуль №5. Региональные особенности организации строительства\r\n	</td>\r\n	<td>\r\n		6\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			              Промежуточная аттестация знаний по модулям общей части программы\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			<strong>Специализированная   часть программы (38 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<span style="background-color: initial;">5</span>\r\n	</td>\r\n	<td>\r\n		         Модуль №6. Осуществление строительного контроля\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			38\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			              Итоговая аттестация знаний по модулям   общей, специализированной и региональной частей программы\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			<strong>Итого</strong>\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			<strong>72</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n</tbody>\r\n</table>', 4000.00, 0, 72, NULL, 36, 1, '2014-10-29 15:39:26', '2014-10-31 16:30:00');
INSERT INTO `courses` (`id`, `direction_id`, `order`, `code`, `title`, `description`, `curriculum`, `price`, `discount`, `hours`, `metodical`, `certificate`, `active`, `created_at`, `updated_at`) VALUES
(17, 1, 17, 'БС-16', 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (организация строительства)', '', '<p style="text-align: center;">\r\n	<strong>Учебный план <br>\r\n	</strong><strong style="background-color: initial;">дополнительной профессиональной программы</strong>\r\n</p>\r\n<p style="text-align: center;">\r\n	<strong>БС-16 «Строительство, реконструкция, капитальный ремонт объектов капитального строительства (организация строительства)»</strong>\r\n</p>\r\n<table>\r\n<tbody>\r\n<tr>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			<strong>№№ п</strong>\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<h4 style="text-align: center;"><strong>Наименование учебных   модулей</strong></h4>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			<strong>Всего часов</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              1\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              3\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			<strong>Общая часть программы   (30 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              1\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №1. Законодательное и нормативное правовое обеспечение строительства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              2\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №2. <span style="background-color: initial;">Экономика строительного производства</span>\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              3\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №3. <span style="background-color: initial;">Государственный с</span><span style="background-color: initial;">троительный надзор и строительный контроль</span>\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              4\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль №4. <span style="background-color: initial;">Техника безопасности строительного производства</span>\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		5\r\n	</td>\r\n	<td>\r\n		<span style="background-color: initial;">Модуль №5. Региональные особенности организации строительства</span>\r\n	</td>\r\n	<td>\r\n		6\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			              Промежуточная аттестация знаний по модулям общей части программы\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			<strong>Специализированная   часть программы (38 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			6\r\n		</p>\r\n	</td>\r\n	<td>\r\n		         Модуль №6. Организация строительства\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			38\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			              Итоговая аттестация знаний по модулям   общей, специализированной и региональной частей программы\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			<strong>Итого</strong>\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			<strong>72</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n</tbody>\r\n</table>', 4000.00, 0, 72, NULL, 36, 1, '2014-10-29 15:43:16', '2014-10-31 16:33:50');

-- --------------------------------------------------------

--
-- Структура таблицы `dictionary`
--

DROP TABLE IF EXISTS `dictionary`;
CREATE TABLE IF NOT EXISTS `dictionary` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entity` tinyint(1) unsigned DEFAULT NULL,
  `icon_class` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `hide_slug` tinyint(1) unsigned DEFAULT NULL,
  `make_slug_from_name` tinyint(1) unsigned DEFAULT NULL,
  `name_title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pagination` int(10) unsigned NOT NULL DEFAULT '0',
  `view_access` smallint(5) unsigned DEFAULT NULL,
  `sort_by` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sort_order_reverse` smallint(5) unsigned NOT NULL DEFAULT '0',
  `sortable` smallint(5) unsigned NOT NULL DEFAULT '1',
  `order` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `dictionary_slug_unique` (`slug`),
  KEY `dictionary_name_index` (`name`),
  KEY `dictionary_entity_index` (`entity`),
  KEY `dictionary_view_access_index` (`view_access`),
  KEY `dictionary_order_index` (`order`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=9 ;

--
-- Дамп данных таблицы `dictionary`
--

INSERT INTO `dictionary` (`id`, `slug`, `name`, `entity`, `icon_class`, `hide_slug`, `make_slug_from_name`, `name_title`, `pagination`, `view_access`, `sort_by`, `sort_order_reverse`, `sortable`, `order`, `created_at`, `updated_at`) VALUES
(1, 'actions-types', 'Типы событий', 1, 'fa-bolt', 1, 1, 'Название типа события', 0, 1, NULL, 0, 1, 0, '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(2, 'actions-history', 'История событий', 1, 'fa-bell', 1, 1, '', 30, 1, 'created_at', 1, 0, 0, '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(3, 'reviews', 'Отзывы', 1, 'fa-comments-o', 1, 1, 'Имя пользователя оставившего отзыв', 30, 0, 'created_at', 1, 1, 0, '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(4, 'information-baners', 'Инф.банеры', 1, 'fa-info', 1, 1, 'Название банера', 30, 0, 'created_at', 1, 1, 0, '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(5, 'properties-site', 'Настройка сайта', 1, 'fa-wrench', 1, 1, 'Название свойства', 0, 1, NULL, 0, 0, 0, '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(6, 'order-documents', 'Документы', 1, 'fa-clipboard', 1, 1, 'Название документа', 0, 2, 'name', 0, 1, 0, '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(7, 'types-system-messages', 'Типы СС', 1, 'fa-bolt', 1, 1, 'Текст сообщения', 0, 1, NULL, 0, 1, 0, '2014-11-05 14:26:33', '2014-11-05 14:26:33'),
(8, 'system-messages', 'Системные сообщения', 0, 'fa-bolt', 1, 1, 'Текст сообщения', 30, 1, 'created_at', 1, 1, 0, '2014-11-05 14:26:33', '2014-11-05 14:26:33');

-- --------------------------------------------------------

--
-- Структура таблицы `dictionary_fields_values`
--

DROP TABLE IF EXISTS `dictionary_fields_values`;
CREATE TABLE IF NOT EXISTS `dictionary_fields_values` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `dicval_id` int(10) unsigned DEFAULT NULL,
  `language` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `dictionary_fields_values_dicval_id_index` (`dicval_id`),
  KEY `dictionary_fields_values_language_index` (`language`),
  KEY `dictionary_fields_values_key_index` (`key`),
  KEY `dictionary_fields_values_value_index` (`value`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=25 ;

--
-- Дамп данных таблицы `dictionary_fields_values`
--

INSERT INTO `dictionary_fields_values` (`id`, `dicval_id`, `language`, `key`, `value`, `created_at`, `updated_at`) VALUES
(1, 33, NULL, 'variables', '', '2014-10-30 12:10:23', '2014-10-30 12:10:23'),
(2, 33, NULL, 'content', '', '2014-10-30 12:10:23', '2014-10-30 12:10:23'),
(3, 33, NULL, 'word_template', '133', '2014-10-30 12:10:23', '2014-10-30 12:10:23'),
(4, 39, NULL, 'user_id', '2', '2014-10-30 12:10:23', '2014-10-30 12:10:23'),
(5, 39, NULL, 'action_id', '21', '2014-10-30 12:10:23', '2014-10-30 12:10:23'),
(6, 39, NULL, 'title', 'Событие за 30.10.2014 в 12:10', '2014-10-30 12:10:23', '2014-10-30 12:10:23'),
(7, 39, NULL, 'link', NULL, '2014-10-30 12:10:23', '2014-10-30 12:10:23'),
(8, 39, NULL, 'created_time', '2014-10-30 12:10:23', '2014-10-30 12:10:23', '2014-10-30 12:10:23'),
(9, 35, NULL, 'variables', '', '2014-10-30 12:10:48', '2014-10-30 12:10:48'),
(10, 35, NULL, 'content', '', '2014-10-30 12:10:48', '2014-10-30 12:10:48'),
(11, 35, NULL, 'word_template', '134', '2014-10-30 12:10:48', '2014-10-30 12:10:48'),
(12, 41, NULL, 'user_id', '2', '2014-10-30 12:10:48', '2014-10-30 12:10:48'),
(13, 41, NULL, 'action_id', '21', '2014-10-30 12:10:48', '2014-10-30 12:10:48'),
(14, 41, NULL, 'title', 'Событие за 30.10.2014 в 12:10', '2014-10-30 12:10:48', '2014-10-30 12:10:48'),
(15, 41, NULL, 'link', NULL, '2014-10-30 12:10:48', '2014-10-30 12:10:48'),
(16, 41, NULL, 'created_time', '2014-10-30 12:10:48', '2014-10-30 12:10:48', '2014-10-30 12:10:48'),
(17, 34, NULL, 'variables', '', '2014-10-30 12:11:03', '2014-10-30 12:11:03'),
(18, 34, NULL, 'content', '', '2014-10-30 12:11:03', '2014-10-30 12:11:03'),
(19, 34, NULL, 'word_template', '135', '2014-10-30 12:11:03', '2014-10-30 12:11:03'),
(20, 43, NULL, 'user_id', '2', '2014-10-30 12:11:03', '2014-10-30 12:11:03'),
(21, 43, NULL, 'action_id', '21', '2014-10-30 12:11:03', '2014-10-30 12:11:03'),
(22, 43, NULL, 'title', 'Событие за 30.10.2014 в 12:11', '2014-10-30 12:11:03', '2014-10-30 12:11:03'),
(23, 43, NULL, 'link', NULL, '2014-10-30 12:11:03', '2014-10-30 12:11:03'),
(24, 43, NULL, 'created_time', '2014-10-30 12:11:03', '2014-10-30 12:11:03', '2014-10-30 12:11:03');

-- --------------------------------------------------------

--
-- Структура таблицы `dictionary_textfields_values`
--

DROP TABLE IF EXISTS `dictionary_textfields_values`;
CREATE TABLE IF NOT EXISTS `dictionary_textfields_values` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `dicval_id` int(10) unsigned DEFAULT NULL,
  `language` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `value` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `dictionary_textfields_values_dicval_id_index` (`dicval_id`),
  KEY `dictionary_textfields_values_language_index` (`language`),
  KEY `dictionary_textfields_values_key_index` (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `dictionary_values`
--

DROP TABLE IF EXISTS `dictionary_values`;
CREATE TABLE IF NOT EXISTS `dictionary_values` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `version_of` int(10) unsigned DEFAULT NULL,
  `dic_id` int(10) unsigned DEFAULT NULL,
  `slug` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `order` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `dictionary_values_version_of_index` (`version_of`),
  KEY `dictionary_values_dic_id_index` (`dic_id`),
  KEY `dictionary_values_slug_index` (`slug`),
  KEY `dictionary_values_order_index` (`order`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=69 ;

--
-- Дамп данных таблицы `dictionary_values`
--

INSERT INTO `dictionary_values` (`id`, `version_of`, `dic_id`, `slug`, `name`, `order`, `created_at`, `updated_at`) VALUES
(1, NULL, 1, 'directions.store', 'Добавлено направление', 0, '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(2, NULL, 1, 'directions.update', 'Обновлено направление', 1, '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(3, NULL, 1, 'directions.destroy', 'Удалено направление', 2, '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(4, NULL, 1, 'courses.store', 'Добавлен курс', 3, '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(5, NULL, 1, 'courses.update', 'Обновлен курс', 4, '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(6, NULL, 1, 'courses.destroy', 'Удален курс', 5, '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(7, NULL, 1, 'chapters.store', 'Добавлена глава', 6, '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(8, NULL, 1, 'chapters.update', 'Обновлена глава', 7, '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(9, NULL, 1, 'chapters.destroy', 'Удалена глава', 8, '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(10, NULL, 1, 'lectures.store', 'Добавлена лекция', 9, '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(11, NULL, 1, 'lectures.update', 'Обновлена лекция', 10, '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(12, NULL, 1, 'lectures.destroy', 'Удалена лекция', 11, '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(13, NULL, 1, 'testing.index', 'Добавлен тест', 12, '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(14, NULL, 1, 'testing.destroy', 'Удален тест', 13, '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(15, NULL, 1, 'dobavlen-otzuv', 'Добавлен отзыв', 14, '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(16, NULL, 1, 'otredaktirovan-otzuv', 'Обновлен отзыв', 15, '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(17, NULL, 1, 'udalen-otzuv', 'Удален отзыв', 16, '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(18, NULL, 1, 'dobavlena-novost', 'Добавлена новость', 17, '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(19, NULL, 1, 'otredaktirovana-novost', 'Обновлена новость', 18, '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(20, NULL, 1, 'udalena-novost', 'Удалена новость', 19, '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(21, NULL, 1, 'otredaktirovan-document', 'Обновлен документ', 20, '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(22, NULL, 1, 'payment-order-number-store', 'Добавлен платеж', 21, '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(23, NULL, 1, 'payment-order-number-update', 'Обновлен платеж', 22, '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(24, NULL, 1, 'payment-order-number-delete', 'Удален платеж', 23, '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(25, NULL, 1, 'change-order-status', 'Изменен статус заказа', 24, '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(26, NULL, 1, 'moderator-company-profile-update', 'Изменен профиль компании', 25, '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(27, NULL, 1, 'moderator-company-profile-activated', 'Активирован аккаунт компании', 26, '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(28, NULL, 1, 'moderator-company-profile-approved', 'Подтвержден аккаунт компании', 27, '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(29, NULL, 1, 'moderator-listener-profile-update', 'Изменен профиль слушателя', 28, '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(30, NULL, 1, 'moderator-listener-profile-activated', 'Активирован аккаунт слушателя', 29, '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(31, NULL, 5, 'count-by-course-discount', 'Количество курсов для применения скидки', 1, '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(32, NULL, 5, 'count-by-course-discount-percent', 'Величина скидки при оформлении заказа', 0, '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(33, NULL, 6, 'dogovor', 'Договор', 1, '2014-10-29 08:18:38', '2014-10-30 12:10:23'),
(34, NULL, 6, 'schet', 'Счет', 2, '2014-10-29 08:18:38', '2014-10-30 12:11:03'),
(35, NULL, 6, 'akt', 'Акт', 3, '2014-10-29 08:18:38', '2014-10-30 12:10:48'),
(36, NULL, 6, 'order-documents-certificate-first', 'Сертификат первый ', 4, '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(37, NULL, 6, 'order-documents-certificate-second', 'Сертификат второй ', 5, '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(38, 33, 6, 'order-documents-contract', 'Договор', 1, '2014-10-30 12:10:23', '2014-10-30 12:10:23'),
(39, NULL, 2, 'otredaktirovan-document.2014-10-30 12:10:23', 'Событие за 30.10.2014 в 12:10', NULL, '2014-10-30 12:10:23', '2014-10-30 12:10:23'),
(40, 35, 6, 'order-documents-act', 'Акт', 3, '2014-10-30 12:10:48', '2014-10-30 12:10:48'),
(41, NULL, 2, 'otredaktirovan-document.2014-10-30 12:10:48', 'Событие за 30.10.2014 в 12:10', NULL, '2014-10-30 12:10:48', '2014-10-30 12:10:48'),
(42, 34, 6, 'order-documents-invoice', 'Счет', 2, '2014-10-30 12:11:03', '2014-10-30 12:11:03'),
(43, NULL, 2, 'otredaktirovan-document.2014-10-30 12:11:03', 'Событие за 30.10.2014 в 12:11', NULL, '2014-10-30 12:11:03', '2014-10-30 12:11:03'),
(44, NULL, 7, 'organization.approve-email', 'Подтвердите свой e-mail (пройдите по ссылке, направленной на указанный при регистрации адрес)', 1, '2014-11-05 14:26:33', '2014-11-05 14:26:33'),
(45, NULL, 7, 'organization.save-profile', 'Заполните анкету компании и сможете покупать курсы.', 2, '2014-11-05 14:26:33', '2014-11-05 14:26:33'),
(46, NULL, 7, 'organization.register-listeners', 'Добавьте слушателей — сотрудников, которых нужно обучить.', 3, '2014-11-05 14:26:33', '2014-11-05 14:26:33'),
(47, NULL, 7, 'organization.select-courses', 'Выберите нужные курсы, назначьте слушателей и оформите заказ.', 4, '2014-11-05 14:26:33', '2014-11-05 14:26:33'),
(48, NULL, 7, 'organization.account-blocked', 'Ваша учетная запись заблокирована. За уточнениями обратитесь к администрации системы.', 5, '2014-11-05 14:26:33', '2014-11-05 14:26:33'),
(49, NULL, 7, 'organization.order-puy', 'Для начала обучения оплатите счет <a href="[link]">№[order]</a>.', 6, '2014-11-05 14:26:33', '2014-11-05 14:26:33'),
(50, NULL, 7, 'organization.study.begin', 'Начало обучения — сотрудник [listener] открыл первую лекцию курса [course]', 7, '2014-11-05 14:26:33', '2014-11-05 14:26:33'),
(51, NULL, 7, 'organization.study.control', 'Контрольные точки — курс [course]: сотрудник [listener] успешно завершил промежуточное тестирования с результатом [percent]%.', 8, '2014-11-05 14:26:33', '2014-11-05 14:26:33'),
(52, NULL, 7, 'organization.study.fail', 'Неудачные попытки — курс [course]: сотрудник [listener] неудачно завершил промежуточное/итоговое тестирование с результатом [percent]%.', 9, '2014-11-05 14:26:33', '2014-11-05 14:26:33'),
(53, NULL, 7, 'organization.study.finish', 'Итоговый результат — сотрудник [listener] завершил обучение по курсу [course]. Итоговое тестирование завершено с результатом [percent]%.', 10, '2014-11-05 14:26:33', '2014-11-05 14:26:33'),
(54, NULL, 7, 'organization.order.new', 'Новый заказ ожидает отправки', 11, '2014-11-05 14:26:33', '2014-11-05 14:26:33'),
(55, NULL, 7, 'organization.order.approve', 'Заказ №[order] ожидает подтверждения администратором', 12, '2014-11-05 14:26:33', '2014-11-05 14:26:33'),
(56, NULL, 7, 'organization.order.not-puy-not-access', 'Заказ №[order] не оплачен, доступ к обучению не предоставлен.', 13, '2014-11-05 14:26:33', '2014-11-05 14:26:33'),
(57, NULL, 7, 'organization.order.not-puy-yes-access', 'Заказ №[order] не оплачен, но доступ к обучению предоставлен.', 14, '2014-11-05 14:26:33', '2014-11-05 14:26:33'),
(58, NULL, 7, 'organization.order.part-puy-not-access', 'Заказ №[order] оплачен частично, доступ к обучению не предоставлен.', 15, '2014-11-05 14:26:33', '2014-11-05 14:26:33'),
(59, NULL, 7, 'organization.order.part-puy-yes-access', 'Заказ №[order] оплачен частично, но доступ к обучению предоставлен.', 16, '2014-11-05 14:26:33', '2014-11-05 14:26:33'),
(60, NULL, 7, 'organization.order.yes-puy-yes-access', 'Заказ №[order] оплачен, доступ к обучению предоставлен.', 17, '2014-11-05 14:26:33', '2014-11-05 14:26:33'),
(61, NULL, 7, 'moderator.register-organization', 'Зарегистрирована организация [organization]', 18, '2014-11-05 14:26:33', '2014-11-05 14:26:33'),
(62, NULL, 7, 'moderator.update-profile-organization', 'Организация [organization] обновила регистрационные данные', 19, '2014-11-05 14:26:33', '2014-11-05 14:26:33'),
(63, NULL, 7, 'moderator.register-listener', 'Организация [organization] зарегистрировала [listener] как сотрудника', 20, '2014-11-05 14:26:33', '2014-11-05 14:26:33'),
(64, NULL, 7, 'moderator.update-profile-listener', 'Сотрудник организации [organization], [listener],  обновил(-а) регистрационные данные', 21, '2014-11-05 14:26:33', '2014-11-05 14:26:33'),
(65, NULL, 7, 'moderator.order.new', 'Оформлен заказ №[order]', 22, '2014-11-05 14:26:33', '2014-11-05 14:26:33'),
(66, NULL, 7, 'moderator.order.closed', 'Заказ №[order] закрыт', 23, '2014-11-05 11:32:22', '2014-11-05 08:23:28'),
(67, NULL, 7, 'organization.order.closed', 'Заказ <a href="[link]">№[order]</a> закрылся', 24, '2014-11-05 08:21:37', '2014-11-05 07:25:33'),
(68, NULL, 7, 'organization.order.yes-puy-not-access', 'Заказ [order] оплачен, но доступ к обучению не предоставлен.', 25, '2014-11-05 13:36:34', '2014-11-05 14:39:30');

-- --------------------------------------------------------

--
-- Структура таблицы `dictionary_values_meta`
--

DROP TABLE IF EXISTS `dictionary_values_meta`;
CREATE TABLE IF NOT EXISTS `dictionary_values_meta` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `dicval_id` int(10) unsigned DEFAULT NULL,
  `language` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `dictionary_values_meta_dicval_id_index` (`dicval_id`),
  KEY `dictionary_values_meta_language_index` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `dictionary_values_rel`
--

DROP TABLE IF EXISTS `dictionary_values_rel`;
CREATE TABLE IF NOT EXISTS `dictionary_values_rel` (
  `dicval_parent_id` int(10) unsigned NOT NULL DEFAULT '0',
  `dicval_child_id` int(10) unsigned NOT NULL DEFAULT '0',
  `dicval_child_dic` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`dicval_parent_id`,`dicval_child_id`),
  KEY `dictionary_values_rel_dicval_parent_id_index` (`dicval_parent_id`),
  KEY `dictionary_values_rel_dicval_child_id_index` (`dicval_child_id`),
  KEY `dictionary_values_rel_dicval_child_dic_index` (`dicval_child_dic`(255))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `directions`
--

DROP TABLE IF EXISTS `directions`;
CREATE TABLE IF NOT EXISTS `directions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `order` int(10) unsigned DEFAULT NULL,
  `code` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `photo_id` int(10) unsigned DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `discount` tinyint(4) DEFAULT '0',
  `active` tinyint(1) unsigned DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=7 ;

--
-- Дамп данных таблицы `directions`
--

INSERT INTO `directions` (`id`, `order`, `code`, `title`, `photo_id`, `description`, `discount`, `active`, `created_at`, `updated_at`) VALUES
(1, 1, 'БС', 'Строительство', 1, '', 0, 1, '2014-10-29 08:22:26', '2014-10-30 06:44:00'),
(2, 2, 'П', 'Проектирование', 2, '', 0, 1, '2014-10-29 08:22:26', '2014-10-30 06:48:00'),
(3, 3, 'И', 'Инженерные изыскания', 3, '', 0, 1, '2014-10-29 08:22:26', '2014-10-30 06:48:17');

-- --------------------------------------------------------

--
-- Структура таблицы `galleries`
--

DROP TABLE IF EXISTS `galleries`;
CREATE TABLE IF NOT EXISTS `galleries` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `settings` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `groups`
--

DROP TABLE IF EXISTS `groups`;
CREATE TABLE IF NOT EXISTS `groups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `desc` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `dashboard` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `start_url` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `groups_name_unique` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=7 ;

--
-- Дамп данных таблицы `groups`
--

INSERT INTO `groups` (`id`, `name`, `desc`, `dashboard`, `start_url`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'Администраторы', 'admin', '', '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(3, 'moderator', 'Модераторы', 'moderator', '', '2014-10-29 08:18:38', '2014-10-29 09:00:28'),
(4, 'organization', 'Юридическое лицо', 'organization', '', '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(5, 'listener', 'Сотрудник организаци', 'listener', '', '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(6, 'individual', 'Индивидуальный слуша', 'individual-listener', '', '2014-10-29 08:18:38', '2014-10-29 08:18:38');

-- --------------------------------------------------------

--
-- Структура таблицы `individuals`
--

DROP TABLE IF EXISTS `individuals`;
CREATE TABLE IF NOT EXISTS `individuals` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT '0',
  `fio` varchar(160) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fio_rod` varchar(160) COLLATE utf8_unicode_ci DEFAULT NULL,
  `passport_seria` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `passport_number` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `passport_data` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `passport_date` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `code` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `postaddress` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `discount` tinyint(4) DEFAULT '0',
  `moderator_approve` tinyint(1) DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `individuals_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `lectures`
--

DROP TABLE IF EXISTS `lectures`;
CREATE TABLE IF NOT EXISTS `lectures` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `course_id` int(10) unsigned DEFAULT NULL,
  `chapter_id` int(10) unsigned DEFAULT NULL,
  `order` int(10) unsigned DEFAULT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `hours` int(10) unsigned DEFAULT '0',
  `document` int(10) unsigned DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `lectures_course_id_index` (`course_id`),
  KEY `lectures_chapter_id_index` (`chapter_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=133 ;

--
-- Дамп данных таблицы `lectures`
--

INSERT INTO `lectures` (`id`, `course_id`, `chapter_id`, `order`, `title`, `description`, `hours`, `document`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 1, 'Модуль №1. Законодательное и нормативное правовое обеспечение строительства', '', 6, 1, '2014-10-29 12:16:41', '2014-10-29 12:16:41'),
(2, 1, 1, 2, 'Модуль №2. Организация инвестиционно-строительных процессов', '', 6, 2, '2014-10-29 12:17:31', '2014-10-29 12:17:31'),
(3, 1, 1, 3, 'Модуль №3. Экономика строительного производства', '', 6, 3, '2014-10-29 12:18:15', '2014-10-29 12:18:15'),
(4, 1, 1, 4, 'Модуль №4. Государственный строительный надзор и строительный контроль', '', 10, 4, '2014-10-29 12:19:18', '2014-10-29 12:19:18'),
(5, 1, 2, 1, 'Модуль №5. Инновации в технологии выполнения общестроительных работ. Показатели и критерии качества выполнения общестроительных работ', '', 24, 5, '2014-10-29 12:20:37', '2014-10-29 12:20:37'),
(6, 1, 2, 2, 'Модуль №6. Техника безопасности строительного производства', '', 6, 6, '2014-10-29 12:21:09', '2014-10-29 12:21:09'),
(7, 1, 3, 1, 'Модуль №7. Региональные особенности организации строительства', '', 8, 7, '2014-10-29 12:22:20', '2014-10-29 12:22:20'),
(8, 1, 3, 2, 'Модуль №8. Особенности выполнения строительных работ в региональных условиях осуществления строительства ', '', 2, 8, '2014-10-29 12:22:46', '2014-10-29 12:22:46'),
(9, 2, 4, 1, 'Модуль №1. Законодательное и нормативное правовое обеспечение строительства', '', 6, 9, '2014-10-29 12:34:58', '2014-10-29 12:34:58'),
(10, 2, 4, 2, 'Модуль №2. Организация инвестиционно-строительных процессов', '', 6, 10, '2014-10-29 12:35:20', '2014-10-29 12:35:20'),
(11, 2, 4, 3, 'Модуль №3. Экономика строительного производства', '', 6, 11, '2014-10-29 12:35:40', '2014-10-29 12:35:40'),
(12, 2, 4, 4, 'Модуль №4. Государственный строительный надзор и строительный контроль', '', 10, 12, '2014-10-29 12:36:07', '2014-10-29 12:36:07'),
(13, 2, 5, 1, 'Модуль №5. Инновации в технологии геодезических, подготовительных и земляных работ, устройства оснований и фундаментов. Показатели и критерии качества выполнения геодезических, подготовительных и земляных работ, устройства оснований и фундаментов ', '', 24, 13, '2014-10-29 12:37:37', '2014-10-29 12:37:37'),
(14, 2, 5, 2, 'Модуль №6. Техника безопасности строительного производства', '', 6, 14, '2014-10-29 12:38:37', '2014-10-29 12:38:37'),
(15, 2, 6, 1, 'Модуль №7. Региональные особенности организации строительства', '', 8, 15, '2014-10-29 12:40:03', '2014-10-29 12:40:03'),
(16, 2, 6, 2, 'Модуль №8. Особенности выполнения строительных работ в региональных условиях осуществления строительства ', '', 2, 16, '2014-10-29 12:40:34', '2014-10-29 12:40:34'),
(17, 3, 7, 1, 'Модуль №1. Законодательное и нормативное правовое обеспечение строительства', '', 6, 17, '2014-10-29 12:42:29', '2014-10-29 12:42:29'),
(18, 3, 7, 2, 'Модуль №2. Организация инвестиционно-строительных процессов', '', 6, 18, '2014-10-29 12:42:47', '2014-10-29 12:42:47'),
(19, 3, 7, 3, 'Модуль №3. Экономика строительного производства', '', 6, 19, '2014-10-29 12:43:05', '2014-10-29 12:43:05'),
(20, 3, 7, 4, 'Модуль №4. Государственный строительный надзор и строительный контроль', '', 10, 20, '2014-10-29 12:43:57', '2014-10-29 12:43:57'),
(21, 3, 8, 1, 'Модуль №5. Инновации в технологии возведения бетонных и железобетонных конструкций. Показатели и критерии качества возведения бетонных и железобетонных конструкций', '', 24, 21, '2014-10-29 12:44:47', '2014-10-29 12:44:47'),
(22, 3, 8, 2, 'Модуль №6. Техника безопасности строительного производства', '', 6, 22, '2014-10-29 12:45:11', '2014-10-29 12:45:11'),
(23, 3, 9, 1, 'Модуль №7. Региональные особенности организации строительства', '', 8, 23, '2014-10-29 12:46:35', '2014-10-29 12:46:35'),
(24, 3, 9, 2, 'Модуль №8. Особенности выполнения строительных работ в региональных условиях осуществления строительства ', '', 2, 24, '2014-10-29 12:46:58', '2014-10-29 12:46:58'),
(25, 4, 10, 1, 'Модуль №1. Законодательное и нормативное правовое обеспечение строительства', '', 6, 25, '2014-10-29 12:55:05', '2014-10-29 12:55:05'),
(26, 4, 10, 2, 'Модуль №2. Организация инвестиционно-строительных процессов', '', 6, 26, '2014-10-29 12:56:00', '2014-10-29 12:56:00'),
(27, 4, 10, 3, 'Модуль №3. Экономика строительного производства', '', 6, 27, '2014-10-29 12:56:27', '2014-10-29 12:56:27'),
(28, 4, 10, 4, 'Модуль №4. Государственный строительный надзор и строительный контроль', '', 10, 28, '2014-10-29 12:57:40', '2014-10-29 12:57:40'),
(29, 4, 11, 1, 'Модуль №5. Инновации в технологии возведения каменных, металлических и деревянных строительных конструкций. Показатели и критерии качества возведения каменных, металлических и деревянных строительных конструкций', '', 24, 29, '2014-10-29 12:58:43', '2014-10-29 12:58:43'),
(30, 4, 11, 2, 'Модуль №6. Техника безопасности строительного производства', '', 6, 30, '2014-10-29 13:16:43', '2014-10-29 13:16:43'),
(31, 4, 12, 1, 'Модуль №7. Региональные особенности организации строительства', '', 8, 31, '2014-10-29 13:18:08', '2014-10-29 13:18:08'),
(32, 4, 12, 2, 'Модуль №8. Особенности выполнения строительных работ в региональных условиях осуществления строительства ', '', 2, 32, '2014-10-29 13:18:46', '2014-10-29 13:18:46'),
(33, 5, 13, 1, 'Модуль №1. Законодательное и нормативное правовое обеспечение строительства', '', 6, 33, '2014-10-29 13:22:05', '2014-10-29 13:22:05'),
(34, 5, 13, 2, 'Модуль №2. Организация инвестиционно-строительных процессов', '', 6, 34, '2014-10-29 13:28:15', '2014-10-29 13:28:15'),
(35, 5, 13, 3, 'Модуль №3. Экономика строительного производства', '', 6, 35, '2014-10-29 13:28:35', '2014-10-29 13:28:35'),
(36, 5, 13, 4, 'Модуль №4. Государственный строительный надзор и строительный контроль', '', 10, 36, '2014-10-29 13:28:59', '2014-10-29 13:28:59'),
(37, 5, 14, 1, 'Модуль №5. Инновации в технологии обеспечения качества выполнения фасадных работ, устройства кровель, защиты строительных конструкций, трубопроводов и оборудования. Показатели и критерии качества выполнения фасадных работ, устройства кровель, защиты строи', '', 24, 37, '2014-10-29 13:30:09', '2014-10-29 13:33:39'),
(38, 5, 14, 2, 'Модуль №6. Техника безопасности строительного производства', '', 6, 38, '2014-10-29 13:31:00', '2014-10-29 13:31:00'),
(39, 5, 15, 1, 'Модуль №7. Региональные особенности организации строительства', '', 8, 39, '2014-10-29 13:32:24', '2014-10-29 13:32:24'),
(40, 5, 15, 2, 'Модуль №8. Особенности выполнения строительных работ в региональных условиях осуществления строительства ', '', 2, 40, '2014-10-29 13:32:43', '2014-10-29 13:32:43'),
(41, 6, 16, 1, 'Модуль №1. Законодательное и нормативное правовое обеспечение строительства', '', 6, 41, '2014-10-29 13:39:09', '2014-10-29 13:39:09'),
(42, 6, 16, 2, 'Модуль №2. Организация инвестиционно-строительных процессов', '', 6, 42, '2014-10-29 13:39:32', '2014-10-29 13:39:32'),
(43, 6, 16, 3, 'Модуль №3. Экономика строительного производства', '', 6, 43, '2014-10-29 13:39:52', '2014-10-29 13:39:52'),
(44, 6, 16, 4, 'Модуль №4. Государственный строительный надзор и строительный контроль', '', 10, 44, '2014-10-29 13:40:18', '2014-10-29 13:40:18'),
(45, 6, 17, 1, 'Модуль №5. Инновации в технологии устройства инженерных систем и сетей. Показатели и критерии качества устройства инженерных систем и сетей', '', 24, 45, '2014-10-29 13:41:56', '2014-10-29 13:41:56'),
(46, 6, 17, 2, 'Модуль №6. Техника безопасности строительного производства', '', 6, 46, '2014-10-29 13:42:25', '2014-10-29 13:42:25'),
(47, 6, 18, 1, 'Модуль №7. Региональные особенности организации строительства', '', 8, 47, '2014-10-29 13:43:27', '2014-10-29 13:43:27'),
(48, 6, 18, 2, 'Модуль №8. Особенности выполнения строительных работ в региональных условиях осуществления строительства ', '', 2, 48, '2014-10-29 13:43:48', '2014-10-29 13:43:48'),
(49, 7, 19, 1, 'Модуль №1. Законодательное и нормативное правовое обеспечение строительства', '', 6, 49, '2014-10-29 14:00:03', '2014-10-29 14:00:03'),
(50, 7, 19, 2, 'Модуль №2. Организация инвестиционно-строительных процессов', '', 6, 50, '2014-10-29 14:00:29', '2014-10-29 14:00:29'),
(51, 7, 19, 3, 'Модуль №3. Экономика строительного производства', '', 6, 51, '2014-10-29 14:00:50', '2014-10-29 14:00:50'),
(52, 7, 19, 4, 'Модуль №4. Государственный строительный надзор и строительный контроль', '', 10, 52, '2014-10-29 14:01:18', '2014-10-29 14:01:18'),
(53, 7, 20, 1, 'Модуль №5. Инновации в технологии устройства электрических сетей и линий связи. Показатели и критерии качества устройства электрических сетей и линий связи', '', 24, 53, '2014-10-29 14:02:25', '2014-10-29 14:02:25'),
(54, 7, 20, 2, 'Модуль №6. Техника безопасности строительного производства', '', 6, 54, '2014-10-29 14:03:00', '2014-10-29 14:03:00'),
(55, 7, 21, 1, 'Модуль №7. Региональные особенности организации строительства', '', 8, 55, '2014-10-29 14:04:15', '2014-10-29 14:04:15'),
(56, 7, 21, 2, 'Модуль №8. Особенности выполнения строительных работ в региональных условиях осуществления строительства ', '', 2, 56, '2014-10-29 14:04:38', '2014-10-29 14:04:38'),
(57, 8, 22, 1, 'Модуль №1. Законодательное и нормативное правовое обеспечение строительства', '', 6, 57, '2014-10-29 14:07:00', '2014-10-29 14:07:00'),
(58, 8, 22, 2, 'Модуль №2. Организация инвестиционно-строительных процессов', '', 6, 58, '2014-10-29 14:07:29', '2014-10-29 14:07:29'),
(59, 8, 22, 3, 'Модуль №3. Экономика строительного производства', '', 6, 59, '2014-10-29 14:15:30', '2014-10-29 14:15:30'),
(60, 8, 22, 4, 'Модуль №4. Государственный строительный надзор и строительный контроль', '', 10, 60, '2014-10-29 14:16:48', '2014-10-29 14:16:48'),
(61, 8, 23, 1, 'Модуль №5. Инновации в технологии устройства объектов нефтяной и газовой промышленности, устройства скважин. Показатели и критерии качества устройства объектов нефтяной и газовой промышленности, устройства скважин', '', 24, 61, '2014-10-29 14:19:19', '2014-10-29 14:19:19'),
(62, 8, 23, 2, 'Модуль №6. Техника безопасности строительного производства', '', 6, 62, '2014-10-29 14:19:49', '2014-10-29 14:19:49'),
(63, 8, 24, 1, 'Модуль №7. Региональные особенности организации строительства', '', 8, 63, '2014-10-29 14:21:02', '2014-10-29 14:21:02'),
(64, 8, 24, 2, 'Модуль №8. Особенности выполнения строительных работ в региональных условиях осуществления строительства ', '', 2, 64, '2014-10-29 14:21:23', '2014-10-29 14:21:23'),
(65, 9, 25, 1, 'Модуль №1. Законодательное и нормативное правовое обеспечение строительства', '', 6, 65, '2014-10-29 14:24:46', '2014-10-29 14:24:46'),
(66, 9, 25, 2, 'Модуль №2. Организация инвестиционно-строительных процессов', '', 6, 66, '2014-10-29 14:25:25', '2014-10-29 14:25:25'),
(67, 9, 25, 3, 'Модуль №3. Экономика строительного производства', '', 6, 67, '2014-10-29 14:27:15', '2014-10-29 14:27:15'),
(68, 9, 25, 4, 'Модуль №4. Государственный строительный надзор и строительный контроль', '', 10, 68, '2014-10-29 14:27:56', '2014-10-29 14:27:56'),
(69, 9, 26, 1, 'Модуль №5. Инновации в технологии выполнения монтажных и пусконаладочных работ лифтового оборудования. Показатели и критерии качества выполнения монтажных и пусконаладочных работ лифтового оборудования', '', 24, 69, '2014-10-29 14:28:57', '2014-10-29 14:28:57'),
(70, 9, 26, 2, 'Модуль №6. Техника безопасности строительного производства', '', 6, 70, '2014-10-29 14:29:24', '2014-10-29 14:29:24'),
(71, 9, 27, 1, 'Модуль №7. Региональные особенности организации строительства', '', 8, 71, '2014-10-29 14:30:07', '2014-10-29 14:30:07'),
(72, 9, 27, 2, 'Модуль №8. Особенности выполнения строительных работ в региональных условиях осуществления строительства ', '', 2, 72, '2014-10-29 14:30:35', '2014-10-29 14:30:35'),
(73, 10, 28, 1, 'Модуль №1. Законодательное и нормативное правовое обеспечение строительства', '', 6, 73, '2014-10-29 14:35:21', '2014-10-29 14:35:21'),
(74, 10, 28, 2, 'Модуль №2. Организация инвестиционно-строительных процессов', '', 6, 74, '2014-10-29 14:35:55', '2014-10-29 14:35:55'),
(75, 10, 28, 3, 'Модуль №3. Экономика строительного производства', '', 6, 75, '2014-10-29 14:36:13', '2014-10-29 14:36:13'),
(76, 10, 28, 4, 'Модуль №4. Государственный строительный надзор и строительный контроль', '', 10, 76, '2014-10-29 14:36:41', '2014-10-29 14:36:41'),
(77, 10, 29, 1, 'Модуль №5. Инновации в технологии устройства автомобильных дорог и аэродромов. Показатели и критерии качества устройства автомобильных дорог и аэродромов', '', 24, 77, '2014-10-29 14:38:08', '2014-10-29 14:38:08'),
(78, 10, 29, 2, 'Модуль №6. Техника безопасности строительного производства', '', 6, 78, '2014-10-29 14:39:16', '2014-10-29 14:39:16'),
(79, 10, 30, 1, 'Модуль №7. Региональные особенности организации строительства', '', 8, 79, '2014-10-29 14:40:18', '2014-10-29 14:40:18'),
(80, 10, 30, 2, 'Модуль №8. Особенности выполнения строительных работ в региональных условиях осуществления строительства ', '', 2, 80, '2014-10-29 14:40:50', '2014-10-29 14:40:50'),
(81, 11, 31, 1, 'Модуль №1. Законодательное и нормативное правовое обеспечение строительства', '', 6, 81, '2014-10-29 14:51:12', '2014-10-29 14:51:12'),
(82, 11, 31, 2, 'Модуль №2. Организация инвестиционно-строительных процессов', '', 6, 82, '2014-10-29 15:05:35', '2014-10-29 15:05:35'),
(83, 11, 31, 3, 'Модуль №3. Экономика строительного производства', '', 6, 83, '2014-10-29 15:12:20', '2014-10-29 15:12:20'),
(84, 11, 31, 4, 'Модуль №4. Государственный строительный надзор и строительный контроль', '', 10, 84, '2014-10-29 15:12:38', '2014-10-29 15:12:38'),
(85, 11, 32, 1, 'Модуль №5. Инновации в технологии устройства железнодорожных и трамвайных путей. Показатели и критерии качества устройства железнодорожных и трамвайных путей', '', 24, 85, '2014-10-29 15:13:28', '2014-10-29 15:13:28'),
(86, 11, 32, 2, 'Модуль №6. Техника безопасности строительного производства', '', 6, 86, '2014-10-29 15:13:52', '2014-10-29 15:13:52'),
(87, 11, 33, 1, 'Модуль №7. Региональные особенности организации строительства', '', 8, 87, '2014-10-29 15:14:29', '2014-10-29 15:14:29'),
(88, 11, 33, 2, 'Модуль №8. Особенности выполнения строительных работ в региональных условиях осуществления строительства ', '', 2, 88, '2014-10-29 15:15:48', '2014-10-29 15:15:48'),
(89, 12, 34, 1, 'Модуль №1. Законодательное и нормативное правовое обеспечение строительства', '', 6, 89, '2014-10-29 15:17:39', '2014-10-29 15:17:39'),
(90, 12, 34, 2, 'Модуль №2. Организация инвестиционно-строительных процессов', '', 6, 90, '2014-10-29 15:17:58', '2014-10-29 15:17:58'),
(91, 12, 34, 3, 'Модуль №3. Экономика строительного производства', '', 6, 91, '2014-10-29 15:18:12', '2014-10-29 15:18:12'),
(92, 12, 34, 4, 'Модуль №4. Государственный строительный надзор и строительный контроль', '', 10, 92, '2014-10-29 15:18:30', '2014-10-29 15:18:30'),
(93, 12, 35, 1, 'Модуль №5. Инновации в технологии устройства подземных сооружений, осуществления специальных земляных и буровзрывных работ при строительстве. Показатели и критерии качества устройства подземных сооружений, осуществления специальных земляных и буровзрывных', '', 24, 93, '2014-10-29 15:19:29', '2014-10-29 15:19:29'),
(94, 12, 35, 2, 'Модуль №6. Техника безопасности строительного производства', '', 6, 94, '2014-10-29 15:19:48', '2014-10-29 15:19:48'),
(95, 12, 36, 1, 'Модуль №7. Региональные особенности организации строительства', '', 8, 95, '2014-10-29 15:20:28', '2014-10-29 15:20:28'),
(96, 12, 36, 2, 'Модуль №8. Особенности выполнения строительных работ в региональных условиях осуществления строительства ', '', 2, 96, '2014-10-29 15:20:47', '2014-10-29 15:20:47'),
(97, 13, 37, 1, 'Модуль №1. Законодательное и нормативное правовое обеспечение строительства', '', 6, 97, '2014-10-29 15:22:29', '2014-10-29 15:22:29'),
(98, 13, 37, 2, 'Модуль №2. Организация инвестиционно-строительных процессов', '', 6, 98, '2014-10-29 15:22:44', '2014-10-29 15:22:44'),
(99, 13, 37, 3, 'Модуль №3. Экономика строительного производства', '', 6, 99, '2014-10-29 15:23:01', '2014-10-29 15:23:01'),
(100, 13, 37, 4, 'Модуль №4. Государственный строительный надзор и строительный контроль', '', 10, 100, '2014-10-29 15:23:18', '2014-10-29 15:23:18'),
(101, 13, 38, 1, 'Модуль №5. Инновации в технологии устройства мостов, эстакад, путепроводов. Показатели и критерии качества устройства мостов, эстакад, путепроводов', '', 24, 101, '2014-10-29 15:25:10', '2014-10-29 15:25:10'),
(102, 13, 38, 2, 'Модуль №6. Техника безопасности строительного производства', '', 6, 102, '2014-10-29 15:25:34', '2014-10-29 15:25:34'),
(103, 13, 39, 1, 'Модуль №7. Региональные особенности организации строительства', '', 8, 103, '2014-10-29 15:26:19', '2014-10-29 15:26:19'),
(104, 13, 39, 2, 'Модуль №8. Особенности выполнения строительных работ в региональных условиях осуществления строительства ', '', 2, 104, '2014-10-29 15:26:40', '2014-10-29 15:26:40'),
(105, 14, 40, 1, 'Модуль №1. Законодательное и нормативное правовое обеспечение строительства', '', 6, 105, '2014-10-29 15:28:52', '2014-10-29 15:28:52'),
(106, 14, 40, 2, 'Модуль №2. Организация инвестиционно-строительных процессов', '', 6, 106, '2014-10-29 15:29:23', '2014-10-29 15:29:23'),
(107, 14, 40, 3, 'Модуль №3. Экономика строительного производства', '', 6, 107, '2014-10-29 15:30:04', '2014-10-29 15:30:04'),
(108, 14, 40, 4, 'Модуль №4. Государственный строительный надзор и строительный контроль', '', 10, 108, '2014-10-29 15:30:41', '2014-10-29 15:30:41'),
(109, 14, 41, 1, 'Модуль №5. Инновации в технологии выполнения гидротехнических и водолазных работ. Показатели и критерии качества выполнения гидротехнических и водолазных работ', '', 24, 109, '2014-10-29 15:31:29', '2014-10-29 15:31:29'),
(110, 14, 41, 2, 'Модуль №6. Техника безопасности строительного производства', '', 6, 110, '2014-10-29 15:32:06', '2014-10-29 15:32:06'),
(111, 14, 42, 1, 'Модуль №7. Региональные особенности организации строительства', '', 8, 111, '2014-10-29 15:32:41', '2014-10-29 15:32:41'),
(112, 14, 42, 2, 'Модуль №8. Особенности выполнения строительных работ в региональных условиях осуществления строительства ', '', 2, 112, '2014-10-29 15:32:58', '2014-10-29 15:32:58'),
(113, 15, 43, 1, 'Модуль №1. Законодательное и нормативное правовое обеспечение строительства', '', 6, 113, '2014-10-29 15:35:16', '2014-10-29 15:35:16'),
(114, 15, 43, 2, 'Модуль №2. Организация инвестиционно-строительных процессов', '', 6, 114, '2014-10-29 15:35:35', '2014-10-29 15:35:35'),
(115, 15, 43, 3, 'Модуль №3. Экономика строительного производства', '', 6, 115, '2014-10-29 15:35:48', '2014-10-29 15:35:48'),
(116, 15, 43, 4, 'Модуль №4. Государственный строительный надзор и строительный контроль', '', 10, 116, '2014-10-29 15:36:04', '2014-10-29 15:36:04'),
(117, 15, 44, 1, 'Модуль №5. Инновации в технологии устройства промышленных печей и домовых труб. Показатели и критерии качества устройства промышленных печей и дымовых труб', '', 24, 117, '2014-10-29 15:37:07', '2014-10-29 15:37:07'),
(118, 15, 44, 2, 'Модуль №6. Техника безопасности строительного производства', '', 6, 118, '2014-10-29 15:37:32', '2014-10-29 15:37:32'),
(119, 15, 45, 1, 'Модуль №7. Региональные особенности организации строительства', '', 8, 119, '2014-10-29 15:38:10', '2014-10-29 15:38:10'),
(120, 15, 45, 2, 'Модуль №8. Особенности выполнения строительных работ в региональных условиях осуществления строительства ', '', 2, 120, '2014-10-29 15:38:31', '2014-10-29 15:38:31'),
(121, 16, 46, 1, 'Модуль №1. Законодательное и нормативное правовое обеспечение строительства', '', 6, 121, '2014-10-29 15:40:24', '2014-10-29 15:40:24'),
(122, 16, 46, 2, 'Модуль №2. Организация инвестиционно-строительных процессов', '', 6, 122, '2014-10-29 15:40:49', '2014-10-29 15:40:49'),
(123, 16, 46, 3, 'Модуль №3. Экономика строительного производства', '', 6, 123, '2014-10-29 15:41:06', '2014-10-29 15:41:06'),
(124, 16, 46, 4, 'Модуль №4. Техника безопасности строительного производства', '', 6, 124, '2014-10-29 15:41:28', '2014-10-29 15:41:28'),
(125, 16, 46, 5, 'Модуль №5. Региональные особенности организации строительства', '', 6, 125, '2014-10-29 15:41:44', '2014-10-29 15:41:44'),
(126, 16, 47, 1, 'Модуль №6. Осуществление строительного контроля', '', 38, 126, '2014-10-29 15:42:30', '2014-10-29 15:42:30'),
(127, 17, 48, 1, 'Модуль №1. Законодательное и нормативное правовое обеспечение строительства', '', 6, 127, '2014-10-29 15:44:06', '2014-10-29 15:44:06'),
(128, 17, 48, 2, 'Модуль №2. Экономика строительного производства', '', 6, 128, '2014-10-29 15:44:24', '2014-10-29 15:44:24'),
(129, 17, 48, 3, 'Модуль №3. Государственный строительный надзор и строительный контроль', '', 6, 129, '2014-10-29 15:44:41', '2014-10-29 15:44:41'),
(130, 17, 48, 4, 'Модуль №4. Техника безопасности строительного производства', '', 6, 130, '2014-10-29 15:44:56', '2014-10-29 15:44:56'),
(131, 17, 48, 5, 'Модуль №5. Региональные особенности организации строительства', '', 6, 131, '2014-10-29 15:46:05', '2014-10-29 15:46:05'),
(132, 17, 49, 1, 'Модуль №6. Организация строительства', '', 38, 132, '2014-10-29 15:46:21', '2014-10-29 15:46:21');

-- --------------------------------------------------------

--
-- Структура таблицы `listeners`
--

DROP TABLE IF EXISTS `listeners`;
CREATE TABLE IF NOT EXISTS `listeners` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT '0',
  `organization_id` int(10) unsigned DEFAULT '0',
  `fio` varchar(160) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fio_dat` varchar(160) COLLATE utf8_unicode_ci DEFAULT NULL,
  `position` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `postaddress` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `education` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `education_document_data` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `educational_institution` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `specialty` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `listeners_user_id_index` (`user_id`),
  KEY `listeners_organization_id_index` (`organization_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `migrations`
--

INSERT INTO `migrations` (`migration`, `batch`) VALUES
('2014_01_01_100000_create_groups_table', 1),
('2014_01_01_100010_create_users_table', 1),
('2014_01_01_100020_create_modules_table', 1),
('2014_01_01_100030_create_actions_table', 1),
('2014_01_01_100040_create_session_table', 1),
('2014_01_01_100050_create_settings_table', 1),
('2014_01_01_100051_create_storages_table', 1),
('2014_01_01_100060_create_pages_tables', 1),
('2014_01_01_100070_create_news_tables', 1),
('2014_01_01_100080_create_galleries_table', 1),
('2014_01_01_100090_create_photos_table', 1),
('2014_01_01_100100_create_rel_mod_gallery_table', 1),
('2014_01_01_100110_create_seo_table', 1),
('2014_07_03_161130_create_dics_tables', 1),
('2014_09_02_161130_create_uploads_tables', 1),
('2014_09_02_161140_create_video_tables', 1),
('2014_09_04_150007_create_directions_table', 1),
('2014_09_04_151141_create_courses_table', 1),
('2014_09_08_113541_create_chapter_table', 1),
('2014_09_08_113712_create_lectures_table', 1),
('2014_09_09_113857_create_tests_table', 1),
('2014_09_09_134300_create_tests_questions_table', 1),
('2014_09_09_134539_create_tests_answers_table', 1),
('2014_09_12_111807_create_account_types_table', 1),
('2014_09_24_130138_create_organization_table', 1),
('2014_09_24_131546_create_individual_table', 1),
('2014_09_25_082127_create_listener_table', 1),
('2014_10_01_081703_create_password_reminders_table', 1),
('2014_10_03_124653_create_orders_table', 1),
('2014_10_03_125652_create_payment_status_table', 1),
('2014_10_09_121118_create_order_payments', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `modules`
--

DROP TABLE IF EXISTS `modules`;
CREATE TABLE IF NOT EXISTS `modules` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `on` tinyint(1) NOT NULL DEFAULT '0',
  `order` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=11 ;

--
-- Дамп данных таблицы `modules`
--

INSERT INTO `modules` (`id`, `name`, `on`, `order`, `created_at`, `updated_at`) VALUES
(1, 'system', 1, 0, '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(2, 'pages', 1, 0, '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(3, 'news', 1, 0, '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(4, 'galleries', 1, 0, '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(5, 'seo', 1, 0, '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(6, 'dictionaries', 1, 0, '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(7, 'education', 1, 0, '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(8, 'logging', 1, 0, '2014-10-29 08:19:26', '2014-10-29 08:19:26'),
(9, 'uploads', 1, 0, '2014-10-29 08:19:27', '2014-10-29 08:19:27'),
(10, 'video', 0, 0, '2014-10-29 08:19:28', '2014-10-29 08:19:29');

-- --------------------------------------------------------

--
-- Структура таблицы `news`
--

DROP TABLE IF EXISTS `news`;
CREATE TABLE IF NOT EXISTS `news` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `template` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `type_id` int(10) unsigned DEFAULT NULL,
  `publication` tinyint(1) unsigned DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `published_at` date NOT NULL,
  PRIMARY KEY (`id`),
  KEY `news_type_id_index` (`type_id`),
  KEY `news_publication_index` (`publication`),
  KEY `news_published_at_index` (`published_at`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

-- --------------------------------------------------------

--
-- Структура таблицы `news_meta`
--

DROP TABLE IF EXISTS `news_meta`;
CREATE TABLE IF NOT EXISTS `news_meta` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `news_id` int(10) unsigned DEFAULT NULL,
  `language` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `title` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `preview` text COLLATE utf8_unicode_ci,
  `content` mediumtext COLLATE utf8_unicode_ci,
  `photo_id` int(10) unsigned DEFAULT NULL,
  `gallery_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `news_meta_news_id_index` (`news_id`),
  KEY `news_meta_language_index` (`language`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

-- --------------------------------------------------------

--
-- Структура таблицы `orders`
--

DROP TABLE IF EXISTS `orders`;
CREATE TABLE IF NOT EXISTS `orders` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT '0',
  `number` int(10) unsigned DEFAULT '0',
  `completed` tinyint(1) DEFAULT '0',
  `payment_status` tinyint(3) unsigned DEFAULT '1',
  `payment_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `discount` tinyint(4) DEFAULT '0',
  `close_status` tinyint(1) DEFAULT '0',
  `close_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `archived` tinyint(1) DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `orders_user_id_index` (`user_id`),
  KEY `orders_payment_status_index` (`payment_status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `order_listeners`
--

DROP TABLE IF EXISTS `order_listeners`;
CREATE TABLE IF NOT EXISTS `order_listeners` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` int(10) unsigned DEFAULT '0',
  `course_id` int(10) unsigned DEFAULT '0',
  `user_id` int(10) unsigned DEFAULT '0',
  `price` float(8,2) unsigned DEFAULT '0.00',
  `access_status` tinyint(1) unsigned DEFAULT '0',
  `start_status` tinyint(1) unsigned DEFAULT '0',
  `over_status` tinyint(1) unsigned DEFAULT '0',
  `start_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `over_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `order_listeners_order_id_index` (`order_id`),
  KEY `order_listeners_course_id_index` (`course_id`),
  KEY `order_listeners_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `order_listener_tests`
--

DROP TABLE IF EXISTS `order_listener_tests`;
CREATE TABLE IF NOT EXISTS `order_listener_tests` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `order_listeners_id` int(10) unsigned DEFAULT '0',
  `chapter_id` int(10) unsigned DEFAULT '0',
  `test_id` int(10) unsigned DEFAULT '0',
  `data_results` text COLLATE utf8_unicode_ci,
  `result_attempt` tinyint(3) unsigned DEFAULT '0',
  `time_attempt` int(10) unsigned DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `order_listener_tests_order_listeners_id_index` (`order_listeners_id`),
  KEY `order_listener_tests_chapter_id_index` (`chapter_id`),
  KEY `order_listener_tests_test_id_index` (`test_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `order_payments`
--

DROP TABLE IF EXISTS `order_payments`;
CREATE TABLE IF NOT EXISTS `order_payments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` int(10) unsigned DEFAULT '0',
  `price` float(8,2) unsigned DEFAULT '0.00',
  `payment_number` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `payment_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `order_payments_order_id_index` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `organizations`
--

DROP TABLE IF EXISTS `organizations`;
CREATE TABLE IF NOT EXISTS `organizations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT '0',
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fio_manager` varchar(160) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fio_manager_rod` varchar(160) COLLATE utf8_unicode_ci DEFAULT NULL,
  `manager` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `statutory` varchar(160) COLLATE utf8_unicode_ci DEFAULT NULL,
  `inn` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ogrn` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `kpp` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `uraddress` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `postaddress` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `account_type` smallint(5) unsigned DEFAULT '0',
  `account_number` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `account_kor_number` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bank` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bik` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `discount` tinyint(4) DEFAULT '0',
  `moderator_approve` tinyint(1) DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `organizations_user_id_index` (`user_id`),
  KEY `organizations_account_type_index` (`account_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `pages`
--

DROP TABLE IF EXISTS `pages`;
CREATE TABLE IF NOT EXISTS `pages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `version_of` int(10) unsigned DEFAULT NULL,
  `name` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `slug` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `template` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `type_id` int(10) unsigned DEFAULT NULL,
  `publication` tinyint(1) unsigned DEFAULT '1',
  `start_page` tinyint(1) unsigned DEFAULT NULL,
  `in_menu` tinyint(1) unsigned DEFAULT NULL,
  `order` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `pages_version_of_index` (`version_of`),
  KEY `pages_slug_index` (`slug`),
  KEY `pages_type_id_index` (`type_id`),
  KEY `pages_publication_index` (`publication`),
  KEY `pages_start_page_index` (`start_page`),
  KEY `pages_in_menu_index` (`in_menu`),
  KEY `pages_order_index` (`order`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=7 ;

--
-- Дамп данных таблицы `pages`
--

INSERT INTO `pages` (`id`, `version_of`, `name`, `slug`, `template`, `type_id`, `publication`, `start_page`, `in_menu`, `order`, `created_at`, `updated_at`) VALUES
(1, NULL, 'Главная страница', 'glavnaya-stranica', 'index-page', NULL, 1, 1, NULL, NULL, '2014-09-25 06:44:13', '2014-10-08 11:44:48'),
(2, NULL, 'Оформление заявки', 'registration', 'by-slug', NULL, 1, NULL, NULL, NULL, '2014-09-25 06:45:04', '2014-09-25 06:46:20'),
(3, NULL, 'Каталог курсов', 'catalog', 'by-slug', NULL, 1, NULL, 1, NULL, '2014-10-01 11:39:57', '2014-10-01 11:39:57'),
(4, NULL, 'Как это работает', 'how-it-works', 'by-slug', NULL, 1, NULL, NULL, NULL, '2014-10-07 06:48:57', '2014-10-07 06:48:57'),
(5, NULL, 'Контакты', 'contacts', 'by-slug', NULL, 1, NULL, NULL, NULL, '2014-10-08 10:45:01', '2014-10-08 11:41:11'),
(6, NULL, 'О портале', 'about', 'by-slug', NULL, 1, NULL, NULL, NULL, '2014-10-09 03:59:01', '2014-10-09 03:59:01');

-- --------------------------------------------------------

--
-- Структура таблицы `pages_blocks`
--

DROP TABLE IF EXISTS `pages_blocks`;
CREATE TABLE IF NOT EXISTS `pages_blocks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `page_id` int(10) unsigned DEFAULT NULL,
  `name` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `slug` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `desc` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `template` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `order` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `pages_blocks_page_id_index` (`page_id`),
  KEY `pages_blocks_slug_index` (`slug`),
  KEY `pages_blocks_order_index` (`order`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=62 ;

--
-- Дамп данных таблицы `pages_blocks`
--

INSERT INTO `pages_blocks` (`id`, `page_id`, `name`, `slug`, `desc`, `template`, `order`, `created_at`, `updated_at`) VALUES
(1, 1, 'Название страницы', 'top_h2', NULL, NULL, 0, '2014-09-25 06:44:13', '2014-09-25 06:44:13'),
(2, 2, 'Название страницы', 'top_h2', NULL, NULL, 0, '2014-09-25 06:45:04', '2014-09-25 06:45:04'),
(3, 3, 'Название страницы', 'top_h2', NULL, NULL, 0, '2014-10-01 11:39:57', '2014-10-01 11:39:57'),
(4, 3, 'Описание страницы', 'top_desc', NULL, NULL, 1, '2014-10-01 11:39:57', '2014-10-01 11:39:57'),
(5, 2, 'Описание страницы', 'top_desc', NULL, NULL, 1, '2014-10-01 11:43:27', '2014-10-01 11:43:27'),
(6, 4, 'Название страницы', 'top_h2', NULL, NULL, 0, '2014-10-07 06:48:57', '2014-10-07 06:48:57'),
(7, 4, 'Описание страницы', 'top_desc', NULL, NULL, 1, '2014-10-07 06:48:57', '2014-10-07 06:48:57'),
(8, 4, 'Контент страницы', 'content', NULL, NULL, 2, '2014-10-07 06:55:58', '2014-10-07 06:55:58'),
(9, 5, 'Название страницы', 'top_h2', NULL, NULL, 0, '2014-10-08 10:45:01', '2014-10-15 10:37:36'),
(10, 5, 'Описание страницы', 'top_desc', NULL, NULL, 1, '2014-10-08 10:45:01', '2014-10-15 10:39:54'),
(11, 5, 'Адрес', 'address', NULL, NULL, 2, '2014-10-08 10:45:01', '2014-10-15 10:39:54'),
(12, 5, 'Контактные номера', 'phones', NULL, NULL, 3, '2014-10-08 10:45:01', '2014-10-15 10:39:54'),
(25, 5, 'Email адрес', 'email', NULL, NULL, 4, '2014-10-08 10:49:48', '2014-10-15 10:39:54'),
(26, 5, 'Банковские реквизиты (Название)', 'center_h2', NULL, NULL, 5, '2014-10-08 10:49:48', '2014-10-15 10:39:54'),
(27, 6, 'Название страницы', 'top_h2', NULL, NULL, 0, '2014-10-09 03:59:02', '2014-10-09 03:59:02'),
(28, 6, 'Описание страницы', 'top_desc', NULL, NULL, 1, '2014-10-09 03:59:02', '2014-10-09 03:59:02'),
(30, 1, 'Описание страницы', 'top_desc', NULL, NULL, 1, '2014-10-15 10:31:08', '2014-10-15 10:31:08'),
(31, 1, 'Преимущества название', 'benefits_title', NULL, NULL, 2, '2014-10-15 10:31:08', '2014-10-15 10:31:08'),
(32, 1, 'Преимущества описание', 'benefits_list', NULL, NULL, 3, '2014-10-15 10:31:08', '2014-10-15 10:31:25'),
(49, 5, 'ИНН', 'inn', NULL, NULL, 6, '2014-10-15 10:39:54', '2014-10-15 10:39:54'),
(50, 5, 'ОГРН', 'ogrn', NULL, NULL, 7, '2014-10-15 10:39:54', '2014-10-15 10:39:54'),
(51, 5, 'КПП', 'kpp', NULL, NULL, 8, '2014-10-15 10:39:54', '2014-10-15 10:39:54'),
(52, 5, 'ОКПО', 'okpo', NULL, NULL, 9, '2014-10-15 10:39:54', '2014-10-15 10:39:54'),
(53, 5, 'ОКАТО', 'okato', NULL, NULL, 10, '2014-10-15 10:39:54', '2014-10-15 10:39:54'),
(54, 5, 'ОКВЭД', 'pkved', NULL, NULL, 11, '2014-10-15 10:39:54', '2014-10-15 10:39:54'),
(55, 5, 'р/сч', 'rasschet', NULL, NULL, 12, '2014-10-15 10:39:54', '2014-10-15 10:39:54'),
(56, 5, 'к/сч', 'kschet', NULL, NULL, 13, '2014-10-15 10:39:54', '2014-10-15 10:39:54'),
(57, 5, 'Банк', 'bank', NULL, NULL, 14, '2014-10-15 10:39:54', '2014-10-15 10:39:54'),
(58, 5, 'БИК', 'bik', NULL, NULL, 15, '2014-10-15 10:39:54', '2014-10-15 10:39:54'),
(61, 6, 'Лицензии', 'center_h3', NULL, NULL, 2, '2014-10-15 10:43:32', '2014-10-15 10:44:02');

-- --------------------------------------------------------

--
-- Структура таблицы `pages_blocks_meta`
--

DROP TABLE IF EXISTS `pages_blocks_meta`;
CREATE TABLE IF NOT EXISTS `pages_blocks_meta` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `block_id` int(10) unsigned DEFAULT NULL,
  `name` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `content` text COLLATE utf8_unicode_ci,
  `language` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `template` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `pages_blocks_meta_block_id_index` (`block_id`),
  KEY `pages_blocks_meta_language_index` (`language`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=49 ;

--
-- Дамп данных таблицы `pages_blocks_meta`
--

INSERT INTO `pages_blocks_meta` (`id`, `block_id`, `name`, `content`, `language`, `template`, `created_at`, `updated_at`) VALUES
(1, 3, NULL, '<h2>Каталог курсов</h2>', 'ru', NULL, '2014-10-01 11:40:30', '2014-10-01 11:40:30'),
(2, 4, NULL, '<p>В данном каталоге мы предлагаем имеющиеся курсы различных направлений. Всего в вашем распоряжении 8 курсов, каждый из которых проводится с применением образовательных технологий  электронного обучения.</p>', 'ru', NULL, '2014-10-01 11:41:25', '2014-10-01 11:41:25'),
(3, 6, NULL, '<h2>Как это работает</h2>', 'ru', NULL, '2014-10-07 06:55:12', '2014-10-07 06:55:12'),
(4, 7, NULL, '<p>Для того чтобы начать обучение вам нужно выбрать юридическое или физическое лицо и пройти регистрацию, заполнив все поля.</p>', 'ru', NULL, '2014-10-07 06:55:25', '2014-10-07 06:55:38'),
(5, 8, NULL, '<ul class="htw-ul">\r\n	<li class="htw-li htw-num-1">\r\n	<h3 class="htw-head">                                 Оформление заявки                             </h3>\r\n	<div class="htw-text">\r\n		<ol>\r\n			<li><a href="/registration">Зарегистрируйте</a> заказчика (для юр. лиц)</li>\r\n			<li>Выберите <a href="/catalog">курсы</a></li>\r\n			<li>Зарегистрируйте слушатеей</li>\r\n			<li>Получите счет и договор</li>\r\n		</ol>\r\n	</div>\r\n	</li>\r\n	<li class="htw-li htw-num-2">\r\n	<h3 class="htw-head">                                 Оплата                             </h3>\r\n	<div class="htw-text">\r\n		                                 Счет Вы получите автоматически по завершении оформления заявки.                                 Совершить оплату Вы можете в любом банке. Доступ к лекциям открывается                                 в течение 1-2 дней после оплаты.\r\n	</div>\r\n	</li>\r\n	<li class="htw-li htw-num-3">\r\n	<h3 class="htw-head">                                 Обучение                             </h3>\r\n	<div class="htw-text">\r\n		                                 Слушатели обучаются в своих <a href="#">личных кабинетах</a>                                 на сайте. Для завершения обучения слушатели выполняют итоговое тестирование.\r\n	</div>\r\n	</li>\r\n	<li class="htw-li htw-num-4">\r\n	<h3 class="htw-head">                                 Получение удостоверения                             </h3>\r\n	<div class="htw-text">\r\n		                                 Как только слушатели успешно завершают обучение, мы выдаем удостоверения о повышении квалификации. Документы можно получить лично либо высылаются по месту нахождения заказчика курьерской службой, бесплатно!\r\n	</div>\r\n	</li>\r\n</ul>', 'ru', NULL, '2014-10-07 06:56:19', '2014-10-15 10:34:11'),
(6, 1, NULL, 'Повышение квалификации через Интернет<br/>с выдачей удостоверения установленного образца', 'ru', NULL, '2014-10-08 10:14:23', '2014-10-22 06:40:37'),
(7, 9, NULL, 'Контакты', 'ru', NULL, '2014-10-08 11:31:47', '2014-10-15 10:35:49'),
(11, 10, NULL, 'Негосударственное образовательное учреждение                          дополнительного профессионального образования                          «Центр качества строительства»', 'ru', NULL, '2014-10-08 11:47:08', '2014-10-15 10:36:06'),
(12, 2, NULL, 'Регистрация в системе', 'ru', NULL, '2014-10-09 03:29:47', '2014-10-15 10:55:59'),
(13, 5, NULL, '<p>\r\n	                         Уважаемый заказчик! Для оформления заявок на повышение                         квалификации Вам необходимо пройти систему регистрации.\r\n</p>', 'ru', NULL, '2014-10-09 03:29:54', '2014-10-15 10:56:12'),
(14, 27, NULL, 'О портале', 'ru', NULL, '2014-10-15 10:28:52', '2014-10-15 10:42:53'),
(15, 28, NULL, '<p class="margin-bottom-20">\r\n	                         Образовательный портал южно-окружного центра повышения                         квалификации – это система дистанционного обучения, предназначенная                         для повышения квалификации через Интернет с выдачей удостоверения государственного образца. Система позволяет организовать процесс                         обучения без отрыва от производства, с помощью электронных учебных курсов                         в дистанционной форме через сети Интернет.\r\n</p>\r\n<p class="margin-bottom-20">\r\n	                         Южно-окружной центр повышения квалификации и переподготовки кадров                         для строительного и жилищно-коммунального комплекса является образовательным учреждением дополнительного профессионального образования. Центр учрежден в 2012 году и находится в ведении Министерства Юстиции Российской Федерации. 2 апреля 2012 года центр был аккредитован региональной службой по надзору и контролю в сфере образования Ростовской области и получил лицензию на право осуществления образовательной  деятельности в сфере дополнительного профессионального образования.\r\n</p>', 'ru', NULL, '2014-10-15 10:28:58', '2014-10-15 10:43:07'),
(18, 30, NULL, '<p>\r\n	                          Система электронного обучения позволяет организовать образовательный процесс с помощью электронных учебных курсов в электронной форме через сети Интернет.\r\n</p>\r\n<p>\r\n	                          После окончания обучения и успешной сдачи итогового тестирования слушатели курсов в самые кратчайшие сроки получают удостоверение о повышении квалификации государственного образца.\r\n</p>', 'ru', NULL, '2014-10-15 10:32:01', '2014-10-22 06:27:30'),
(19, 31, NULL, '<h3>\r\n	Преимущества\r\n</h3>', 'ru', NULL, '2014-10-15 10:32:12', '2014-10-22 06:17:52'),
(20, 32, NULL, '<ul class="benefits-ul clearfix">\r\n	<li class="benefits-li benefit-num-1"><strong>Удобная система</strong> – подойдет для пользователей любого уровня подготовки.                         </li>\r\n	<li class="benefits-li benefit-num-2"><strong>Широкий набор образовательных программ</strong> – обязательно найдете то, что нужно именно вашей компании.                         </li>\r\n	<li class="benefits-li benefit-num-3"><strong>Дистанционное электронное образование</strong> – обучайтесь где и когда удобно.                          </li>\r\n	<li class="benefits-li benefit-num-4"><strong>Надежность</strong> – все программы составленны на основании текущих нормативных документах.                         </li>\r\n</ul>', 'ru', NULL, '2014-10-15 10:32:26', '2014-10-15 10:32:26'),
(21, 11, NULL, '344 092, г. Ростов-на-Дону,<br>\r\n                            пер. Соляной Спуск, 8-10<br>', 'ru', NULL, '2014-10-15 10:36:21', '2014-10-15 10:36:21'),
(22, 12, NULL, '<p>\r\n	8 (800) 299-07-14<br>\r\n	8 (800) 299-07-15\r\n</p>', 'ru', NULL, '2014-10-15 10:37:01', '2014-10-15 10:37:01'),
(23, 25, NULL, 'tehvuz@gmail.ru', 'ru', NULL, '2014-10-15 10:37:12', '2014-10-15 10:37:12'),
(29, 26, NULL, 'Банковские реквизиты', 'ru', NULL, '2014-10-15 10:37:48', '2014-10-15 10:37:48'),
(36, 49, NULL, '6164990260', 'ru', NULL, '2014-10-15 10:40:19', '2014-10-15 10:40:19'),
(37, 50, NULL, '1126100001720', 'ru', NULL, '2014-10-15 10:40:25', '2014-10-15 10:40:25'),
(38, 51, NULL, '616401001', 'ru', NULL, '2014-10-15 10:40:34', '2014-10-15 10:40:34'),
(39, 52, NULL, '38426411', 'ru', NULL, '2014-10-15 10:40:40', '2014-10-15 10:40:40'),
(40, 53, NULL, '60401372000', 'ru', NULL, '2014-10-15 10:40:48', '2014-10-15 10:40:48'),
(41, 54, NULL, 'ОКВЭД', 'ru', NULL, '2014-10-15 10:40:56', '2014-10-15 10:40:56'),
(42, 55, NULL, '4070381082605000000', 'ru', NULL, '2014-10-15 10:41:07', '2014-10-15 10:41:07'),
(43, 56, NULL, '30101810500000000207', 'ru', NULL, '2014-10-15 10:41:15', '2014-10-15 10:41:15'),
(44, 57, NULL, 'ОАО Альфа-Банк г.  Ростов-на-Дону', 'ru', NULL, '2014-10-15 10:41:25', '2014-10-15 10:41:25'),
(45, 58, NULL, '046015207', 'ru', NULL, '2014-10-15 10:41:32', '2014-10-15 10:41:32'),
(48, 61, NULL, 'Наши лицензии и сертификаты', 'ru', NULL, '2014-10-15 10:43:37', '2014-10-15 10:43:37');

-- --------------------------------------------------------

--
-- Структура таблицы `pages_meta`
--

DROP TABLE IF EXISTS `pages_meta`;
CREATE TABLE IF NOT EXISTS `pages_meta` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `page_id` int(10) unsigned DEFAULT NULL,
  `language` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `template` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `pages_meta_page_id_index` (`page_id`),
  KEY `pages_meta_language_index` (`language`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=7 ;

--
-- Дамп данных таблицы `pages_meta`
--

INSERT INTO `pages_meta` (`id`, `page_id`, `language`, `template`, `created_at`, `updated_at`) VALUES
(1, 1, 'ru', NULL, '2014-09-25 06:44:13', '2014-09-25 06:44:13'),
(2, 2, 'ru', NULL, '2014-09-25 06:45:04', '2014-09-25 06:45:04'),
(3, 3, 'ru', NULL, '2014-10-01 11:39:57', '2014-10-01 11:39:57'),
(4, 4, 'ru', NULL, '2014-10-07 06:48:57', '2014-10-07 06:48:57'),
(5, 5, 'ru', NULL, '2014-10-08 10:45:01', '2014-10-08 10:45:01'),
(6, 6, 'ru', NULL, '2014-10-09 03:59:01', '2014-10-09 03:59:01');

-- --------------------------------------------------------

--
-- Структура таблицы `password_reminders`
--

DROP TABLE IF EXISTS `password_reminders`;
CREATE TABLE IF NOT EXISTS `password_reminders` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  KEY `password_reminders_email_index` (`email`),
  KEY `password_reminders_token_index` (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `payment_status`
--

DROP TABLE IF EXISTS `payment_status`;
CREATE TABLE IF NOT EXISTS `payment_status` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `class` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=7 ;

--
-- Дамп данных таблицы `payment_status`
--

INSERT INTO `payment_status` (`id`, `title`, `class`, `created_at`, `updated_at`) VALUES
(1, 'Не оплачен', 'non-paid-order', '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(2, 'Оплачен', 'paid-order', '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(3, 'Частично оплачен', 'part-order', '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(4, 'Частично оплачен но доступ разрешен', 'part-order', '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(5, 'Не оплачен но доступ разрешен', 'non-paid-order', '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(6, 'Оплачен но доступ запрещен', 'paid-order', '2014-10-29 08:18:38', '2014-10-29 08:18:38');

-- --------------------------------------------------------

--
-- Структура таблицы `photos`
--

DROP TABLE IF EXISTS `photos`;
CREATE TABLE IF NOT EXISTS `photos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `gallery_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `photos_gallery_id_index` (`gallery_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=7 ;

--
-- Дамп данных таблицы `photos`
--

INSERT INTO `photos` (`id`, `name`, `gallery_id`, `created_at`, `updated_at`) VALUES
(1, '1414571488_1330.png', 0, '2014-10-29 08:31:28', '2014-10-29 08:31:28'),
(2, '1412239705_1367.png', 0, '2014-10-02 04:48:25', '2014-10-02 04:48:25'),
(3, '1412239721_1122.png', 0, '2014-10-02 04:48:41', '2014-10-02 04:48:41'),
(4, '1412239737_1059.png', 0, '2014-10-02 04:48:57', '2014-10-02 04:48:57'),
(5, '1412239752_1941.png', 0, '2014-10-02 04:49:12', '2014-10-02 04:49:12'),
(6, '1412239767_1820.png', 0, '2014-10-02 04:49:27', '2014-10-02 04:49:27');

-- --------------------------------------------------------

--
-- Структура таблицы `rel_mod_gallery`
--

DROP TABLE IF EXISTS `rel_mod_gallery`;
CREATE TABLE IF NOT EXISTS `rel_mod_gallery` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `module` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `unit_id` int(10) unsigned DEFAULT '0',
  `gallery_id` int(10) unsigned DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `rel_mod_gallery_module_index` (`module`),
  KEY `unit_id` (`module`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `seo`
--

DROP TABLE IF EXISTS `seo`;
CREATE TABLE IF NOT EXISTS `seo` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `module` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `unit_id` int(10) unsigned DEFAULT NULL,
  `language` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `title` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `keywords` text COLLATE utf8_unicode_ci,
  `url` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `h1` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `unit_id` (`module`),
  KEY `seo_module_index` (`module`),
  KEY `seo_unit_id_index` (`unit_id`),
  KEY `seo_language_index` (`language`),
  KEY `seo_url_index` (`url`(255))
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=38 ;

--
-- Дамп данных таблицы `seo`
--

INSERT INTO `seo` (`id`, `module`, `unit_id`, `language`, `title`, `description`, `keywords`, `url`, `h1`, `created_at`, `updated_at`) VALUES
(1, 'page_meta', 1, NULL, 'Главная страница', '', '', '', '', '2014-09-25 06:44:13', '2014-09-25 06:44:24'),
(2, 'page_meta', 2, NULL, 'Оформление заявки', '', '', 'registration', '', '2014-09-25 06:45:04', '2014-09-25 06:45:04'),
(3, 'page_meta', 3, NULL, 'Каталог курсов', '', '', 'catalog', '', '2014-10-01 11:39:57', '2014-10-01 11:39:57'),
(4, 'page_meta', 4, NULL, 'Как это работает', '', '', 'how-it-works', '', '2014-10-07 06:48:57', '2014-10-07 06:48:57'),
(5, 'Page', 5, 'ru', 'Контакты', '', '', 'contacts', '', '2014-10-08 10:45:01', '2014-10-08 10:45:01'),
(11, 'Page', 1, 'ru', '', '', '', '', '', '2014-10-08 11:44:48', '2014-10-08 11:44:48'),
(12, 'Page', 6, 'ru', 'О портале', '', '', 'about', '', '2014-10-09 03:59:01', '2014-10-09 03:59:01'),
(19, 'news_meta', 1, NULL, '', '', '', '', '', '2014-10-22 11:19:45', '2014-10-22 11:19:45'),
(20, 'news_meta', 2, NULL, '', '', '', '', '', '2014-10-22 13:12:24', '2014-10-22 13:12:24'),
(21, 'education-courses', 1, NULL, 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства', '', '', 'stroitelstvo-rekonstrukciya-kapitalnyiy-remont-obektov-kapitalnogo-stroitelstva', 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства', '2014-10-29 12:08:46', '2014-10-30 07:56:09'),
(22, 'education-courses', 2, NULL, 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (выполнение геодезических, подготовительных и земляных работ, устройства оснований и фундаментов)', '', '', 'stroitelstvo-rekonstrukciya-kapitalnyiy-remont-obektov-kapitalnogo-stroitelstva-vypolnenie-geodezicheskih-podgotovitelnyh-i-zemlyanyh-rabot-ustroiystva-osnovaniiy-i-fundamentov', 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (выполнение геодезических, подготовительных и земляных работ, устройства оснований и фундаментов)', '2014-10-29 12:33:23', '2014-10-31 12:17:10'),
(23, 'education-courses', 3, NULL, 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (возведение бетонных и железобетонных конструкций)', '', '', 'stroitelstvo-rekonstrukciya-kapitalnyiy-remont-obektov-kapitalnogo-stroitelstva-vozvedenie-betonnyh-i-jelezobetonnyh-konstrukciiy', 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (возведение бетонных и железобетонных конструкций)', '2014-10-29 12:41:38', '2014-10-31 15:00:45'),
(24, 'education-courses', 4, NULL, 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (возведение каменных, металлических и деревянных строительных конструкций)', '', '', 'stroitelstvo-rekonstrukciya-kapitalnyiy-remont-obektov-kapitalnogo-stroitelstva-vozvedenie-kamennyh-metallicheskih-i-derevyannyh-stroitelnyh-konstrukciiy', 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (возведение каменных, металлических и деревянных строительных конструкций)', '2014-10-29 12:48:42', '2014-10-31 15:02:54'),
(25, 'education-courses', 5, NULL, 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (выполнение фасадных работ, устройство кровель, защита строительных конструкций, трубопроводов и оборудования)', '', '', 'stroitelstvo-rekonstrukciya-kapitalnyiy-remont-obektov-kapitalnogo-stroitelstva-vypolnenie-fasadnyh-rabot-ustroiystvo-krovel-zashita-stroitelnyh-konstrukciiy-truboprovodov-i-oborudovaniya', 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (выполнение фасадных работ, устройство кровель, защита строительных конструкций, трубопроводов и оборудования)', '2014-10-29 13:20:47', '2014-10-31 15:12:20'),
(26, 'education-courses', 6, NULL, 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (устройство инженерных систем и сетей)', '', '', 'stroitelstvo-rekonstrukciya-kapitalnyiy-remont-obektov-kapitalnogo-stroitelstva-ustroiystvo-injenernyh-sistem-i-seteiy', 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (устройство инженерных систем и сетей)', '2014-10-29 13:38:24', '2014-10-31 15:14:06'),
(27, 'education-courses', 7, NULL, 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (устройство электрических сетей и линий связи)', '', '', 'stroitelstvo-rekonstrukciya-kapitalnyiy-remont-obektov-kapitalnogo-stroitelstva-ustroiystvo-lektricheskih-seteiy-i-liniiy-svyazi', 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (устройство электрических сетей и линий связи)', '2014-10-29 13:45:11', '2014-10-31 15:15:43'),
(28, 'education-courses', 8, NULL, 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (устройство объектов нефтяной и газовой промышленности, устройство скважин)', '', '', 'stroitelstvo-rekonstrukciya-kapitalnyiy-remont-obektov-kapitalnogo-stroitelstva-ustroiystvo-obektov-neftyanoiy-i-gazovoiy-promyshlennosti-ustroiystvo-skvajin', 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (устройство объектов нефтяной и газовой промышленности, устройство скважин)', '2014-10-29 14:05:57', '2014-10-31 15:17:27'),
(29, 'education-courses', 9, NULL, 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (выполнение монтажных и пусконаладочных работ)', '', '', 'stroitelstvo-rekonstrukciya-kapitalnyiy-remont-obektov-kapitalnogo-stroitelstva-vypolnenie-montajnyh-i-puskonaladochnyh-rabot', 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (выполнение монтажных и пусконаладочных работ)', '2014-10-29 14:23:31', '2014-10-31 15:19:05'),
(30, 'education-courses', 10, NULL, 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (устройство автомобильных дорог и аэродромов)', '', '', 'stroitelstvo-rekonstrukciya-kapitalnyiy-remont-obektov-kapitalnogo-stroitelstva-ustroiystvo-avtomobilnyh-dorog-i-arodromov', 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (устройство автомобильных дорог и аэродромов)', '2014-10-29 14:32:22', '2014-10-31 15:24:31'),
(31, 'education-courses', 11, NULL, 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (устройство железнодорожных и трамвайных путей)', '', '', 'stroitelstvo-rekonstrukciya-kapitalnyiy-remont-obektov-kapitalnogo-stroitelstva-ustroiystvo-jeleznodorojnyh-i-tramvaiynyh-puteiy', 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (устройство железнодорожных и трамвайных путей)', '2014-10-29 14:43:57', '2014-10-31 15:26:10'),
(32, 'education-courses', 12, NULL, 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (устройство подземных сооружений, осуществление специальных земляных и буровзрывных работ при строительстве)', '', '', 'stroitelstvo-rekonstrukciya-kapitalnyiy-remont-obektov-kapitalnogo-stroitelstva-ustroiystvo-podzemnyh-soorujeniiy-osushestvlenie-specialnyh-zemlyanyh-i-burovzryvnyh-rabot-pri-stroitelstve', 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (устройство подземных сооружений, осуществление специальных земляных и буровзрывных работ при строительстве)', '2014-10-29 15:16:51', '2014-10-31 15:35:59'),
(33, 'education-courses', 13, NULL, 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (устройство мостов, эстакад и путепроводов)', '', '', 'stroitelstvo-rekonstrukciya-kapitalnyiy-remont-obektov-kapitalnogo-stroitelstva-ustroiystvo-mostov-stakad-i-puteprovodov', 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (устройство мостов, эстакад и путепроводов)', '2014-10-29 15:21:49', '2014-10-31 15:37:20'),
(34, 'education-courses', 14, NULL, 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (выполнение гидротехнических, водолазных работ)', '', '', 'stroitelstvo-rekonstrukciya-kapitalnyiy-remont-obektov-kapitalnogo-stroitelstva-vypolnenie-gidrotehnicheskih-vodolaznyh-rabot', 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (выполнение гидротехнических, водолазных работ)', '2014-10-29 15:27:53', '2014-10-31 15:39:09'),
(35, 'education-courses', 15, NULL, 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (устройство промышленных печей и дымовых труб)', '', '', 'stroitelstvo-rekonstrukciya-kapitalnyiy-remont-obektov-kapitalnogo-stroitelstva-ustroiystvo-promyshlennyh-pecheiy-i-dymovyh-trub', 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (устройство промышленных печей и дымовых труб)', '2014-10-29 15:34:16', '2014-10-31 15:46:56'),
(36, 'education-courses', 16, NULL, 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (осуществление строительного контроля)', '', '', 'stroitelstvo-rekonstrukciya-kapitalnyiy-remont-obektov-kapitalnogo-stroitelstva-osushestvlenie-stroitelnogo-kontrolya', 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (осуществление строительного контроля)', '2014-10-29 15:39:26', '2014-10-31 16:30:00'),
(37, 'education-courses', 17, NULL, 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (организация строительства)', '', '', 'stroitelstvo-rekonstrukciya-kapitalnyiy-remont-obektov-kapitalnogo-stroitelstva-organizaciya-stroitelstva', 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (организация строительства)', '2014-10-29 15:43:16', '2014-10-31 16:33:50');

-- --------------------------------------------------------

--
-- Структура таблицы `sessions`
--

DROP TABLE IF EXISTS `sessions`;
CREATE TABLE IF NOT EXISTS `sessions` (
  `id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `payload` text COLLATE utf8_unicode_ci NOT NULL,
  `last_activity` int(11) NOT NULL,
  UNIQUE KEY `sessions_id_unique` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `sessions`
--

INSERT INTO `sessions` (`id`, `payload`, `last_activity`) VALUES
('099579a7083cc57eaefcc530c06d6c25492207c7', 'YTo1OntzOjY6Il90b2tlbiI7czo0MDoiVEtHTW1iUWhxSzNwV0xVWEJWblUwOTFrRHlZZTc4NHlGc1o3VGVLQyI7czoyMjoiUEhQREVCVUdCQVJfU1RBQ0tfREFUQSI7YTowOnt9czo1OiJmbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjM4OiJsb2dpbl84MmU1ZDJjNTZiZGQwODExMzE4ZjBjZjA3OGI3OGJmYyI7czoxOiIyIjtzOjk6Il9zZjJfbWV0YSI7YTozOntzOjE6InUiO2k6MTQxNTIwMzg0NDtzOjE6ImMiO2k6MTQxNTE5ODIzMTtzOjE6ImwiO3M6MToiMCI7fX0=', 1415203844),
('2a2cccd4e5b916d02be2143aab994149e7ea35a9', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiVlI0bmticmxldDlGbWw3dGU4UkxjYTNXNkxldnN3Z1JKYWFzeE4zMCI7czoyMjoiUEhQREVCVUdCQVJfU1RBQ0tfREFUQSI7YTowOnt9czo1OiJmbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjk6Il9zZjJfbWV0YSI7YTozOntzOjE6InUiO2k6MTQxNTIwMjQzNDtzOjE6ImMiO2k6MTQxNTIwMjQzMjtzOjE6ImwiO3M6MToiMCI7fX0=', 1415202434),
('4a9a8d767295cadb06683768ffcd1634611b471a', 'YTo1OntzOjY6Il90b2tlbiI7czo0MDoiUVVhRWx3UkRWaFZVdjB2TFVqY0tiV2JqSWN2ZldadGFTdG5kRTNRaCI7czo1OiJmbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjM4OiJsb2dpbl84MmU1ZDJjNTZiZGQwODExMzE4ZjBjZjA3OGI3OGJmYyI7czoxOiIyIjtzOjIyOiJQSFBERUJVR0JBUl9TVEFDS19EQVRBIjthOjA6e31zOjk6Il9zZjJfbWV0YSI7YTozOntzOjE6InUiO2k6MTQxNTE5ODMyMDtzOjE6ImMiO2k6MTQxNTE5NzIyMztzOjE6ImwiO3M6MToiMCI7fX0=', 1415198320),
('8edfa8a9d228d46e770291b8292bbe338551403d', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiZXVJRXNCR1dXNUhlbUpMcXc2ZVU3d3Zuakx6OEJJR1lvdXpseVhSdiI7czoyMjoiUEhQREVCVUdCQVJfU1RBQ0tfREFUQSI7YTowOnt9czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MTUyMDM5MzY7czoxOiJjIjtpOjE0MTUyMDM5MzY7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1415203939),
('a519d9cc689557fe319ebe42aa48aa032fb269fb', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiakVoZlVVdFNDVEJLcHIwUWRJM0pwdlVKWUpQTUFqUVRmQzNiSXBnaCI7czoyMjoiUEhQREVCVUdCQVJfU1RBQ0tfREFUQSI7YTowOnt9czo1OiJmbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjk6Il9zZjJfbWV0YSI7YTozOntzOjE6InUiO2k6MTQxNTIwNDA0MjtzOjE6ImMiO2k6MTQxNTIwNDAzOTtzOjE6ImwiO3M6MToiMCI7fX0=', 1415204042),
('cad3f7d0292dd8ac3724dc91c7bc18e2024d5658', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiMVRwSklKR2tyNlBNMHloMVFzamNKSjhHdWZwaEhFemxYZ0pQcUk4OCI7czoyMjoiUEhQREVCVUdCQVJfU1RBQ0tfREFUQSI7YTowOnt9czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MTUyMDA2MDg7czoxOiJjIjtpOjE0MTUyMDA2MDg7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1415200608),
('d79be5f710b9c503cdf5f4bef2129a5f190783b2', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiMEhibDk1Q1N4NlBBbWNyeTZQeVRJYmRsWGRDYlY4QnlOVHY1TnRobCI7czoyMjoiUEhQREVCVUdCQVJfU1RBQ0tfREFUQSI7YTowOnt9czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MTUxOTcxNzU7czoxOiJjIjtpOjE0MTUxOTcxNzU7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1415197179),
('da49c67b9accd6df2a61338704152a977ada3e72', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoidUpvNnJaVW9OVGQ3cVBWckdDU2ZHMm9FS2dNM2VUcnBuV3pFVm9odCI7czo1OiJmbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjIyOiJQSFBERUJVR0JBUl9TVEFDS19EQVRBIjthOjA6e31zOjk6Il9zZjJfbWV0YSI7YTozOntzOjE6InUiO2k6MTQxNTIwMDM1ODtzOjE6ImMiO2k6MTQxNTIwMDEyNTtzOjE6ImwiO3M6MToiMCI7fX0=', 1415200359);

-- --------------------------------------------------------

--
-- Структура таблицы `settings`
--

DROP TABLE IF EXISTS `settings`;
CREATE TABLE IF NOT EXISTS `settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `value` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `settings`
--

INSERT INTO `settings` (`id`, `name`, `value`, `created_at`, `updated_at`) VALUES
(1, 'language', 'ru', '2014-10-29 08:18:38', '2014-10-29 08:18:38');

-- --------------------------------------------------------

--
-- Структура таблицы `storages`
--

DROP TABLE IF EXISTS `storages`;
CREATE TABLE IF NOT EXISTS `storages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `module` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `value` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `storages_module_index` (`module`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `tests`
--

DROP TABLE IF EXISTS `tests`;
CREATE TABLE IF NOT EXISTS `tests` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `course_id` int(10) unsigned DEFAULT NULL,
  `chapter_id` int(10) unsigned DEFAULT NULL,
  `order` int(10) unsigned DEFAULT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `active` tinyint(1) unsigned DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `tests_course_id_index` (`course_id`),
  KEY `tests_chapter_id_index` (`chapter_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `tests_answers`
--

DROP TABLE IF EXISTS `tests_answers`;
CREATE TABLE IF NOT EXISTS `tests_answers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `test_id` int(10) unsigned DEFAULT NULL,
  `test_question_id` int(10) unsigned DEFAULT NULL,
  `order` int(10) unsigned DEFAULT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `correct` int(10) unsigned DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `tests_answers_test_id_index` (`test_id`),
  KEY `tests_answers_test_question_id_index` (`test_question_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `tests_questions`
--

DROP TABLE IF EXISTS `tests_questions`;
CREATE TABLE IF NOT EXISTS `tests_questions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `test_id` int(10) unsigned DEFAULT NULL,
  `order` int(10) unsigned DEFAULT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `tests_questions_test_id_index` (`test_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `uploads`
--

DROP TABLE IF EXISTS `uploads`;
CREATE TABLE IF NOT EXISTS `uploads` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `path` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `original_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `filesize` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mimetype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mime1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mime2` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `module` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `unit_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `uploads_mime1_index` (`mime1`),
  KEY `uploads_mime2_index` (`mime2`),
  KEY `uploads_module_index` (`module`),
  KEY `uploads_unit_id_index` (`unit_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=136 ;

--
-- Дамп данных таблицы `uploads`
--

INSERT INTO `uploads` (`id`, `path`, `original_name`, `filesize`, `mimetype`, `mime1`, `mime2`, `module`, `unit_id`, `created_at`, `updated_at`) VALUES
(1, '/uploads/files/1414585001_1598.pdf', 'Модуль №1.pdf', '197636', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 12:16:41', '2014-10-29 12:16:41'),
(2, '/uploads/files/1414585051_1558.pdf', 'Модуль №2.pdf', '123765', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 12:17:31', '2014-10-29 12:17:31'),
(3, '/uploads/files/1414585095_1159.pdf', 'Модуль №3.pdf', '164951', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 12:18:15', '2014-10-29 12:18:15'),
(4, '/uploads/files/1414585158_1027.pdf', 'Модуль №4.pdf', '202256', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 12:19:18', '2014-10-29 12:19:18'),
(5, '/uploads/files/1414585237_1373.pdf', 'Модуль №5.pdf', '941149', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 12:20:37', '2014-10-29 12:20:37'),
(6, '/uploads/files/1414585269_1728.pdf', 'Модуль №6.pdf', '217317', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 12:21:09', '2014-10-29 12:21:09'),
(7, '/uploads/files/1414585340_1760.pdf', 'Модуль №7.pdf', '254896', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 12:22:20', '2014-10-29 12:22:20'),
(8, '/uploads/files/1414585366_1981.pdf', 'Модуль №8.pdf', '236257', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 12:22:46', '2014-10-29 12:22:46'),
(9, '/uploads/files/1414586098_1969.pdf', 'Модуль №1.pdf', '197636', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 12:34:58', '2014-10-29 12:34:58'),
(10, '/uploads/files/1414586120_1359.pdf', 'Модуль №2.pdf', '123765', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 12:35:20', '2014-10-29 12:35:20'),
(11, '/uploads/files/1414586140_1480.pdf', 'Модуль №3.pdf', '164951', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 12:35:40', '2014-10-29 12:35:40'),
(12, '/uploads/files/1414586167_1599.pdf', 'Модуль №4.pdf', '202256', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 12:36:07', '2014-10-29 12:36:07'),
(13, '/uploads/files/1414586257_1257.pdf', 'Модуль №5.pdf', '478376', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 12:37:37', '2014-10-29 12:37:37'),
(14, '/uploads/files/1414586317_1551.pdf', 'Модуль №6.pdf', '217317', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 12:38:37', '2014-10-29 12:38:37'),
(15, '/uploads/files/1414586403_1338.pdf', 'Модуль №7.pdf', '254896', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 12:40:03', '2014-10-29 12:40:03'),
(16, '/uploads/files/1414586434_1599.pdf', 'Модуль №8.pdf', '236257', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 12:40:34', '2014-10-29 12:40:34'),
(17, '/uploads/files/1414586549_1556.pdf', 'Модуль №1.pdf', '197636', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 12:42:29', '2014-10-29 12:42:29'),
(18, '/uploads/files/1414586567_1723.pdf', 'Модуль №2.pdf', '123765', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 12:42:47', '2014-10-29 12:42:47'),
(19, '/uploads/files/1414586585_1184.pdf', 'Модуль №3.pdf', '164951', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 12:43:05', '2014-10-29 12:43:05'),
(20, '/uploads/files/1414586637_1615.pdf', 'Модуль №4.pdf', '202256', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 12:43:57', '2014-10-29 12:43:57'),
(21, '/uploads/files/1414586687_1311.pdf', 'Модуль №5.pdf', '308775', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 12:44:47', '2014-10-29 12:44:47'),
(22, '/uploads/files/1414586711_1336.pdf', 'Модуль №6.pdf', '217317', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 12:45:11', '2014-10-29 12:45:11'),
(23, '/uploads/files/1414586795_1697.pdf', 'Модуль №7.pdf', '254896', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 12:46:35', '2014-10-29 12:46:35'),
(24, '/uploads/files/1414586818_1830.pdf', 'Модуль №8.pdf', '236257', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 12:46:58', '2014-10-29 12:46:58'),
(25, '/uploads/files/1414587305_1773.pdf', 'Модуль №1.pdf', '197636', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 12:55:05', '2014-10-29 12:55:05'),
(26, '/uploads/files/1414587360_1455.pdf', 'Модуль №2.pdf', '123765', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 12:56:00', '2014-10-29 12:56:00'),
(27, '/uploads/files/1414587387_1752.pdf', 'Модуль №3.pdf', '164951', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 12:56:27', '2014-10-29 12:56:27'),
(28, '/uploads/files/1414587460_1393.pdf', 'Модуль №4.pdf', '202256', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 12:57:40', '2014-10-29 12:57:40'),
(29, '/uploads/files/1414587523_1836.pdf', 'Модуль №5.pdf', '411330', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 12:58:43', '2014-10-29 12:58:43'),
(30, '/uploads/files/1414588603_1177.pdf', 'Модуль №6.pdf', '217317', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 13:16:43', '2014-10-29 13:16:43'),
(31, '/uploads/files/1414588688_1599.pdf', 'Модуль №7.pdf', '254896', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 13:18:08', '2014-10-29 13:18:08'),
(32, '/uploads/files/1414588726_1546.pdf', 'Модуль №8.pdf', '236257', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 13:18:46', '2014-10-29 13:18:46'),
(33, '/uploads/files/1414588925_1958.pdf', 'Модуль №1.pdf', '197636', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 13:22:05', '2014-10-29 13:22:05'),
(34, '/uploads/files/1414589295_1999.pdf', 'Модуль №2.pdf', '123765', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 13:28:15', '2014-10-29 13:28:15'),
(35, '/uploads/files/1414589315_1880.pdf', 'Модуль №3.pdf', '164951', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 13:28:35', '2014-10-29 13:28:35'),
(36, '/uploads/files/1414589339_1427.pdf', 'Модуль №4.pdf', '202256', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 13:28:59', '2014-10-29 13:28:59'),
(37, '/uploads/files/1414589409_1454.pdf', 'Модуль №5.pdf', '327316', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 13:30:09', '2014-10-29 13:30:09'),
(38, '/uploads/files/1414589460_1652.pdf', 'Модуль №6.pdf', '217317', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 13:31:00', '2014-10-29 13:31:00'),
(39, '/uploads/files/1414589544_1153.pdf', 'Модуль №7.pdf', '254896', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 13:32:24', '2014-10-29 13:32:24'),
(40, '/uploads/files/1414589563_1800.pdf', 'Модуль №8.pdf', '236257', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 13:32:43', '2014-10-29 13:32:43'),
(41, '/uploads/files/1414589949_1244.pdf', 'Модуль №1.pdf', '197636', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 13:39:09', '2014-10-29 13:39:09'),
(42, '/uploads/files/1414589972_1548.pdf', 'Модуль №2.pdf', '123765', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 13:39:32', '2014-10-29 13:39:32'),
(43, '/uploads/files/1414589992_1851.pdf', 'Модуль №3.pdf', '164951', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 13:39:52', '2014-10-29 13:39:52'),
(44, '/uploads/files/1414590018_1150.pdf', 'Модуль №4.pdf', '202256', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 13:40:18', '2014-10-29 13:40:18'),
(45, '/uploads/files/1414590116_1354.pdf', 'Модуль №5.pdf', '283368', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 13:41:56', '2014-10-29 13:41:56'),
(46, '/uploads/files/1414590145_1039.pdf', 'Модуль №6.pdf', '217317', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 13:42:25', '2014-10-29 13:42:25'),
(47, '/uploads/files/1414590207_1031.pdf', 'Модуль №7.pdf', '254896', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 13:43:27', '2014-10-29 13:43:27'),
(48, '/uploads/files/1414590228_1544.pdf', 'Модуль №8.pdf', '236257', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 13:43:48', '2014-10-29 13:43:48'),
(49, '/uploads/files/1414591203_1895.pdf', 'Модуль №1.pdf', '197636', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 14:00:03', '2014-10-29 14:00:03'),
(50, '/uploads/files/1414591229_1181.pdf', 'Модуль №2.pdf', '123765', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 14:00:29', '2014-10-29 14:00:29'),
(51, '/uploads/files/1414591250_1303.pdf', 'Модуль №3.pdf', '164951', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 14:00:50', '2014-10-29 14:00:50'),
(52, '/uploads/files/1414591278_1915.pdf', 'Модуль №4.pdf', '202256', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 14:01:18', '2014-10-29 14:01:18'),
(53, '/uploads/files/1414591345_1888.pdf', 'Модуль №5.pdf', '295506', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 14:02:25', '2014-10-29 14:02:25'),
(54, '/uploads/files/1414591380_1927.pdf', 'Модуль №6.pdf', '217317', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 14:03:00', '2014-10-29 14:03:00'),
(55, '/uploads/files/1414591455_1886.pdf', 'Модуль №7.pdf', '254896', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 14:04:15', '2014-10-29 14:04:15'),
(56, '/uploads/files/1414591478_1096.pdf', 'Модуль №8.pdf', '236257', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 14:04:38', '2014-10-29 14:04:38'),
(57, '/uploads/files/1414591620_1996.pdf', 'Модуль №1.pdf', '197636', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 14:07:00', '2014-10-29 14:07:00'),
(58, '/uploads/files/1414591649_1373.pdf', 'Модуль №2.pdf', '123765', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 14:07:29', '2014-10-29 14:07:29'),
(59, '/uploads/files/1414592130_1389.pdf', 'Модуль №3.pdf', '164951', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 14:15:30', '2014-10-29 14:15:30'),
(60, '/uploads/files/1414592208_1320.pdf', 'Модуль №4.pdf', '202256', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 14:16:48', '2014-10-29 14:16:48'),
(61, '/uploads/files/1414592359_1012.pdf', 'Модуль №5.pdf', '430875', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 14:19:19', '2014-10-29 14:19:19'),
(62, '/uploads/files/1414592389_1825.pdf', 'Модуль №6.pdf', '217317', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 14:19:49', '2014-10-29 14:19:49'),
(63, '/uploads/files/1414592462_1829.pdf', 'Модуль №7.pdf', '254896', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 14:21:02', '2014-10-29 14:21:02'),
(64, '/uploads/files/1414592483_1829.pdf', 'Модуль №8.pdf', '236257', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 14:21:23', '2014-10-29 14:21:23'),
(65, '/uploads/files/1414592686_1059.pdf', 'Модуль №1.pdf', '197636', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 14:24:46', '2014-10-29 14:24:46'),
(66, '/uploads/files/1414592725_1447.pdf', 'Модуль №2.pdf', '123765', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 14:25:25', '2014-10-29 14:25:25'),
(67, '/uploads/files/1414592835_1685.pdf', 'Модуль №3.pdf', '164951', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 14:27:15', '2014-10-29 14:27:15'),
(68, '/uploads/files/1414592876_1527.pdf', 'Модуль №4.pdf', '202256', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 14:27:56', '2014-10-29 14:27:56'),
(69, '/uploads/files/1414592937_1427.pdf', 'Модуль №5.pdf', '343905', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 14:28:57', '2014-10-29 14:28:57'),
(70, '/uploads/files/1414592964_1966.pdf', 'Модуль №6.pdf', '217317', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 14:29:24', '2014-10-29 14:29:24'),
(71, '/uploads/files/1414593007_1273.pdf', 'Модуль №7.pdf', '254896', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 14:30:07', '2014-10-29 14:30:07'),
(72, '/uploads/files/1414593035_1418.pdf', 'Модуль №8.pdf', '236257', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 14:30:35', '2014-10-29 14:30:35'),
(73, '/uploads/files/1414593321_1726.pdf', 'Модуль №1.pdf', '197636', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 14:35:21', '2014-10-29 14:35:21'),
(74, '/uploads/files/1414593355_1302.pdf', 'Модуль №2.pdf', '123765', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 14:35:55', '2014-10-29 14:35:55'),
(75, '/uploads/files/1414593373_1280.pdf', 'Модуль №3.pdf', '164951', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 14:36:13', '2014-10-29 14:36:13'),
(76, '/uploads/files/1414593401_1421.pdf', 'Модуль №4.pdf', '202256', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 14:36:41', '2014-10-29 14:36:41'),
(77, '/uploads/files/1414593488_1409.pdf', 'Модуль №5.pdf', '447106', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 14:38:08', '2014-10-29 14:38:08'),
(78, '/uploads/files/1414593555_1432.pdf', 'Модуль №6.pdf', '217317', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 14:39:16', '2014-10-29 14:39:16'),
(79, '/uploads/files/1414593618_1848.pdf', 'Модуль №7.pdf', '254896', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 14:40:18', '2014-10-29 14:40:18'),
(80, '/uploads/files/1414593650_1788.pdf', 'Модуль №8.pdf', '236257', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 14:40:50', '2014-10-29 14:40:50'),
(81, '/uploads/files/1414594272_1720.pdf', 'Модуль №1.pdf', '197636', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 14:51:12', '2014-10-29 14:51:12'),
(82, '/uploads/files/1414595135_1099.pdf', 'Модуль №2.pdf', '123765', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:05:35', '2014-10-29 15:05:35'),
(83, '/uploads/files/1414595540_1128.pdf', 'Модуль №3.pdf', '164951', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:12:20', '2014-10-29 15:12:20'),
(84, '/uploads/files/1414595558_1992.pdf', 'Модуль №4.pdf', '202256', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:12:38', '2014-10-29 15:12:38'),
(85, '/uploads/files/1414595608_1855.pdf', 'Модуль №5.pdf', '342725', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:13:28', '2014-10-29 15:13:28'),
(86, '/uploads/files/1414595632_1707.pdf', 'Модуль №6.pdf', '217317', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:13:52', '2014-10-29 15:13:52'),
(87, '/uploads/files/1414595669_1940.pdf', 'Модуль №7.pdf', '254896', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:14:29', '2014-10-29 15:14:29'),
(88, '/uploads/files/1414595748_1615.pdf', 'Модуль №8.pdf', '236257', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:15:48', '2014-10-29 15:15:48'),
(89, '/uploads/files/1414595859_1905.pdf', 'Модуль №1.pdf', '197636', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:17:39', '2014-10-29 15:17:39'),
(90, '/uploads/files/1414595878_1528.pdf', 'Модуль №2.pdf', '123765', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:17:58', '2014-10-29 15:17:58'),
(91, '/uploads/files/1414595892_1566.pdf', 'Модуль №3.pdf', '164951', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:18:12', '2014-10-29 15:18:12'),
(92, '/uploads/files/1414595910_1452.pdf', 'Модуль №4.pdf', '202256', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:18:30', '2014-10-29 15:18:30'),
(93, '/uploads/files/1414595969_1752.pdf', 'Модуль №5.pdf', '299241', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:19:29', '2014-10-29 15:19:29'),
(94, '/uploads/files/1414595988_1438.pdf', 'Модуль №6.pdf', '217317', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:19:48', '2014-10-29 15:19:48'),
(95, '/uploads/files/1414596028_1327.pdf', 'Модуль №7.pdf', '254896', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:20:28', '2014-10-29 15:20:28'),
(96, '/uploads/files/1414596047_1695.pdf', 'Модуль №8.pdf', '236257', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:20:47', '2014-10-29 15:20:47'),
(97, '/uploads/files/1414596149_1496.pdf', 'Модуль №1.pdf', '197636', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:22:29', '2014-10-29 15:22:29'),
(98, '/uploads/files/1414596164_1410.pdf', 'Модуль №2.pdf', '123765', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:22:44', '2014-10-29 15:22:44'),
(99, '/uploads/files/1414596181_1475.pdf', 'Модуль №3.pdf', '164951', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:23:01', '2014-10-29 15:23:01'),
(100, '/uploads/files/1414596198_1020.pdf', 'Модуль №4.pdf', '202256', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:23:18', '2014-10-29 15:23:18'),
(101, '/uploads/files/1414596310_1992.pdf', 'Модуль №5.pdf', '308572', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:25:10', '2014-10-29 15:25:10'),
(102, '/uploads/files/1414596334_1700.pdf', 'Модуль №6.pdf', '217317', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:25:34', '2014-10-29 15:25:34'),
(103, '/uploads/files/1414596379_1613.pdf', 'Модуль №7.pdf', '254896', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:26:19', '2014-10-29 15:26:19'),
(104, '/uploads/files/1414596400_1870.pdf', 'Модуль №8.pdf', '236257', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:26:40', '2014-10-29 15:26:40'),
(105, '/uploads/files/1414596532_1518.pdf', 'Модуль №1.pdf', '197636', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:28:52', '2014-10-29 15:28:52'),
(106, '/uploads/files/1414596563_1953.pdf', 'Модуль №2.pdf', '123765', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:29:23', '2014-10-29 15:29:23'),
(107, '/uploads/files/1414596604_1513.pdf', 'Модуль №3.pdf', '164951', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:30:04', '2014-10-29 15:30:04'),
(108, '/uploads/files/1414596641_1953.pdf', 'Модуль №4.pdf', '202256', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:30:41', '2014-10-29 15:30:41'),
(109, '/uploads/files/1414596689_1601.pdf', 'Модуль №5.pdf', '292690', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:31:29', '2014-10-29 15:31:29'),
(110, '/uploads/files/1414596726_1396.pdf', 'Модуль №6.pdf', '217317', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:32:06', '2014-10-29 15:32:06'),
(111, '/uploads/files/1414596761_1217.pdf', 'Модуль №7.pdf', '254896', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:32:41', '2014-10-29 15:32:41'),
(112, '/uploads/files/1414596778_1239.pdf', 'Модуль №8.pdf', '236257', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:32:58', '2014-10-29 15:32:58'),
(113, '/uploads/files/1414596916_1158.pdf', 'Модуль №1.pdf', '197636', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:35:16', '2014-10-29 15:35:16'),
(114, '/uploads/files/1414596935_1283.pdf', 'Модуль №2.pdf', '123765', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:35:35', '2014-10-29 15:35:35'),
(115, '/uploads/files/1414596948_1188.pdf', 'Модуль №3.pdf', '164951', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:35:48', '2014-10-29 15:35:48'),
(116, '/uploads/files/1414596964_1359.pdf', 'Модуль №4.pdf', '202256', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:36:04', '2014-10-29 15:36:04'),
(117, '/uploads/files/1414597027_1184.pdf', 'Модуль №5.pdf', '281618', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:37:07', '2014-10-29 15:37:07'),
(118, '/uploads/files/1414597052_1211.pdf', 'Модуль №6.pdf', '217317', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:37:32', '2014-10-29 15:37:32'),
(119, '/uploads/files/1414597090_1343.pdf', 'Модуль №7.pdf', '254896', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:38:10', '2014-10-29 15:38:10'),
(120, '/uploads/files/1414597111_1341.pdf', 'Модуль №8.pdf', '236257', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:38:31', '2014-10-29 15:38:31'),
(121, '/uploads/files/1414597224_1582.pdf', 'Модуль №1.pdf', '197636', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:40:24', '2014-10-29 15:40:24'),
(122, '/uploads/files/1414597249_1263.pdf', 'Модуль №2.pdf', '123765', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:40:49', '2014-10-29 15:40:49'),
(123, '/uploads/files/1414597266_1594.pdf', 'Модуль №3.pdf', '164951', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:41:06', '2014-10-29 15:41:06'),
(124, '/uploads/files/1414597288_1642.pdf', 'Модуль №4.pdf', '217195', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:41:28', '2014-10-29 15:41:28'),
(125, '/uploads/files/1414597304_1386.pdf', 'Модуль №5.pdf', '254654', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:41:44', '2014-10-29 15:41:44'),
(126, '/uploads/files/1414597350_1492.pdf', 'Модуль №6.pdf', '948731', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:42:30', '2014-10-29 15:42:30'),
(127, '/uploads/files/1414597446_1722.pdf', 'Модуль №1.pdf', '197636', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:44:06', '2014-10-29 15:44:06'),
(128, '/uploads/files/1414597464_1125.pdf', 'Модуль №2.pdf', '165118', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:44:24', '2014-10-29 15:44:24'),
(129, '/uploads/files/1414597481_1073.pdf', 'Модуль №3.pdf', '202298', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:44:41', '2014-10-29 15:44:41'),
(130, '/uploads/files/1414597496_1605.pdf', 'Модуль №4.pdf', '217195', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:44:56', '2014-10-29 15:44:56'),
(131, '/uploads/files/1414597565_1103.pdf', 'Модуль №5.pdf', '254654', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:46:05', '2014-10-29 15:46:05'),
(132, '/uploads/files/1414597581_1710.pdf', 'Модуль №6.pdf', '314912', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:46:21', '2014-10-29 15:46:21'),
(133, '/uploads/files/1414671023_1334.docx', 'Договор(2013).docx', '33811', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'application', 'vnd.openxmlformats-officedocument.wordprocessingml.document', 'dicval', 33, '2014-10-30 12:10:23', '2014-10-30 12:10:23'),
(134, '/uploads/files/1414671048_1384.docx', 'Акт(2013).docx', '18238', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'application', 'vnd.openxmlformats-officedocument.wordprocessingml.document', 'dicval', 35, '2014-10-30 12:10:48', '2014-10-30 12:10:48'),
(135, '/uploads/files/1414671063_1379.docx', 'Счет(2013).docx', '16845', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'application', 'vnd.openxmlformats-officedocument.wordprocessingml.document', 'dicval', 34, '2014-10-30 12:11:03', '2014-10-30 12:11:03');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `group_id` smallint(5) unsigned DEFAULT '0',
  `name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `surname` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `active` smallint(5) unsigned DEFAULT '0',
  `password` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `photo` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `thumbnail` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `temporary_code` varchar(25) COLLATE utf8_unicode_ci DEFAULT NULL,
  `code_life` bigint(20) DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `group_id`, `name`, `surname`, `email`, `active`, `password`, `photo`, `thumbnail`, `temporary_code`, `code_life`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 1, 'Администратор', '', 'admin@techvuz.ru', 1, '$2y$10$GPtYyNgMs1WtT6KPPl373.I1K0cLLuvlZTrjCLnamhzkOalG1HDEu', '', '', '', 0, 'LUHxtWWRjky6zF9aJmJgJ5T53KCXfNYyLB3x51GHPT2jXAE0kNfmp2Y9cOIq', '2014-10-29 08:18:38', '2014-10-31 11:22:23'),
(2, 3, 'Модератор', '', 'moder@techvuz.ru', 1, '$2y$10$FoyyWv5KcoTJY2QfC4o6uuqGYjl0hwtAzi.o.6ny8INNwLB1SHMV6', '', '', '', 0, 'h7GWDoaqfKHikojIxdUOGzxZiU7AAMUx46Xh9NNBVllltk5x0uUaA1cfRxWq', '2014-10-29 08:18:38', '2014-11-05 15:11:32');

-- --------------------------------------------------------

--
-- Дублирующая структура для представления `users_individuals`
--
DROP VIEW IF EXISTS `users_individuals`;
CREATE TABLE IF NOT EXISTS `users_individuals` (
`id` int(10) unsigned
,`email` varchar(100)
,`active` smallint(5) unsigned
,`created_at` timestamp
,`individual_id` int(10) unsigned
,`fio` varchar(160)
,`fio_rod` varchar(160)
,`passport_seria` varchar(10)
,`passport_number` varchar(10)
,`passport_data` varchar(200)
,`passport_date` varchar(20)
,`code` varchar(50)
,`postaddress` varchar(255)
,`phone` varchar(40)
,`discount` tinyint(4)
,`moderator_approve` tinyint(1)
);
-- --------------------------------------------------------

--
-- Дублирующая структура для представления `users_listeners`
--
DROP VIEW IF EXISTS `users_listeners`;
CREATE TABLE IF NOT EXISTS `users_listeners` (
`id` int(10) unsigned
,`email` varchar(100)
,`active` smallint(5) unsigned
,`created_at` timestamp
,`listener_id` int(10) unsigned
,`organization_id` int(10) unsigned
,`fio` varchar(160)
,`fio_dat` varchar(160)
,`position` varchar(100)
,`postaddress` varchar(255)
,`phone` varchar(40)
,`education` varchar(100)
,`education_document_data` varchar(100)
,`educational_institution` varchar(100)
,`specialty` varchar(100)
);
-- --------------------------------------------------------

--
-- Дублирующая структура для представления `users_organizations`
--
DROP VIEW IF EXISTS `users_organizations`;
CREATE TABLE IF NOT EXISTS `users_organizations` (
`id` int(10) unsigned
,`email` varchar(100)
,`active` smallint(5) unsigned
,`created_at` timestamp
,`organization_id` int(10) unsigned
,`title` varchar(255)
,`fio_manager` varchar(160)
,`fio_manager_rod` varchar(160)
,`manager` varchar(100)
,`statutory` varchar(160)
,`inn` varchar(40)
,`ogrn` varchar(40)
,`kpp` varchar(40)
,`postaddress` varchar(255)
,`uraddress` varchar(255)
,`account_type_id` smallint(5) unsigned
,`account_number` varchar(40)
,`account_kor_number` varchar(40)
,`bank` varchar(255)
,`bik` varchar(40)
,`name` varchar(100)
,`phone` varchar(40)
,`discount` tinyint(4)
,`moderator_approve` tinyint(1)
,`account_type` varchar(50)
);
-- --------------------------------------------------------

--
-- Структура таблицы `videos`
--

DROP TABLE IF EXISTS `videos`;
CREATE TABLE IF NOT EXISTS `videos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `embed` text COLLATE utf8_unicode_ci,
  `image_id` int(11) DEFAULT NULL,
  `module` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `unit_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `videos_module_index` (`module`),
  KEY `videos_unit_id_index` (`unit_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура для представления `users_individuals`
--
DROP TABLE IF EXISTS `users_individuals`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `users_individuals` AS select `users`.`id` AS `id`,`users`.`email` AS `email`,`users`.`active` AS `active`,`users`.`created_at` AS `created_at`,`individuals`.`id` AS `individual_id`,`individuals`.`fio` AS `fio`,`individuals`.`fio_rod` AS `fio_rod`,`individuals`.`passport_seria` AS `passport_seria`,`individuals`.`passport_number` AS `passport_number`,`individuals`.`passport_data` AS `passport_data`,`individuals`.`passport_date` AS `passport_date`,`individuals`.`code` AS `code`,`individuals`.`postaddress` AS `postaddress`,`individuals`.`phone` AS `phone`,`individuals`.`discount` AS `discount`,`individuals`.`moderator_approve` AS `moderator_approve` from (`users` left join `individuals` on((`users`.`id` = `individuals`.`user_id`))) where (`users`.`group_id` = 6);

-- --------------------------------------------------------

--
-- Структура для представления `users_listeners`
--
DROP TABLE IF EXISTS `users_listeners`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `users_listeners` AS select `users`.`id` AS `id`,`users`.`email` AS `email`,`users`.`active` AS `active`,`users`.`created_at` AS `created_at`,`listeners`.`id` AS `listener_id`,`listeners`.`organization_id` AS `organization_id`,`listeners`.`fio` AS `fio`,`listeners`.`fio_dat` AS `fio_dat`,`listeners`.`position` AS `position`,`listeners`.`postaddress` AS `postaddress`,`listeners`.`phone` AS `phone`,`listeners`.`education` AS `education`,`listeners`.`education_document_data` AS `education_document_data`,`listeners`.`educational_institution` AS `educational_institution`,`listeners`.`specialty` AS `specialty` from (`listeners` left join `users` on((`users`.`id` = `listeners`.`user_id`))) where (`users`.`group_id` = 5);

-- --------------------------------------------------------

--
-- Структура для представления `users_organizations`
--
DROP TABLE IF EXISTS `users_organizations`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `users_organizations` AS select `users`.`id` AS `id`,`users`.`email` AS `email`,`users`.`active` AS `active`,`users`.`created_at` AS `created_at`,`organizations`.`id` AS `organization_id`,`organizations`.`title` AS `title`,`organizations`.`fio_manager` AS `fio_manager`,`organizations`.`fio_manager_rod` AS `fio_manager_rod`,`organizations`.`manager` AS `manager`,`organizations`.`statutory` AS `statutory`,`organizations`.`inn` AS `inn`,`organizations`.`ogrn` AS `ogrn`,`organizations`.`kpp` AS `kpp`,`organizations`.`postaddress` AS `postaddress`,`organizations`.`uraddress` AS `uraddress`,`organizations`.`account_type` AS `account_type_id`,`organizations`.`account_number` AS `account_number`,`organizations`.`account_kor_number` AS `account_kor_number`,`organizations`.`bank` AS `bank`,`organizations`.`bik` AS `bik`,`organizations`.`name` AS `name`,`organizations`.`phone` AS `phone`,`organizations`.`discount` AS `discount`,`organizations`.`moderator_approve` AS `moderator_approve`,`account_types`.`title` AS `account_type` from ((`organizations` left join `users` on((`users`.`id` = `organizations`.`user_id`))) join `account_types` on((`organizations`.`account_type` = `account_types`.`id`))) where (`users`.`group_id` = 4);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
