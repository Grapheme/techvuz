-- phpMyAdmin SQL Dump
-- version 3.4.10.1deb1
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Дек 18 2014 г., 17:15
-- Версия сервера: 5.5.37
-- Версия PHP: 5.5.12-2+deb.sury.org~precise+1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `techvuz`
--

-- --------------------------------------------------------

--
-- Структура таблицы `account_types`
--

DROP TABLE IF EXISTS `account_types`;
CREATE TABLE IF NOT EXISTS `account_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=7 ;

--
-- Дамп данных таблицы `account_types`
--

INSERT INTO `account_types` (`id`, `title`, `created_at`, `updated_at`) VALUES
(1, 'Расчетный', '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(2, 'Валютный', '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(3, 'Текущий', '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(4, 'Временный', '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(5, 'Транзитный', '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(6, 'Депозитный', '2014-10-29 08:18:38', '2014-10-29 08:18:38');

-- --------------------------------------------------------

--
-- Структура таблицы `actions`
--

DROP TABLE IF EXISTS `actions`;
CREATE TABLE IF NOT EXISTS `actions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `group_id` int(10) unsigned DEFAULT NULL,
  `module` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `action` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `actions_group_id_index` (`group_id`),
  KEY `actions_module_index` (`module`),
  KEY `actions_action_index` (`action`),
  KEY `actions_status_index` (`status`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=27 ;

--
-- Дамп данных таблицы `actions`
--

INSERT INTO `actions` (`id`, `group_id`, `module`, `action`, `status`) VALUES
(1, 3, 'dictionaries', 'dicval_view', 1),
(2, 3, 'dictionaries', 'dicval_create', 1),
(3, 3, 'dictionaries', 'dicval_edit', 1),
(4, 3, 'dictionaries', 'dicval_delete', 1),
(5, 3, 'dictionaries', 'dicval_restore', 1),
(6, 3, 'dictionaries', 'dicval_entity_view', 1),
(7, 3, 'dictionaries', 'hidden', 1),
(8, 3, 'education', 'view', 1),
(9, 3, 'education', 'create', 1),
(10, 3, 'education', 'edit', 1),
(11, 3, 'education', 'delete', 1),
(12, 3, 'galleries', 'create', 1),
(13, 3, 'galleries', 'edit', 1),
(14, 3, 'galleries', 'delete', 1),
(15, 3, 'logging', 'logging', 1),
(16, 3, 'news', 'view', 1),
(17, 3, 'news', 'create', 1),
(18, 3, 'news', 'edit', 1),
(19, 3, 'news', 'delete', 1),
(20, 3, 'pages', 'view', 1),
(21, 3, 'pages', 'create', 1),
(22, 3, 'pages', 'edit', 1),
(23, 3, 'pages', 'delete', 1),
(24, 3, 'pages', 'advanced', 1),
(25, 3, 'pages', 'page_restore', 1),
(26, 3, 'seo', 'edit', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `chapters`
--

DROP TABLE IF EXISTS `chapters`;
CREATE TABLE IF NOT EXISTS `chapters` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `course_id` int(10) unsigned DEFAULT NULL,
  `order` int(10) unsigned DEFAULT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `test_title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `hours` int(10) unsigned DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `chapters_course_id_index` (`course_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=50 ;

--
-- Дамп данных таблицы `chapters`
--

INSERT INTO `chapters` (`id`, `course_id`, `order`, `title`, `test_title`, `description`, `hours`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 'Общая часть программы', NULL, '', 28, '2014-10-29 12:15:25', '2014-10-29 12:15:25'),
(2, 1, 2, 'Специализированная часть программы', NULL, '', 30, '2014-10-29 12:19:50', '2014-10-29 12:19:50'),
(3, 1, 3, 'Региональная часть программы', NULL, '', 10, '2014-10-29 12:21:37', '2014-10-29 12:21:37'),
(4, 2, 1, 'Общая часть программы ', NULL, '', 28, '2014-10-29 12:34:09', '2014-10-29 12:34:09'),
(5, 2, 2, 'Специализированная часть программы', NULL, '', 30, '2014-10-29 12:36:33', '2014-10-29 12:36:33'),
(6, 2, 3, 'Региональная часть программы', NULL, '', 10, '2014-10-29 12:39:39', '2014-10-29 12:39:39'),
(7, 3, 1, 'Общая часть программы', NULL, '', 28, '2014-10-29 12:42:16', '2014-10-29 12:42:16'),
(8, 3, 2, 'Специализированная часть программы', NULL, '', 30, '2014-10-29 12:44:14', '2014-10-29 12:44:14'),
(9, 3, 3, 'Региональная часть программы', NULL, '', 10, '2014-10-29 12:46:07', '2014-10-29 12:46:07'),
(10, 4, 1, 'Общая часть программы', NULL, '', 28, '2014-10-29 12:54:35', '2014-10-29 12:55:14'),
(11, 4, 2, 'Специализированная часть программы', NULL, '', 30, '2014-10-29 12:58:16', '2014-10-29 12:58:16'),
(12, 4, 3, 'Региональная часть программы', NULL, '', 10, '2014-10-29 13:17:16', '2014-10-29 13:17:16'),
(13, 5, 1, 'Общая часть программы', NULL, '', 28, '2014-10-29 13:21:32', '2014-10-29 13:21:32'),
(14, 5, 2, 'Специализированная часть программы', NULL, '', 30, '2014-10-29 13:29:28', '2014-10-29 13:29:28'),
(15, 5, 3, 'Региональная часть программы', NULL, '', 10, '2014-10-29 13:32:00', '2014-10-29 13:32:00'),
(16, 6, 1, 'Общая часть программы', NULL, '', 28, '2014-10-29 13:38:50', '2014-10-29 13:38:50'),
(17, 6, 2, 'Специализированная часть программы', NULL, '', 30, '2014-10-29 13:41:26', '2014-10-29 13:41:26'),
(18, 6, 3, 'Региональная часть программы', NULL, '', 10, '2014-10-29 13:42:46', '2014-10-29 13:42:46'),
(19, 7, 1, 'Общая часть программы', NULL, '', 6, '2014-10-29 13:54:20', '2014-10-29 13:54:20'),
(20, 7, 2, 'Специализированная часть программы', NULL, '', 30, '2014-10-29 14:01:56', '2014-10-29 14:01:56'),
(21, 7, 3, 'Региональная часть программы', NULL, '', 10, '2014-10-29 14:03:19', '2014-10-29 14:03:19'),
(22, 8, 1, 'Общая часть программы', NULL, '', 28, '2014-10-29 14:06:22', '2014-10-29 14:06:22'),
(23, 8, 2, 'Специализированная часть программы', NULL, '', 30, '2014-10-29 14:18:23', '2014-10-29 14:18:23'),
(24, 8, 3, 'Региональная часть программы ', NULL, '', 10, '2014-10-29 14:20:39', '2014-10-29 14:20:39'),
(25, 9, 1, 'Общая часть программы', NULL, '', 28, '2014-10-29 14:24:28', '2014-10-29 14:24:28'),
(26, 9, 2, 'Специализированная часть программы', NULL, '', 30, '2014-10-29 14:28:27', '2014-10-29 14:28:27'),
(27, 9, 3, 'Региональная часть программы', NULL, '', 10, '2014-10-29 14:29:47', '2014-10-29 14:29:47'),
(28, 10, 1, 'Общая часть программы', NULL, '', 28, '2014-10-29 14:35:00', '2014-10-29 14:35:00'),
(29, 10, 2, 'Специализированная часть программы', NULL, '', 30, '2014-10-29 14:37:41', '2014-10-29 14:37:41'),
(30, 10, 3, 'Региональная часть программы', NULL, '', 10, '2014-10-29 14:39:54', '2014-10-29 14:39:54'),
(31, 11, 1, 'Общая часть программы', NULL, '', 28, '2014-10-29 14:50:54', '2014-10-29 14:50:54'),
(32, 11, 2, 'Специализированная часть программы', NULL, '', 30, '2014-10-29 15:12:53', '2014-10-29 15:12:53'),
(33, 11, 3, 'Региональная часть программы', NULL, '', 10, '2014-10-29 15:14:07', '2014-10-29 15:14:07'),
(34, 12, 1, 'Общая часть программы', NULL, '', 28, '2014-10-29 15:17:23', '2014-10-29 15:17:23'),
(35, 12, 2, 'Специализированная часть программы', NULL, '', 30, '2014-10-29 15:18:49', '2014-10-29 15:18:49'),
(36, 12, 3, 'Региональная часть программы', NULL, '', 10, '2014-10-29 15:20:03', '2014-10-29 15:20:03'),
(37, 13, 1, 'Общая часть программы', NULL, '', 28, '2014-10-29 15:22:09', '2014-10-29 15:22:09'),
(38, 13, 2, 'Специализированная часть программы', NULL, '', 30, '2014-10-29 15:23:35', '2014-10-29 15:23:35'),
(39, 13, 3, 'Региональная часть программы', NULL, '', 10, '2014-10-29 15:25:49', '2014-10-29 15:25:49'),
(40, 14, 1, 'Общая часть программы', NULL, '', 28, '2014-10-29 15:28:17', '2014-10-29 15:28:17'),
(41, 14, 2, 'Специализированная часть программы', NULL, '', 30, '2014-10-29 15:30:59', '2014-10-29 15:30:59'),
(42, 14, 3, 'Региональная часть программы', NULL, '', 10, '2014-10-29 15:32:23', '2014-10-29 15:32:23'),
(43, 15, 1, 'Общая часть программы', NULL, '', 28, '2014-10-29 15:34:51', '2014-10-29 15:34:51'),
(44, 15, 2, 'Специализированная часть программы', NULL, '', 30, '2014-10-29 15:36:43', '2014-10-29 15:36:43'),
(45, 15, 3, 'Региональная часть программы', NULL, '', 10, '2014-10-29 15:37:48', '2014-10-29 15:37:48'),
(46, 16, 1, 'Общая часть программы', NULL, '', 30, '2014-10-29 15:39:50', '2014-10-29 15:39:50'),
(47, 16, 2, 'Специализированная часть программы', NULL, '', 38, '2014-10-29 15:42:10', '2014-10-29 15:42:10'),
(48, 17, 1, 'Общая часть программы', NULL, '', 30, '2014-10-29 15:43:39', '2014-10-29 15:43:39'),
(49, 17, 2, 'Специализированная часть программы', NULL, '', 38, '2014-10-29 15:45:24', '2014-10-29 15:45:24');

-- --------------------------------------------------------

--
-- Структура таблицы `courses`
--

DROP TABLE IF EXISTS `courses`;
CREATE TABLE IF NOT EXISTS `courses` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `direction_id` int(10) unsigned DEFAULT NULL,
  `order` int(10) unsigned DEFAULT NULL,
  `code` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `curriculum` text COLLATE utf8_unicode_ci,
  `price` float(8,2) unsigned DEFAULT '0.00',
  `discount` tinyint(4) DEFAULT '0',
  `use_discount` tinyint(1) DEFAULT '1',
  `hours` int(10) unsigned DEFAULT '0',
  `certificate` int(10) unsigned DEFAULT '0',
  `active` tinyint(1) unsigned DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `courses_direction_id_index` (`direction_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=18 ;

--
-- Дамп данных таблицы `courses`
--

INSERT INTO `courses` (`id`, `direction_id`, `order`, `code`, `title`, `description`, `curriculum`, `price`, `discount`, `use_discount`, `hours`, `certificate`, `active`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 'БС-00', 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства', '', '<p style="text-align: center;">\r\n	<strong>Учебный план <br>\r\n	</strong><strong style="background-color: initial;">дополнительной профессиональной программы</strong>\r\n</p>\r\n<p style="text-align: center;">\r\n	<strong>БС-00 «Строительство, реконструкция, капитальный ремонт объектов капитального строительства»</strong>\r\n</p>\r\n<table>\r\n<tbody>\r\n<tr>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			<strong>№№ п</strong>\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<h4 style="text-align: center;"><strong>Наименование учебных   модулей</strong></h4>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			<strong>Всего часов</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			                      1\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			                      2\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			                      3\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			<strong>Общая часть программы   (28 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			                      1\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			                      Модуль   №1. Законодательное и нормативное правовое обеспечение строительства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			                      6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			                      2\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			                      Модуль   №2. Организация инвестиционно-строительных процессов\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			                      6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			                      3\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			                      Модуль   №3. Экономика строительного производства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			                      6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			                      4\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			                      Модуль №4. Государственный строительный надзор и строительный контроль\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			                      10\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			                      Промежуточная аттестация знаний по модулям общей части программы\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			                      2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			<strong>Специализированная   часть программы (30 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			                      5\r\n		</p>\r\n	</td>\r\n	<td>\r\n		                 Модуль №5. Инновации в технологии выполнения общестроительных работ. Показатели и критерии качества выполнения общестроительных работ\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			                      24\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			                      6\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			                      Модуль   №6. Техника безопасности строительного производства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			                      6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			<strong>Региональная часть   программы (10 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			                      7\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			                      Модуль   №7. Региональные особенности организации строительства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			                      8\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			                      8\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			                      Модуль   №8. Особенности выполнения строительных работ в региональных условиях осуществления   строительства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			                      2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			                      Итоговая аттестация знаний по модулям   общей, специализированной и региональной частей программы\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			                      2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			<strong>Итого</strong>\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			<strong>72</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n</tbody>\r\n</table>', 4000.00, 96, 0, 72, 36, 1, '2014-10-29 12:08:46', '2014-12-11 12:56:38'),
(2, 1, 2, 'БС-01', 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (выполнение геодезических, подготовительных и земляных работ, устройства оснований и фундаментов)', '', '<p style="text-align: center;">\r\n	<strong>Учебный план <br>\r\n	</strong><strong style="background-color: initial;">дополнительной профессиональной программы</strong>\r\n</p>\r\n<p style="text-align: center;">\r\n	<strong>БС-01 «Строительство, реконструкция, капитальный ремонт объектов капитального строительства (выполнение геодезических, подготовительных и земляных работ, устройства оснований и фундаментов)»</strong>\r\n</p>\r\n<table>\r\n<tbody>\r\n<tr>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			<strong>№№ п</strong>\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<h4 style="text-align: center;"><strong>Наименование учебных   модулей</strong></h4>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			<strong>Всего часов</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              1\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              3\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			<strong>Общая часть программы   (28 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              1\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №1. Законодательное и нормативное правовое обеспечение строительства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              2\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №2. Организация инвестиционно-строительных процессов\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              3\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №3. Экономика строительного производства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              4\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль №4. Государственный строительный надзор и строительный контроль\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              10\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			              Промежуточная аттестация знаний по модулям общей части программы\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			<strong>Специализированная   часть программы (30 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              5\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			Модуль №5. Инновации в технологии геодезических, подготовительных и земляных работ, устройства оснований и фундаментов. Показатели и критерии качества выполнения геодезических, подготовительных и земляных работ, устройства оснований и фундаментов\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              24\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              6\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №6. Техника безопасности строительного производства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			<strong>Региональная часть   программы (10 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              7\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №7. Региональные особенности организации строительства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              8\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              8\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №8. Особенности выполнения строительных работ в региональных условиях осуществления   строительства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			              Итоговая аттестация знаний по модулям   общей, специализированной и региональной частей программы\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			<strong>Итого</strong>\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			<strong>72</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n</tbody>\r\n</table>', 4000.00, 0, 1, 72, 36, 1, '2014-10-29 12:33:23', '2014-12-10 08:59:22'),
(3, 1, 3, 'БС-02', 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (возведение бетонных и железобетонных конструкций)', '', '<p style="text-align: center;">\r\n	<strong>Учебный план <br>\r\n	</strong><strong style="background-color: initial;">дополнительной профессиональной программы</strong>\r\n</p>\r\n<p style="text-align: center;">\r\n	<strong>БС-02 «Строительство, реконструкция, капитальный ремонт объектов капитального строительства (возведение бетонных и железобетонных конструкций)»</strong>\r\n</p>\r\n<table>\r\n<tbody>\r\n<tr>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			<strong>№№ п</strong>\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<h4 style="text-align: center;"><strong>Наименование учебных   модулей</strong></h4>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			<strong>Всего часов</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              1\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              3\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			<strong>Общая часть программы   (28 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              1\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №1. Законодательное и нормативное правовое обеспечение строительства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              2\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №2. Организация инвестиционно-строительных процессов\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              3\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №3. Экономика строительного производства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              4\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль №4. Государственный строительный надзор и строительный контроль\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              10\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			              Промежуточная аттестация знаний по модулям общей части программы\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			<strong>Специализированная   часть программы (30 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              5\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			Модуль №5. Инновации в технологии возведения бетонных и железобетонных конструкций. Показатели и критерии качества возведения бетонных и железобетонных конструкций\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              24\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              6\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №6. Техника безопасности строительного производства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			<strong>Региональная часть   программы (10 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              7\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №7. Региональные особенности организации строительства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              8\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              8\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №8. Особенности выполнения строительных работ в региональных условиях осуществления   строительства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			              Итоговая аттестация знаний по модулям   общей, специализированной и региональной частей программы\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			<strong>Итого</strong>\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			<strong>72</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n</tbody>\r\n</table>', 4000.00, 0, 1, 72, 36, 1, '2014-10-29 12:41:37', '2014-10-31 15:00:45'),
(4, 1, 4, 'БС-03', 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (возведение каменных, металлических и деревянных строительных конструкций)', '', '<p style="text-align: center;">\r\n	 <strong>Учебный план <br>\r\n	 </strong><strong style="background-color: initial;">дополнительной профессиональной программы</strong>\r\n</p>\r\n<p style="text-align: center;">\r\n	 <strong>БС-03 «Строительство, реконструкция, капитальный ремонт объектов капитального строительства (возведение каменных, металлических и деревянных строительных конструкций)»</strong>\r\n</p>\r\n<table>\r\n<tbody>\r\n<tr>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			 <strong>№№ п</strong>\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<h4 style="text-align: center;"><strong>Наименование учебных   модулей</strong></h4>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			 <strong>Всего часов</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			               1\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			               2\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			               3\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			 <strong>Общая часть программы   (28 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			               1\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			               Модуль   №1. Законодательное и нормативное правовое обеспечение строительства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			               6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			               2\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			               Модуль   №2. Организация инвестиционно-строительных процессов\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			               6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			               3\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			               Модуль   №3. Экономика строительного производства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			               6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			               4\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			               Модуль №4. Государственный строительный надзор и строительный контроль\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			               10\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			               Промежуточная аттестация знаний по модулям общей части программы\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			               2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			 <strong>Специализированная   часть программы (30 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			               5\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			 Модуль №5. Инновации в технологии возведения каменных, металлических и деревянных строительных конструкций. Показатели и критерии качества возведения каменных, металлических и деревянных строительных конструкций\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			               24\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			               6\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			               Модуль   №6. Техника безопасности строительного производства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			               6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			 <strong>Региональная часть   программы (10 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			               7\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			               Модуль   №7. Региональные особенности организации строительства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			               8\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			               8\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			               Модуль   №8. Особенности выполнения строительных работ в региональных условиях осуществления   строительства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			               2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			               Итоговая аттестация знаний по модулям   общей, специализированной и региональной частей программы\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			               2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			 <strong>Итого</strong>\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			 <strong>72</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n</tbody>\r\n</table>', 4000.00, 0, 1, 72, 36, 1, '2014-10-29 12:48:42', '2014-10-31 15:03:21'),
(5, 1, 5, 'БС-04', 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (выполнение фасадных работ, устройство кровель, защита строительных конструкций, трубопроводов и оборудования)', '', '<p style="text-align: center;">\r\n	<strong>Учебный план <br>\r\n	</strong><strong style="background-color: initial;">дополнительной профессиональной программы</strong>\r\n</p>\r\n<p style="text-align: center;">\r\n	<strong>БС-04 «Строительство, реконструкция, капитальный ремонт объектов капитального строительства (выполнение фасадных работ, устройство кровель, защита строительных конструкций, трубопроводов и оборудования)»</strong>\r\n</p>\r\n<table>\r\n<tbody>\r\n<tr>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			<strong>№№ п</strong>\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<h4 style="text-align: center;"><strong>Наименование учебных   модулей</strong></h4>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			<strong>Всего часов</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              1\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              3\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			<strong>Общая часть программы   (28 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              1\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №1. Законодательное и нормативное правовое обеспечение строительства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              2\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №2. Организация инвестиционно-строительных процессов\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              3\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №3. Экономика строительного производства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              4\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль №4. Государственный строительный надзор и строительный контроль\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              10\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			              Промежуточная аттестация знаний по модулям общей части программы\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			<strong>Специализированная   часть программы (30 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              5\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			Модуль №5. Инновации в технологии обеспечения качества выполнения фасадных работ, устройства кровель, защиты строительных конструкций, трубопроводов и оборудования. Показатели и критерии качества выполнения фасадных работ, устройства кровель, защиты строительных конструкций, трубопроводов и оборудования\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              24\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              6\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №6. Техника безопасности строительного производства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			<strong>Региональная часть   программы (10 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              7\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №7. Региональные особенности организации строительства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              8\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              8\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №8. Особенности выполнения строительных работ в региональных условиях осуществления   строительства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			              Итоговая аттестация знаний по модулям   общей, специализированной и региональной частей программы\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			<strong>Итого</strong>\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			<strong>72</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n</tbody>\r\n</table>', 4000.00, 0, 1, 72, 36, 1, '2014-10-29 13:20:47', '2014-10-31 15:12:20'),
(6, 1, 6, 'БС-05', 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (устройство инженерных систем и сетей)', '', '<p style="text-align: center;">\r\n	<strong>Учебный план <br>\r\n	</strong><strong style="background-color: initial;">дополнительной профессиональной программы</strong>\r\n</p>\r\n<p style="text-align: center;">\r\n	<strong>БС-05 «Строительство, реконструкция, капитальный ремонт объектов капитального строительства (устройство инженерных систем и сетей)»</strong>\r\n</p>\r\n<table>\r\n<tbody>\r\n<tr>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			<strong>№№ п</strong>\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<h4 style="text-align: center;"><strong>Наименование учебных   модулей</strong></h4>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			<strong>Всего часов</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              1\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              3\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			<strong>Общая часть программы   (28 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              1\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №1. Законодательное и нормативное правовое обеспечение строительства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              2\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №2. Организация инвестиционно-строительных процессов\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              3\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №3. Экономика строительного производства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              4\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль №4. Государственный строительный надзор и строительный контроль\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              10\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			              Промежуточная аттестация знаний по модулям общей части программы\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			<strong>Специализированная   часть программы (30 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              5\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			Модуль №5. Инновации в технологии устройства инженерных систем и сетей. Показатели и критерии качества устройства инженерных систем и сетей\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              24\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              6\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №6. Техника безопасности строительного производства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			<strong>Региональная часть   программы (10 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              7\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №7. Региональные особенности организации строительства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              8\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              8\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №8. Особенности выполнения строительных работ в региональных условиях осуществления   строительства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			              Итоговая аттестация знаний по модулям   общей, специализированной и региональной частей программы\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			<strong>Итого</strong>\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			<strong>72</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n</tbody>\r\n</table>', 4000.00, 0, 1, 72, 36, 1, '2014-10-29 13:38:24', '2014-10-31 15:14:06'),
(7, 1, 7, 'БС-06', 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (устройство электрических сетей и линий связи)', '', '<p style="text-align: center;">\r\n	<strong>Учебный план <br>\r\n	</strong><strong style="background-color: initial;">дополнительной профессиональной программы</strong>\r\n</p>\r\n<p style="text-align: center;">\r\n	<strong>БС-06 «Строительство, реконструкция, капитальный ремонт объектов капитального строительства (устройство электрических сетей и линий связи)»</strong>\r\n</p>\r\n<table>\r\n<tbody>\r\n<tr>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			<strong>№№ п</strong>\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<h4 style="text-align: center;"><strong>Наименование учебных   модулей</strong></h4>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			<strong>Всего часов</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              1\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              3\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			<strong>Общая часть программы   (28 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              1\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №1. Законодательное и нормативное правовое обеспечение строительства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              2\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №2. Организация инвестиционно-строительных процессов\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              3\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №3. Экономика строительного производства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              4\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль №4. Государственный строительный надзор и строительный контроль\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              10\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			              Промежуточная аттестация знаний по модулям общей части программы\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			<strong>Специализированная   часть программы (30 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              5\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			Модуль №5. Инновации в технологии устройства электрических сетей и линий связи. Показатели и критерии качества устройства электрических сетей и линий связи\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              24\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              6\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №6. Техника безопасности строительного производства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			<strong>Региональная часть   программы (10 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              7\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №7. Региональные особенности организации строительства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              8\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              8\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №8. Особенности выполнения строительных работ в региональных условиях осуществления   строительства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			              Итоговая аттестация знаний по модулям   общей, специализированной и региональной частей программы\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			<strong>Итого</strong>\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			<strong>72</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n</tbody>\r\n</table>', 4000.00, 0, 1, 72, 36, 1, '2014-10-29 13:45:11', '2014-10-31 15:15:43'),
(8, 1, 8, 'БС-07', 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (устройство объектов нефтяной и газовой промышленности, устройство скважин)', '', '<p style="text-align: center;">\r\n	<strong>Учебный план <br>\r\n	</strong><strong style="background-color: initial;">дополнительной профессиональной программы</strong>\r\n</p>\r\n<p style="text-align: center;">\r\n	<strong>БС-07 «Строительство, реконструкция, капитальный ремонт объектов капитального строительства (устройство объектов нефтяной и газовой промышленности, устройство скважин)»</strong>\r\n</p>\r\n<table>\r\n<tbody>\r\n<tr>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			<strong>№№ п</strong>\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<h4 style="text-align: center;"><strong>Наименование учебных   модулей</strong></h4>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			<strong>Всего часов</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              1\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              3\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			<strong>Общая часть программы   (28 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              1\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №1. Законодательное и нормативное правовое обеспечение строительства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              2\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №2. Организация инвестиционно-строительных процессов\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              3\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №3. Экономика строительного производства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              4\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль №4. Государственный строительный надзор и строительный контроль\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              10\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			              Промежуточная аттестация знаний по модулям общей части программы\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			<strong>Специализированная   часть программы (30 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              5\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			Модуль №5. Инновации в технологии устройства объектов нефтяной и газовой промышленности, устройства скважин. Показатели и критерии качества устройства объектов нефтяной и газовой промышленности, устройства скважин\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              24\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              6\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №6. Техника безопасности строительного производства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			<strong>Региональная часть   программы (10 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              7\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №7. Региональные особенности организации строительства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              8\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              8\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №8. Особенности выполнения строительных работ в региональных условиях осуществления   строительства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			              Итоговая аттестация знаний по модулям   общей, специализированной и региональной частей программы\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			<strong>Итого</strong>\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			<strong>72</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n</tbody>\r\n</table>', 4000.00, 0, 1, 72, 36, 1, '2014-10-29 14:05:57', '2014-10-31 15:17:27');
INSERT INTO `courses` (`id`, `direction_id`, `order`, `code`, `title`, `description`, `curriculum`, `price`, `discount`, `use_discount`, `hours`, `certificate`, `active`, `created_at`, `updated_at`) VALUES
(9, 1, 9, 'БС-08', 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (выполнение монтажных и пусконаладочных работ)', '', '<p style="text-align: center;">\r\n	 <strong>Учебный план <br>\r\n	 </strong><strong style="background-color: initial;">дополнительной профессиональной программы</strong>\r\n</p>\r\n<p style="text-align: center;">\r\n	 <strong>БС-08 «Строительство, реконструкция, капитальный ремонт объектов капитального строительства (выполнение монтажных и пусконаладочных работ)»</strong>\r\n</p>\r\n<table>\r\n<tbody>\r\n<tr>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			 <strong>№№ п</strong>\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<h4 style="text-align: center;"><strong>Наименование учебных   модулей</strong></h4>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			 <strong>Всего часов</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			               1\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			               2\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			               3\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			 <strong>Общая часть программы   (28 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			               1\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			               Модуль   №1. Законодательное и нормативное правовое обеспечение строительства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			               6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			               2\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			               Модуль   №2. Организация инвестиционно-строительных процессов\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			               6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			               3\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			               Модуль   №3. Экономика строительного производства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			               6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			               4\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			               Модуль №4. Государственный строительный надзор и строительный контроль\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			               10\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			               Промежуточная аттестация знаний по модулям общей части программы\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			               2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			 <strong>Специализированная   часть программы (30 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			               5\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			 Модуль №5. Инновации в технологии выполнения монтажных и пусконаладочных работ лифтового оборудования. Показатели и критерии качества выполнения монтажных и пусконаладочных работ лифтового оборудования\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			               24\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			               6\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			               Модуль   №6. Техника безопасности строительного производства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			               6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			 <strong>Региональная часть   программы (10 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			               7\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			               Модуль   №7. Региональные особенности организации строительства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			               8\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			               8\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			               Модуль   №8. Особенности выполнения строительных работ в региональных условиях осуществления   строительства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			               2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			               Итоговая аттестация знаний по модулям   общей, специализированной и региональной частей программы\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			               2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			 <strong>Итого</strong>\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			 <strong>72</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n</tbody>\r\n</table>', 4000.00, 0, 1, 72, 36, 1, '2014-10-29 14:23:31', '2014-10-31 15:22:43'),
(10, 1, 10, 'БС-09', 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (устройство автомобильных дорог и аэродромов)', '', '<p style="text-align: center;">\r\n	<strong>Учебный план <br>\r\n	</strong><strong style="background-color: initial;">дополнительной профессиональной программы</strong>\r\n</p>\r\n<p style="text-align: center;">\r\n	<strong>БС-09 «Строительство, реконструкция, капитальный ремонт объектов капитального строительства (устройство автомобильных дорог и аэродромов)»</strong>\r\n</p>\r\n<table>\r\n<tbody>\r\n<tr>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			<strong>№№ п</strong>\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<h4 style="text-align: center;"><strong>Наименование учебных   модулей</strong></h4>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			<strong>Всего часов</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              1\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              3\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			<strong>Общая часть программы   (28 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              1\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №1. Законодательное и нормативное правовое обеспечение строительства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              2\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №2. Организация инвестиционно-строительных процессов\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              3\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №3. Экономика строительного производства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              4\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль №4. Государственный строительный надзор и строительный контроль\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              10\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			              Промежуточная аттестация знаний по модулям общей части программы\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			<strong>Специализированная   часть программы (30 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              5\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			Модуль №5. Инновации в технологии устройства автомобильных дорог и аэродромов. Показатели и критерии качества устройства автомобильных дорог и аэродромов\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              24\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              6\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №6. Техника безопасности строительного производства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			<strong>Региональная часть   программы (10 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              7\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №7. Региональные особенности организации строительства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              8\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              8\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №8. Особенности выполнения строительных работ в региональных условиях осуществления   строительства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			              Итоговая аттестация знаний по модулям   общей, специализированной и региональной частей программы\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			<strong>Итого</strong>\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			<strong>72</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n</tbody>\r\n</table>', 4000.00, 0, 1, 72, 36, 1, '2014-10-29 14:32:22', '2014-10-31 15:24:31'),
(11, 1, 11, 'БС-10', 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (устройство железнодорожных и трамвайных путей)', '', '<p style="text-align: center;">\r\n	<strong>Учебный план <br>\r\n	</strong><strong style="background-color: initial;">дополнительной профессиональной программы</strong>\r\n</p>\r\n<p style="text-align: center;">\r\n	<strong>БС-10 «Строительство, реконструкция, капитальный ремонт объектов капитального строительства (устройство железнодорожных и трамвайных путей)»</strong>\r\n</p>\r\n<table>\r\n<tbody>\r\n<tr>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			<strong>№№ п</strong>\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<h4 style="text-align: center;"><strong>Наименование учебных   модулей</strong></h4>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			<strong>Всего часов</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              1\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              3\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			<strong>Общая часть программы   (28 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              1\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №1. Законодательное и нормативное правовое обеспечение строительства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              2\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №2. Организация инвестиционно-строительных процессов\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              3\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №3. Экономика строительного производства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              4\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль №4. Государственный строительный надзор и строительный контроль\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              10\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			              Промежуточная аттестация знаний по модулям общей части программы\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			<strong>Специализированная   часть программы (30 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              5\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			Модуль №5. Инновации в технологии устройства железнодорожных и трамвайных путей. Показатели и критерии качества устройства железнодорожных и трамвайных путей\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              24\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              6\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №6. Техника безопасности строительного производства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			<strong>Региональная часть   программы (10 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              7\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №7. Региональные особенности организации строительства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              8\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              8\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №8. Особенности выполнения строительных работ в региональных условиях осуществления   строительства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			              Итоговая аттестация знаний по модулям   общей, специализированной и региональной частей программы\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			<strong>Итого</strong>\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			<strong>72</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n</tbody>\r\n</table>', 4000.00, 0, 1, 72, 36, 1, '2014-10-29 14:43:57', '2014-10-31 15:26:10'),
(12, 1, 12, 'БС-11', 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (устройство подземных сооружений, осуществление специальных земляных и буровзрывных работ при строительстве)', '', '<p style="text-align: center;">\r\n	<strong>Учебный план <br>\r\n	</strong><strong style="background-color: initial;">дополнительной профессиональной программы</strong>\r\n</p>\r\n<p style="text-align: center;">\r\n	<strong>БС-11 «Строительство, реконструкция, капитальный ремонт объектов капитального строительства (устройство подземных сооружений, осуществление специальных земляных и буровзрывных работ при строительстве)»</strong>\r\n</p>\r\n<table>\r\n<tbody>\r\n<tr>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			<strong>№№ п</strong>\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<h4 style="text-align: center;"><strong>Наименование учебных   модулей</strong></h4>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			<strong>Всего часов</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              1\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              3\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			<strong>Общая часть программы   (28 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              1\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №1. Законодательное и нормативное правовое обеспечение строительства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              2\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №2. Организация инвестиционно-строительных процессов\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              3\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №3. Экономика строительного производства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              4\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль №4. Государственный строительный надзор и строительный контроль\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              10\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			              Промежуточная аттестация знаний по модулям общей части программы\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			<strong>Специализированная   часть программы (30 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              5\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			Модуль №5. Инновации в технологии устройства подземных сооружений, осуществления специальных земляных и буровзрывных работ при строительстве. Показатели и критерии качества устройства подземных сооружений, осуществления специальных земляных и буровзрывных работ при строительстве\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              24\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              6\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №6. Техника безопасности строительного производства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			<strong>Региональная часть   программы (10 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              7\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №7. Региональные особенности организации строительства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              8\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              8\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №8. Особенности выполнения строительных работ в региональных условиях осуществления   строительства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			              Итоговая аттестация знаний по модулям   общей, специализированной и региональной частей программы\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			<strong>Итого</strong>\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			<strong>72</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n</tbody>\r\n</table>', 4000.00, 0, 1, 72, 36, 1, '2014-10-29 15:16:51', '2014-10-31 15:35:59'),
(13, 1, 13, 'БС-12', 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (устройство мостов, эстакад и путепроводов)', '', '<p style="text-align: center;">\r\n	<strong>Учебный план <br>\r\n	</strong><strong style="background-color: initial;">дополнительной профессиональной программы</strong>\r\n</p>\r\n<p style="text-align: center;">\r\n	<strong>БС-12 «Строительство, реконструкция, капитальный ремонт объектов капитального строительства (устройство мостов, эстакад и путепроводов)»</strong>\r\n</p>\r\n<table>\r\n<tbody>\r\n<tr>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			<strong>№№ п</strong>\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<h4 style="text-align: center;"><strong>Наименование учебных   модулей</strong></h4>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			<strong>Всего часов</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              1\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              3\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			<strong>Общая часть программы   (28 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              1\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №1. Законодательное и нормативное правовое обеспечение строительства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              2\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №2. Организация инвестиционно-строительных процессов\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              3\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №3. Экономика строительного производства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              4\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль №4. Государственный строительный надзор и строительный контроль\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              10\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			              Промежуточная аттестация знаний по модулям общей части программы\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			<strong>Специализированная   часть программы (30 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              5\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			Модуль №5. Инновации в технологии устройства мостов, эстакад, путепроводов. Показатели и критерии качества устройства мостов, эстакад, путепроводов\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              24\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              6\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №6. Техника безопасности строительного производства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			<strong>Региональная часть   программы (10 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              7\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №7. Региональные особенности организации строительства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              8\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              8\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №8. Особенности выполнения строительных работ в региональных условиях осуществления   строительства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			              Итоговая аттестация знаний по модулям   общей, специализированной и региональной частей программы\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			<strong>Итого</strong>\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			<strong>72</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n</tbody>\r\n</table>', 4000.00, 0, 1, 72, 36, 1, '2014-10-29 15:21:49', '2014-10-31 15:37:20'),
(14, 1, 14, 'БС-13', 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (выполнение гидротехнических, водолазных работ)', '', '<p style="text-align: center;">\r\n	<strong>Учебный план <br>\r\n	</strong><strong style="background-color: initial;">дополнительной профессиональной программы</strong>\r\n</p>\r\n<p style="text-align: center;">\r\n	<strong>БС-13 «Строительство, реконструкция, капитальный ремонт объектов капитального строительства (выполнение гидротехнических, водолазных работ)»</strong>\r\n</p>\r\n<table>\r\n<tbody>\r\n<tr>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			<strong>№№ п</strong>\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<h4 style="text-align: center;"><strong>Наименование учебных   модулей</strong></h4>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			<strong>Всего часов</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              1\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              3\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			<strong>Общая часть программы   (28 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              1\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №1. Законодательное и нормативное правовое обеспечение строительства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              2\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №2. Организация инвестиционно-строительных процессов\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              3\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №3. Экономика строительного производства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              4\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль №4. Государственный строительный надзор и строительный контроль\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              10\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			              Промежуточная аттестация знаний по модулям общей части программы\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			<strong>Специализированная   часть программы (30 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              5\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			Модуль №5. Инновации в технологии выполнения гидротехнических и водолазных работ. Показатели и критерии качества выполнения гидротехнических и водолазных работ\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              24\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              6\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №6. Техника безопасности строительного производства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			<strong>Региональная часть   программы (10 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              7\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №7. Региональные особенности организации строительства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              8\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              8\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №8. Особенности выполнения строительных работ в региональных условиях осуществления   строительства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			              Итоговая аттестация знаний по модулям   общей, специализированной и региональной частей программы\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			<strong>Итого</strong>\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			<strong>72</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n</tbody>\r\n</table>', 4000.00, 0, 1, 72, 36, 1, '2014-10-29 15:27:53', '2014-10-31 15:39:09'),
(15, 1, 15, 'БС-14', 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (устройство промышленных печей и дымовых труб)', '', '<p style="text-align: center;">\r\n	<strong>Учебный план <br>\r\n	</strong><strong style="background-color: initial;">дополнительной профессиональной программы</strong>\r\n</p>\r\n<p style="text-align: center;">\r\n	<strong>БС-14 «Строительство, реконструкция, капитальный ремонт объектов капитального строительства (устройство промышленных печей и дымовых труб)»</strong>\r\n</p>\r\n<table>\r\n<tbody>\r\n<tr>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			<strong>№№ п</strong>\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<h4 style="text-align: center;"><strong>Наименование учебных   модулей</strong></h4>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			<strong>Всего часов</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              1\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              3\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			<strong>Общая часть программы   (28 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              1\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №1. Законодательное и нормативное правовое обеспечение строительства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              2\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №2. Организация инвестиционно-строительных процессов\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              3\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №3. Экономика строительного производства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              4\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль №4. Государственный строительный надзор и строительный контроль\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              10\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			              Промежуточная аттестация знаний по модулям общей части программы\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			<strong>Специализированная   часть программы (30 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              5\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			Модуль №5. Инновации в технологии устройства промышленных печей и домовых труб. Показатели и критерии качества устройства промышленных печей и дымовых труб\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              24\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              6\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №6. Техника безопасности строительного производства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			<strong>Региональная часть   программы (10 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              7\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №7. Региональные особенности организации строительства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              8\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              8\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №8. Особенности выполнения строительных работ в региональных условиях осуществления   строительства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			              Итоговая аттестация знаний по модулям   общей, специализированной и региональной частей программы\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			<strong>Итого</strong>\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			<strong>72</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n</tbody>\r\n</table>', 4000.00, 0, 1, 72, 36, 1, '2014-10-29 15:34:16', '2014-10-31 15:46:56'),
(16, 1, 16, 'БС-15', 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (осуществление строительного контроля)', '', '<p style="text-align: center;">\r\n	<strong>Учебный план <br>\r\n	</strong><strong style="background-color: initial;">дополнительной профессиональной программы</strong>\r\n</p>\r\n<p style="text-align: center;">\r\n	<strong>БС-15 «Строительство, реконструкция, капитальный ремонт объектов капитального строительства (осуществление строительного контроля)»</strong>\r\n</p>\r\n<table>\r\n<tbody>\r\n<tr>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			<strong>№№ п</strong>\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<h4 style="text-align: center;"><strong>Наименование учебных   модулей</strong></h4>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			<strong>Всего часов</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              1\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              3\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			<strong>Общая часть программы   (30 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              1\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №1. Законодательное и нормативное правовое обеспечение строительства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              2\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №2. Организация инвестиционно-строительных процессов\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              3\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №3. Экономика строительного производства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              4\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль №4. Техника безопасности строительного производства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		5\r\n	</td>\r\n	<td>\r\n		Модуль №5. Региональные особенности организации строительства\r\n	</td>\r\n	<td>\r\n		6\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			              Промежуточная аттестация знаний по модулям общей части программы\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			<strong>Специализированная   часть программы (38 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<span style="background-color: initial;">5</span>\r\n	</td>\r\n	<td>\r\n		         Модуль №6. Осуществление строительного контроля\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			38\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			              Итоговая аттестация знаний по модулям   общей, специализированной и региональной частей программы\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			<strong>Итого</strong>\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			<strong>72</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n</tbody>\r\n</table>', 4000.00, 0, 1, 72, 36, 1, '2014-10-29 15:39:26', '2014-10-31 16:30:00');
INSERT INTO `courses` (`id`, `direction_id`, `order`, `code`, `title`, `description`, `curriculum`, `price`, `discount`, `use_discount`, `hours`, `certificate`, `active`, `created_at`, `updated_at`) VALUES
(17, 1, 17, 'БС-16', 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (организация строительства)', '', '<p style="text-align: center;">\r\n	<strong>Учебный план <br>\r\n	</strong><strong style="background-color: initial;">дополнительной профессиональной программы</strong>\r\n</p>\r\n<p style="text-align: center;">\r\n	<strong>БС-16 «Строительство, реконструкция, капитальный ремонт объектов капитального строительства (организация строительства)»</strong>\r\n</p>\r\n<table>\r\n<tbody>\r\n<tr>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			<strong>№№ п</strong>\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<h4 style="text-align: center;"><strong>Наименование учебных   модулей</strong></h4>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			<strong>Всего часов</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              1\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              3\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			<strong>Общая часть программы   (30 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              1\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №1. Законодательное и нормативное правовое обеспечение строительства\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              2\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №2. <span style="background-color: initial;">Экономика строительного производства</span>\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              3\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль   №3. <span style="background-color: initial;">Государственный с</span><span style="background-color: initial;">троительный надзор и строительный контроль</span>\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			              4\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p>\r\n			              Модуль №4. <span style="background-color: initial;">Техника безопасности строительного производства</span>\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			6\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		5\r\n	</td>\r\n	<td>\r\n		<span style="background-color: initial;">Модуль №5. Региональные особенности организации строительства</span>\r\n	</td>\r\n	<td>\r\n		6\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			              Промежуточная аттестация знаний по модулям общей части программы\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3">\r\n		<p style="text-align: center;">\r\n			<strong>Специализированная   часть программы (38 часов)</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			6\r\n		</p>\r\n	</td>\r\n	<td>\r\n		         Модуль №6. Организация строительства\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			38\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			              Итоговая аттестация знаний по модулям   общей, специализированной и региональной частей программы\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			              2\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2">\r\n		<p>\r\n			<strong>Итого</strong>\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<p style="text-align: center;">\r\n			<strong>72</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n</tbody>\r\n</table>', 4000.00, 0, 1, 72, 36, 1, '2014-10-29 15:43:16', '2014-10-31 16:33:50');

-- --------------------------------------------------------

--
-- Структура таблицы `course_metodical`
--

DROP TABLE IF EXISTS `course_metodical`;
CREATE TABLE IF NOT EXISTS `course_metodical` (
  `id` int(10) unsigned NOT NULL,
  `course_id` int(10) unsigned DEFAULT NULL,
  `order` int(10) unsigned DEFAULT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `document_id` int(10) unsigned DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `dictionary`
--

DROP TABLE IF EXISTS `dictionary`;
CREATE TABLE IF NOT EXISTS `dictionary` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entity` tinyint(1) unsigned DEFAULT NULL,
  `icon_class` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `hide_slug` tinyint(1) unsigned DEFAULT NULL,
  `make_slug_from_name` tinyint(1) unsigned DEFAULT NULL,
  `name_title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pagination` int(10) unsigned NOT NULL DEFAULT '0',
  `view_access` smallint(5) unsigned DEFAULT NULL,
  `sort_by` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sort_order_reverse` smallint(5) unsigned NOT NULL DEFAULT '0',
  `sortable` smallint(5) unsigned NOT NULL DEFAULT '1',
  `order` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `dictionary_slug_unique` (`slug`),
  KEY `dictionary_name_index` (`name`),
  KEY `dictionary_entity_index` (`entity`),
  KEY `dictionary_view_access_index` (`view_access`),
  KEY `dictionary_order_index` (`order`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=10 ;

--
-- Дамп данных таблицы `dictionary`
--

INSERT INTO `dictionary` (`id`, `slug`, `name`, `entity`, `icon_class`, `hide_slug`, `make_slug_from_name`, `name_title`, `pagination`, `view_access`, `sort_by`, `sort_order_reverse`, `sortable`, `order`, `created_at`, `updated_at`) VALUES
(1, 'actions-types', 'Типы событий', 1, 'fa-bolt', 1, NULL, 'Название типа события', 0, 1, NULL, 0, 1, 0, '2014-10-29 08:18:38', '2014-11-06 14:52:40'),
(2, 'actions-history', 'История событий', 1, 'fa-bell', 1, 1, '', 30, 1, 'created_at', 1, 0, 0, '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(3, 'reviews', 'Отзывы', 1, 'fa-comments-o', 1, 1, 'Имя пользователя оставившего отзыв', 30, 0, 'created_at', 1, 1, 0, '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(4, 'information-baners', 'Инф.банеры', 1, 'fa-info', 1, 1, 'Название банера', 30, 0, 'created_at', 1, 1, 0, '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(5, 'properties-site', 'Настройка сайта', 1, 'fa-wrench', 1, NULL, 'Название свойства', 0, 1, NULL, 0, 0, 0, '2014-10-29 08:18:38', '2014-11-06 14:51:58'),
(6, 'order-documents', 'Документы', 1, 'fa-clipboard', NULL, NULL, 'Название документа', 0, 2, 'name', 0, 1, 0, '2014-10-29 08:18:38', '2014-11-10 15:21:33'),
(7, 'types-system-messages', 'Типы СС', 1, 'fa-bolt', 1, NULL, 'Текст сообщения', 0, 1, NULL, 0, 1, 0, '2014-11-05 14:26:33', '2014-11-06 14:52:19'),
(8, 'system-messages', 'Системные сообщения', 0, 'fa-bolt', 1, 1, 'Текст сообщения', 30, 1, 'created_at', 1, 1, 0, '2014-11-05 14:26:33', '2014-11-05 14:26:33'),
(9, 'licenses-certificates', 'Сертификаты', 1, 'fa-picture-o', 1, 1, 'Название', 0, NULL, NULL, 0, 1, NULL, '2014-12-11 15:33:34', '2014-12-11 15:27:36');

-- --------------------------------------------------------

--
-- Структура таблицы `dictionary_fields_values`
--

DROP TABLE IF EXISTS `dictionary_fields_values`;
CREATE TABLE IF NOT EXISTS `dictionary_fields_values` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `dicval_id` int(10) unsigned DEFAULT NULL,
  `language` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `value` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `dictionary_fields_values_dicval_id_index` (`dicval_id`),
  KEY `dictionary_fields_values_language_index` (`language`),
  KEY `dictionary_fields_values_key_index` (`key`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1818 ;

--
-- Дамп данных таблицы `dictionary_fields_values`
--

INSERT INTO `dictionary_fields_values` (`id`, `dicval_id`, `language`, `key`, `value`, `created_at`, `updated_at`) VALUES
(1, 33, NULL, 'variables', '', '2014-10-30 12:10:23', '2014-10-30 12:10:23'),
(2, 33, NULL, 'content', '<p align="center">\r\n	<strong>Договор №{{ @$NomerZakaza }} ЭПК</strong>\r\n</p>\r\n<p align="center">\r\n	<strong>на оказание платных образовательных услуг</strong>\r\n</p>\r\n<p>\r\n	            г. Ростов-на-Дону\r\n</p>\r\n<p style="text-align: right;">\r\n	           {{ @$DataOformleniyaZakazaSlovami }}\r\n</p>\r\n<p>\r\n	            Автономная некоммерческая организация дополнительного профессионального образования «Центр качества строительства» (далее – АНО ДПО «ЦКС»), именуемая в дальнейшем Исполнитель, в лице руководителя Шумеева Павла Андреевича, действующего на основании Устава, с одной стороны, и {{ @$NazvanieOrganizacii }}, именуемое в дальнейшем Заказчик, в лице {{ @$DoljnostOtvetstvennogoLicaOrganizacii }} {{ @$ImyaOtvetstvennogoLicaOrganizacii }}, действующего на основании {{ @$DeystvuyucheeOsnovanieOrganizacii }} с другой стороны, вместе именуемые Стороны, заключили настоящий договор (далее - Договор) о нижеследующем:\r\n</p>\r\n<p align="center">\r\n	<strong> </strong>\r\n</p>\r\n<p align="center">\r\n	<strong>1. </strong><strong>Предмет договора</strong>\r\n</p>\r\n<p>\r\n	                         1.1. Исполнитель обязуется предоставить сотрудникам Заказчика (далее – Слушатели) платные образовательные услуги по повышению квалификации в соответствии с утвержденными дополнительными профессиональными программами (далее – ДПП) согласно Приложению №1 (далее – прил. №1), а Заказчик обязуется оплатить данные образовательные услуги.\r\n</p>\r\n<p>\r\n	                         1.2. Повышение квалификации слушателей проводится на основании лицензии на осуществление образовательной деятельности, выданной Региональной службой по надзору и контролю в сфере образования Ростовской области 18.11.2014, серия 61Л01 № 0001674, рег. № 4097.\r\n</p>\r\n<p>\r\n	                         1.3. Общий объем ДПП – 72 часа.\r\n</p>\r\n<p>\r\n	                         1.4. Срок освоения ДПП – 9 дней.\r\n</p>\r\n<p>\r\n	                         1.5. Форма обучения – заочная.\r\n</p>\r\n<p>\r\n	                         1.6. По результатам обучения (при условии успешного освоения ДПП) Исполнитель выдает каждому Слушателю удостоверение о повышении квалификации установленного образца по соответствующей ДПП, указанной в прил. №1.\r\n</p>\r\n<p align="center">\r\n	 <strong>2. Права и обязанности Исполнителя, Заказчика и Слушателя</strong>\r\n</p>\r\n<p>\r\n	                   2.1. Права и обязанности Исполнителя.\r\n</p>\r\n<p>\r\n	                   2.1.1. Исполнитель самостоятельно осуществляет образовательный процесс, выбирает системы оценок, формы, порядок и периодичность аттестации Слушателей.\r\n</p>\r\n<p>\r\n	                   2.1.2. Исполнитель имеет право потребовать от Заказчика в письменном виде информацию и разъяснения по любому вопросу, связанному с выполнением         обязательств Исполнителя по договору.\r\n</p>\r\n<p>\r\n	                   2.1.3. Исполнитель обязан обеспечить Заказчику оказание платных образовательных услуг в полном объеме в соответствии с образовательными программами,         утвержденными Исполнителем, и условиями договора.\r\n</p>\r\n<p>\r\n	                   2.1.4. Исполнитель обеспечивает Слушателя учебно-методическими материалами в электронной форме по соответствующей ДПП согласно прил. №1.\r\n</p>\r\n<p>\r\n	                   2.1.5. Исполнитель обязан довести до Заказчика информацию, содержащую сведения о предоставлении платных образовательных услуг в порядке и объеме,         которые предусмотрены Законом Российской Федерации «О защите прав потребителей» и Федеральным законом «Об образовании в Российской Федерации».\r\n</p>\r\n<p>\r\n	                   2.2. Права и обязанности Заказчика.\r\n</p>\r\n<p>\r\n	                   2.2.1. При нарушении Исполнителем сроков оказания платных образовательных услуг (сроков начала и (или) окончания оказания платных образовательных услуг         и (или) промежуточных сроков оказания платной образовательной услуги) Заказчик вправе по своему выбору:\r\n</p>\r\n<p>\r\n	                   - назначить исполнителю новый срок, в течение которого исполнитель должен приступить к оказанию платных образовательных услуг и (или) закончить         оказание платных образовательных услуг;\r\n</p>\r\n<p>\r\n	                   - потребовать уменьшения стоимости платных образовательных услуг.\r\n</p>\r\n<p>\r\n	                   2.2.2. Заказчик обязан оплатить услуги Исполнителя в размере и сроки, предусмотренные условиями договора.\r\n</p>\r\n<p>\r\n	                   2.2.3. Заказчик обязан соблюдать установленный Исполнителем порядок обучения (повышения квалификации).\r\n</p>\r\n<p>\r\n	                   2.2.4. Заказчик обязан в 3-дневный срок с момента получения от Исполнителя запроса предоставлять информацию и разъяснения по любому вопросу, связанному         с выполнением обязательств Исполнителя по договору.\r\n</p>\r\n<p>\r\n	                   2.2.5. Заказчик обязан контролировать освоение Слушателем ДПП в полном объеме (72 часа), а также прохождение слушателем промежуточной и итоговой         аттестаций.\r\n</p>\r\n<p>\r\n	                   2.3. Права и обязанности Слушателя.\r\n</p>\r\n<p>\r\n	                   2.3.1. Слушатель имеет право на бесплатное пользование электронными фондами библиотеки АНО ДПО «ЦКС».\r\n</p>\r\n<p>\r\n	                   2.3.2. Слушатель имеет право своевременно получать информацию об образовательном процессе в необходимом объеме, установленном законодательством.\r\n</p>\r\n<p>\r\n	                   2.3.3. Слушатель имеет право на объективную оценку в соответствии со своими знаниями, умением и навыками.\r\n</p>\r\n<p>\r\n	                   2.3.4. Слушатель имеет право на получение соответствующих документов об уровне образования после итоговой аттестации.\r\n</p>\r\n<p>\r\n	                   2.3.5. Слушатель обязан соблюдать установленный Исполнителем порядок обучения (повышения квалификации), а также порядки и положения, установленные         Исполнителем иными локальными актами.\r\n</p>\r\n<p>\r\n	                   2.3.6. Слушатель обязан выполнять в установленные сроки все виды заданий, предусмотренные программой, в том числе выполнять задания для самостоятельной         подготовки, самостоятельно проходить промежуточную и итоговую аттестацию.\r\n</p>\r\n<p align="center">\r\n	<strong>3.Стоимость образовательных услуг и порядок оплаты</strong>\r\n</p>\r\n<p>\r\n	                 3.1. За оказание образовательных услуг по повышению квалификации Заказчик оплачивает Исполнителю сумму в размере 10 000 рублей (Десять тысяч рублей) за         1 (одного) слушателя. НДС не облагается на основании п.2 ст.346.11 НК РФ. Стоимость установлена в соответствии с условиями Акции*.\r\n</p>\r\n<p>\r\n	                 3.2. Оплата образовательных услуг в размере, указанном в п.3.1 Договора, осуществляется в течении 3 (трех) банковских дней с момента подписания         Договора.\r\n</p>\r\n<p align="center">\r\n	<strong>4. </strong><strong>Порядок изменения и расторжения договора</strong><strong></strong>\r\n</p>\r\n<p>\r\n	                 4.1. Условия, на которых заключен настоящий договор, могут быть изменены либо по соглашению сторон, либо в соответствии с действующим законодательством         Российской Федерации. Все изменения оформляются в письменном виде путем подписания Сторонами дополнительных соглашений к настоящему договору. Все         приложения и дополнительные соглашения являются неотъемлемой частью договора. Дополнительные соглашения к настоящему договору вступают в силу с момента         их подписания Сторонами.\r\n</p>\r\n<p>\r\n	                 4.2. Настоящий договор может быть расторгнут по обоюдному соглашению сторон.\r\n</p>\r\n<p>\r\n	                 4.3. Заказчик вправе в одностороннем порядке отказаться от исполнения настоящего договора, предупредив об этом Исполнителя в письменной форме. В случае         отказа Заказчика от исполнения договора до начала обучения (повышения квалификации), уплаченная сумма возвращается ему в полном размере. В случае         отказа Заказчика от выполнения настоящего договора после начала обучения (повышения квалификации), а также в случае не сдачи итоговой аттестации         (тестирования) Слушателями, уплаченная сумма не возвращается.\r\n</p>\r\n<p>\r\n	                 4.4. При нарушении Исполнителем сроков оказания платных образовательных услуг (сроков начала и (или) окончания оказания платных образовательных услуг и         (или) промежуточных сроков оказания платной образовательной услуги) Заказчик вправе в одностороннем порядке расторгнуть договор.\r\n</p>\r\n<p>\r\n	                 4.5. Исполнитель имеет право расторгнуть договор в одностороннем порядке в следующих случаях:\r\n</p>\r\n<p>\r\n	                 - применение к Слушателю отчисления как меры дисциплинарного взыскания;\r\n</p>\r\n<p>\r\n	                 - невыполнение Слушателем обязанностей по добросовестному освоению ДПП и выполнению учебного плана;\r\n</p>\r\n<p>\r\n	                 - установление нарушения порядка приема Слушателя в АНО ДПО «ЦКС», повлекшего по вине Слушателя его незаконное зачисление в АНО ДПО «ЦКС»;\r\n</p>\r\n<p>\r\n	                 - просрочка оплаты стоимости платных образовательных услуг;\r\n</p>\r\n<p>\r\n	                 - невозможность надлежащего исполнения обязательств по оказанию платных образовательных услуг вследствие действий (бездействия) Слушателя.\r\n</p>\r\n<p align="center">\r\n	<strong>5. </strong><strong>Ответственность </strong><strong>Исполнителя, Заказчика и Слушателя</strong>\r\n</p>\r\n<p>\r\n	                 5.1. В случае неисполнения или ненадлежащего исполнения Исполнителем, Заказчиком и (или) Слушателем обязательств по настоящему договору они несут         ответственность, предусмотренную договором, Гражданским кодексом Российской Федерации, федеральными законами, Законом Российской Федерации «О защите         прав потребителей» и иными нормативными правовыми актами.\r\n</p>\r\n<p>\r\n	                 5.2. Заказчик несет ответственность за достоверность всех предоставленных им сведений, в том числе, но не исключительно: сведений о сотрудниках         Заказчика, реквизитах Заказчика.\r\n</p>\r\n<p>\r\n	<strong> </strong>\r\n</p>\r\n<p align="center">\r\n	<strong>6. </strong><strong>Форс-мажорные обстоятельства</strong>\r\n</p>\r\n<p>\r\n	                 6.1. При наступлении обстоятельств невозможности полного или частичного исполнения любой из Сторон обязательств по настоящему договору – непреодолимой         силы (форс-мажор), а именно: землетрясения, стихийного бедствия или других обстоятельств непреодолимой силы, срок исполнения обязательств по настоящему         договору отодвигается соразмерно времени, в течение которого будут действовать такие обстоятельства или их последствия.\r\n</p>\r\n<p>\r\n	                 6.2. Если эти обстоятельства или их последствия будут продолжаться более трех месяцев, каждая из сторон вправе отказаться от дальнейшего исполнения         обязательств по настоящему договору без взаимных претензий друг к другу.\r\n</p>\r\n<p align="center">\r\n	<strong>7. </strong><strong>Прочие условия</strong>\r\n</p>\r\n<p>\r\n	                 7.1. Настоящий договор вступает в силу с момента его подписания и действует до исполнения сторонами своих обязательств.\r\n</p>\r\n<p>\r\n	                 7.2. Взаимоотношения сторон, неурегулированные договором, регламентируются действующим гражданским Законодательством РФ.\r\n</p>\r\n<p>\r\n	                 7.3. В случае невозможности урегулирования возникающих споров и разногласий путем переговоров стороны обращаются в Арбитражный суд Ростовской области.\r\n</p>\r\n<p>\r\n	                 7.4. Настоящий договор составлен в двух экземплярах, имеющих одинаковую юридическую силу, один из которых находится у Заказчика, второй – у         Исполнителя.\r\n</p>\r\n<p align="center">\r\n	<strong>8. Юридические адреса и реквизиты сторон</strong>\r\n</p>\r\n<table>\r\n<tbody>\r\n<tr>\r\n	<td valign="top" width="434">\r\n		<p>\r\n			<strong>Исполнитель:</strong>\r\n		</p>\r\n		<p>\r\n			                                         НОУ ДПО «ЦКС»\r\n		</p>\r\n		<p>\r\n			                                         Место нахождения исполнителя:\r\n		</p>\r\n		<p>\r\n			                                         344002, г. Ростов-на-Дону,\r\n		</p>\r\n		<p>\r\n			                                         пер. Соляной спуск, 8-10\r\n		</p>\r\n		<p>\r\n			                                         ОГРН 1146100003180\r\n		</p>\r\n		<p>\r\n			                                         ИНН 6164990894\r\n		</p>\r\n		<p>\r\n			                                         КПП 616401001\r\n		</p>\r\n		<p>\r\n			                                         р/сч 40703810626050000009\r\n		</p>\r\n		<p>\r\n			                                         к/сч 30101810500000000207\r\n		</p>\r\n		<p>\r\n			        Филиал "Ростовский" ОАО АЛЬФА-БАНК\r\n		</p>\r\n		<p>\r\n			        г. Ростов-на-Дону\r\n		</p>\r\n		<p>\r\n			                                         БИК 046015207\r\n		</p>\r\n		<p>\r\n			                                         телефон: (863) 299-07-14\r\n		</p>\r\n		<p>\r\n			                                         Руководитель\r\n		</p>\r\n		<p>\r\n			                                         ____________________ Шумеев П.А.\r\n		</p>\r\n		<p>\r\n			                                         м.п.\r\n		</p>\r\n		<p>\r\n			<strong> </strong>\r\n		</p>\r\n	</td>\r\n	<td valign="top" width="434">\r\n		<p>\r\n			<strong>Заказчик:</strong>\r\n		</p>\r\n		<p>\r\n			                                         {{ @$NazvanieOrganizacii }}<br>\r\n			              Место нахождения заказчика:\r\n		</p>\r\n		<p>\r\n			              {{ @$UridicheskiyAdresOrganizacii }}\r\n		</p>\r\n		<p>\r\n			                                         {{ @$OGNROrganizacii }}\r\n		</p>\r\n		<p>\r\n			                                         {{ @$INNOrganizacii }}\r\n		</p>\r\n		<p>\r\n			                                         {{ @$KPPOrganizacii }}\r\n		</p>\r\n		<p>\r\n			                                         {{ @$RaschetnuySchetOrganizacii }}\r\n		</p>\r\n		<p>\r\n			                                         {{ @$KorrespondentskuyChetOrganizacii }}\r\n		</p>\r\n		<p>\r\n			                                         {{ @$NazvanieBankaOrganizacii }}\r\n		</p>\r\n		<p>\r\n			                                         {{ @$BIKOrganizacii }}\r\n		</p>\r\n		<p>\r\n			                                         телефон: {{ @$KontaktnuyTelefonZakazchika }}\r\n		</p>\r\n		<p>\r\n			<br>\r\n			<br>\r\n		</p>\r\n		<p>\r\n			        {{ @$DoljnostOtvetstvennogoLicaOrganizacii }}\r\n		</p>\r\n		<p>\r\n			                                         ____________________  {{ @$ImyaOtvetstvennogoLicaInicialu }}\r\n		</p>\r\n		<p>\r\n			                                         м.п.\r\n		</p>\r\n		<p>\r\n			<strong> </strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<p>\r\n	      *Стоимость оказания платных образовательных услуг установлена в соответствии с условиями Акции, утвержденной приказом руководителя НОУ ДПО «ЦКС» А №002 от 01.07.2014.\r\n</p>', '2014-10-30 12:10:23', '2014-12-17 12:38:55'),
(3, 33, NULL, 'word_template', NULL, '2014-10-30 12:10:23', '2014-12-17 07:19:55'),
(4, 39, NULL, 'user_id', '2', '2014-10-30 12:10:23', '2014-10-30 12:10:23'),
(5, 39, NULL, 'action_id', '21', '2014-10-30 12:10:23', '2014-10-30 12:10:23'),
(6, 39, NULL, 'title', 'Событие за 30.10.2014 в 12:10', '2014-10-30 12:10:23', '2014-10-30 12:10:23'),
(7, 39, NULL, 'link', NULL, '2014-10-30 12:10:23', '2014-10-30 12:10:23'),
(8, 39, NULL, 'created_time', '2014-10-30 12:10:23', '2014-10-30 12:10:23', '2014-10-30 12:10:23'),
(9, 35, NULL, 'variables', '', '2014-10-30 12:10:48', '2014-10-30 12:10:48'),
(10, 35, NULL, 'content', '<p>\r\n	 <strong></strong>\r\n</p>\r\n<p style="text-align: center;">\r\n	 <strong> Акт сдачи-приемки оказанных услуг №{{ @$NomerZakaza }} ЭПК от {{ @$DataOplatuZakaza }}</strong>\r\n</p>\r\n<p style="text-align: center;">\r\n</p>\r\n<p>\r\n	<strong>Исполнитель: </strong>Автономная некоммерческая организация дополнительного профессионального образования «Центр качества строительства»\r\n</p>\r\n<p>\r\n	<strong> </strong>\r\n</p>\r\n<p>\r\n	<strong>Заказчик:</strong> {{ @$Zakazchik }}\r\n</p>\r\n<p>\r\n	<strong>Наименование услуг:</strong>оказание платных образовательных услуг в соответствии с договором №{{ @$NomerZakaza }} ЭПК от {{ @$DataOplatuZakaza }}\r\n</p>\r\n<p align="right">\r\n	<strong>Валюта: Руб</strong>\r\n</p>\r\n<p>\r\n	    {{ @$SpisokSluschateleyDlyaAkta }}\r\n</p>\r\n<p align="right">\r\n	<strong></strong>\r\n</p>\r\n<p>\r\n	<em>Всего оказано услуг на сумму</em><em>: </em>{{ @$SummaZakazaSlovami }}<em><u>.</u></em>\r\n</p>\r\n<p>\r\n	<em>НДС не облагается п.2 ст.346.11 НК РФ.</em>\r\n</p>\r\n<p>\r\n	    Вышеперечисленные услуги оказаны в полном объеме и в срок. Заказчик претензий по объему, качеству и срокам оказания услуг не имеет.\r\n</p>\r\n<p>\r\n	<strong>Исполнитель: Заказчик: </strong>\r\n</p>\r\n<p>\r\n	               Руководитель {{ @$DoljnostOtvetstvennogoLicaOrganizacii }}\r\n</p>\r\n<p>\r\n	               ____________________ Шумеев П.А. ___________________ {{ @$ImyaOtvetstvennogoLicaInicialu }}\r\n</p>\r\n<p>\r\n	               м.п.                                                                   м.п.\r\n</p>', '2014-10-30 12:10:48', '2014-12-17 12:33:01'),
(11, 35, NULL, 'word_template', NULL, '2014-10-30 12:10:48', '2014-12-17 09:26:50'),
(12, 41, NULL, 'user_id', '2', '2014-10-30 12:10:48', '2014-10-30 12:10:48'),
(13, 41, NULL, 'action_id', '21', '2014-10-30 12:10:48', '2014-10-30 12:10:48'),
(14, 41, NULL, 'title', 'Событие за 30.10.2014 в 12:10', '2014-10-30 12:10:48', '2014-10-30 12:10:48'),
(15, 41, NULL, 'link', NULL, '2014-10-30 12:10:48', '2014-10-30 12:10:48'),
(16, 41, NULL, 'created_time', '2014-10-30 12:10:48', '2014-10-30 12:10:48', '2014-10-30 12:10:48'),
(17, 34, NULL, 'variables', '', '2014-10-30 12:11:03', '2014-10-30 12:11:03'),
(18, 34, NULL, 'content', '<table border="1" cellpadding="0" cellspacing="0">\r\n<tbody>\r\n<tr>\r\n	<td style="padding: 3pt 6pt 3pt 6pt;" valign="top" width="218">\r\n		<p>\r\n			                                           ИНН 6164990894\r\n		</p>\r\n	</td>\r\n	<td style="padding: 3pt;" width="218">\r\n		<p>\r\n			                                           КПП 616401001\r\n		</p>\r\n	</td>\r\n	<td style="padding: 3pt 6pt 3pt 6pt;" valign="top" width="218">\r\n		<p>\r\n			                                           р/с №\r\n		</p>\r\n	</td>\r\n	<td style="padding: 3pt 6pt 3pt 6pt;" rowspan="2" valign="top" width="218">\r\n		<p>\r\n			                                           40703810626050000009\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td style="padding: 3pt 6pt 3pt 6pt;" colspan="3" valign="top" width="654">\r\n		<p>\r\n			                                           Автономная некоммерческая организация дополнительного профессионального образования "Центр качества строительства"\r\n		</p>\r\n		<p>\r\n			                                           Получатель\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td style="padding: 3pt 6pt 3pt 6pt;" rowspan="2" colspan="2" width="436">\r\n		<p>\r\n			                                           Филиал "Ростовский" ОАО АЛЬФА-БАНК г. Ростов-на-Дону\r\n		</p>\r\n		<p>\r\n			                                           Банк получателя\r\n		</p>\r\n	</td>\r\n	<td style="padding: 3pt 6pt 3pt 6pt;" valign="top" width="218">\r\n		<p>\r\n			                                           БИК\r\n		</p>\r\n	</td>\r\n	<td style="padding: 3pt 6pt 3pt 6pt;" rowspan="2" valign="top" width="218">\r\n		<p>\r\n			                                           046015207\r\n		</p>\r\n		<p>\r\n			                                           30101810500000000207\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td style="padding: 3pt;" width="218">\r\n		<p>\r\n			                                           к/с №\r\n		</p>\r\n	</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<h2>                         Счет № {{ @$NomerZakaza }}<strong> </strong>от {{ @$DataOformleniyaZakaza}} </h2>\r\n<table border="1" cellpadding="0" cellspacing="0">\r\n<tbody>\r\n<tr>\r\n	<td style="padding: 3pt 6pt 3pt 6pt;" valign="top" width="108">\r\n		<p>\r\n			                                           Поставщик:\r\n		</p>\r\n	</td>\r\n	<td style="padding: 3pt 6pt 3pt 6pt;" valign="top" width="763">\r\n		<p>\r\n			<strong>                         Автономная некоммерческая организация дополнительного профессионального образования "Центр качества строительства", ИНН 6164990894, КПП                         616401001, г. Ростов-на-Дону, ул. Соляной спуск, д. 8-10, тел. (863) 299-07-14                     </strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<table border="0" cellpadding="0" cellspacing="0" width="793">\r\n<tbody>\r\n<tr>\r\n	<td style="padding: 3pt;" nowrap="" valign="top" width="98">\r\n		<p>\r\n			                                            Покупатель:\r\n		</p>\r\n	</td>\r\n	<td style="padding: 3pt;" valign="top" width="666">\r\n		<p>\r\n			                      {{ @$Zakazchik}}\r\n		</p>\r\n	</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<p>\r\n	             {{ @$SpisokSluschateleyDlyaScheta }}\r\n</p>\r\n<div align="right">\r\n	<table style="float: right; margin-left: 50%; margin-bottom: 10%; width: 50%;" border="1" cellpadding="0" cellspacing="0" width="">\r\n	<tbody>\r\n	<tr>\r\n		<td style="padding: 3pt;" nowrap="" valign="top" width="150">\r\n			<p align="right">\r\n				 <strong>Итого</strong>\r\n			</p>\r\n		</td>\r\n		<td style="padding: 3pt;" nowrap="" valign="top" width="200">\r\n			<p align="right">\r\n				<strong>{{ @$SummaZakaza }},00</strong>\r\n			</p>\r\n		</td>\r\n	</tr>\r\n	<tr>\r\n		<td style="padding: 3pt;" nowrap="" valign="top" width="133">\r\n			<p align="right">\r\n				 <strong>Сумма НДС</strong>\r\n			</p>\r\n		</td>\r\n		<td style="padding: 3pt;" nowrap="" valign="top" width="115">\r\n			<p align="right">\r\n				 <strong>0,00</strong>\r\n			</p>\r\n		</td>\r\n	</tr>\r\n	</tbody>\r\n	</table>\r\n</div>\r\n<p>\r\n	                            В поле "Назначение платежа" необходимо указать:\r\n</p>\r\n<p>\r\n	                            Оказание платных образовательных услуг в соответствии с договором №{{ @$NomerZakaza}} от {{ @$DataOformleniyaZakaza}}.\r\n</p>\r\n<p>\r\n	                            Всего наименований: {{ @$VsegoNaimenovaliy }}; количество: {{ @$KolichestvoNaimenovaliy }}\r\n</p>\r\n<p>\r\n	                       на сумму {{ @$SummaZakaza }}.00 Руб\r\n</p>\r\n<p>\r\n	         ({{ @$SummaZakazaSlovami }})\r\n</p>\r\n<p>\r\n	      Руководитель /Шумеев П.А./\r\n</p>', '2014-10-30 12:11:03', '2014-12-17 09:24:45'),
(19, 34, NULL, 'word_template', NULL, '2014-10-30 12:11:03', '2014-12-17 08:46:13'),
(20, 43, NULL, 'user_id', '2', '2014-10-30 12:11:03', '2014-10-30 12:11:03'),
(21, 43, NULL, 'action_id', '21', '2014-10-30 12:11:03', '2014-10-30 12:11:03'),
(22, 43, NULL, 'title', 'Событие за 30.10.2014 в 12:11', '2014-10-30 12:11:03', '2014-10-30 12:11:03'),
(23, 43, NULL, 'link', NULL, '2014-10-30 12:11:03', '2014-10-30 12:11:03'),
(24, 43, NULL, 'created_time', '2014-10-30 12:11:03', '2014-10-30 12:11:03', '2014-10-30 12:11:03'),
(25, 73, NULL, 'user_id', '3', '2014-11-06 14:14:44', '2014-11-06 14:14:44'),
(26, 73, NULL, 'action_id', '44', '2014-11-06 14:14:44', '2014-11-06 14:14:44'),
(27, 73, NULL, 'created_time', '2014-11-06 14:14:44', '2014-11-06 14:14:44', '2014-11-06 14:14:44'),
(28, 74, NULL, 'user_id', '3', '2014-11-06 14:14:44', '2014-11-06 14:14:44'),
(29, 74, NULL, 'action_id', '45', '2014-11-06 14:14:44', '2014-11-06 14:14:44'),
(30, 74, NULL, 'created_time', '2014-11-06 14:14:44', '2014-11-06 14:14:44', '2014-11-06 14:14:44'),
(31, 75, NULL, 'user_id', '3', '2014-11-06 14:14:44', '2014-11-06 14:14:44'),
(32, 75, NULL, 'action_id', '46', '2014-11-06 14:14:44', '2014-11-06 14:14:44'),
(33, 75, NULL, 'created_time', '2014-11-06 14:14:44', '2014-11-06 14:14:44', '2014-11-06 14:14:44'),
(34, 76, NULL, 'user_id', '3', '2014-11-06 14:14:44', '2014-11-06 14:14:44'),
(35, 76, NULL, 'action_id', '47', '2014-11-06 14:14:44', '2014-11-06 14:14:44'),
(36, 76, NULL, 'created_time', '2014-11-06 14:14:44', '2014-11-06 14:14:44', '2014-11-06 14:14:44'),
(76, 91, NULL, 'user_id', '3', '2014-11-06 16:19:44', '2014-11-06 16:19:44'),
(78, 91, NULL, 'created_time', '2014-11-06 16:19:44', '2014-11-06 16:19:44', '2014-11-06 16:19:44'),
(82, 93, NULL, 'user_id', '2', '2014-11-06 16:27:42', '2014-11-06 16:27:42'),
(83, 93, NULL, 'action_id', '28', '2014-11-06 16:27:42', '2014-11-06 16:27:42'),
(84, 93, NULL, 'title', 'Управление финансового контроля Ростовской области', '2014-11-06 16:27:42', '2014-11-06 16:27:42'),
(85, 93, NULL, 'link', NULL, '2014-11-06 16:27:42', '2014-11-06 16:27:42'),
(86, 93, NULL, 'created_time', '2014-11-06 16:27:42', '2014-11-06 16:27:42', '2014-11-06 16:27:42'),
(87, 94, NULL, 'user_id', '2', '2014-11-06 16:27:42', '2014-11-06 16:27:42'),
(88, 94, NULL, 'action_id', '26', '2014-11-06 16:27:42', '2014-11-06 16:27:42'),
(89, 94, NULL, 'title', 'Организация: Управление финансового контроля Ростовской области', '2014-11-06 16:27:42', '2014-11-06 16:27:42'),
(91, 94, NULL, 'created_time', '2014-11-06 16:27:42', '2014-11-06 16:27:42', '2014-11-06 16:27:42'),
(93, 95, NULL, 'action_id', '60', '2014-11-06 16:29:43', '2014-11-06 16:29:43'),
(94, 95, NULL, 'created_time', '2014-11-06 16:29:43', '2014-11-06 16:29:43', '2014-11-06 16:29:43'),
(95, 96, NULL, 'user_id', '2', '2014-11-06 16:29:43', '2014-11-06 16:29:43'),
(96, 96, NULL, 'action_id', '25', '2014-11-06 16:29:43', '2014-11-06 16:29:43'),
(97, 96, NULL, 'title', 'Заказ №1', '2014-11-06 16:29:43', '2014-11-06 16:29:43'),
(98, 96, NULL, 'link', NULL, '2014-11-06 16:29:43', '2014-11-06 16:29:43'),
(99, 96, NULL, 'created_time', '2014-11-06 16:29:43', '2014-11-06 16:29:43', '2014-11-06 16:29:43'),
(100, 97, NULL, 'user_id', '2', '2014-11-06 16:30:04', '2014-11-06 16:30:04'),
(101, 97, NULL, 'action_id', '22', '2014-11-06 16:30:04', '2014-11-06 16:30:04'),
(102, 97, NULL, 'title', 'Заказ №1. Сумма: 8000.00 руб.', '2014-11-06 16:30:04', '2014-11-06 16:30:04'),
(103, 97, NULL, 'link', NULL, '2014-11-06 16:30:04', '2014-11-06 16:30:04'),
(104, 97, NULL, 'created_time', '2014-11-06 16:30:04', '2014-11-06 16:30:04', '2014-11-06 16:30:04'),
(105, 98, NULL, 'user_id', '3', '2014-11-06 16:32:12', '2014-11-06 16:32:12'),
(106, 98, NULL, 'action_id', '50', '2014-11-06 16:32:12', '2014-11-06 16:32:12'),
(108, 99, NULL, 'user_id', '3', '2014-11-06 16:54:44', '2014-11-06 16:54:44'),
(109, 99, NULL, 'action_id', '52', '2014-11-06 16:54:44', '2014-11-06 16:54:44'),
(111, 100, NULL, 'user_id', '3', '2014-11-06 17:01:52', '2014-11-06 17:01:52'),
(112, 100, NULL, 'action_id', '52', '2014-11-06 17:01:52', '2014-11-06 17:01:52'),
(114, 101, NULL, 'user_id', '3', '2014-11-06 17:19:37', '2014-11-06 17:19:37'),
(115, 101, NULL, 'action_id', '51', '2014-11-06 17:19:37', '2014-11-06 17:19:37'),
(119, 102, NULL, 'created_time', '2014-11-06 17:21:58', '2014-11-06 17:21:58', '2014-11-06 17:21:58'),
(122, 103, NULL, 'created_time', '2014-11-06 17:21:59', '2014-11-06 17:21:59', '2014-11-06 17:21:59'),
(126, 105, NULL, 'user_id', '3', '2014-11-06 17:22:55', '2014-11-06 17:22:55'),
(127, 105, NULL, 'action_id', '53', '2014-11-06 17:22:55', '2014-11-06 17:22:55'),
(128, 105, NULL, 'created_time', '2014-11-06 17:22:55', '2014-11-06 17:22:55', '2014-11-06 17:22:55'),
(129, 106, NULL, 'user_id', '3', '2014-11-06 17:22:55', '2014-11-06 17:22:55'),
(130, 106, NULL, 'action_id', '67', '2014-11-06 17:22:55', '2014-11-06 17:22:55'),
(131, 106, NULL, 'created_time', '2014-11-06 17:22:55', '2014-11-06 17:22:55', '2014-11-06 17:22:55'),
(135, 108, NULL, 'user_id', '3', '2014-11-06 17:30:56', '2014-11-06 17:30:56'),
(136, 108, NULL, 'action_id', '53', '2014-11-06 17:30:56', '2014-11-06 17:30:56'),
(137, 108, NULL, 'created_time', '2014-11-06 17:30:56', '2014-11-06 17:30:56', '2014-11-06 17:30:56'),
(138, 109, NULL, 'user_id', '3', '2014-11-06 17:30:56', '2014-11-06 17:30:56'),
(139, 109, NULL, 'action_id', '67', '2014-11-06 17:30:56', '2014-11-06 17:30:56'),
(140, 109, NULL, 'created_time', '2014-11-06 17:30:56', '2014-11-06 17:30:56', '2014-11-06 17:30:56'),
(144, 111, NULL, 'user_id', '3', '2014-11-06 17:33:15', '2014-11-06 17:33:15'),
(145, 111, NULL, 'action_id', '53', '2014-11-06 17:33:15', '2014-11-06 17:33:15'),
(146, 111, NULL, 'created_time', '2014-11-06 17:33:15', '2014-11-06 17:33:15', '2014-11-06 17:33:15'),
(147, 112, NULL, 'user_id', '3', '2014-11-06 17:33:15', '2014-11-06 17:33:15'),
(148, 112, NULL, 'action_id', '67', '2014-11-06 17:33:15', '2014-11-06 17:33:15'),
(149, 112, NULL, 'created_time', '2014-11-06 17:33:15', '2014-11-06 17:33:15', '2014-11-06 17:33:15'),
(153, 114, NULL, 'user_id', '3', '2014-11-06 17:34:19', '2014-11-06 17:34:19'),
(156, 115, NULL, 'user_id', '3', '2014-11-06 17:34:19', '2014-11-06 17:34:19'),
(157, 115, NULL, 'action_id', '67', '2014-11-06 17:34:19', '2014-11-06 17:34:19'),
(158, 115, NULL, 'created_time', '2014-11-06 17:34:19', '2014-11-06 17:34:19', '2014-11-06 17:34:19'),
(192, 127, NULL, 'user_id', '2', '2014-11-07 14:33:02', '2014-11-07 14:33:02'),
(193, 127, NULL, 'action_id', '21', '2014-11-07 14:33:02', '2014-11-07 14:33:02'),
(194, 127, NULL, 'title', 'Событие за 07.11.2014 в 14:33', '2014-11-07 14:33:02', '2014-11-07 14:33:02'),
(195, 127, NULL, 'link', NULL, '2014-11-07 14:33:02', '2014-11-07 14:33:02'),
(196, 127, NULL, 'created_time', '2014-11-07 14:33:02', '2014-11-07 14:33:02', '2014-11-07 14:33:02'),
(200, 129, NULL, 'user_id', '2', '2014-11-07 14:33:22', '2014-11-07 14:33:22'),
(201, 129, NULL, 'action_id', '21', '2014-11-07 14:33:22', '2014-11-07 14:33:22'),
(202, 129, NULL, 'title', 'Событие за 07.11.2014 в 14:33', '2014-11-07 14:33:22', '2014-11-07 14:33:22'),
(203, 129, NULL, 'link', NULL, '2014-11-07 14:33:22', '2014-11-07 14:33:22'),
(204, 129, NULL, 'created_time', '2014-11-07 14:33:22', '2014-11-07 14:33:22', '2014-11-07 14:33:22'),
(208, 131, NULL, 'user_id', '2', '2014-11-07 14:33:43', '2014-11-07 14:33:43'),
(209, 131, NULL, 'action_id', '21', '2014-11-07 14:33:43', '2014-11-07 14:33:43'),
(210, 131, NULL, 'title', 'Событие за 07.11.2014 в 14:33', '2014-11-07 14:33:43', '2014-11-07 14:33:43'),
(211, 131, NULL, 'link', NULL, '2014-11-07 14:33:43', '2014-11-07 14:33:43'),
(212, 131, NULL, 'created_time', '2014-11-07 14:33:43', '2014-11-07 14:33:43', '2014-11-07 14:33:43'),
(216, 134, NULL, 'user_id', '2', '2014-11-10 13:27:27', '2014-11-10 13:27:27'),
(217, 134, NULL, 'action_id', '21', '2014-11-10 13:27:27', '2014-11-10 13:27:27'),
(218, 134, NULL, 'title', 'Событие за 10.11.2014 в 13:27', '2014-11-10 13:27:27', '2014-11-10 13:27:27'),
(219, 134, NULL, 'link', NULL, '2014-11-10 13:27:27', '2014-11-10 13:27:27'),
(220, 134, NULL, 'created_time', '2014-11-10 13:27:27', '2014-11-10 13:27:27', '2014-11-10 13:27:27'),
(224, 136, NULL, 'user_id', '2', '2014-11-10 13:27:51', '2014-11-10 13:27:51'),
(225, 136, NULL, 'action_id', '21', '2014-11-10 13:27:51', '2014-11-10 13:27:51'),
(226, 136, NULL, 'title', 'Событие за 10.11.2014 в 13:27', '2014-11-10 13:27:51', '2014-11-10 13:27:51'),
(227, 136, NULL, 'link', NULL, '2014-11-10 13:27:51', '2014-11-10 13:27:51'),
(228, 136, NULL, 'created_time', '2014-11-10 13:27:51', '2014-11-10 13:27:51', '2014-11-10 13:27:51'),
(232, 138, NULL, 'user_id', '2', '2014-11-10 14:10:14', '2014-11-10 14:10:14'),
(233, 138, NULL, 'action_id', '21', '2014-11-10 14:10:14', '2014-11-10 14:10:14'),
(234, 138, NULL, 'title', 'Событие за 10.11.2014 в 14:10', '2014-11-10 14:10:14', '2014-11-10 14:10:14'),
(235, 138, NULL, 'link', NULL, '2014-11-10 14:10:14', '2014-11-10 14:10:14'),
(236, 138, NULL, 'created_time', '2014-11-10 14:10:14', '2014-11-10 14:10:14', '2014-11-10 14:10:14'),
(240, 140, NULL, 'user_id', '2', '2014-11-10 14:11:10', '2014-11-10 14:11:10'),
(241, 140, NULL, 'action_id', '21', '2014-11-10 14:11:10', '2014-11-10 14:11:10'),
(242, 140, NULL, 'title', 'Событие за 10.11.2014 в 14:11', '2014-11-10 14:11:10', '2014-11-10 14:11:10'),
(243, 140, NULL, 'link', NULL, '2014-11-10 14:11:10', '2014-11-10 14:11:10'),
(244, 140, NULL, 'created_time', '2014-11-10 14:11:10', '2014-11-10 14:11:10', '2014-11-10 14:11:10'),
(248, 142, NULL, 'user_id', '2', '2014-11-10 14:11:29', '2014-11-10 14:11:29'),
(249, 142, NULL, 'action_id', '21', '2014-11-10 14:11:29', '2014-11-10 14:11:29'),
(250, 142, NULL, 'title', 'Событие за 10.11.2014 в 14:11', '2014-11-10 14:11:29', '2014-11-10 14:11:29'),
(251, 142, NULL, 'link', NULL, '2014-11-10 14:11:29', '2014-11-10 14:11:29'),
(252, 142, NULL, 'created_time', '2014-11-10 14:11:29', '2014-11-10 14:11:29', '2014-11-10 14:11:29'),
(256, 144, NULL, 'user_id', '2', '2014-11-10 15:16:47', '2014-11-10 15:16:47'),
(257, 144, NULL, 'action_id', '21', '2014-11-10 15:16:47', '2014-11-10 15:16:47'),
(258, 144, NULL, 'title', 'Событие за 10.11.2014 в 15:16', '2014-11-10 15:16:47', '2014-11-10 15:16:47'),
(259, 144, NULL, 'link', NULL, '2014-11-10 15:16:47', '2014-11-10 15:16:47'),
(260, 144, NULL, 'created_time', '2014-11-10 15:16:47', '2014-11-10 15:16:47', '2014-11-10 15:16:47'),
(264, 146, NULL, 'user_id', '2', '2014-11-10 15:17:08', '2014-11-10 15:17:08'),
(265, 146, NULL, 'action_id', '21', '2014-11-10 15:17:08', '2014-11-10 15:17:08'),
(266, 146, NULL, 'title', 'Событие за 10.11.2014 в 15:17', '2014-11-10 15:17:08', '2014-11-10 15:17:08'),
(267, 146, NULL, 'link', NULL, '2014-11-10 15:17:08', '2014-11-10 15:17:08'),
(268, 146, NULL, 'created_time', '2014-11-10 15:17:08', '2014-11-10 15:17:08', '2014-11-10 15:17:08'),
(272, 148, NULL, 'user_id', '2', '2014-11-10 15:17:25', '2014-11-10 15:17:25'),
(273, 148, NULL, 'action_id', '21', '2014-11-10 15:17:25', '2014-11-10 15:17:25'),
(274, 148, NULL, 'title', 'Событие за 10.11.2014 в 15:17', '2014-11-10 15:17:25', '2014-11-10 15:17:25'),
(275, 148, NULL, 'link', NULL, '2014-11-10 15:17:25', '2014-11-10 15:17:25'),
(276, 148, NULL, 'created_time', '2014-11-10 15:17:25', '2014-11-10 15:17:25', '2014-11-10 15:17:25'),
(277, 149, NULL, 'variables', '', '2014-11-10 15:22:02', '2014-11-10 15:22:02'),
(278, 149, NULL, 'content', '<p align="right">\r\n	         Приложение № 3\r\n</p>\r\n<p align="right">\r\n	         к Договору №{{ @$NomerZakaza }} ПК\r\n</p>\r\n<p style="text-align: right;">\r\n	         от {{ @$DataOplatuZakaza }}\r\n</p>\r\n<p align="center">\r\n	<strong></strong>\r\n</p>\r\n<p align="center">\r\n	<strong>Акт сдачи-приемки выполненных работ</strong>\r\n</p>\r\n<p style="text-align: center;">\r\n	         от {{ @$DataZakrutiyaZakaza }} по Договору №{{ @$NomerZakaza }} ПК от {{ @$DataOplatuZakaza }}\r\n</p>\r\n<p style="text-align: center;">\r\n</p>\r\n<p>\r\n	<strong>Исполнитель: </strong>     Негосударственное образовательное учреждение дополнительного профессионального образования «Центр качества строительства»\r\n</p>\r\n<p>\r\n	<strong> </strong>\r\n</p>\r\n<p>\r\n	<strong>Заказчик:</strong> {{ @$NazvanieOrganizacii }}\r\n</p>\r\n<p align="right">\r\n	<strong>Валюта: Руб</strong>\r\n</p>\r\n<table border="1" cellpadding="0" cellspacing="0" width="836">\r\n<tbody>\r\n<tr>\r\n	<td valign="top">\r\n		<p align="center">\r\n			                             №\r\n		</p>\r\n	</td>\r\n	<td valign="top" width="377">\r\n		<p align="center">\r\n			                             Наименование работы (услуги)\r\n		</p>\r\n	</td>\r\n	<td valign="top" width="92">\r\n		<p align="center">\r\n			                             Ед.изм.\r\n		</p>\r\n	</td>\r\n	<td valign="top" width="118">\r\n		<p align="center">\r\n			                             Количество\r\n		</p>\r\n	</td>\r\n	<td valign="top" width="119">\r\n		<p align="center">\r\n			                             Цена\r\n		</p>\r\n	</td>\r\n	<td valign="top" width="93">\r\n		<p align="center">\r\n			                             Сумма\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td valign="top">\r\n		<p>\r\n			                             1\r\n		</p>\r\n	</td>\r\n	<td valign="top" width="377">\r\n		<p>\r\n			                             Оказание платных образовательных услуг в соответствии с договором №{{ @$NomerZakaza }} ПК от {{ @$DataOplatuZakaza }}\r\n		</p>\r\n	</td>\r\n	<td valign="top" width="92">\r\n		<p style="text-align: center;" align="center">\r\n			                             чел.\r\n		</p>\r\n	</td>\r\n	<td valign="top" width="118">\r\n		<p align="center">\r\n		</p>\r\n		<p style="text-align: center;">\r\n			       {{ @$KolichestvoSluschateley }}\r\n		</p>\r\n		<p align="center">\r\n		</p>\r\n	</td>\r\n	<td valign="top" width="119">\r\n		<p align="center">\r\n			<strong></strong>\r\n		</p>\r\n		<p style="text-align: center;">\r\n			       {{ @$SummaZakaza }}\r\n		</p>\r\n		<p align="center">\r\n			<strong></strong>\r\n		</p>\r\n	</td>\r\n	<td valign="top" width="93">\r\n		<p align="center">\r\n			<strong></strong>\r\n		</p>\r\n		<p style="text-align: center;">\r\n			       {{ @$SummaZakaza }}\r\n		</p>\r\n		<p align="center">\r\n			<strong></strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td valign="top">\r\n		<br>\r\n	</td>\r\n	<td valign="top" width="377">\r\n		<br>\r\n	</td>\r\n	<td valign="top" width="92">\r\n		<br>\r\n	</td>\r\n	<td valign="top" width="118">\r\n		<br>\r\n	</td>\r\n	<td valign="top" width="119">\r\n		<p align="center">\r\n			<strong>Итого:</strong>\r\n		</p>\r\n	</td>\r\n	<td valign="top" width="93">\r\n		<p style="text-align: center;">\r\n			       {{ @$SummaZakaza }}\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td valign="top">\r\n		<br>\r\n	</td>\r\n	<td valign="top" width="377">\r\n		<br>\r\n	</td>\r\n	<td valign="top" width="92">\r\n		<br>\r\n	</td>\r\n	<td valign="top" width="118">\r\n		<br>\r\n	</td>\r\n	<td valign="top" width="119">\r\n		<p align="center">\r\n			<strong>В т.ч.НДС:</strong>\r\n		</p>\r\n	</td>\r\n	<td valign="top" width="93">\r\n		<p align="center">\r\n			<strong>-</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<p>\r\n	<em>Всего выполнено работ (оказано услуг) на сумму: </em>{{ @$SummaZakazaSlovami }}<em><u>.</u> НДС не облагается п.2 ст.346.11 НК РФ.</em>\r\n</p>\r\n<p>\r\n	         Вышеперечисленные работы (услуги) выполнены полностью и в срок. Заказчик претензий по объему, качеству и срокам выполнения работ (оказания услуг) не имеет.\r\n</p>\r\n<p>\r\n	<strong>Исполнитель: Заказчик: </strong>\r\n</p>\r\n<p>\r\n	         Руководитель Директор\r\n</p>\r\n<p>\r\n	         ____________________ П.А. Шумеев ___________________ А.П. Донченко\r\n</p>\r\n<p>\r\n	         м.п.                                                                   м.п.\r\n</p>', '2014-11-10 15:22:02', '2014-11-10 15:22:02'),
(279, 149, NULL, 'word_template', '134', '2014-11-10 15:22:02', '2014-11-10 15:22:02'),
(280, 150, NULL, 'user_id', '2', '2014-11-10 15:42:46', '2014-11-10 15:42:46'),
(281, 150, NULL, 'action_id', '70', '2014-11-10 15:42:46', '2014-11-10 15:42:46'),
(282, 150, NULL, 'title', '№003-14', '2014-11-10 15:42:46', '2014-11-10 15:42:46'),
(283, 150, NULL, 'link', NULL, '2014-11-10 15:42:46', '2014-11-10 15:42:46'),
(284, 150, NULL, 'created_time', '2014-11-10 15:42:46', '2014-11-10 15:42:46', '2014-11-10 15:42:46'),
(285, 151, NULL, 'user_id', '2', '2014-11-10 15:42:46', '2014-11-10 15:42:46'),
(286, 151, NULL, 'action_id', '72', '2014-11-10 15:42:46', '2014-11-10 15:42:46'),
(287, 151, NULL, 'title', '№003-14', '2014-11-10 15:42:46', '2014-11-10 15:42:46'),
(288, 151, NULL, 'link', NULL, '2014-11-10 15:42:46', '2014-11-10 15:42:46'),
(289, 151, NULL, 'created_time', '2014-11-10 15:42:46', '2014-11-10 15:42:46', '2014-11-10 15:42:46'),
(290, 152, NULL, 'user_id', '2', '2014-11-10 15:42:55', '2014-11-10 15:42:55'),
(291, 152, NULL, 'action_id', '70', '2014-11-10 15:42:55', '2014-11-10 15:42:55'),
(292, 152, NULL, 'title', '№002-14', '2014-11-10 15:42:55', '2014-11-10 15:42:55'),
(293, 152, NULL, 'link', NULL, '2014-11-10 15:42:55', '2014-11-10 15:42:55'),
(294, 152, NULL, 'created_time', '2014-11-10 15:42:55', '2014-11-10 15:42:55', '2014-11-10 15:42:55'),
(295, 153, NULL, 'user_id', '2', '2014-11-10 15:42:55', '2014-11-10 15:42:55'),
(296, 153, NULL, 'action_id', '72', '2014-11-10 15:42:55', '2014-11-10 15:42:55'),
(297, 153, NULL, 'title', '№002-14', '2014-11-10 15:42:55', '2014-11-10 15:42:55'),
(298, 153, NULL, 'link', NULL, '2014-11-10 15:42:55', '2014-11-10 15:42:55'),
(299, 153, NULL, 'created_time', '2014-11-10 15:42:55', '2014-11-10 15:42:55', '2014-11-10 15:42:55'),
(306, 156, NULL, 'user_id', '2', '2014-11-11 14:38:46', '2014-11-11 14:38:46');
INSERT INTO `dictionary_fields_values` (`id`, `dicval_id`, `language`, `key`, `value`, `created_at`, `updated_at`) VALUES
(307, 156, NULL, 'action_id', '132', '2014-11-11 14:38:46', '2014-11-11 14:38:46'),
(308, 156, NULL, 'title', '№001-14', '2014-11-11 14:38:46', '2014-11-11 14:38:46'),
(309, 156, NULL, 'link', NULL, '2014-11-11 14:38:46', '2014-11-11 14:38:46'),
(310, 156, NULL, 'created_time', '2014-11-11 14:38:46', '2014-11-11 14:38:46', '2014-11-11 14:38:46'),
(314, 162, NULL, 'user_id', '2', '2014-11-19 11:30:37', '2014-11-19 11:30:37'),
(315, 162, NULL, 'action_id', '21', '2014-11-19 11:30:37', '2014-11-19 11:30:37'),
(316, 162, NULL, 'title', 'Событие за 19.11.2014 в 11:30', '2014-11-19 11:30:37', '2014-11-19 11:30:37'),
(317, 162, NULL, 'link', NULL, '2014-11-19 11:30:37', '2014-11-19 11:30:37'),
(318, 162, NULL, 'created_time', '2014-11-19 11:30:37', '2014-11-19 11:30:37', '2014-11-19 11:30:37'),
(322, 164, NULL, 'user_id', '2', '2014-11-19 11:31:07', '2014-11-19 11:31:07'),
(323, 164, NULL, 'action_id', '21', '2014-11-19 11:31:07', '2014-11-19 11:31:07'),
(324, 164, NULL, 'title', 'Событие за 19.11.2014 в 11:31', '2014-11-19 11:31:07', '2014-11-19 11:31:07'),
(325, 164, NULL, 'link', NULL, '2014-11-19 11:31:07', '2014-11-19 11:31:07'),
(326, 164, NULL, 'created_time', '2014-11-19 11:31:07', '2014-11-19 11:31:07', '2014-11-19 11:31:07'),
(327, 165, NULL, 'variables', '', '2014-11-19 11:44:15', '2014-11-19 11:44:15'),
(328, 165, NULL, 'content', '<p align="center">\r\n	<strong>Договор №{{ @$NomerZakaza }} ПК</strong>\r\n</p>\r\n<p align="center">\r\n	<strong>на оказание платных образовательных услуг</strong>\r\n</p>\r\n<p>\r\n	      г. Ростов-на-Дону\r\n</p>\r\n<p style="text-align: right;">\r\n	     {{ @$DataOformleniyaZakazaSlovami }}\r\n</p>\r\n<p>\r\n	      Автономная некоммерческая организация дополнительного профессионального образования «Центр качества строительства» (далее – АНО ДПО «ЦКС»), именуемая в дальнейшем Исполнитель, в лице руководителя Шумеева Павла Андреевича, действующего на основании Устава, с одной стороны, и {{ @$NazvanieOrganizacii }}, именуемое в дальнейшем Заказчик, в лице {{ @$DoljnostOtvetstvennogoLicaOrganizacii }} {{ @$ImyaOtvetstvennogoLicaOrganizacii }}, действующего на основании {{ @$DeystvuyucheeOsnovanieOrganizacii }} с другой стороны, вместе именуемые Стороны, заключили настоящий договор (далее - Договор) о нижеследующем:\r\n</p>\r\n<p align="center">\r\n	<strong> </strong>\r\n</p>\r\n<p align="center">\r\n	<strong>1. </strong><strong>Предмет договора</strong>\r\n</p>\r\n<p>\r\n	                   1.1. Исполнитель обязуется предоставить сотрудникам Заказчика (далее – Слушатели) платные образовательные услуги по повышению квалификации в соответствии с утвержденными дополнительными профессиональными программами (далее – ДПП) согласно Приложению №1 (далее – прил. №1), а Заказчик обязуется оплатить данные образовательные услуги.\r\n</p>\r\n<p>\r\n	                   1.2. Повышение квалификации слушателей проводится на основании лицензии на осуществление образовательной деятельности, выданной Региональной службой по надзору и контролю в сфере образования Ростовской области 18.12.2012, серия 61Л01 № 0000344, рег. № 3095.\r\n</p>\r\n<p>\r\n	                   1.3. Общий объем ДПП – 72 часа.\r\n</p>\r\n<p>\r\n	                   1.4. Срок освоения ДПП – 9 дней.\r\n</p>\r\n<p>\r\n	                   1.5. Форма обучения – заочная.\r\n</p>\r\n<p>\r\n	                   1.6. По результатам обучения (при условии успешного освоения ДПП) Исполнитель выдает каждому Слушателю удостоверение о повышении квалификации установленного образца по соответствующей ДПП, указанной в прил. №1.\r\n</p>\r\n<p align="center">\r\n	 <strong>2. Права и обязанности Исполнителя, Заказчика и Слушателя</strong>\r\n</p>\r\n<p>\r\n	             2.1. Права и обязанности Исполнителя.\r\n</p>\r\n<p>\r\n	             2.1.1. Исполнитель самостоятельно осуществляет образовательный процесс, выбирает системы оценок, формы, порядок и периодичность аттестации Слушателей.\r\n</p>\r\n<p>\r\n	             2.1.2. Исполнитель имеет право потребовать от Заказчика в письменном виде информацию и разъяснения по любому вопросу, связанному с выполнением         обязательств Исполнителя по договору.\r\n</p>\r\n<p>\r\n	             2.1.3. Исполнитель обязан обеспечить Заказчику оказание платных образовательных услуг в полном объеме в соответствии с образовательными программами,         утвержденными Исполнителем, и условиями договора.\r\n</p>\r\n<p>\r\n	             2.1.4. Исполнитель обеспечивает Слушателя учебно-методическими материалами в электронной форме по соответствующей ДПП согласно прил. №1.\r\n</p>\r\n<p>\r\n	             2.1.5. Исполнитель обязан довести до Заказчика информацию, содержащую сведения о предоставлении платных образовательных услуг в порядке и объеме,         которые предусмотрены Законом Российской Федерации «О защите прав потребителей» и Федеральным законом «Об образовании в Российской Федерации».\r\n</p>\r\n<p>\r\n	             2.2. Права и обязанности Заказчика.\r\n</p>\r\n<p>\r\n	             2.2.1. При нарушении Исполнителем сроков оказания платных образовательных услуг (сроков начала и (или) окончания оказания платных образовательных услуг         и (или) промежуточных сроков оказания платной образовательной услуги) Заказчик вправе по своему выбору:\r\n</p>\r\n<p>\r\n	             - назначить исполнителю новый срок, в течение которого исполнитель должен приступить к оказанию платных образовательных услуг и (или) закончить         оказание платных образовательных услуг;\r\n</p>\r\n<p>\r\n	             - потребовать уменьшения стоимости платных образовательных услуг.\r\n</p>\r\n<p>\r\n	             2.2.2. Заказчик обязан оплатить услуги Исполнителя в размере и сроки, предусмотренные условиями договора.\r\n</p>\r\n<p>\r\n	             2.2.3. Заказчик обязан соблюдать установленный Исполнителем порядок обучения (повышения квалификации).\r\n</p>\r\n<p>\r\n	             2.2.4. Заказчик обязан в 3-дневный срок с момента получения от Исполнителя запроса предоставлять информацию и разъяснения по любому вопросу, связанному         с выполнением обязательств Исполнителя по договору.\r\n</p>\r\n<p>\r\n	             2.2.5. Заказчик обязан контролировать освоение Слушателем ДПП в полном объеме (72 часа), а также прохождение слушателем промежуточной и итоговой         аттестаций.\r\n</p>\r\n<p>\r\n	             2.3. Права и обязанности Слушателя.\r\n</p>\r\n<p>\r\n	             2.3.1. Слушатель имеет право на бесплатное пользование электронными фондами библиотеки АНО ДПО «ЦКС».\r\n</p>\r\n<p>\r\n	             2.3.2. Слушатель имеет право своевременно получать информацию об образовательном процессе в необходимом объеме, установленном законодательством.\r\n</p>\r\n<p>\r\n	             2.3.3. Слушатель имеет право на объективную оценку в соответствии со своими знаниями, умением и навыками.\r\n</p>\r\n<p>\r\n	             2.3.4. Слушатель имеет право на получение соответствующих документов об уровне образования после итоговой аттестации.\r\n</p>\r\n<p>\r\n	             2.3.5. Слушатель обязан соблюдать установленный Исполнителем порядок обучения (повышения квалификации), а также порядки и положения, установленные         Исполнителем иными локальными актами.\r\n</p>\r\n<p>\r\n	             2.3.6. Слушатель обязан выполнять в установленные сроки все виды заданий, предусмотренные программой, в том числе выполнять задания для самостоятельной         подготовки, самостоятельно проходить промежуточную и итоговую аттестацию.\r\n</p>\r\n<p align="center">\r\n	<strong>3.Стоимость образовательных услуг и порядок оплаты</strong>\r\n</p>\r\n<p>\r\n	           3.1. За оказание образовательных услуг по повышению квалификации Заказчик оплачивает Исполнителю сумму в размере 10 000 рублей (Десять тысяч рублей) за         1 (одного) слушателя. НДС не облагается на основании п.2 ст.346.11 НК РФ. Стоимость установлена в соответствии с условиями Акции*.\r\n</p>\r\n<p>\r\n	           3.2. Оплата образовательных услуг в размере, указанном в п.3.1 Договора, осуществляется в течении 3 (трех) банковских дней с момента подписания         Договора.\r\n</p>\r\n<p align="center">\r\n	<strong>4. </strong><strong>Порядок изменения и расторжения договора</strong><strong></strong>\r\n</p>\r\n<p>\r\n	           4.1. Условия, на которых заключен настоящий договор, могут быть изменены либо по соглашению сторон, либо в соответствии с действующим законодательством         Российской Федерации. Все изменения оформляются в письменном виде путем подписания Сторонами дополнительных соглашений к настоящему договору. Все         приложения и дополнительные соглашения являются неотъемлемой частью договора. Дополнительные соглашения к настоящему договору вступают в силу с момента         их подписания Сторонами.\r\n</p>\r\n<p>\r\n	           4.2. Настоящий договор может быть расторгнут по обоюдному соглашению сторон.\r\n</p>\r\n<p>\r\n	           4.3. Заказчик вправе в одностороннем порядке отказаться от исполнения настоящего договора, предупредив об этом Исполнителя в письменной форме. В случае         отказа Заказчика от исполнения договора до начала обучения (повышения квалификации), уплаченная сумма возвращается ему в полном размере. В случае         отказа Заказчика от выполнения настоящего договора после начала обучения (повышения квалификации), а также в случае не сдачи итоговой аттестации         (тестирования) Слушателями, уплаченная сумма не возвращается.\r\n</p>\r\n<p>\r\n	           4.4. При нарушении Исполнителем сроков оказания платных образовательных услуг (сроков начала и (или) окончания оказания платных образовательных услуг и         (или) промежуточных сроков оказания платной образовательной услуги) Заказчик вправе в одностороннем порядке расторгнуть договор.\r\n</p>\r\n<p>\r\n	           4.5. Исполнитель имеет право расторгнуть договор в одностороннем порядке в следующих случаях:\r\n</p>\r\n<p>\r\n	           - применение к Слушателю отчисления как меры дисциплинарного взыскания;\r\n</p>\r\n<p>\r\n	           - невыполнение Слушателем обязанностей по добросовестному освоению ДПП и выполнению учебного плана;\r\n</p>\r\n<p>\r\n	           - установление нарушения порядка приема Слушателя в АНО ДПО «ЦКС», повлекшего по вине Слушателя его незаконное зачисление в АНО ДПО «ЦКС»;\r\n</p>\r\n<p>\r\n	           - просрочка оплаты стоимости платных образовательных услуг;\r\n</p>\r\n<p>\r\n	           - невозможность надлежащего исполнения обязательств по оказанию платных образовательных услуг вследствие действий (бездействия) Слушателя.\r\n</p>\r\n<p align="center">\r\n	<strong>5. </strong><strong>Ответственность </strong><strong>Исполнителя, Заказчика и Слушателя</strong>\r\n</p>\r\n<p>\r\n	           5.1. В случае неисполнения или ненадлежащего исполнения Исполнителем, Заказчиком и (или) Слушателем обязательств по настоящему договору они несут         ответственность, предусмотренную договором, Гражданским кодексом Российской Федерации, федеральными законами, Законом Российской Федерации «О защите         прав потребителей» и иными нормативными правовыми актами.\r\n</p>\r\n<p>\r\n	           5.2. Заказчик несет ответственность за достоверность всех предоставленных им сведений, в том числе, но не исключительно: сведений о сотрудниках         Заказчика, реквизитах Заказчика.\r\n</p>\r\n<p>\r\n	<strong> </strong>\r\n</p>\r\n<p align="center">\r\n	<strong>6. </strong><strong>Форс-мажорные обстоятельства</strong>\r\n</p>\r\n<p>\r\n	           6.1. При наступлении обстоятельств невозможности полного или частичного исполнения любой из Сторон обязательств по настоящему договору – непреодолимой         силы (форс-мажор), а именно: землетрясения, стихийного бедствия или других обстоятельств непреодолимой силы, срок исполнения обязательств по настоящему         договору отодвигается соразмерно времени, в течение которого будут действовать такие обстоятельства или их последствия.\r\n</p>\r\n<p>\r\n	           6.2. Если эти обстоятельства или их последствия будут продолжаться более трех месяцев, каждая из сторон вправе отказаться от дальнейшего исполнения         обязательств по настоящему договору без взаимных претензий друг к другу.\r\n</p>\r\n<p align="center">\r\n	<strong>7. </strong><strong>Прочие условия</strong>\r\n</p>\r\n<p>\r\n	           7.1. Настоящий договор вступает в силу с момента его подписания и действует до исполнения сторонами своих обязательств.\r\n</p>\r\n<p>\r\n	           7.2. Взаимоотношения сторон, неурегулированные договором, регламентируются действующим гражданским Законодательством РФ.\r\n</p>\r\n<p>\r\n	           7.3. В случае невозможности урегулирования возникающих споров и разногласий путем переговоров стороны обращаются в Арбитражный суд Ростовской области.\r\n</p>\r\n<p>\r\n	           7.4. Настоящий договор составлен в двух экземплярах, имеющих одинаковую юридическую силу, один из которых находится у Заказчика, второй – у         Исполнителя.\r\n</p>\r\n<p align="center">\r\n	<strong>8. Юридические адреса и реквизиты сторон</strong>\r\n</p>\r\n<table>\r\n<tbody>\r\n<tr>\r\n	<td valign="top" width="434">\r\n		<p>\r\n			<strong>Исполнитель:</strong>\r\n		</p>\r\n		<p>\r\n			                                   НОУ ДПО «ЦКС»\r\n		</p>\r\n		<p>\r\n			                                   Место нахождения исполнителя:\r\n		</p>\r\n		<p>\r\n			                                   344002, г. Ростов-на-Дону,\r\n		</p>\r\n		<p>\r\n			                                   пер. Соляной спуск, 8-10\r\n		</p>\r\n		<p>\r\n			                                   ОГРН 1146100003180\r\n		</p>\r\n		<p>\r\n			                                   ИНН 6164990894\r\n		</p>\r\n		<p>\r\n			                                   КПП 616401001\r\n		</p>\r\n		<p>\r\n			                                   р/сч 40703810626050000009\r\n		</p>\r\n		<p>\r\n			                                   к/сч 30101810500000000207\r\n		</p>\r\n		<p>\r\n			  Филиал "Ростовский" ОАО АЛЬФА-БАНК\r\n		</p>\r\n		<p>\r\n			  г. Ростов-на-Дону\r\n		</p>\r\n		<p>\r\n			                                   БИК 046015207\r\n		</p>\r\n		<p>\r\n			                                   телефон: (863) 299-07-14\r\n		</p>\r\n		<p>\r\n			                                   Руководитель\r\n		</p>\r\n		<p>\r\n			                                   ____________________П.А. Шумеев\r\n		</p>\r\n		<p>\r\n			                                   м.п.\r\n		</p>\r\n		<p>\r\n			<strong> </strong>\r\n		</p>\r\n	</td>\r\n	<td valign="top" width="434">\r\n		<p>\r\n			<strong>Заказчик:</strong>\r\n		</p>\r\n		<p>\r\n			                                   {{ @$NazvanieOrganizacii }}<br>\r\n			        Место нахождения заказчика:\r\n		</p>\r\n		<p>\r\n			        {{ @$UridicheskiyAdresOrganizacii }}\r\n		</p>\r\n		<p>\r\n			                                   {{ @$OGNROrganizacii }}\r\n		</p>\r\n		<p>\r\n			                                   {{ @$INNOrganizacii }}\r\n		</p>\r\n		<p>\r\n			                                   {{ @$KPPOrganizacii }}\r\n		</p>\r\n		<p>\r\n			                                   {{ @$RaschetnuySchetOrganizacii }}\r\n		</p>\r\n		<p>\r\n			                                   {{ @$KorrespondentskuyChetOrganizacii }}\r\n		</p>\r\n		<p>\r\n			                                   {{ @$NazvanieBankaOrganizacii }}\r\n		</p>\r\n		<p>\r\n			                                   {{ @$BIKOrganizacii }}\r\n		</p>\r\n		<p>\r\n			                                   телефон: {{ @$KontaktnuyTelefonZakazchika }\r\n		</p>\r\n		<p>\r\n			 <br>\r\n			 <br>\r\n			 <br>\r\n		</p>\r\n		<p>\r\n			  {{ @$DoljnostOtvetstvennogoLicaOrganizacii }}\r\n		</p>\r\n		<p>\r\n			                                   ____________________ФИО\r\n		</p>\r\n		<p>\r\n			                                   м.п.\r\n		</p>\r\n		<p>\r\n			<strong> </strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<p>\r\n	<strong> </strong>\r\n</p>\r\n<p>\r\n	                   *Стоимость оказания платных образовательных услуг установлена в соответствии с условиями Акции, утвержденной приказом руководителя НОУ ДПО «ЦКС» А №002         от 01.07.2014.\r\n</p>\r\n<p align="right">\r\n	                   Приложение №1\r\n</p>\r\n<p align="right">\r\n	                   к Договору №{{@$NomerZakaza }} ПК\r\n</p>\r\n<p align="right">\r\n	                   от {{ @$DataOformleniyaZakazaSlovami }}\r\n</p>\r\n<p style="text-align: center;">\r\n	        {{ @$TablicaSluschateleyDlyaDogovora}}\r\n</p>\r\n<p>\r\n	<strong> </strong>\r\n</p>\r\n<p>\r\n	<strong>Исполнитель:</strong>\r\n</p>\r\n<p>\r\n	                   Руководитель НОУ ДПО «ЦКС»\r\n</p>\r\n<p>\r\n	                   ___________________ П.А. Шумеев\r\n</p>\r\n<p>\r\n	                   м.п.\r\n</p>\r\n<p>\r\n	<strong> </strong>\r\n</p>\r\n<p>\r\n	<strong> </strong>\r\n</p>\r\n<p>\r\n	<strong> </strong>\r\n</p>\r\n<p>\r\n	<strong>Заказчик:</strong>\r\n</p>\r\n<p>\r\n	                   Директор <em><u>{{ @$NazvanieOrganizacii }}</u></em>\r\n</p>\r\n<p>\r\n	                   ___________________ <em><u>ФИО</u></em>\r\n</p>\r\n<p>\r\n	                   м.п.\r\n</p>\r\n<p align="right">\r\n	               Приложение №2*\r\n</p>\r\n<p align="right">\r\n	               к Договору №{{ @$NomerZakaza }} ПК\r\n</p>\r\n<p align="right">\r\n	               от {{ @$DataOformleniyaZakazaSlovami }}\r\n</p>\r\n<p align="center">\r\n	<strong> </strong>\r\n</p>\r\n<p align="center">\r\n	<strong>СОГЛАСИЕ</strong>\r\n</p>\r\n<p align="center">\r\n	<strong>на обработку персональных данных</strong>\r\n</p>\r\n<p>\r\n	               Я, нижеподписавшийся, ____________________________________________________\r\n</p>\r\n<p>\r\n	<sup>ФИО, почтовый адрес, </sup>\r\n</p>\r\n<p>\r\n	               ______________________________________________________________________________\r\n</p>\r\n<p>\r\n	<sup>№ и дата выдачи паспорта, название выдавшего паспорт органа</sup>\r\n</p>\r\n<p>\r\n	<sup>____________________________________________________________________________________________________________________________</sup>\r\n</p>\r\n<p>\r\n	               в соответствии с требованиями статьи 9 Федерального закона от 27.07.2006 № 152-ФЗ «О персональных данных» подтверждаю свое согласие на обработку     Негосударственным образовательным учреждением дополнительного профессионального образования «Центр качества строительства» (далее – Оператор) моих     персональных данных, представляемых для внесения в реестр слушателей Негосударственного образовательного учреждения дополнительного профессионального     образования «Центр качества строительства», включающих:\r\n</p>\r\n<p>\r\n	               1) фамилию, имя, отчество;\r\n</p>\r\n<p>\r\n	               2) пол;\r\n</p>\r\n<p>\r\n	               3) дату рождения;\r\n</p>\r\n<p>\r\n	               4) место жительства;\r\n</p>\r\n<p>\r\n	               5) контактный номер телефона;\r\n</p>\r\n<p>\r\n	               6) адрес электронной почты;\r\n</p>\r\n<p>\r\n	               7) сведения об образовании (номер и дата выдачи документа о высшем / среднем профессиональном, наименование специальности, учебного заведения)\r\n</p>\r\n<p>\r\n	               8) сведения о работодателе (ИНН, ОГРН, полное наименование, адрес);\r\n</p>\r\n<p>\r\n	               9) паспортные данные.\r\n</p>\r\n<p>\r\n	               Предоставляю Оператору право осуществлять все действия (операции) с моими персональными данными, включая сбор, систематизацию, накопление, хранение,     обновление, изменение, использование, обезличивание, блокирование, уничтожение. Оператор вправе обрабатывать мои персональные данные посредством внесения     их в электронную базу данных, включения в списки (реестры) и отчетные формы, предусмотренные документами, регламентирующими предоставление отчетных данных     (документов).\r\n</p>\r\n<p>\r\n	               Оператор имеет право на обмен (прием и передачу) моими персональными данными с использованием машинных носителей или по каналам связи, с соблюдением мер,     обеспечивающих их защиту от несанкционированного доступа, при условии, что их прием и обработка будут осуществляться лицом, обязанным сохранять     профессиональную тайну.\r\n</p>\r\n<p>\r\n	               Настоящее согласие действует бессрочно, срок хранения моих персональных данных не ограничен.\r\n</p>\r\n<p>\r\n	               Оставляю за собой право отозвать свое согласие посредством составления соответствующего письменного документа, который может быть направлен мной в адрес     Оператора по почте заказным письмом с уведомлением о вручении либо вручен лично под расписку представителю Оператора. В случае получения моего письменного     заявления об отзыве настоящего согласия на обработку персональных данных Оператор обязан прекратить их обработку и исключить соответствующие сведения из     реестра слушателей Негосударственного образовательного учреждения дополнительного профессионального образования «Центр качества строительства».\r\n</p>\r\n<p>\r\n	               Подпись субъекта персональных данных ________________________________________\r\n</p>\r\n<p>\r\n	               Дата: _________________\r\n</p>\r\n<p>\r\n	               * - заполняется каждым слушателем самостоятельно\r\n</p>', '2014-11-19 11:44:15', '2014-11-19 11:44:15'),
(329, 165, NULL, 'word_template', '133', '2014-11-19 11:44:15', '2014-11-19 11:44:15'),
(330, 166, NULL, 'user_id', '2', '2014-11-19 11:44:15', '2014-11-19 11:44:15'),
(331, 166, NULL, 'action_id', '21', '2014-11-19 11:44:15', '2014-11-19 11:44:15'),
(332, 166, NULL, 'title', 'Событие за 19.11.2014 в 11:44', '2014-11-19 11:44:15', '2014-11-19 11:44:15'),
(333, 166, NULL, 'link', NULL, '2014-11-19 11:44:15', '2014-11-19 11:44:15'),
(334, 166, NULL, 'created_time', '2014-11-19 11:44:15', '2014-11-19 11:44:15', '2014-11-19 11:44:15'),
(335, 167, NULL, 'variables', '', '2014-11-19 12:01:44', '2014-11-19 12:01:44'),
(336, 167, NULL, 'content', '<p align="right">\r\n	    Приложение №1\r\n</p>\r\n<p align="right">\r\n	    к Договору №{{@$NomerZakaza }} ЭПК\r\n</p>\r\n<p align="right">\r\n	    от {{ @$DataOformleniyaZakazaSlovami }}\r\n</p>\r\n    {{ @$TablicaSluschateleyDlyaDogovora }}\r\n<table>\r\n<tbody>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			<strong>Исполнитель:</strong>\r\n		</p>\r\n		<p>\r\n			                           Руководитель НОУ ДПО «ЦКС»\r\n		</p>\r\n		<p>\r\n			                           ___________________ П.А. Шумеев\r\n		</p>\r\n		<p>\r\n			                           м.п.\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<strong>Заказчик:</strong>\r\n		<p>\r\n			                           {{@$DoljnostOtvetstvennogoLicaOrganizacii}} <em><u>{{@$NazvanieOrganizacii}}</u></em>\r\n		</p>\r\n		<p>\r\n			                           ___________________ <em><u>ФИО</u></em>\r\n		</p>\r\n		<p>\r\n			                           м.п.\r\n		</p>\r\n	</td>\r\n</tr>\r\n</tbody>\r\n</table>', '2014-11-19 12:01:44', '2014-12-04 11:59:36'),
(337, 167, NULL, 'word_template', NULL, '2014-11-19 12:01:44', '2014-11-19 12:01:44'),
(338, 169, NULL, 'user_id', '2', '2014-11-19 12:01:44', '2014-11-19 12:01:44'),
(339, 169, NULL, 'action_id', '21', '2014-11-19 12:01:44', '2014-11-19 12:01:44'),
(340, 169, NULL, 'title', 'Событие за 19.11.2014 в 12:01', '2014-11-19 12:01:44', '2014-11-19 12:01:44'),
(341, 169, NULL, 'link', NULL, '2014-11-19 12:01:44', '2014-11-19 12:01:44'),
(342, 169, NULL, 'created_time', '2014-11-19 12:01:44', '2014-11-19 12:01:44', '2014-11-19 12:01:44'),
(343, 170, NULL, 'variables', '', '2014-11-19 13:39:37', '2014-11-19 13:39:37'),
(344, 170, NULL, 'content', '<p align="center">\r\n	<strong>СОГЛАСИЕ</strong>\r\n</p>\r\n<p align="center">\r\n	<strong>на обработку персональных данных</strong>\r\n</p>\r\n<p>\r\n	         Я, нижеподписавшийся, <u> {{ $FIO_listener }}, {{ $Address_listener }} </u>\r\n</p>\r\n<p>\r\n	<sup>ФИО, почтовый адрес, </sup>\r\n</p>\r\n<p>\r\n	         _____________________________________________________________________________________\r\n</p>\r\n<p>\r\n	<sup>№ и дата выдачи паспорта, название выдавшего паспорт органа</sup>\r\n</p>\r\n<p>\r\n	<sup>____________________________________________________________________________________________________________________________</sup>\r\n</p>\r\n<p>\r\n	         в соответствии с требованиями статьи 9 Федерального закона от 27.07.2006 № 152-ФЗ «О персональных данных» подтверждаю свое согласие на обработку Автономной     некоммерческой организацией дополнительного профессионального образования «Центр качества строительства» (далее – Оператор) моих персональных данных,     представляемых для внесения в реестр слушателей Автономной некоммерческой организации дополнительного профессионального образования «Центр качества     строительства», включающих:\r\n</p>\r\n<p>\r\n	         1) паспортные данные;\r\n</p>\r\n<p>\r\n	         2) фамилию, имя, отчество;\r\n</p>\r\n<p>\r\n	         3) пол;\r\n</p>\r\n<p>\r\n	         4) дату рождения;\r\n</p>\r\n<p>\r\n	         5) место жительства;\r\n</p>\r\n<p>\r\n	         6) контактный номер телефона;\r\n</p>\r\n<p>\r\n	         7) адрес электронной почты;\r\n</p>\r\n<p>\r\n	         8) сведения об образовании (номер и дата выдачи документа о высшем / среднем профессиональном, наименование специальности, учебного заведения)\r\n</p>\r\n<p>\r\n	         9) сведения о работодателе;\r\n</p>\r\n<p>\r\n	         10) должность.\r\n</p>\r\n<p>\r\n	         Предоставляю Оператору право осуществлять все действия (операции) с моими персональными данными, включая сбор, систематизацию, накопление, хранение,     обновление, изменение, использование, обезличивание, блокирование, уничтожение. Оператор вправе обрабатывать мои персональные данные посредством внесения     их в электронную базу данных, включения в списки (реестры) и отчетные формы, предусмотренные документами, регламентирующими предоставление отчетных данных     (документов).\r\n</p>\r\n<p>\r\n	         Оператор имеет право на обмен (прием и передачу) моими персональными данными с использованием машинных носителей или по каналам связи, с соблюдением мер,     обеспечивающих их защиту от несанкционированного доступа, при условии, что их прием и обработка будут осуществляться лицом, обязанным сохранять     профессиональную тайну.\r\n</p>\r\n<p>\r\n	         Настоящее согласие действует бессрочно, срок хранения моих персональных данных не ограничен.\r\n</p>\r\n<p>\r\n	         Оставляю за собой право отозвать свое согласие посредством составления соответствующего письменного документа, который может быть направлен мной в адрес     Оператора по почте заказным письмом с уведомлением о вручении либо вручен лично под расписку представителю Оператора. В случае получения моего письменного     заявления об отзыве настоящего согласия на обработку персональных данных Оператор обязан прекратить их обработку и исключить соответствующие сведения из     реестра слушателей Автономной некоммерческой организации дополнительного профессионального образования «Центр качества строительства».\r\n</p>\r\n<p>\r\n	         Подпись субъекта персональных данных ________________________________________\r\n</p>\r\n<p>\r\n	         Дата: _________________\r\n</p>', '2014-11-19 13:39:37', '2014-11-19 13:39:37'),
(345, 170, NULL, 'word_template', NULL, '2014-11-19 13:39:37', '2014-11-19 13:39:37'),
(346, 172, NULL, 'user_id', '2', '2014-11-19 13:39:37', '2014-11-19 13:39:37'),
(347, 172, NULL, 'action_id', '21', '2014-11-19 13:39:37', '2014-11-19 13:39:37'),
(348, 172, NULL, 'title', 'Событие за 19.11.2014 в 13:39', '2014-11-19 13:39:37', '2014-11-19 13:39:37'),
(349, 172, NULL, 'link', NULL, '2014-11-19 13:39:37', '2014-11-19 13:39:37'),
(350, 172, NULL, 'created_time', '2014-11-19 13:39:37', '2014-11-19 13:39:37', '2014-11-19 13:39:37'),
(354, 174, NULL, 'user_id', '2', '2014-11-19 14:36:05', '2014-11-19 14:36:05'),
(355, 174, NULL, 'action_id', '21', '2014-11-19 14:36:05', '2014-11-19 14:36:05'),
(356, 174, NULL, 'title', 'Событие за 19.11.2014 в 14:36', '2014-11-19 14:36:05', '2014-11-19 14:36:05'),
(357, 174, NULL, 'link', NULL, '2014-11-19 14:36:05', '2014-11-19 14:36:05'),
(358, 174, NULL, 'created_time', '2014-11-19 14:36:05', '2014-11-19 14:36:05', '2014-11-19 14:36:05'),
(362, 176, NULL, 'user_id', '2', '2014-11-19 14:58:27', '2014-11-19 14:58:27'),
(363, 176, NULL, 'action_id', '21', '2014-11-19 14:58:27', '2014-11-19 14:58:27'),
(364, 176, NULL, 'title', 'Событие за 19.11.2014 в 14:58', '2014-11-19 14:58:27', '2014-11-19 14:58:27'),
(365, 176, NULL, 'link', NULL, '2014-11-19 14:58:27', '2014-11-19 14:58:27'),
(366, 176, NULL, 'created_time', '2014-11-19 14:58:27', '2014-11-19 14:58:27', '2014-11-19 14:58:27'),
(370, 178, NULL, 'user_id', '2', '2014-11-19 16:24:40', '2014-11-19 16:24:40'),
(371, 178, NULL, 'action_id', '21', '2014-11-19 16:24:40', '2014-11-19 16:24:40'),
(372, 178, NULL, 'title', 'Событие за 19.11.2014 в 16:24', '2014-11-19 16:24:40', '2014-11-19 16:24:40'),
(373, 178, NULL, 'link', NULL, '2014-11-19 16:24:40', '2014-11-19 16:24:40'),
(374, 178, NULL, 'created_time', '2014-11-19 16:24:40', '2014-11-19 16:24:40', '2014-11-19 16:24:40'),
(378, 180, NULL, 'user_id', '2', '2014-11-19 16:30:58', '2014-11-19 16:30:58'),
(379, 180, NULL, 'action_id', '21', '2014-11-19 16:30:58', '2014-11-19 16:30:58'),
(380, 180, NULL, 'title', 'Событие за 19.11.2014 в 16:30', '2014-11-19 16:30:58', '2014-11-19 16:30:58'),
(381, 180, NULL, 'link', NULL, '2014-11-19 16:30:58', '2014-11-19 16:30:58'),
(382, 180, NULL, 'created_time', '2014-11-19 16:30:58', '2014-11-19 16:30:58', '2014-11-19 16:30:58'),
(386, 182, NULL, 'user_id', '2', '2014-11-19 16:31:30', '2014-11-19 16:31:30'),
(387, 182, NULL, 'action_id', '21', '2014-11-19 16:31:30', '2014-11-19 16:31:30'),
(388, 182, NULL, 'title', 'Событие за 19.11.2014 в 16:31', '2014-11-19 16:31:30', '2014-11-19 16:31:30'),
(389, 182, NULL, 'link', NULL, '2014-11-19 16:31:30', '2014-11-19 16:31:30'),
(390, 182, NULL, 'created_time', '2014-11-19 16:31:30', '2014-11-19 16:31:30', '2014-11-19 16:31:30'),
(391, 183, NULL, 'variables', '', '2014-11-19 16:32:40', '2014-11-19 16:32:40'),
(392, 183, NULL, 'content', '<table border="1" cellpadding="0" cellspacing="0">\r\n<tbody>\r\n<tr>\r\n	<td valign="top" width="218">\r\n		<p>\r\n			                                    ИНН 6164990894\r\n		</p>\r\n	</td>\r\n	<td width="218">\r\n		<p>\r\n			                                    КПП 616401001\r\n		</p>\r\n	</td>\r\n	<td valign="top" width="218">\r\n		<p>\r\n			                                    р/с №\r\n		</p>\r\n	</td>\r\n	<td rowspan="2" valign="top" width="218">\r\n		<p>\r\n			                                    40703810626050000009\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="3" valign="top" width="654">\r\n		<p>\r\n			                                    Автономная некоммерческая организация дополнительного профессионального образования "Центр качества строительства"\r\n		</p>\r\n		<p>\r\n			                                    Получатель\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td colspan="2" rowspan="2" width="436">\r\n		<p>\r\n			                                    Филиал "Ростовский" ОАО АЛЬФА-БАНК г. Ростов-на-Дону\r\n		</p>\r\n		<p>\r\n			                                    Банк получателя\r\n		</p>\r\n	</td>\r\n	<td valign="top" width="218">\r\n		<p>\r\n			                                    БИК\r\n		</p>\r\n	</td>\r\n	<td rowspan="2" valign="top" width="218">\r\n		<p>\r\n			                                    046015207\r\n		</p>\r\n		<p>\r\n			                                    30101810500000000207\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td width="218">\r\n		<p>\r\n			                                    к/с №\r\n		</p>\r\n	</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<p>\r\n	                    Счет № {{ @$NomerZakaza }}<strong> </strong>от {{ @$DataOplatuZakaza }}\r\n</p>\r\n<table border="1" cellpadding="0" cellspacing="0">\r\n<tbody>\r\n<tr>\r\n	<td valign="top" width="108">\r\n		<p>\r\n			                                    Поставщик:\r\n		</p>\r\n	</td>\r\n	<td valign="top" width="763">\r\n		<p>\r\n			 <strong>                         Автономная некоммерческая организация дополнительного профессионального образования "Центр качества строительства", ИНН 6164990894, КПП                         616401001, г. Ростов-на-Дону, ул. Соляной спуск, д. 8-10, тел. (863) 299-07-14                     </strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<table border="0" cellpadding="0" cellspacing="0" width="793">\r\n<tbody>\r\n<tr>\r\n	<td nowrap="" valign="top" width="98">\r\n		<p>\r\n			                                    Покупатель:\r\n		</p>\r\n	</td>\r\n	<td valign="top" width="666">\r\n		<p>\r\n			 <strong></strong>\r\n		</p>\r\n		<p>\r\n			              {{ @$NazvanieOrganizacii }}\r\n		</p>\r\n		<p>\r\n			<strong></strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<p>\r\n	     {{ @$SpisokSluschateleyDlyaScheta }}\r\n</p>\r\n<div align="right">\r\n	<table border="1" cellpadding="0" cellspacing="0" width="350">\r\n	<tbody>\r\n	<tr>\r\n		<td nowrap="" valign="top" width="150">\r\n			<p align="right">\r\n				 <strong>Итого</strong>\r\n			</p>\r\n		</td>\r\n		<td nowrap="" valign="top" width="200">\r\n			<p align="right">\r\n				 <strong></strong>\r\n			</p>\r\n			<p align="right">\r\n				<strong>{{ @$SummaZakaza }},00</strong>\r\n			</p>\r\n		</td>\r\n	</tr>\r\n	<tr>\r\n		<td nowrap="" valign="top" width="133">\r\n			<p align="right">\r\n				 <strong>Сумма НДС</strong>\r\n			</p>\r\n		</td>\r\n		<td nowrap="" valign="top" width="115">\r\n			<p align="right">\r\n				 <strong>0,00</strong>\r\n			</p>\r\n		</td>\r\n	</tr>\r\n	</tbody>\r\n	</table>\r\n</div>\r\n<p>\r\n	                    В поле "Назначение платежа" необходимо указать:\r\n</p>\r\n<p>\r\n	                    Оказание платных образовательных услуг в соответствии с договором №{{ @$NomerZakaza}} от {{ @$DataOplatuZakaza }}.\r\n</p>\r\n<p>\r\n	                    Всего наименований: {{ @$VsegoNaimenovaliy }}; количество: {{ @$KolichestvoNaimenovaliy }}\r\n</p>\r\n<p>\r\n	               на сумму {{ @$SummaZakaza }}.00 Руб\r\n</p>\r\n<p>\r\n	 ({{ @$SummaZakazaSlovami }})\r\n</p>\r\n<p>\r\n	 Руководитель /Шумеев П.А./\r\n</p>', '2014-11-19 16:32:40', '2014-11-19 16:32:40'),
(393, 183, NULL, 'word_template', '135', '2014-11-19 16:32:40', '2014-11-19 16:32:40'),
(394, 184, NULL, 'user_id', '2', '2014-11-19 16:32:40', '2014-11-19 16:32:40'),
(395, 184, NULL, 'action_id', '21', '2014-11-19 16:32:40', '2014-11-19 16:32:40'),
(396, 184, NULL, 'title', 'Событие за 19.11.2014 в 16:32', '2014-11-19 16:32:40', '2014-11-19 16:32:40'),
(397, 184, NULL, 'link', NULL, '2014-11-19 16:32:40', '2014-11-19 16:32:40'),
(398, 184, NULL, 'created_time', '2014-11-19 16:32:40', '2014-11-19 16:32:40', '2014-11-19 16:32:40'),
(399, 185, NULL, 'user_id', '0', '2014-11-26 13:13:31', '2014-11-26 13:13:31'),
(400, 185, NULL, 'action_id', '61', '2014-11-26 13:13:31', '2014-11-26 13:13:31'),
(401, 185, NULL, 'created_time', '2014-11-26 13:13:31', '2014-11-26 13:13:31', '2014-11-26 13:13:31'),
(402, 186, NULL, 'user_id', '0', '2014-11-26 13:18:38', '2014-11-26 13:18:38'),
(403, 186, NULL, 'action_id', '61', '2014-11-26 13:18:38', '2014-11-26 13:18:38'),
(404, 186, NULL, 'created_time', '2014-11-26 13:18:38', '2014-11-26 13:18:38', '2014-11-26 13:18:38'),
(405, 187, NULL, 'user_id', '8', '2014-11-26 13:19:49', '2014-11-26 13:19:49'),
(406, 187, NULL, 'action_id', '47', '2014-11-26 13:19:49', '2014-11-26 13:19:49'),
(407, 187, NULL, 'created_time', '2014-11-26 13:19:49', '2014-11-26 13:19:49', '2014-11-26 13:19:49'),
(408, 188, NULL, 'user_id', '8', '2014-11-26 13:19:49', '2014-11-26 13:19:49'),
(409, 188, NULL, 'action_id', '46', '2014-11-26 13:19:49', '2014-11-26 13:19:49'),
(410, 188, NULL, 'created_time', '2014-11-26 13:19:49', '2014-11-26 13:19:49', '2014-11-26 13:19:49'),
(411, 189, NULL, 'user_id', '8', '2014-11-26 13:19:49', '2014-11-26 13:19:49'),
(412, 189, NULL, 'action_id', '157', '2014-11-26 13:19:49', '2014-11-26 13:19:49'),
(413, 189, NULL, 'created_time', '2014-11-26 13:19:49', '2014-11-26 13:19:49', '2014-11-26 13:19:49'),
(414, 190, NULL, 'user_id', '8', '2014-11-26 13:19:49', '2014-11-26 13:19:49'),
(415, 190, NULL, 'action_id', '158', '2014-11-26 13:19:49', '2014-11-26 13:19:49'),
(416, 190, NULL, 'created_time', '2014-11-26 13:19:49', '2014-11-26 13:19:49', '2014-11-26 13:19:49'),
(417, 191, NULL, 'user_id', '0', '2014-11-26 13:31:15', '2014-11-26 13:31:15'),
(418, 191, NULL, 'action_id', '63', '2014-11-26 13:31:15', '2014-11-26 13:31:15'),
(419, 191, NULL, 'created_time', '2014-11-26 13:31:15', '2014-11-26 13:31:15', '2014-11-26 13:31:15'),
(420, 192, NULL, 'user_id', '8', '2014-11-26 13:31:46', '2014-11-26 13:31:46'),
(421, 192, NULL, 'action_id', '78', '2014-11-26 13:31:46', '2014-11-26 13:31:46'),
(422, 192, NULL, 'created_time', '2014-11-26 13:31:46', '2014-11-26 13:31:46', '2014-11-26 13:31:46'),
(423, 193, NULL, 'user_id', '0', '2014-11-26 13:31:46', '2014-11-26 13:31:46'),
(424, 193, NULL, 'action_id', '65', '2014-11-26 13:31:46', '2014-11-26 13:31:46'),
(425, 193, NULL, 'created_time', '2014-11-26 13:31:46', '2014-11-26 13:31:46', '2014-11-26 13:31:46'),
(426, 194, NULL, 'user_id', '0', '2014-11-27 08:40:55', '2014-11-27 08:40:55'),
(427, 194, NULL, 'action_id', '61', '2014-11-27 08:40:55', '2014-11-27 08:40:55'),
(428, 194, NULL, 'created_time', '2014-11-27 08:40:55', '2014-11-27 08:40:55', '2014-11-27 08:40:55');
INSERT INTO `dictionary_fields_values` (`id`, `dicval_id`, `language`, `key`, `value`, `created_at`, `updated_at`) VALUES
(429, 195, NULL, 'user_id', '0', '2014-11-27 13:39:01', '2014-11-27 13:39:01'),
(430, 195, NULL, 'action_id', '63', '2014-11-27 13:39:01', '2014-11-27 13:39:01'),
(431, 195, NULL, 'created_time', '2014-11-27 13:39:01', '2014-11-27 13:39:01', '2014-11-27 13:39:01'),
(432, 196, NULL, 'user_id', '8', '2014-11-28 10:51:33', '2014-11-28 10:51:33'),
(433, 196, NULL, 'action_id', '78', '2014-11-28 10:51:33', '2014-11-28 10:51:33'),
(434, 196, NULL, 'created_time', '2014-11-28 10:51:33', '2014-11-28 10:51:33', '2014-11-28 10:51:33'),
(435, 197, NULL, 'user_id', '0', '2014-11-28 10:51:33', '2014-11-28 10:51:33'),
(436, 197, NULL, 'action_id', '65', '2014-11-28 10:51:33', '2014-11-28 10:51:33'),
(437, 197, NULL, 'created_time', '2014-11-28 10:51:33', '2014-11-28 10:51:33', '2014-11-28 10:51:33'),
(438, 198, NULL, 'user_id', '8', '2014-11-28 11:15:30', '2014-11-28 11:15:30'),
(439, 198, NULL, 'action_id', '57', '2014-11-28 11:15:30', '2014-11-28 11:15:30'),
(440, 198, NULL, 'created_time', '2014-11-28 11:15:30', '2014-11-28 11:15:30', '2014-11-28 11:15:30'),
(441, 199, NULL, 'user_id', '2', '2014-11-28 11:15:30', '2014-11-28 11:15:30'),
(442, 199, NULL, 'action_id', '25', '2014-11-28 11:15:30', '2014-11-28 11:15:30'),
(443, 199, NULL, 'title', 'Заказ №3', '2014-11-28 11:15:30', '2014-11-28 11:15:30'),
(444, 199, NULL, 'link', NULL, '2014-11-28 11:15:30', '2014-11-28 11:15:30'),
(445, 199, NULL, 'created_time', '2014-11-28 11:15:30', '2014-11-28 11:15:30', '2014-11-28 11:15:30'),
(446, 200, NULL, 'user_id', '8', '2014-11-28 11:16:11', '2014-11-28 11:16:11'),
(447, 200, NULL, 'action_id', '50', '2014-11-28 11:16:11', '2014-11-28 11:16:11'),
(448, 200, NULL, 'created_time', '2014-11-28 11:16:11', '2014-11-28 11:16:11', '2014-11-28 11:16:11'),
(449, 201, NULL, 'user_id', '2', '2014-11-28 11:27:09', '2014-11-28 11:27:09'),
(450, 201, NULL, 'action_id', '28', '2014-11-28 11:27:09', '2014-11-28 11:27:09'),
(451, 201, NULL, 'title', 'ПМЖ-12', '2014-11-28 11:27:09', '2014-11-28 11:27:09'),
(452, 201, NULL, 'link', NULL, '2014-11-28 11:27:09', '2014-11-28 11:27:09'),
(453, 201, NULL, 'created_time', '2014-11-28 11:27:09', '2014-11-28 11:27:09', '2014-11-28 11:27:09'),
(454, 202, NULL, 'user_id', '8', '2014-11-28 11:27:09', '2014-11-28 11:27:09'),
(455, 202, NULL, 'action_id', '159', '2014-11-28 11:27:09', '2014-11-28 11:27:09'),
(456, 202, NULL, 'created_time', '2014-11-28 11:27:09', '2014-11-28 11:27:09', '2014-11-28 11:27:09'),
(457, 203, NULL, 'user_id', '2', '2014-11-28 11:27:09', '2014-11-28 11:27:09'),
(458, 203, NULL, 'action_id', '26', '2014-11-28 11:27:09', '2014-11-28 11:27:09'),
(459, 203, NULL, 'title', 'Организация: ПМЖ-12', '2014-11-28 11:27:09', '2014-11-28 11:27:09'),
(460, 203, NULL, 'link', NULL, '2014-11-28 11:27:09', '2014-11-28 11:27:09'),
(461, 203, NULL, 'created_time', '2014-11-28 11:27:09', '2014-11-28 11:27:09', '2014-11-28 11:27:09'),
(462, 204, NULL, 'user_id', '2', '2014-11-28 14:30:40', '2014-11-28 14:30:40'),
(463, 204, NULL, 'action_id', '13', '2014-11-28 14:30:40', '2014-11-28 14:30:40'),
(464, 204, NULL, 'title', 'Промежуточное тестирование. Курс: Строительство, реконструкция, капитальный ремонт объектов капитального строительства (возведение каменных, металлических и деревянных строительных конструкций)', '2014-11-28 14:30:40', '2014-11-28 14:30:40'),
(465, 204, NULL, 'link', NULL, '2014-11-28 14:30:40', '2014-11-28 14:30:40'),
(466, 204, NULL, 'created_time', '2014-11-28 14:30:40', '2014-11-28 14:30:40', '2014-11-28 14:30:40'),
(470, 206, NULL, 'user_id', '0', '2014-11-28 15:02:13', '2014-11-28 15:02:13'),
(471, 206, NULL, 'action_id', '63', '2014-11-28 15:02:13', '2014-11-28 15:02:13'),
(472, 206, NULL, 'created_time', '2014-11-28 15:02:13', '2014-11-28 15:02:13', '2014-11-28 15:02:13'),
(473, 207, NULL, 'user_id', '12', '2014-11-28 15:10:13', '2014-11-28 15:10:13'),
(474, 207, NULL, 'action_id', '157', '2014-11-28 15:10:13', '2014-11-28 15:10:13'),
(475, 207, NULL, 'created_time', '2014-11-28 15:10:13', '2014-11-28 15:10:13', '2014-11-28 15:10:13'),
(476, 208, NULL, 'user_id', '12', '2014-11-28 15:10:13', '2014-11-28 15:10:13'),
(477, 208, NULL, 'action_id', '158', '2014-11-28 15:10:13', '2014-11-28 15:10:13'),
(478, 208, NULL, 'created_time', '2014-11-28 15:10:13', '2014-11-28 15:10:13', '2014-11-28 15:10:13'),
(479, 209, NULL, 'user_id', '8', '2014-11-28 16:34:34', '2014-11-28 16:34:34'),
(480, 209, NULL, 'action_id', '52', '2014-11-28 16:34:34', '2014-11-28 16:34:34'),
(481, 209, NULL, 'created_time', '2014-11-28 16:34:34', '2014-11-28 16:34:34', '2014-11-28 16:34:34'),
(482, 210, NULL, 'user_id', '8', '2014-11-28 16:56:18', '2014-11-28 16:56:18'),
(483, 210, NULL, 'action_id', '52', '2014-11-28 16:56:18', '2014-11-28 16:56:18'),
(484, 210, NULL, 'created_time', '2014-11-28 16:56:18', '2014-11-28 16:56:18', '2014-11-28 16:56:18'),
(485, 211, NULL, 'user_id', '0', '2014-12-01 13:34:18', '2014-12-01 13:34:18'),
(486, 211, NULL, 'action_id', '61', '2014-12-01 13:34:18', '2014-12-01 13:34:18'),
(487, 211, NULL, 'created_time', '2014-12-01 13:34:18', '2014-12-01 13:34:18', '2014-12-01 13:34:18'),
(488, 212, NULL, 'user_id', '8', '2014-12-01 14:29:15', '2014-12-01 14:29:15'),
(489, 212, NULL, 'action_id', '51', '2014-12-01 14:29:15', '2014-12-01 14:29:15'),
(490, 212, NULL, 'created_time', '2014-12-01 14:29:15', '2014-12-01 14:29:15', '2014-12-01 14:29:15'),
(494, 215, NULL, 'user_id', '8', '2014-12-01 15:29:49', '2014-12-01 15:29:49'),
(495, 215, NULL, 'action_id', '51', '2014-12-01 15:29:49', '2014-12-01 15:29:49'),
(496, 215, NULL, 'created_time', '2014-12-01 15:29:49', '2014-12-01 15:29:49', '2014-12-01 15:29:49'),
(497, 216, NULL, 'user_id', '8', '2014-12-01 15:30:26', '2014-12-01 15:30:26'),
(498, 216, NULL, 'action_id', '214', '2014-12-01 15:30:26', '2014-12-01 15:30:26'),
(499, 216, NULL, 'created_time', '2014-12-01 15:30:26', '2014-12-01 15:30:26', '2014-12-01 15:30:26'),
(500, 217, NULL, 'user_id', '8', '2014-12-01 15:30:50', '2014-12-01 15:30:50'),
(501, 217, NULL, 'action_id', '51', '2014-12-01 15:30:50', '2014-12-01 15:30:50'),
(502, 217, NULL, 'created_time', '2014-12-01 15:30:50', '2014-12-01 15:30:50', '2014-12-01 15:30:50'),
(503, 218, NULL, 'user_id', '8', '2014-12-01 16:08:49', '2014-12-01 16:08:49'),
(504, 218, NULL, 'action_id', '51', '2014-12-01 16:08:49', '2014-12-01 16:08:49'),
(505, 218, NULL, 'created_time', '2014-12-01 16:08:49', '2014-12-01 16:08:49', '2014-12-01 16:08:49'),
(506, 219, NULL, 'user_id', '0', '2014-12-02 08:49:55', '2014-12-02 08:49:55'),
(507, 219, NULL, 'action_id', '61', '2014-12-02 08:49:55', '2014-12-02 08:49:55'),
(508, 219, NULL, 'created_time', '2014-12-02 08:49:55', '2014-12-02 08:49:55', '2014-12-02 08:49:55'),
(509, 220, NULL, 'user_id', '14', '2014-12-02 08:51:25', '2014-12-02 08:51:25'),
(510, 220, NULL, 'action_id', '47', '2014-12-02 08:51:25', '2014-12-02 08:51:25'),
(511, 220, NULL, 'created_time', '2014-12-02 08:51:25', '2014-12-02 08:51:25', '2014-12-02 08:51:25'),
(512, 221, NULL, 'user_id', '14', '2014-12-02 08:51:25', '2014-12-02 08:51:25'),
(513, 221, NULL, 'action_id', '46', '2014-12-02 08:51:25', '2014-12-02 08:51:25'),
(514, 221, NULL, 'created_time', '2014-12-02 08:51:25', '2014-12-02 08:51:25', '2014-12-02 08:51:25'),
(515, 222, NULL, 'user_id', '14', '2014-12-02 08:51:25', '2014-12-02 08:51:25'),
(516, 222, NULL, 'action_id', '157', '2014-12-02 08:51:25', '2014-12-02 08:51:25'),
(517, 222, NULL, 'created_time', '2014-12-02 08:51:25', '2014-12-02 08:51:25', '2014-12-02 08:51:25'),
(518, 223, NULL, 'user_id', '14', '2014-12-02 08:51:25', '2014-12-02 08:51:25'),
(519, 223, NULL, 'action_id', '158', '2014-12-02 08:51:25', '2014-12-02 08:51:25'),
(520, 223, NULL, 'created_time', '2014-12-02 08:51:25', '2014-12-02 08:51:25', '2014-12-02 08:51:25'),
(521, 224, NULL, 'user_id', '0', '2014-12-02 09:01:42', '2014-12-02 09:01:42'),
(522, 224, NULL, 'action_id', '61', '2014-12-02 09:01:42', '2014-12-02 09:01:42'),
(523, 224, NULL, 'created_time', '2014-12-02 09:01:42', '2014-12-02 09:01:42', '2014-12-02 09:01:42'),
(524, 225, NULL, 'user_id', '15', '2014-12-02 09:02:03', '2014-12-02 09:02:03'),
(525, 225, NULL, 'action_id', '47', '2014-12-02 09:02:03', '2014-12-02 09:02:03'),
(526, 225, NULL, 'created_time', '2014-12-02 09:02:03', '2014-12-02 09:02:03', '2014-12-02 09:02:03'),
(527, 226, NULL, 'user_id', '15', '2014-12-02 09:02:03', '2014-12-02 09:02:03'),
(528, 226, NULL, 'action_id', '46', '2014-12-02 09:02:04', '2014-12-02 09:02:04'),
(529, 226, NULL, 'created_time', '2014-12-02 09:02:03', '2014-12-02 09:02:04', '2014-12-02 09:02:04'),
(530, 227, NULL, 'user_id', '15', '2014-12-02 09:02:04', '2014-12-02 09:02:04'),
(531, 227, NULL, 'action_id', '157', '2014-12-02 09:02:04', '2014-12-02 09:02:04'),
(532, 227, NULL, 'created_time', '2014-12-02 09:02:04', '2014-12-02 09:02:04', '2014-12-02 09:02:04'),
(536, 229, NULL, 'user_id', '2', '2014-12-02 12:09:33', '2014-12-02 12:09:33'),
(537, 229, NULL, 'action_id', '21', '2014-12-02 12:09:33', '2014-12-02 12:09:33'),
(538, 229, NULL, 'title', 'Событие за 02.12.2014 в 12:09', '2014-12-02 12:09:33', '2014-12-02 12:09:33'),
(539, 229, NULL, 'link', NULL, '2014-12-02 12:09:33', '2014-12-02 12:09:33'),
(540, 229, NULL, 'created_time', '2014-12-02 12:09:33', '2014-12-02 12:09:33', '2014-12-02 12:09:33'),
(541, 230, NULL, 'user_id', '8', '2014-12-02 12:18:06', '2014-12-02 12:18:06'),
(542, 230, NULL, 'action_id', '60', '2014-12-02 12:18:06', '2014-12-02 12:18:06'),
(543, 230, NULL, 'created_time', '2014-12-02 12:18:06', '2014-12-02 12:18:06', '2014-12-02 12:18:06'),
(544, 231, NULL, 'user_id', '2', '2014-12-02 12:18:06', '2014-12-02 12:18:06'),
(545, 231, NULL, 'action_id', '25', '2014-12-02 12:18:06', '2014-12-02 12:18:06'),
(546, 231, NULL, 'title', 'Заказ №2', '2014-12-02 12:18:06', '2014-12-02 12:18:06'),
(547, 231, NULL, 'link', NULL, '2014-12-02 12:18:06', '2014-12-02 12:18:06'),
(548, 231, NULL, 'created_time', '2014-12-02 12:18:06', '2014-12-02 12:18:06', '2014-12-02 12:18:06'),
(549, 232, NULL, 'user_id', '8', '2014-12-02 12:19:04', '2014-12-02 12:19:04'),
(550, 232, NULL, 'action_id', '60', '2014-12-02 12:19:04', '2014-12-02 12:19:04'),
(551, 232, NULL, 'created_time', '2014-12-02 12:19:04', '2014-12-02 12:19:04', '2014-12-02 12:19:04'),
(552, 233, NULL, 'user_id', '2', '2014-12-02 12:19:04', '2014-12-02 12:19:04'),
(553, 233, NULL, 'action_id', '22', '2014-12-02 12:19:04', '2014-12-02 12:19:04'),
(554, 233, NULL, 'title', 'Заказ №1. Сумма: 4000 руб.', '2014-12-02 12:19:04', '2014-12-02 12:19:04'),
(555, 233, NULL, 'link', NULL, '2014-12-02 12:19:04', '2014-12-02 12:19:04'),
(556, 233, NULL, 'created_time', '2014-12-02 12:19:04', '2014-12-02 12:19:04', '2014-12-02 12:19:04'),
(557, 234, NULL, 'user_id', '2', '2014-12-02 12:30:00', '2014-12-02 12:30:00'),
(558, 234, NULL, 'action_id', '13', '2014-12-02 12:30:00', '2014-12-02 12:30:00'),
(559, 234, NULL, 'title', 'Итоговое тестирование. Курс: Строительство, реконструкция, капитальный ремонт объектов капитального строительства (возведение каменных, металлических и деревянных строительных конструкций)', '2014-12-02 12:30:00', '2014-12-02 12:30:00'),
(560, 234, NULL, 'link', NULL, '2014-12-02 12:30:00', '2014-12-02 12:30:00'),
(561, 234, NULL, 'created_time', '2014-12-02 12:30:00', '2014-12-02 12:30:00', '2014-12-02 12:30:00'),
(562, 235, NULL, 'user_id', '8', '2014-12-02 12:30:53', '2014-12-02 12:30:53'),
(563, 235, NULL, 'action_id', '53', '2014-12-02 12:30:53', '2014-12-02 12:30:53'),
(564, 235, NULL, 'created_time', '2014-12-02 12:30:53', '2014-12-02 12:30:53', '2014-12-02 12:30:53'),
(565, 236, NULL, 'user_id', '8', '2014-12-02 12:37:38', '2014-12-02 12:37:38'),
(566, 236, NULL, 'action_id', '50', '2014-12-02 12:37:38', '2014-12-02 12:37:38'),
(567, 236, NULL, 'created_time', '2014-12-02 12:37:38', '2014-12-02 12:37:38', '2014-12-02 12:37:38'),
(571, 238, NULL, 'user_id', '2', '2014-12-02 12:45:25', '2014-12-02 12:45:25'),
(572, 238, NULL, 'action_id', '21', '2014-12-02 12:45:25', '2014-12-02 12:45:25'),
(573, 238, NULL, 'title', 'Событие за 02.12.2014 в 12:45', '2014-12-02 12:45:25', '2014-12-02 12:45:25'),
(574, 238, NULL, 'link', NULL, '2014-12-02 12:45:25', '2014-12-02 12:45:25'),
(575, 238, NULL, 'created_time', '2014-12-02 12:45:25', '2014-12-02 12:45:25', '2014-12-02 12:45:25'),
(576, 239, NULL, 'user_id', '0', '2014-12-02 13:08:42', '2014-12-02 13:08:42'),
(577, 239, NULL, 'action_id', '61', '2014-12-02 13:08:42', '2014-12-02 13:08:42'),
(578, 239, NULL, 'created_time', '2014-12-02 13:08:42', '2014-12-02 13:08:42', '2014-12-02 13:08:42'),
(579, 240, NULL, 'user_id', '0', '2014-12-02 13:15:51', '2014-12-02 13:15:51'),
(580, 240, NULL, 'action_id', '63', '2014-12-02 13:15:51', '2014-12-02 13:15:51'),
(581, 240, NULL, 'created_time', '2014-12-02 13:15:51', '2014-12-02 13:15:51', '2014-12-02 13:15:51'),
(582, 241, NULL, 'user_id', '0', '2014-12-02 13:21:37', '2014-12-02 13:21:37'),
(583, 241, NULL, 'action_id', '63', '2014-12-02 13:21:37', '2014-12-02 13:21:37'),
(584, 241, NULL, 'created_time', '2014-12-02 13:21:37', '2014-12-02 13:21:37', '2014-12-02 13:21:37'),
(585, 242, NULL, 'user_id', '16', '2014-12-02 13:23:02', '2014-12-02 13:23:02'),
(586, 242, NULL, 'action_id', '78', '2014-12-02 13:23:02', '2014-12-02 13:23:02'),
(587, 242, NULL, 'created_time', '2014-12-02 13:23:02', '2014-12-02 13:23:02', '2014-12-02 13:23:02'),
(588, 243, NULL, 'user_id', '0', '2014-12-02 13:23:02', '2014-12-02 13:23:02'),
(589, 243, NULL, 'action_id', '65', '2014-12-02 13:23:02', '2014-12-02 13:23:02'),
(590, 243, NULL, 'created_time', '2014-12-02 13:23:02', '2014-12-02 13:23:02', '2014-12-02 13:23:02'),
(591, 244, NULL, 'user_id', '8', '2014-12-02 15:24:28', '2014-12-02 15:24:28'),
(592, 244, NULL, 'action_id', '49', '2014-12-02 15:24:28', '2014-12-02 15:24:28'),
(593, 244, NULL, 'created_time', '2014-12-02 15:24:28', '2014-12-02 15:24:28', '2014-12-02 15:24:28'),
(594, 245, NULL, 'user_id', '0', '2014-12-02 15:24:28', '2014-12-02 15:24:28'),
(595, 245, NULL, 'action_id', '65', '2014-12-02 15:24:28', '2014-12-02 15:24:28'),
(596, 245, NULL, 'created_time', '2014-12-02 15:24:28', '2014-12-02 15:24:28', '2014-12-02 15:24:28'),
(597, 246, NULL, 'user_id', '8', '2014-12-02 15:24:53', '2014-12-02 15:24:53'),
(598, 246, NULL, 'action_id', '60', '2014-12-02 15:24:53', '2014-12-02 15:24:53'),
(599, 246, NULL, 'created_time', '2014-12-02 15:24:53', '2014-12-02 15:24:53', '2014-12-02 15:24:53'),
(600, 247, NULL, 'user_id', '2', '2014-12-02 15:24:53', '2014-12-02 15:24:53'),
(601, 247, NULL, 'action_id', '25', '2014-12-02 15:24:53', '2014-12-02 15:24:53'),
(602, 247, NULL, 'title', 'Заказ №5', '2014-12-02 15:24:53', '2014-12-02 15:24:53'),
(603, 247, NULL, 'link', NULL, '2014-12-02 15:24:53', '2014-12-02 15:24:53'),
(604, 247, NULL, 'created_time', '2014-12-02 15:24:53', '2014-12-02 15:24:53', '2014-12-02 15:24:53'),
(605, 248, NULL, 'user_id', '8', '2014-12-02 15:25:07', '2014-12-02 15:25:07'),
(606, 248, NULL, 'action_id', '59', '2014-12-02 15:25:07', '2014-12-02 15:25:07'),
(607, 248, NULL, 'created_time', '2014-12-02 15:25:07', '2014-12-02 15:25:07', '2014-12-02 15:25:07'),
(608, 249, NULL, 'user_id', '2', '2014-12-02 15:25:07', '2014-12-02 15:25:07'),
(609, 249, NULL, 'action_id', '25', '2014-12-02 15:25:07', '2014-12-02 15:25:07'),
(610, 249, NULL, 'title', 'Заказ №5', '2014-12-02 15:25:07', '2014-12-02 15:25:07'),
(611, 249, NULL, 'link', NULL, '2014-12-02 15:25:07', '2014-12-02 15:25:07'),
(612, 249, NULL, 'created_time', '2014-12-02 15:25:07', '2014-12-02 15:25:07', '2014-12-02 15:25:07'),
(616, 251, NULL, 'user_id', '2', '2014-12-02 16:10:03', '2014-12-02 16:10:03'),
(617, 251, NULL, 'action_id', '25', '2014-12-02 16:10:03', '2014-12-02 16:10:03'),
(618, 251, NULL, 'title', 'Заказ №5', '2014-12-02 16:10:03', '2014-12-02 16:10:03'),
(619, 251, NULL, 'link', NULL, '2014-12-02 16:10:03', '2014-12-02 16:10:03'),
(620, 251, NULL, 'created_time', '2014-12-02 16:10:03', '2014-12-02 16:10:03', '2014-12-02 16:10:03'),
(621, 252, NULL, 'user_id', '8', '2014-12-02 16:45:12', '2014-12-02 16:45:12'),
(622, 252, NULL, 'action_id', '49', '2014-12-02 16:45:12', '2014-12-02 16:45:12'),
(623, 252, NULL, 'created_time', '2014-12-02 16:45:12', '2014-12-02 16:45:12', '2014-12-02 16:45:12'),
(624, 253, NULL, 'user_id', '0', '2014-12-02 16:45:12', '2014-12-02 16:45:12'),
(625, 253, NULL, 'action_id', '65', '2014-12-02 16:45:12', '2014-12-02 16:45:12'),
(626, 253, NULL, 'created_time', '2014-12-02 16:45:12', '2014-12-02 16:45:12', '2014-12-02 16:45:12'),
(627, 254, NULL, 'user_id', '0', '2014-12-02 21:08:51', '2014-12-02 21:08:51'),
(628, 254, NULL, 'action_id', '61', '2014-12-02 21:08:51', '2014-12-02 21:08:51'),
(629, 254, NULL, 'created_time', '2014-12-02 21:08:51', '2014-12-02 21:08:51', '2014-12-02 21:08:51'),
(633, 256, NULL, 'user_id', '19', '2014-12-02 21:15:17', '2014-12-02 21:15:17'),
(634, 256, NULL, 'action_id', '46', '2014-12-02 21:15:17', '2014-12-02 21:15:17'),
(635, 256, NULL, 'created_time', '2014-12-02 21:15:17', '2014-12-02 21:15:17', '2014-12-02 21:15:17'),
(636, 257, NULL, 'user_id', '19', '2014-12-02 21:15:17', '2014-12-02 21:15:17'),
(637, 257, NULL, 'action_id', '157', '2014-12-02 21:15:17', '2014-12-02 21:15:17'),
(638, 257, NULL, 'created_time', '2014-12-02 21:15:17', '2014-12-02 21:15:17', '2014-12-02 21:15:17'),
(639, 258, NULL, 'user_id', '0', '2014-12-02 21:21:09', '2014-12-02 21:21:09'),
(640, 258, NULL, 'action_id', '63', '2014-12-02 21:21:09', '2014-12-02 21:21:09'),
(641, 258, NULL, 'created_time', '2014-12-02 21:21:09', '2014-12-02 21:21:09', '2014-12-02 21:21:09'),
(642, 259, NULL, 'user_id', '0', '2014-12-02 21:28:35', '2014-12-02 21:28:35'),
(643, 259, NULL, 'action_id', '63', '2014-12-02 21:28:35', '2014-12-02 21:28:35'),
(644, 259, NULL, 'created_time', '2014-12-02 21:28:35', '2014-12-02 21:28:35', '2014-12-02 21:28:35'),
(645, 260, NULL, 'user_id', '19', '2014-12-02 21:36:56', '2014-12-02 21:36:56'),
(646, 260, NULL, 'action_id', '78', '2014-12-02 21:36:56', '2014-12-02 21:36:56'),
(647, 260, NULL, 'created_time', '2014-12-02 21:36:56', '2014-12-02 21:36:56', '2014-12-02 21:36:56'),
(648, 261, NULL, 'user_id', '0', '2014-12-02 21:36:56', '2014-12-02 21:36:56'),
(649, 261, NULL, 'action_id', '65', '2014-12-02 21:36:56', '2014-12-02 21:36:56'),
(650, 261, NULL, 'created_time', '2014-12-02 21:36:56', '2014-12-02 21:36:56', '2014-12-02 21:36:56'),
(651, 262, NULL, 'user_id', '2', '2014-12-02 22:42:07', '2014-12-02 22:42:07'),
(652, 262, NULL, 'action_id', '28', '2014-12-02 22:42:07', '2014-12-02 22:42:07'),
(653, 262, NULL, 'title', 'Фирма-2', '2014-12-02 22:42:07', '2014-12-02 22:42:07'),
(654, 262, NULL, 'link', NULL, '2014-12-02 22:42:07', '2014-12-02 22:42:07'),
(655, 262, NULL, 'created_time', '2014-12-02 22:42:07', '2014-12-02 22:42:07', '2014-12-02 22:42:07'),
(656, 263, NULL, 'user_id', '19', '2014-12-02 22:42:07', '2014-12-02 22:42:07'),
(657, 263, NULL, 'action_id', '159', '2014-12-02 22:42:07', '2014-12-02 22:42:07'),
(658, 263, NULL, 'created_time', '2014-12-02 22:42:07', '2014-12-02 22:42:07', '2014-12-02 22:42:07'),
(659, 264, NULL, 'user_id', '2', '2014-12-02 22:42:07', '2014-12-02 22:42:07'),
(660, 264, NULL, 'action_id', '26', '2014-12-02 22:42:07', '2014-12-02 22:42:07'),
(661, 264, NULL, 'title', 'Организация: Фирма-2', '2014-12-02 22:42:07', '2014-12-02 22:42:07'),
(662, 264, NULL, 'link', NULL, '2014-12-02 22:42:07', '2014-12-02 22:42:07'),
(663, 264, NULL, 'created_time', '2014-12-02 22:42:07', '2014-12-02 22:42:07', '2014-12-02 22:42:07'),
(664, 265, NULL, 'user_id', '19', '2014-12-02 22:51:41', '2014-12-02 22:51:41'),
(665, 265, NULL, 'action_id', '59', '2014-12-02 22:51:41', '2014-12-02 22:51:41'),
(666, 265, NULL, 'created_time', '2014-12-02 22:51:41', '2014-12-02 22:51:41', '2014-12-02 22:51:41'),
(667, 266, NULL, 'user_id', '2', '2014-12-02 22:51:41', '2014-12-02 22:51:41'),
(668, 266, NULL, 'action_id', '25', '2014-12-02 22:51:41', '2014-12-02 22:51:41'),
(669, 266, NULL, 'title', 'Заказ №7', '2014-12-02 22:51:41', '2014-12-02 22:51:41'),
(670, 266, NULL, 'link', NULL, '2014-12-02 22:51:41', '2014-12-02 22:51:41'),
(671, 266, NULL, 'created_time', '2014-12-02 22:51:41', '2014-12-02 22:51:41', '2014-12-02 22:51:41'),
(672, 267, NULL, 'user_id', '19', '2014-12-02 22:52:02', '2014-12-02 22:52:02'),
(673, 267, NULL, 'action_id', '58', '2014-12-02 22:52:02', '2014-12-02 22:52:02'),
(674, 267, NULL, 'created_time', '2014-12-02 22:52:02', '2014-12-02 22:52:02', '2014-12-02 22:52:02'),
(675, 268, NULL, 'user_id', '2', '2014-12-02 22:52:02', '2014-12-02 22:52:02'),
(676, 268, NULL, 'action_id', '22', '2014-12-02 22:52:02', '2014-12-02 22:52:02'),
(677, 268, NULL, 'title', 'Заказ №1. Сумма: 10000 руб.', '2014-12-02 22:52:02', '2014-12-02 22:52:02'),
(678, 268, NULL, 'link', NULL, '2014-12-02 22:52:02', '2014-12-02 22:52:02'),
(679, 268, NULL, 'created_time', '2014-12-02 22:52:02', '2014-12-02 22:52:02', '2014-12-02 22:52:02'),
(680, 269, NULL, 'user_id', '19', '2014-12-02 23:00:13', '2014-12-02 23:00:13'),
(681, 269, NULL, 'action_id', '50', '2014-12-02 23:00:13', '2014-12-02 23:00:13'),
(682, 269, NULL, 'created_time', '2014-12-02 23:00:13', '2014-12-02 23:00:14', '2014-12-02 23:00:14'),
(683, 270, NULL, 'user_id', '19', '2014-12-02 23:05:39', '2014-12-02 23:05:39'),
(684, 270, NULL, 'action_id', '214', '2014-12-02 23:05:39', '2014-12-02 23:05:39'),
(685, 270, NULL, 'created_time', '2014-12-02 23:05:39', '2014-12-02 23:05:39', '2014-12-02 23:05:39'),
(686, 271, NULL, 'user_id', '19', '2014-12-02 23:07:48', '2014-12-02 23:07:48'),
(687, 271, NULL, 'action_id', '51', '2014-12-02 23:07:48', '2014-12-02 23:07:48'),
(688, 271, NULL, 'created_time', '2014-12-02 23:07:48', '2014-12-02 23:07:48', '2014-12-02 23:07:48'),
(689, 272, NULL, 'user_id', '19', '2014-12-02 23:08:13', '2014-12-02 23:08:13'),
(690, 272, NULL, 'action_id', '50', '2014-12-02 23:08:13', '2014-12-02 23:08:13'),
(691, 272, NULL, 'created_time', '2014-12-02 23:08:13', '2014-12-02 23:08:13', '2014-12-02 23:08:13'),
(692, 273, NULL, 'user_id', '0', '2014-12-03 09:35:51', '2014-12-03 09:35:51'),
(693, 273, NULL, 'action_id', '63', '2014-12-03 09:35:51', '2014-12-03 09:35:51'),
(694, 273, NULL, 'created_time', '2014-12-03 09:35:51', '2014-12-03 09:35:51', '2014-12-03 09:35:51'),
(695, 274, NULL, 'user_id', '8', '2014-12-03 10:20:14', '2014-12-03 10:20:14'),
(696, 274, NULL, 'action_id', '59', '2014-12-03 10:20:14', '2014-12-03 10:20:14'),
(697, 274, NULL, 'created_time', '2014-12-03 10:20:14', '2014-12-03 10:20:14', '2014-12-03 10:20:14'),
(698, 275, NULL, 'user_id', '2', '2014-12-03 10:20:14', '2014-12-03 10:20:14'),
(699, 275, NULL, 'action_id', '25', '2014-12-03 10:20:14', '2014-12-03 10:20:14'),
(700, 275, NULL, 'title', 'Заказ №6', '2014-12-03 10:20:14', '2014-12-03 10:20:14'),
(701, 275, NULL, 'link', NULL, '2014-12-03 10:20:14', '2014-12-03 10:20:14'),
(702, 275, NULL, 'created_time', '2014-12-03 10:20:14', '2014-12-03 10:20:14', '2014-12-03 10:20:14'),
(706, 277, NULL, 'user_id', '2', '2014-12-03 10:20:25', '2014-12-03 10:20:25'),
(707, 277, NULL, 'action_id', '22', '2014-12-03 10:20:25', '2014-12-03 10:20:25'),
(708, 277, NULL, 'title', 'Заказ №1. Сумма: 12000 руб.', '2014-12-03 10:20:25', '2014-12-03 10:20:25'),
(709, 277, NULL, 'link', NULL, '2014-12-03 10:20:25', '2014-12-03 10:20:25'),
(710, 277, NULL, 'created_time', '2014-12-03 10:20:25', '2014-12-03 10:20:25', '2014-12-03 10:20:25'),
(711, 278, NULL, 'user_id', '8', '2014-12-03 10:21:30', '2014-12-03 10:21:30'),
(712, 278, NULL, 'action_id', '50', '2014-12-03 10:21:30', '2014-12-03 10:21:30'),
(713, 278, NULL, 'created_time', '2014-12-03 10:21:30', '2014-12-03 10:21:30', '2014-12-03 10:21:30'),
(714, 279, NULL, 'user_id', '0', '2014-12-03 10:23:27', '2014-12-03 10:23:27'),
(715, 279, NULL, 'action_id', '63', '2014-12-03 10:23:27', '2014-12-03 10:23:27'),
(716, 279, NULL, 'created_time', '2014-12-03 10:23:27', '2014-12-03 10:23:27', '2014-12-03 10:23:27'),
(717, 280, NULL, 'user_id', '15', '2014-12-03 10:24:29', '2014-12-03 10:24:29'),
(718, 280, NULL, 'action_id', '78', '2014-12-03 10:24:29', '2014-12-03 10:24:29'),
(719, 280, NULL, 'created_time', '2014-12-03 10:24:29', '2014-12-03 10:24:29', '2014-12-03 10:24:29'),
(720, 281, NULL, 'user_id', '0', '2014-12-03 10:24:29', '2014-12-03 10:24:29'),
(721, 281, NULL, 'action_id', '65', '2014-12-03 10:24:29', '2014-12-03 10:24:29'),
(722, 281, NULL, 'created_time', '2014-12-03 10:24:29', '2014-12-03 10:24:29', '2014-12-03 10:24:29'),
(723, 282, NULL, 'user_id', '0', '2014-12-03 14:39:12', '2014-12-03 14:39:12'),
(724, 282, NULL, 'action_id', '63', '2014-12-03 14:39:12', '2014-12-03 14:39:12'),
(725, 282, NULL, 'created_time', '2014-12-03 14:39:12', '2014-12-03 14:39:12', '2014-12-03 14:39:12'),
(726, 293, NULL, 'user_id', '0', '2014-12-04 10:47:02', '2014-12-04 10:47:02'),
(727, 293, NULL, 'action_id', '61', '2014-12-04 10:47:02', '2014-12-04 10:47:02'),
(728, 293, NULL, 'created_time', '2014-12-04 10:47:02', '2014-12-04 10:47:02', '2014-12-04 10:47:02'),
(729, 283, NULL, 'variables', '', '2014-12-04 11:09:54', '2014-12-04 11:09:54'),
(730, 283, NULL, 'content', '<p style="text-align: right;">\r\n	     Руководителю АНО ДПО «ЦКС»\r\n</p>\r\n<p style="text-align: right;">\r\n	    Шумееву П.А.\r\n</p>\r\n<p style="text-align: right;">\r\n	    от <u>{{ $FIO_listener }}</u>\r\n</p>\r\n<p style="text-align: right;">\r\n	    {{ @$NazvanieOrganizacii }}\r\n</p>\r\n<p style="text-align: right;">\r\n	    телефон: {{ @$Phone_listener}}\r\n</p>\r\n<p style="text-align: right;">\r\n	    E-mail: {{ @$Email_listener}}\r\n</p>\r\n<p align="center">\r\n	<strong>Заявка</strong>\r\n</p>\r\n<p>\r\n	           Прошу принять меня на обучение по дополнительной профессиональной программе повышения квалификации «ИКС. Качество строительства».\r\n</p>\r\n<p>\r\n	           Настоящим подтверждаю, что с уставом, лицензией на осуществление образовательной деятельности, соответствующей образовательной программой и другими     документами, регламентирующими организацию и осуществление образовательной деятельности, права и обязанности слушателей, в АНО ДПО «ЦКС» ознакомлен.\r\n</p>\r\n<table>\r\n<tbody>\r\n<tr>\r\n	<td valign="top" width="260">\r\n		<p>\r\n			                           {{ @$DataOformleniyaZakazaSlovami }}\r\n		</p>\r\n	</td>\r\n	<td valign="top" width="321">\r\n		<br>\r\n	</td>\r\n	<td valign="top" width="270">\r\n		<p align="right">\r\n			                           {{ @$FIO_initial_listener }}<br>\r\n		</p>\r\n	</td>\r\n</tr>\r\n</tbody>\r\n</table>', '2014-12-04 11:09:54', '2014-12-04 11:35:04'),
(731, 283, NULL, 'word_template', NULL, '2014-12-04 11:09:54', '2014-12-04 11:09:54'),
(732, 295, NULL, 'user_id', '2', '2014-12-04 11:09:54', '2014-12-04 11:09:54'),
(733, 295, NULL, 'action_id', '21', '2014-12-04 11:09:54', '2014-12-04 11:09:54'),
(734, 295, NULL, 'title', 'Событие за 04.12.2014 в 11:09', '2014-12-04 11:09:54', '2014-12-04 11:09:54'),
(735, 295, NULL, 'link', NULL, '2014-12-04 11:09:54', '2014-12-04 11:09:54'),
(736, 295, NULL, 'created_time', '2014-12-04 11:09:54', '2014-12-04 11:09:54', '2014-12-04 11:09:54'),
(737, 296, NULL, 'variables', '', '2014-12-04 11:35:04', '2014-12-04 11:35:04'),
(738, 296, NULL, 'content', '<p style="text-align: right;">\r\n	  Руководителю АНО ДПО «ЦКС»\r\n</p>\r\n<p style="text-align: right;">\r\n	 Шумееву П.А.\r\n</p>\r\n<p style="text-align: right;">\r\n	 от <u>{{ $FIO_listener }}</u>\r\n</p>\r\n<p style="text-align: right;">\r\n</p>\r\n<p style="text-align: right;">\r\n</p>\r\n<p style="text-align: right;">\r\n	 {{ @$NazvanieOrganizacii }}\r\n</p>\r\n<p style="text-align: right;">\r\n	 телефон: {{ @$Phone_listener}}\r\n</p>\r\n<p style="text-align: right;">\r\n	 E-mail: {{ @$Email_listener}}\r\n</p>\r\n<p align="center">\r\n	 <strong>Заявка</strong>\r\n</p>\r\n<p>\r\n	        Прошу принять меня на обучение по дополнительной профессиональной программе повышения квалификации «ИКС. Качество строительства».\r\n</p>\r\n<p>\r\n	        Настоящим подтверждаю, что с уставом, лицензией на осуществление образовательной деятельности, соответствующей образовательной программой и другими     документами, регламентирующими организацию и осуществление образовательной деятельности, права и обязанности слушателей, в АНО ДПО «ЦКС» ознакомлен.\r\n</p>\r\n<table>\r\n<tbody>\r\n<tr>\r\n	<td valign="top" width="260">\r\n		<p>\r\n			                        {{ @$DataOformleniyaZakazaSlovami }}\r\n		</p>\r\n	</td>\r\n	<td valign="top" width="321">\r\n		 <br>\r\n	</td>\r\n	<td valign="top" width="270">\r\n		<p align="right">\r\n			                        {{ @$FIO_initial_listener }}<br>\r\n		</p>\r\n	</td>\r\n</tr>\r\n</tbody>\r\n</table>', '2014-12-04 11:35:04', '2014-12-04 11:35:04'),
(739, 296, NULL, 'word_template', NULL, '2014-12-04 11:35:04', '2014-12-04 11:35:04'),
(740, 297, NULL, 'user_id', '2', '2014-12-04 11:35:04', '2014-12-04 11:35:04'),
(741, 297, NULL, 'action_id', '21', '2014-12-04 11:35:04', '2014-12-04 11:35:04'),
(742, 297, NULL, 'title', 'Событие за 04.12.2014 в 11:35', '2014-12-04 11:35:04', '2014-12-04 11:35:04'),
(743, 297, NULL, 'link', NULL, '2014-12-04 11:35:04', '2014-12-04 11:35:04'),
(744, 297, NULL, 'created_time', '2014-12-04 11:35:04', '2014-12-04 11:35:04', '2014-12-04 11:35:04'),
(748, 299, NULL, 'user_id', '2', '2014-12-04 11:58:34', '2014-12-04 11:58:34'),
(749, 299, NULL, 'action_id', '21', '2014-12-04 11:58:34', '2014-12-04 11:58:34'),
(750, 299, NULL, 'title', 'Событие за 04.12.2014 в 11:58', '2014-12-04 11:58:34', '2014-12-04 11:58:34'),
(751, 299, NULL, 'link', NULL, '2014-12-04 11:58:34', '2014-12-04 11:58:34'),
(752, 299, NULL, 'created_time', '2014-12-04 11:58:34', '2014-12-04 11:58:34', '2014-12-04 11:58:34'),
(756, 301, NULL, 'user_id', '2', '2014-12-04 11:59:36', '2014-12-04 11:59:36'),
(757, 301, NULL, 'action_id', '21', '2014-12-04 11:59:36', '2014-12-04 11:59:36'),
(758, 301, NULL, 'title', 'Событие за 04.12.2014 в 11:59', '2014-12-04 11:59:36', '2014-12-04 11:59:36'),
(759, 301, NULL, 'link', NULL, '2014-12-04 11:59:36', '2014-12-04 11:59:36'),
(760, 301, NULL, 'created_time', '2014-12-04 11:59:36', '2014-12-04 11:59:36', '2014-12-04 11:59:36'),
(761, 302, NULL, 'variables', '', '2014-12-04 12:00:07', '2014-12-04 12:00:07'),
(762, 302, NULL, 'content', '<p align="right">\r\n	    Приложение №1\r\n</p>\r\n<p align="right">\r\n	    к Договору №{{@$NomerZakaza }} ЭПК\r\n</p>\r\n<p align="right">\r\n	    от {{ @$DataOformleniyaZakazaSlovami }}\r\n</p>\r\n    {{ @$TablicaSluschateleyDlyaDogovora }}\r\n<table>\r\n<tbody>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			<strong>Исполнитель:</strong>\r\n		</p>\r\n		<p>\r\n			                           Руководитель НОУ ДПО «ЦКС»\r\n		</p>\r\n		<p>\r\n			                           ___________________ П.А. Шумеев\r\n		</p>\r\n		<p>\r\n			                           м.п.\r\n		</p>\r\n	</td>\r\n	<td>\r\n		<strong>Заказчик:</strong>\r\n		<p>\r\n			                           {{@$DoljnostOtvetstvennogoLicaOrganizacii}} <em><u>{{@$NazvanieOrganizacii}}</u></em>\r\n		</p>\r\n		<p>\r\n			                           ___________________ <em><u>ФИО</u></em>\r\n		</p>\r\n		<p>\r\n			                           м.п.\r\n		</p>\r\n	</td>\r\n</tr>\r\n</tbody>\r\n</table>', '2014-12-04 12:00:07', '2014-12-04 12:00:07'),
(763, 302, NULL, 'word_template', NULL, '2014-12-04 12:00:07', '2014-12-04 12:00:07'),
(764, 303, NULL, 'user_id', '2', '2014-12-04 12:00:07', '2014-12-04 12:00:07'),
(765, 303, NULL, 'action_id', '21', '2014-12-04 12:00:07', '2014-12-04 12:00:07'),
(766, 303, NULL, 'title', 'Событие за 04.12.2014 в 12:00', '2014-12-04 12:00:07', '2014-12-04 12:00:07'),
(767, 303, NULL, 'link', NULL, '2014-12-04 12:00:07', '2014-12-04 12:00:07'),
(768, 303, NULL, 'created_time', '2014-12-04 12:00:07', '2014-12-04 12:00:07', '2014-12-04 12:00:07'),
(769, 304, NULL, 'user_id', '8', '2014-12-04 12:15:14', '2014-12-04 12:15:14'),
(770, 304, NULL, 'action_id', '49', '2014-12-04 12:15:14', '2014-12-04 12:15:14'),
(771, 304, NULL, 'created_time', '2014-12-04 12:15:14', '2014-12-04 12:15:14', '2014-12-04 12:15:14'),
(772, 305, NULL, 'user_id', '0', '2014-12-04 12:15:14', '2014-12-04 12:15:14'),
(773, 305, NULL, 'action_id', '65', '2014-12-04 12:15:14', '2014-12-04 12:15:14'),
(774, 305, NULL, 'created_time', '2014-12-04 12:15:14', '2014-12-04 12:15:14', '2014-12-04 12:15:14'),
(775, 306, NULL, 'user_id', '0', '2014-12-04 12:34:29', '2014-12-04 12:34:29'),
(776, 306, NULL, 'action_id', '63', '2014-12-04 12:34:29', '2014-12-04 12:34:29'),
(777, 306, NULL, 'created_time', '2014-12-04 12:34:29', '2014-12-04 12:34:29', '2014-12-04 12:34:29'),
(778, 307, NULL, 'user_id', '0', '2014-12-04 12:43:37', '2014-12-04 12:43:37'),
(779, 307, NULL, 'action_id', '61', '2014-12-04 12:43:37', '2014-12-04 12:43:37'),
(780, 307, NULL, 'created_time', '2014-12-04 12:43:37', '2014-12-04 12:43:37', '2014-12-04 12:43:37'),
(781, 308, NULL, 'user_id', '15', '2014-12-04 13:30:07', '2014-12-04 13:30:07'),
(782, 308, NULL, 'action_id', '78', '2014-12-04 13:30:07', '2014-12-04 13:30:07'),
(783, 308, NULL, 'created_time', '2014-12-04 13:30:07', '2014-12-04 13:30:07', '2014-12-04 13:30:07'),
(784, 309, NULL, 'user_id', '0', '2014-12-04 13:30:07', '2014-12-04 13:30:07'),
(785, 309, NULL, 'action_id', '65', '2014-12-04 13:30:07', '2014-12-04 13:30:07'),
(786, 309, NULL, 'created_time', '2014-12-04 13:30:07', '2014-12-04 13:30:07', '2014-12-04 13:30:07'),
(787, 310, NULL, 'user_id', '0', '2014-12-04 13:47:14', '2014-12-04 13:47:14'),
(788, 310, NULL, 'action_id', '63', '2014-12-04 13:47:14', '2014-12-04 13:47:14'),
(789, 310, NULL, 'created_time', '2014-12-04 13:47:14', '2014-12-04 13:47:14', '2014-12-04 13:47:14'),
(790, 311, NULL, 'user_id', '15', '2014-12-04 14:22:42', '2014-12-04 14:22:42'),
(791, 311, NULL, 'action_id', '60', '2014-12-04 14:22:42', '2014-12-04 14:22:42'),
(792, 311, NULL, 'created_time', '2014-12-04 14:22:42', '2014-12-04 14:22:42', '2014-12-04 14:22:42'),
(793, 312, NULL, 'user_id', '2', '2014-12-04 14:22:42', '2014-12-04 14:22:42'),
(794, 312, NULL, 'action_id', '25', '2014-12-04 14:22:42', '2014-12-04 14:22:42'),
(795, 312, NULL, 'title', 'Заказ №10', '2014-12-04 14:22:42', '2014-12-04 14:22:42'),
(796, 312, NULL, 'link', NULL, '2014-12-04 14:22:42', '2014-12-04 14:22:42'),
(797, 312, NULL, 'created_time', '2014-12-04 14:22:42', '2014-12-04 14:22:42', '2014-12-04 14:22:42'),
(798, 313, NULL, 'user_id', '15', '2014-12-04 14:22:52', '2014-12-04 14:22:52'),
(799, 313, NULL, 'action_id', '60', '2014-12-04 14:22:52', '2014-12-04 14:22:52'),
(800, 313, NULL, 'created_time', '2014-12-04 14:22:52', '2014-12-04 14:22:52', '2014-12-04 14:22:52'),
(801, 314, NULL, 'user_id', '2', '2014-12-04 14:22:52', '2014-12-04 14:22:52'),
(802, 314, NULL, 'action_id', '25', '2014-12-04 14:22:52', '2014-12-04 14:22:52'),
(803, 314, NULL, 'title', 'Заказ №8', '2014-12-04 14:22:52', '2014-12-04 14:22:52'),
(804, 314, NULL, 'link', NULL, '2014-12-04 14:22:52', '2014-12-04 14:22:52'),
(805, 314, NULL, 'created_time', '2014-12-04 14:22:52', '2014-12-04 14:22:52', '2014-12-04 14:22:52'),
(806, 315, NULL, 'user_id', '15', '2014-12-04 14:24:08', '2014-12-04 14:24:08'),
(807, 315, NULL, 'action_id', '50', '2014-12-04 14:24:08', '2014-12-04 14:24:08'),
(808, 315, NULL, 'created_time', '2014-12-04 14:24:08', '2014-12-04 14:24:08', '2014-12-04 14:24:08'),
(809, 316, NULL, 'user_id', '15', '2014-12-04 15:35:09', '2014-12-04 15:35:09'),
(810, 316, NULL, 'action_id', '78', '2014-12-04 15:35:09', '2014-12-04 15:35:09'),
(811, 316, NULL, 'created_time', '2014-12-04 15:35:09', '2014-12-04 15:35:09', '2014-12-04 15:35:09'),
(812, 317, NULL, 'user_id', '0', '2014-12-04 15:35:09', '2014-12-04 15:35:09'),
(813, 317, NULL, 'action_id', '65', '2014-12-04 15:35:09', '2014-12-04 15:35:09'),
(814, 317, NULL, 'created_time', '2014-12-04 15:35:09', '2014-12-04 15:35:09', '2014-12-04 15:35:09'),
(815, 318, NULL, 'user_id', '15', '2014-12-04 15:35:52', '2014-12-04 15:35:52'),
(816, 318, NULL, 'action_id', '78', '2014-12-04 15:35:52', '2014-12-04 15:35:52'),
(817, 318, NULL, 'created_time', '2014-12-04 15:35:52', '2014-12-04 15:35:52', '2014-12-04 15:35:52'),
(818, 319, NULL, 'user_id', '0', '2014-12-04 15:35:52', '2014-12-04 15:35:52'),
(819, 319, NULL, 'action_id', '65', '2014-12-04 15:35:52', '2014-12-04 15:35:52'),
(820, 319, NULL, 'created_time', '2014-12-04 15:35:52', '2014-12-04 15:35:52', '2014-12-04 15:35:52'),
(821, 284, NULL, 'variables', '', '2014-12-05 09:47:45', '2014-12-05 09:47:45'),
(822, 284, NULL, 'content', '<table>\r\n<tbody>\r\n<tr>\r\n	<td valign="top" width="425">\r\n		<p>\r\n			<strong><em>{{ @$DataOformleniyaZakaza}}</em></strong>\r\n		</p>\r\n	</td>\r\n	<td valign="top" width="414">\r\n		<p style="text-align: right;">\r\n			<strong><em>ЭПК №{{ @$NomerZakazaKorotkiy }}</em></strong>\r\n		</p>\r\n		<p align="right">\r\n			 <strong></strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<p align="center">\r\n	<strong>ПРИКАЗ</strong>\r\n</p>\r\n<p align="center">\r\n	<strong>«О зачислении слушателей на курсы повышения квалификации и комплектации групп по дополнительным профессиональным программам»</strong>\r\n</p>\r\n<p>\r\n	               Во исполнение договора на оказание платных образовательных услуг №{{ @$NomerZakaza }} ЭПК от {{ @$DataOformleniyaZakazaSlovami }} между Автономной некоммерческой организацией     дополнительного профессионального образования «Центр качества строительства» и {{ @$NazvanieOrganizacii }}\r\n</p>\r\n<p align="center">\r\n	<strong>Приказываю</strong>\r\n</p>\r\n<p>\r\n	               1. Установить начало обучения по дополнительным профессиональным программам (в объеме 72 часа) для группы №{{ @$NomerZakaza }} с {{ @$DataOplatuZakaza }}.\r\n</p>\r\n<p>\r\n	               2. Зачислить на курсы повышения квалификации по соответствующим дополнительным профессиональным программам следующих слушателей:\r\n</p>\r\n<p>\r\n	               Группа №{{ @$NomerZakaza }}\r\n</p>\r\n<p>\r\n	        {{ @$SpisokSluschateleyDlyaPrikaza }}\r\n</p>\r\n<p align="center">\r\n</p>\r\n<p>\r\n	               3. По окончании обучения Аттестационной комиссии АНО ДПО «ЦКС» провести итоговую аттестацию слушателей.\r\n</p>\r\n<table>\r\n<tbody>\r\n<tr>\r\n	<td valign="top" width="425">\r\n		<p>\r\n			<strong></strong>\r\n		</p>\r\n		<p>\r\n			        Руководитель АНО ДПО «ЦКС»\r\n		</p>\r\n		<p>\r\n			<strong></strong>\r\n		</p>\r\n	</td>\r\n	<td valign="top" width="414">\r\n		<p style="text-align: right;">\r\n			<strong></strong>\r\n		</p>\r\n		<p style="text-align: right;">\r\n			        Шумеев П.А.\r\n		</p>\r\n		<p style="text-align: right;">\r\n			<strong></strong>\r\n		</p>\r\n		<p align="right">\r\n			<strong></strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n</tbody>\r\n</table>', '2014-12-05 09:47:45', '2014-12-05 10:24:28'),
(823, 284, NULL, 'word_template', NULL, '2014-12-05 09:47:45', '2014-12-05 09:47:45'),
(824, 321, NULL, 'user_id', '2', '2014-12-05 09:47:45', '2014-12-05 09:47:45'),
(825, 321, NULL, 'action_id', '21', '2014-12-05 09:47:45', '2014-12-05 09:47:45'),
(826, 321, NULL, 'title', 'Событие за 05.12.2014 в 09:47', '2014-12-05 09:47:45', '2014-12-05 09:47:45'),
(827, 321, NULL, 'link', NULL, '2014-12-05 09:47:45', '2014-12-05 09:47:45'),
(828, 321, NULL, 'created_time', '2014-12-05 09:47:45', '2014-12-05 09:47:45', '2014-12-05 09:47:45'),
(832, 323, NULL, 'user_id', '2', '2014-12-05 10:15:37', '2014-12-05 10:15:37'),
(833, 323, NULL, 'action_id', '21', '2014-12-05 10:15:37', '2014-12-05 10:15:37'),
(834, 323, NULL, 'title', 'Событие за 05.12.2014 в 10:15', '2014-12-05 10:15:37', '2014-12-05 10:15:37'),
(835, 323, NULL, 'link', NULL, '2014-12-05 10:15:37', '2014-12-05 10:15:37'),
(836, 323, NULL, 'created_time', '2014-12-05 10:15:37', '2014-12-05 10:15:37', '2014-12-05 10:15:37'),
(840, 325, NULL, 'user_id', '2', '2014-12-05 10:18:49', '2014-12-05 10:18:49'),
(841, 325, NULL, 'action_id', '21', '2014-12-05 10:18:49', '2014-12-05 10:18:49'),
(842, 325, NULL, 'title', 'Событие за 05.12.2014 в 10:18', '2014-12-05 10:18:49', '2014-12-05 10:18:49'),
(843, 325, NULL, 'link', NULL, '2014-12-05 10:18:49', '2014-12-05 10:18:49'),
(844, 325, NULL, 'created_time', '2014-12-05 10:18:49', '2014-12-05 10:18:49', '2014-12-05 10:18:49'),
(845, 326, NULL, 'user_id', '2', '2014-12-05 10:19:30', '2014-12-05 10:19:30'),
(846, 326, NULL, 'action_id', '13', '2014-12-05 10:19:30', '2014-12-05 10:19:30'),
(847, 326, NULL, 'title', 'Промежуточное тестирование. Курс: Строительство, реконструкция, капитальный ремонт объектов капитального строительства (выполнение геодезических, подготовительных и земляных работ, устройства оснований и фундаментов)', '2014-12-05 10:19:30', '2014-12-05 10:19:30'),
(848, 326, NULL, 'link', NULL, '2014-12-05 10:19:30', '2014-12-05 10:19:30'),
(849, 326, NULL, 'created_time', '2014-12-05 10:19:30', '2014-12-05 10:19:30', '2014-12-05 10:19:30'),
(850, 327, NULL, 'variables', '', '2014-12-05 10:24:28', '2014-12-05 10:24:28'),
(851, 327, NULL, 'content', '<table>\r\n<tbody>\r\n<tr>\r\n	<td valign="top" width="425">\r\n		<p>\r\n			 <strong><em>{{ @$DataOformleniyaZakaza}}</em></strong>\r\n		</p>\r\n	</td>\r\n	<td valign="top" width="414">\r\n		<p style="text-align: right;">\r\n			 <strong><em>ЭПК №{{ @$NomerZakazakorotkiy }}</em></strong>\r\n		</p>\r\n		<p align="right">\r\n			<strong></strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<p align="center">\r\n	 <strong>ПРИКАЗ</strong>\r\n</p>\r\n<p align="center">\r\n	 <strong>«О зачислении слушателей на курсы повышения квалификации и комплектации групп по дополнительным профессиональным программам»</strong>\r\n</p>\r\n<p>\r\n	            Во исполнение договора на оказание платных образовательных услуг №{{ @$NomerZakaza }} ЭПК от {{ @$DataOformleniyaZakazaSlovami }} между Автономной некоммерческой организацией     дополнительного профессионального образования «Центр качества строительства» и {{ @$NazvanieOrganizacii }}\r\n</p>\r\n<p align="center">\r\n	 <strong>Приказываю</strong>\r\n</p>\r\n<p>\r\n	            1. Установить начало обучения по дополнительным профессиональным программам (в объеме 72 часа) для группы №{{ @$NomerZakaza }} с {{ @$DataOplatuZakaza }}.\r\n</p>\r\n<p>\r\n	            2. Зачислить на курсы повышения квалификации по соответствующим дополнительным профессиональным программам следующих слушателей:\r\n</p>\r\n<p>\r\n	            Группа №{{ @$NomerZakaza }}\r\n</p>\r\n<p>\r\n	     {{ @$SpisokSluschateleyDlyaPrikaza }}\r\n</p>\r\n<p align="center">\r\n</p>\r\n<p>\r\n	            3. По окончании обучения Аттестационной комиссии АНО ДПО «ЦКС» провести итоговую аттестацию слушателей.\r\n</p>\r\n<table>\r\n<tbody>\r\n<tr>\r\n	<td valign="top" width="425">\r\n		<p>\r\n			 <strong></strong>\r\n		</p>\r\n		<p>\r\n			     Руководитель АНО ДПО «ЦКС»\r\n		</p>\r\n		<p>\r\n			 <strong></strong>\r\n		</p>\r\n	</td>\r\n	<td valign="top" width="414">\r\n		<p style="text-align: right;">\r\n			 <strong></strong>\r\n		</p>\r\n		<p style="text-align: right;">\r\n			     Шумеев П.А.\r\n		</p>\r\n		<p style="text-align: right;">\r\n			 <strong></strong>\r\n		</p>\r\n		<p align="right">\r\n			 <strong></strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n</tbody>\r\n</table>', '2014-12-05 10:24:28', '2014-12-05 10:24:28'),
(852, 327, NULL, 'word_template', NULL, '2014-12-05 10:24:28', '2014-12-05 10:24:28'),
(853, 328, NULL, 'user_id', '2', '2014-12-05 10:24:28', '2014-12-05 10:24:28'),
(854, 328, NULL, 'action_id', '21', '2014-12-05 10:24:28', '2014-12-05 10:24:28'),
(855, 328, NULL, 'title', 'Событие за 05.12.2014 в 10:24', '2014-12-05 10:24:28', '2014-12-05 10:24:28'),
(856, 328, NULL, 'link', NULL, '2014-12-05 10:24:28', '2014-12-05 10:24:28'),
(857, 328, NULL, 'created_time', '2014-12-05 10:24:28', '2014-12-05 10:24:28', '2014-12-05 10:24:28'),
(858, 329, NULL, 'user_id', '8', '2014-12-05 10:24:40', '2014-12-05 10:24:40'),
(859, 329, NULL, 'action_id', '214', '2014-12-05 10:24:40', '2014-12-05 10:24:40'),
(860, 329, NULL, 'created_time', '2014-12-05 10:24:40', '2014-12-05 10:24:40', '2014-12-05 10:24:40'),
(861, 330, NULL, 'user_id', '8', '2014-12-05 10:27:57', '2014-12-05 10:27:57'),
(862, 330, NULL, 'action_id', '214', '2014-12-05 10:27:57', '2014-12-05 10:27:57'),
(863, 330, NULL, 'created_time', '2014-12-05 10:27:57', '2014-12-05 10:27:57', '2014-12-05 10:27:57'),
(864, 285, NULL, 'variables', '', '2014-12-05 10:46:10', '2014-12-05 10:46:10'),
(865, 285, NULL, 'content', '<table>\r\n<tbody>\r\n<tr>\r\n	<td valign="top" width="425">\r\n		<p>\r\n			 <strong><em>{{ @$DataOformleniyaZakazaSlovami }}</em></strong>\r\n		</p>\r\n	</td>\r\n	<td valign="top" width="414">\r\n		<p style="text-align: right;">\r\n			 <strong><em>ЭПК №{{ @$NomerZakazaKorotkiy }}</em></strong>\r\n		</p>\r\n		<p align="right">\r\n			<strong></strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<p align="center">\r\n	 <strong>ПРИКАЗ</strong>\r\n</p>\r\n<p align="center">\r\n	 <strong>«</strong><strong>О завершении повышения квалификации подополнительным профессиональным программам</strong><strong>»</strong>\r\n</p>\r\n<p>\r\n	   Во исполнение договора на оказание платных образовательных услуг №{{ @$NomerZakaza }} ЭПК от {{ @$DataOformleniyaZakazaSlovami }} между Автономной некоммерческой организацией дополнительного профессионального образования «Центр качества строительства» и {{ @$NazvanieOrganizacii }}\r\n</p>\r\n<p align="center">\r\n	 <strong>Приказываю</strong>\r\n</p>\r\n<p>\r\n	                  1. Слушателям, прошедшим обучение по соответствующим дополнительным профессиональным программам и успешно сдавшим обязательную итоговую аттестацию по 72 часовым программам выдать удостоверение о повышении квалификации, подтверждающее успешное освоение программ\r\n</p>\r\n<p>\r\n	                  Группа №{{ @$NomerZakaza }}\r\n</p>\r\n<p>\r\n	           {{ @$SpisokSluschateleyDlyaPrikaza }}\r\n</p>\r\n<p>\r\n	   Основание: Аттестационная ведомость от {{ @$DataZakrutiyaZakaza }} г.\r\n</p>\r\n<p align="center">\r\n</p>\r\n<p>\r\n	                  2. В связи с освоением дополнительной профессиональной программы и успешным прохождением итоговой аттестации всех вышеперечисленных слушателей отчислить из АНО ДПО «ЦКС» {{ @$DataZakrutiyaZakaza }} г.\r\n</p>\r\n<table>\r\n<tbody>\r\n<tr>\r\n	<td valign="top" width="425">\r\n		<p>\r\n			 <strong></strong>\r\n		</p>\r\n		<p>\r\n			           Руководитель АНО ДПО «ЦКС»\r\n		</p>\r\n		<p>\r\n			 <strong></strong>\r\n		</p>\r\n	</td>\r\n	<td valign="top" width="414">\r\n		<p style="text-align: right;">\r\n			 <strong></strong>\r\n		</p>\r\n		<p style="text-align: right;">\r\n			           Шумеев П.А.\r\n		</p>\r\n		<p style="text-align: right;">\r\n			 <strong></strong>\r\n		</p>\r\n		<p align="right">\r\n			 <strong></strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n</tbody>\r\n</table>', '2014-12-05 10:46:10', '2014-12-05 12:21:51'),
(866, 285, NULL, 'word_template', NULL, '2014-12-05 10:46:10', '2014-12-05 10:46:10'),
(867, 332, NULL, 'user_id', '2', '2014-12-05 10:46:10', '2014-12-05 10:46:10');
INSERT INTO `dictionary_fields_values` (`id`, `dicval_id`, `language`, `key`, `value`, `created_at`, `updated_at`) VALUES
(868, 332, NULL, 'action_id', '21', '2014-12-05 10:46:10', '2014-12-05 10:46:10'),
(869, 332, NULL, 'title', 'Событие за 05.12.2014 в 10:46', '2014-12-05 10:46:10', '2014-12-05 10:46:10'),
(870, 332, NULL, 'link', NULL, '2014-12-05 10:46:10', '2014-12-05 10:46:10'),
(871, 332, NULL, 'created_time', '2014-12-05 10:46:10', '2014-12-05 10:46:10', '2014-12-05 10:46:10'),
(872, 333, NULL, 'user_id', '8', '2014-12-05 11:07:47', '2014-12-05 11:07:47'),
(873, 333, NULL, 'action_id', '214', '2014-12-05 11:07:47', '2014-12-05 11:07:47'),
(874, 333, NULL, 'created_time', '2014-12-05 11:07:47', '2014-12-05 11:07:47', '2014-12-05 11:07:47'),
(875, 334, NULL, 'user_id', '8', '2014-12-05 11:13:18', '2014-12-05 11:13:18'),
(876, 334, NULL, 'action_id', '51', '2014-12-05 11:13:18', '2014-12-05 11:13:18'),
(877, 334, NULL, 'created_time', '2014-12-05 11:13:18', '2014-12-05 11:13:18', '2014-12-05 11:13:18'),
(878, 335, NULL, 'user_id', '8', '2014-12-05 11:24:37', '2014-12-05 11:24:37'),
(879, 335, NULL, 'action_id', '51', '2014-12-05 11:24:37', '2014-12-05 11:24:37'),
(880, 335, NULL, 'created_time', '2014-12-05 11:24:37', '2014-12-05 11:24:37', '2014-12-05 11:24:37'),
(881, 336, NULL, 'variables', '', '2014-12-05 12:21:51', '2014-12-05 12:21:51'),
(882, 336, NULL, 'content', '<table>\r\n<tbody>\r\n<tr>\r\n	<td valign="top" width="425">\r\n		<p>\r\n			<strong><em>{{ @$DataOformleniyaZakaza}}</em></strong>\r\n		</p>\r\n	</td>\r\n	<td valign="top" width="414">\r\n		<p style="text-align: right;">\r\n			<strong><em>ЭПК №{{ @$NomerZakazaKorotkiy }}</em></strong>\r\n		</p>\r\n		<p align="right">\r\n			 <strong></strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<p align="center">\r\n	<strong>ПРИКАЗ</strong>\r\n</p>\r\n<p align="center">\r\n	<strong>«</strong><strong>О завершении повышения квалификации подополнительным профессиональным программам</strong><strong>»</strong>\r\n</p>\r\n<p>\r\n	  Во исполнение договора на оказание платных образовательных услуг №{{ @$NomerZakaza }} ЭПК от {{ @$DataOformleniyaZakazaSlovami }} между Автономной некоммерческой организацией дополнительного профессионального образования «Центр качества строительства» и {{ @$NazvanieOrganizacii }}\r\n</p>\r\n<p align="center">\r\n	<strong>Приказываю</strong>\r\n</p>\r\n<p>\r\n	                 1. Слушателям, прошедшим обучение по соответствующим дополнительным профессиональным программам и успешно сдавшим обязательную итоговую аттестацию по 72 часовым программам выдать удостоверение о повышении квалификации, подтверждающее успешное освоение программ\r\n</p>\r\n<p>\r\n	                 Группа №{{ @$NomerZakaza }}\r\n</p>\r\n<p>\r\n	          {{ @$SpisokSluschateleyDlyaPrikaza }}\r\n</p>\r\n<p>\r\n	  Основание: Аттестационная ведомость от {{ @$DataZakrutiyaZakaza }} г.\r\n</p>\r\n<p align="center">\r\n</p>\r\n<p>\r\n	                 2. В связи с освоением дополнительной профессиональной программы и успешным прохождением итоговой аттестации всех вышеперечисленных слушателей отчислить из АНО ДПО «ЦКС» {{ @$DataZakrutiyaZakaza }} г.\r\n</p>\r\n<table>\r\n<tbody>\r\n<tr>\r\n	<td valign="top" width="425">\r\n		<p>\r\n			<strong></strong>\r\n		</p>\r\n		<p>\r\n			          Руководитель АНО ДПО «ЦКС»\r\n		</p>\r\n		<p>\r\n			<strong></strong>\r\n		</p>\r\n	</td>\r\n	<td valign="top" width="414">\r\n		<p style="text-align: right;">\r\n			<strong></strong>\r\n		</p>\r\n		<p style="text-align: right;">\r\n			          Шумеев П.А.\r\n		</p>\r\n		<p style="text-align: right;">\r\n			<strong></strong>\r\n		</p>\r\n		<p align="right">\r\n			<strong></strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n</tbody>\r\n</table>', '2014-12-05 12:21:51', '2014-12-05 12:21:51'),
(883, 336, NULL, 'word_template', NULL, '2014-12-05 12:21:51', '2014-12-05 12:21:51'),
(884, 337, NULL, 'user_id', '2', '2014-12-05 12:21:51', '2014-12-05 12:21:51'),
(885, 337, NULL, 'action_id', '21', '2014-12-05 12:21:51', '2014-12-05 12:21:51'),
(886, 337, NULL, 'title', 'Событие за 05.12.2014 в 12:21', '2014-12-05 12:21:51', '2014-12-05 12:21:51'),
(887, 337, NULL, 'link', NULL, '2014-12-05 12:21:51', '2014-12-05 12:21:51'),
(888, 337, NULL, 'created_time', '2014-12-05 12:21:51', '2014-12-05 12:21:51', '2014-12-05 12:21:51'),
(889, 286, NULL, 'variables', '', '2014-12-05 12:32:23', '2014-12-05 12:32:23'),
(890, 286, NULL, 'content', '<table>\r\n<tbody>\r\n<tr>\r\n	<td valign="top" width="425">\r\n		<p>\r\n			 <strong></strong>\r\n		</p>\r\n		<p>\r\n			 <strong><em>{{ @$DataOformleniyaZakazaSlovami}}</em></strong>\r\n		</p>\r\n		<p>\r\n			 <strong></strong>\r\n		</p>\r\n	</td>\r\n	<td valign="top" width="437">\r\n		<p align="right">\r\n			 <strong><em>Утверждаю</em></strong>\r\n		</p>\r\n		<p align="right">\r\n			 <strong><em>Руководитель АНО ДПО «ЦКС»</em></strong>\r\n		</p>\r\n		<p align="right">\r\n			 <strong><em> _________________ Шумеев П.А.</em></strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<p style="text-align: center;">\r\n	 <strong>Расписание занятий</strong>\r\n</p>\r\n<p>\r\n	 <strong>Группа: </strong>     №{{ @$NomerZakaza }}\r\n</p>\r\n<p>\r\n	 <strong>Слушатель: </strong>{{ @$FIO_listener }}\r\n</p>\r\n<p>\r\n	 <strong>Наименование дополнительной профессиональной программы:</strong> {{ @$Kod_kursa }}. {{ @$Nazvanie_kursa }}\r\n</p>\r\n<p>\r\n	       {{ @$RaspisanieObucheniyaPoKursu }}\r\n</p>', '2014-12-05 12:32:23', '2014-12-05 14:15:36'),
(891, 286, NULL, 'word_template', NULL, '2014-12-05 12:32:23', '2014-12-05 12:32:23'),
(892, 339, NULL, 'user_id', '2', '2014-12-05 12:32:23', '2014-12-05 12:32:23'),
(893, 339, NULL, 'action_id', '21', '2014-12-05 12:32:23', '2014-12-05 12:32:23'),
(894, 339, NULL, 'title', 'Событие за 05.12.2014 в 12:32', '2014-12-05 12:32:23', '2014-12-05 12:32:23'),
(895, 339, NULL, 'link', NULL, '2014-12-05 12:32:23', '2014-12-05 12:32:23'),
(896, 339, NULL, 'created_time', '2014-12-05 12:32:23', '2014-12-05 12:32:23', '2014-12-05 12:32:23'),
(900, 341, NULL, 'user_id', '2', '2014-12-05 13:14:27', '2014-12-05 13:14:27'),
(901, 341, NULL, 'action_id', '21', '2014-12-05 13:14:27', '2014-12-05 13:14:27'),
(902, 341, NULL, 'title', 'Событие за 05.12.2014 в 13:14', '2014-12-05 13:14:27', '2014-12-05 13:14:27'),
(903, 341, NULL, 'link', NULL, '2014-12-05 13:14:27', '2014-12-05 13:14:27'),
(904, 341, NULL, 'created_time', '2014-12-05 13:14:27', '2014-12-05 13:14:27', '2014-12-05 13:14:27'),
(908, 343, NULL, 'user_id', '2', '2014-12-05 13:28:15', '2014-12-05 13:28:15'),
(909, 343, NULL, 'action_id', '21', '2014-12-05 13:28:15', '2014-12-05 13:28:15'),
(910, 343, NULL, 'title', 'Событие за 05.12.2014 в 13:28', '2014-12-05 13:28:15', '2014-12-05 13:28:15'),
(911, 343, NULL, 'link', NULL, '2014-12-05 13:28:15', '2014-12-05 13:28:15'),
(912, 343, NULL, 'created_time', '2014-12-05 13:28:15', '2014-12-05 13:28:15', '2014-12-05 13:28:15'),
(913, 344, NULL, 'user_id', '8', '2014-12-05 13:49:16', '2014-12-05 13:49:16'),
(914, 344, NULL, 'action_id', '49', '2014-12-05 13:49:16', '2014-12-05 13:49:16'),
(915, 344, NULL, 'created_time', '2014-12-05 13:49:16', '2014-12-05 13:49:16', '2014-12-05 13:49:16'),
(916, 345, NULL, 'user_id', '0', '2014-12-05 13:49:16', '2014-12-05 13:49:16'),
(917, 345, NULL, 'action_id', '65', '2014-12-05 13:49:16', '2014-12-05 13:49:16'),
(918, 345, NULL, 'created_time', '2014-12-05 13:49:16', '2014-12-05 13:49:16', '2014-12-05 13:49:16'),
(919, 346, NULL, 'user_id', '8', '2014-12-05 13:50:33', '2014-12-05 13:50:33'),
(920, 346, NULL, 'action_id', '49', '2014-12-05 13:50:33', '2014-12-05 13:50:33'),
(921, 346, NULL, 'created_time', '2014-12-05 13:50:33', '2014-12-05 13:50:33', '2014-12-05 13:50:33'),
(922, 347, NULL, 'user_id', '0', '2014-12-05 13:50:33', '2014-12-05 13:50:33'),
(923, 347, NULL, 'action_id', '65', '2014-12-05 13:50:33', '2014-12-05 13:50:33'),
(924, 347, NULL, 'created_time', '2014-12-05 13:50:33', '2014-12-05 13:50:33', '2014-12-05 13:50:33'),
(925, 348, NULL, 'user_id', '8', '2014-12-05 13:50:59', '2014-12-05 13:50:59'),
(926, 348, NULL, 'action_id', '49', '2014-12-05 13:50:59', '2014-12-05 13:50:59'),
(927, 348, NULL, 'created_time', '2014-12-05 13:50:59', '2014-12-05 13:50:59', '2014-12-05 13:50:59'),
(928, 349, NULL, 'user_id', '0', '2014-12-05 13:50:59', '2014-12-05 13:50:59'),
(929, 349, NULL, 'action_id', '65', '2014-12-05 13:50:59', '2014-12-05 13:50:59'),
(930, 349, NULL, 'created_time', '2014-12-05 13:50:59', '2014-12-05 13:50:59', '2014-12-05 13:50:59'),
(931, 350, NULL, 'variables', '', '2014-12-05 14:15:36', '2014-12-05 14:15:36'),
(932, 350, NULL, 'content', '<table>\r\n<tbody>\r\n<tr>\r\n	<td valign="top" width="425">\r\n		<p>\r\n			<strong></strong>\r\n		</p>\r\n		<p>\r\n			<strong><em>{{ @$DataOformleniyaZakazaSlovami}}</em></strong>\r\n		</p>\r\n		<p>\r\n			<strong></strong>\r\n		</p>\r\n	</td>\r\n	<td valign="top" width="437">\r\n		<p align="right">\r\n			<strong><em>Утверждаю</em></strong>\r\n		</p>\r\n		<p align="right">\r\n			<strong><em>Руководитель АНО ДПО «ЦКС»</em></strong>\r\n		</p>\r\n		<p align="right">\r\n			<strong><em> _________________ Шумеев П.А.</em></strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<p style="text-align: center;">\r\n	<strong>Расписание занятий</strong>\r\n</p>\r\n<p>\r\n	<strong>Группа: </strong>     №{{ @$NomerZakaza }}\r\n</p>\r\n<p>\r\n	<strong></strong>\r\n</p>\r\n<p>\r\n	<strong>Слушатель: </strong>{{ @$FIO_listener }}\r\n</p>\r\n<p>\r\n	<strong>Наименование дополнительной профессиональной программы:</strong> {{ @$Kod_kursa }}. {{ @$Nazvanie_kursa }}\r\n</p>\r\n<p>\r\n	      {{ @$RaspisanieObucheniyaPoKursu }}\r\n</p>', '2014-12-05 14:15:36', '2014-12-05 14:15:36'),
(933, 350, NULL, 'word_template', NULL, '2014-12-05 14:15:36', '2014-12-05 14:15:36'),
(934, 351, NULL, 'user_id', '2', '2014-12-05 14:15:36', '2014-12-05 14:15:36'),
(935, 351, NULL, 'action_id', '21', '2014-12-05 14:15:36', '2014-12-05 14:15:36'),
(936, 351, NULL, 'title', 'Событие за 05.12.2014 в 14:15', '2014-12-05 14:15:36', '2014-12-05 14:15:36'),
(937, 351, NULL, 'link', NULL, '2014-12-05 14:15:36', '2014-12-05 14:15:36'),
(938, 351, NULL, 'created_time', '2014-12-05 14:15:36', '2014-12-05 14:15:36', '2014-12-05 14:15:36'),
(939, 352, NULL, 'user_id', '8', '2014-12-05 17:21:42', '2014-12-05 17:21:42'),
(940, 352, NULL, 'action_id', '51', '2014-12-05 17:21:42', '2014-12-05 17:21:42'),
(941, 352, NULL, 'created_time', '2014-12-05 17:21:42', '2014-12-05 17:21:42', '2014-12-05 17:21:42'),
(942, 353, NULL, 'user_id', '8', '2014-12-05 17:22:58', '2014-12-05 17:22:58'),
(943, 353, NULL, 'action_id', '214', '2014-12-05 17:22:58', '2014-12-05 17:22:58'),
(944, 353, NULL, 'created_time', '2014-12-05 17:22:58', '2014-12-05 17:22:58', '2014-12-05 17:22:58'),
(945, 354, NULL, 'user_id', '8', '2014-12-08 16:24:14', '2014-12-08 16:24:14'),
(946, 354, NULL, 'action_id', '49', '2014-12-08 16:24:14', '2014-12-08 16:24:14'),
(947, 354, NULL, 'created_time', '2014-12-08 16:24:14', '2014-12-08 16:24:14', '2014-12-08 16:24:14'),
(948, 355, NULL, 'user_id', '0', '2014-12-08 16:24:14', '2014-12-08 16:24:14'),
(949, 355, NULL, 'action_id', '65', '2014-12-08 16:24:14', '2014-12-08 16:24:14'),
(950, 355, NULL, 'created_time', '2014-12-08 16:24:14', '2014-12-08 16:24:14', '2014-12-08 16:24:14'),
(951, 356, NULL, 'user_id', '8', '2014-12-08 16:25:48', '2014-12-08 16:25:48'),
(952, 356, NULL, 'action_id', '49', '2014-12-08 16:25:48', '2014-12-08 16:25:48'),
(953, 356, NULL, 'created_time', '2014-12-08 16:25:48', '2014-12-08 16:25:48', '2014-12-08 16:25:48'),
(954, 357, NULL, 'user_id', '0', '2014-12-08 16:25:48', '2014-12-08 16:25:48'),
(955, 357, NULL, 'action_id', '65', '2014-12-08 16:25:48', '2014-12-08 16:25:48'),
(956, 357, NULL, 'created_time', '2014-12-08 16:25:48', '2014-12-08 16:25:48', '2014-12-08 16:25:48'),
(957, 358, NULL, 'user_id', '15', '2014-12-09 09:05:15', '2014-12-09 09:05:15'),
(958, 358, NULL, 'action_id', '214', '2014-12-09 09:05:15', '2014-12-09 09:05:15'),
(959, 358, NULL, 'created_time', '2014-12-09 09:05:15', '2014-12-09 09:05:15', '2014-12-09 09:05:15'),
(960, 359, NULL, 'user_id', '15', '2014-12-09 09:06:08', '2014-12-09 09:06:08'),
(961, 359, NULL, 'action_id', '51', '2014-12-09 09:06:08', '2014-12-09 09:06:08'),
(962, 359, NULL, 'created_time', '2014-12-09 09:06:08', '2014-12-09 09:06:08', '2014-12-09 09:06:08'),
(963, 360, NULL, 'user_id', '15', '2014-12-09 09:28:38', '2014-12-09 09:28:38'),
(964, 360, NULL, 'action_id', '214', '2014-12-09 09:28:38', '2014-12-09 09:28:38'),
(965, 360, NULL, 'created_time', '2014-12-09 09:28:38', '2014-12-09 09:28:38', '2014-12-09 09:28:38'),
(966, 361, NULL, 'user_id', '15', '2014-12-09 10:51:17', '2014-12-09 10:51:17'),
(967, 361, NULL, 'action_id', '78', '2014-12-09 10:51:17', '2014-12-09 10:51:17'),
(968, 361, NULL, 'created_time', '2014-12-09 10:51:17', '2014-12-09 10:51:17', '2014-12-09 10:51:17'),
(969, 362, NULL, 'user_id', '0', '2014-12-09 10:51:17', '2014-12-09 10:51:17'),
(970, 362, NULL, 'action_id', '65', '2014-12-09 10:51:17', '2014-12-09 10:51:17'),
(971, 362, NULL, 'created_time', '2014-12-09 10:51:17', '2014-12-09 10:51:17', '2014-12-09 10:51:17'),
(972, 363, NULL, 'user_id', '2', '2014-12-09 10:51:48', '2014-12-09 10:51:48'),
(973, 363, NULL, 'action_id', '28', '2014-12-09 10:51:48', '2014-12-09 10:51:48'),
(974, 363, NULL, 'title', 'ООО "Ковровский механический завод"', '2014-12-09 10:51:48', '2014-12-09 10:51:48'),
(975, 363, NULL, 'link', NULL, '2014-12-09 10:51:48', '2014-12-09 10:51:48'),
(976, 363, NULL, 'created_time', '2014-12-09 10:51:48', '2014-12-09 10:51:48', '2014-12-09 10:51:48'),
(977, 364, NULL, 'user_id', '15', '2014-12-09 10:51:48', '2014-12-09 10:51:48'),
(978, 364, NULL, 'action_id', '159', '2014-12-09 10:51:48', '2014-12-09 10:51:48'),
(979, 364, NULL, 'created_time', '2014-12-09 10:51:48', '2014-12-09 10:51:48', '2014-12-09 10:51:48'),
(980, 365, NULL, 'user_id', '2', '2014-12-09 10:51:48', '2014-12-09 10:51:48'),
(981, 365, NULL, 'action_id', '26', '2014-12-09 10:51:48', '2014-12-09 10:51:48'),
(982, 365, NULL, 'title', 'Организация: ООО "Ковровский механический завод"', '2014-12-09 10:51:48', '2014-12-09 10:51:48'),
(983, 365, NULL, 'link', NULL, '2014-12-09 10:51:48', '2014-12-09 10:51:48'),
(984, 365, NULL, 'created_time', '2014-12-09 10:51:48', '2014-12-09 10:51:48', '2014-12-09 10:51:48'),
(985, 366, NULL, 'user_id', '15', '2014-12-09 10:52:15', '2014-12-09 10:52:15'),
(986, 366, NULL, 'action_id', '49', '2014-12-09 10:52:15', '2014-12-09 10:52:15'),
(987, 366, NULL, 'created_time', '2014-12-09 10:52:15', '2014-12-09 10:52:15', '2014-12-09 10:52:15'),
(988, 367, NULL, 'user_id', '0', '2014-12-09 10:52:15', '2014-12-09 10:52:15'),
(989, 367, NULL, 'action_id', '65', '2014-12-09 10:52:15', '2014-12-09 10:52:15'),
(990, 367, NULL, 'created_time', '2014-12-09 10:52:15', '2014-12-09 10:52:15', '2014-12-09 10:52:15'),
(991, 368, NULL, 'user_id', '15', '2014-12-09 10:52:47', '2014-12-09 10:52:47'),
(992, 368, NULL, 'action_id', '59', '2014-12-09 10:52:47', '2014-12-09 10:52:47'),
(993, 368, NULL, 'created_time', '2014-12-09 10:52:47', '2014-12-09 10:52:47', '2014-12-09 10:52:47'),
(994, 369, NULL, 'user_id', '2', '2014-12-09 10:52:47', '2014-12-09 10:52:47'),
(995, 369, NULL, 'action_id', '25', '2014-12-09 10:52:47', '2014-12-09 10:52:47'),
(996, 369, NULL, 'title', 'Заказ №13', '2014-12-09 10:52:47', '2014-12-09 10:52:47'),
(997, 369, NULL, 'link', NULL, '2014-12-09 10:52:47', '2014-12-09 10:52:47'),
(998, 369, NULL, 'created_time', '2014-12-09 10:52:47', '2014-12-09 10:52:47', '2014-12-09 10:52:47'),
(999, 370, NULL, 'user_id', '15', '2014-12-09 10:56:05', '2014-12-09 10:56:05'),
(1000, 370, NULL, 'action_id', '60', '2014-12-09 10:56:05', '2014-12-09 10:56:05'),
(1001, 370, NULL, 'created_time', '2014-12-09 10:56:05', '2014-12-09 10:56:05', '2014-12-09 10:56:05'),
(1002, 371, NULL, 'user_id', '2', '2014-12-09 10:56:05', '2014-12-09 10:56:05'),
(1003, 371, NULL, 'action_id', '25', '2014-12-09 10:56:05', '2014-12-09 10:56:05'),
(1004, 371, NULL, 'title', 'Заказ №13', '2014-12-09 10:56:05', '2014-12-09 10:56:05'),
(1005, 371, NULL, 'link', NULL, '2014-12-09 10:56:05', '2014-12-09 10:56:05'),
(1006, 371, NULL, 'created_time', '2014-12-09 10:56:05', '2014-12-09 10:56:05', '2014-12-09 10:56:05'),
(1007, 372, NULL, 'user_id', '15', '2014-12-09 10:56:33', '2014-12-09 10:56:33'),
(1008, 372, NULL, 'action_id', '58', '2014-12-09 10:56:33', '2014-12-09 10:56:33'),
(1009, 372, NULL, 'created_time', '2014-12-09 10:56:33', '2014-12-09 10:56:33', '2014-12-09 10:56:33'),
(1010, 373, NULL, 'user_id', '2', '2014-12-09 10:56:33', '2014-12-09 10:56:33'),
(1011, 373, NULL, 'action_id', '25', '2014-12-09 10:56:33', '2014-12-09 10:56:33'),
(1012, 373, NULL, 'title', 'Заказ №13', '2014-12-09 10:56:33', '2014-12-09 10:56:33'),
(1013, 373, NULL, 'link', NULL, '2014-12-09 10:56:33', '2014-12-09 10:56:33'),
(1014, 373, NULL, 'created_time', '2014-12-09 10:56:33', '2014-12-09 10:56:33', '2014-12-09 10:56:33'),
(1015, 374, NULL, 'user_id', '15', '2014-12-09 10:56:52', '2014-12-09 10:56:52'),
(1016, 374, NULL, 'action_id', '59', '2014-12-09 10:56:52', '2014-12-09 10:56:52'),
(1017, 374, NULL, 'created_time', '2014-12-09 10:56:52', '2014-12-09 10:56:52', '2014-12-09 10:56:52'),
(1018, 375, NULL, 'user_id', '2', '2014-12-09 10:56:52', '2014-12-09 10:56:52'),
(1019, 375, NULL, 'action_id', '25', '2014-12-09 10:56:52', '2014-12-09 10:56:52'),
(1020, 375, NULL, 'title', 'Заказ №13', '2014-12-09 10:56:52', '2014-12-09 10:56:52'),
(1021, 375, NULL, 'link', NULL, '2014-12-09 10:56:52', '2014-12-09 10:56:52'),
(1022, 375, NULL, 'created_time', '2014-12-09 10:56:52', '2014-12-09 10:56:52', '2014-12-09 10:56:52'),
(1023, 376, NULL, 'user_id', '15', '2014-12-09 10:57:52', '2014-12-09 10:57:52'),
(1024, 376, NULL, 'action_id', '60', '2014-12-09 10:57:52', '2014-12-09 10:57:52'),
(1025, 376, NULL, 'created_time', '2014-12-09 10:57:52', '2014-12-09 10:57:52', '2014-12-09 10:57:52'),
(1026, 377, NULL, 'user_id', '2', '2014-12-09 10:57:52', '2014-12-09 10:57:52'),
(1027, 377, NULL, 'action_id', '25', '2014-12-09 10:57:52', '2014-12-09 10:57:52'),
(1028, 377, NULL, 'title', 'Заказ №13', '2014-12-09 10:57:52', '2014-12-09 10:57:52'),
(1029, 377, NULL, 'link', NULL, '2014-12-09 10:57:52', '2014-12-09 10:57:52'),
(1030, 377, NULL, 'created_time', '2014-12-09 10:57:52', '2014-12-09 10:57:52', '2014-12-09 10:57:52'),
(1031, 378, NULL, 'user_id', '15', '2014-12-09 10:57:55', '2014-12-09 10:57:55'),
(1032, 378, NULL, 'action_id', '57', '2014-12-09 10:57:55', '2014-12-09 10:57:55'),
(1033, 378, NULL, 'created_time', '2014-12-09 10:57:55', '2014-12-09 10:57:55', '2014-12-09 10:57:55'),
(1034, 379, NULL, 'user_id', '2', '2014-12-09 10:57:55', '2014-12-09 10:57:55'),
(1035, 379, NULL, 'action_id', '25', '2014-12-09 10:57:55', '2014-12-09 10:57:55'),
(1036, 379, NULL, 'title', 'Заказ №13', '2014-12-09 10:57:55', '2014-12-09 10:57:55'),
(1037, 379, NULL, 'link', NULL, '2014-12-09 10:57:55', '2014-12-09 10:57:55'),
(1038, 379, NULL, 'created_time', '2014-12-09 10:57:55', '2014-12-09 10:57:55', '2014-12-09 10:57:55'),
(1039, 380, NULL, 'user_id', '15', '2014-12-09 10:57:59', '2014-12-09 10:57:59'),
(1040, 380, NULL, 'action_id', '59', '2014-12-09 10:57:59', '2014-12-09 10:57:59'),
(1041, 380, NULL, 'created_time', '2014-12-09 10:57:59', '2014-12-09 10:57:59', '2014-12-09 10:57:59'),
(1042, 381, NULL, 'user_id', '2', '2014-12-09 10:57:59', '2014-12-09 10:57:59'),
(1043, 381, NULL, 'action_id', '25', '2014-12-09 10:57:59', '2014-12-09 10:57:59'),
(1044, 381, NULL, 'title', 'Заказ №13', '2014-12-09 10:57:59', '2014-12-09 10:57:59'),
(1045, 381, NULL, 'link', NULL, '2014-12-09 10:57:59', '2014-12-09 10:57:59'),
(1046, 381, NULL, 'created_time', '2014-12-09 10:57:59', '2014-12-09 10:57:59', '2014-12-09 10:57:59'),
(1047, 382, NULL, 'user_id', '8', '2014-12-09 11:49:59', '2014-12-09 11:49:59'),
(1048, 382, NULL, 'action_id', '49', '2014-12-09 11:49:59', '2014-12-09 11:49:59'),
(1049, 382, NULL, 'created_time', '2014-12-09 11:49:59', '2014-12-09 11:49:59', '2014-12-09 11:49:59'),
(1050, 383, NULL, 'user_id', '0', '2014-12-09 11:49:59', '2014-12-09 11:49:59'),
(1051, 383, NULL, 'action_id', '65', '2014-12-09 11:49:59', '2014-12-09 11:49:59'),
(1052, 383, NULL, 'created_time', '2014-12-09 11:49:59', '2014-12-09 11:49:59', '2014-12-09 11:49:59'),
(1053, 384, NULL, 'user_id', '8', '2014-12-09 12:29:07', '2014-12-09 12:29:07'),
(1054, 384, NULL, 'action_id', '58', '2014-12-09 12:29:07', '2014-12-09 12:29:07'),
(1055, 384, NULL, 'created_time', '2014-12-09 12:29:07', '2014-12-09 12:29:07', '2014-12-09 12:29:07'),
(1056, 385, NULL, 'user_id', '2', '2014-12-09 12:29:08', '2014-12-09 12:29:08'),
(1057, 385, NULL, 'action_id', '25', '2014-12-09 12:29:08', '2014-12-09 12:29:08'),
(1058, 385, NULL, 'title', 'Заказ №14', '2014-12-09 12:29:08', '2014-12-09 12:29:08'),
(1059, 385, NULL, 'link', NULL, '2014-12-09 12:29:08', '2014-12-09 12:29:08'),
(1060, 385, NULL, 'created_time', '2014-12-09 12:29:08', '2014-12-09 12:29:08', '2014-12-09 12:29:08'),
(1061, 386, NULL, 'user_id', '3', '2014-12-09 12:33:01', '2014-12-09 12:33:01'),
(1062, 386, NULL, 'action_id', '49', '2014-12-09 12:33:01', '2014-12-09 12:33:01'),
(1063, 386, NULL, 'created_time', '2014-12-09 12:33:01', '2014-12-09 12:33:01', '2014-12-09 12:33:01'),
(1064, 387, NULL, 'user_id', '0', '2014-12-09 12:33:01', '2014-12-09 12:33:01'),
(1065, 387, NULL, 'action_id', '65', '2014-12-09 12:33:01', '2014-12-09 12:33:01'),
(1066, 387, NULL, 'created_time', '2014-12-09 12:33:01', '2014-12-09 12:33:01', '2014-12-09 12:33:01'),
(1067, 388, NULL, 'user_id', '3', '2014-12-09 12:33:56', '2014-12-09 12:33:56'),
(1068, 388, NULL, 'action_id', '50', '2014-12-09 12:33:56', '2014-12-09 12:33:56'),
(1069, 388, NULL, 'created_time', '2014-12-09 12:33:56', '2014-12-09 12:33:56', '2014-12-09 12:33:56'),
(1070, 389, NULL, 'user_id', '3', '2014-12-09 12:34:31', '2014-12-09 12:34:31'),
(1071, 389, NULL, 'action_id', '51', '2014-12-09 12:34:31', '2014-12-09 12:34:31'),
(1072, 389, NULL, 'created_time', '2014-12-09 12:34:31', '2014-12-09 12:34:31', '2014-12-09 12:34:31'),
(1084, 395, NULL, 'user_id', '2', '2014-12-10 09:30:29', '2014-12-10 09:30:29'),
(1085, 395, NULL, 'action_id', '15', '2014-12-10 09:30:29', '2014-12-10 09:30:29'),
(1086, 395, NULL, 'title', 'Событие за 10.12.2014 в 09:30', '2014-12-10 09:30:29', '2014-12-10 09:30:29'),
(1087, 395, NULL, 'link', NULL, '2014-12-10 09:30:29', '2014-12-10 09:30:29'),
(1088, 395, NULL, 'created_time', '2014-12-10 09:30:29', '2014-12-10 09:30:29', '2014-12-10 09:30:29'),
(1089, 396, NULL, 'user_id', '2', '2014-12-10 09:31:53', '2014-12-10 09:31:53'),
(1090, 396, NULL, 'action_id', '17', '2014-12-10 09:31:53', '2014-12-10 09:31:53'),
(1091, 396, NULL, 'title', 'Событие за 10.12.2014 в 09:31', '2014-12-10 09:31:53', '2014-12-10 09:31:53'),
(1092, 396, NULL, 'link', NULL, '2014-12-10 09:31:53', '2014-12-10 09:31:53'),
(1093, 396, NULL, 'created_time', '2014-12-10 09:31:53', '2014-12-10 09:31:53', '2014-12-10 09:31:53'),
(1094, 287, NULL, 'variables', '', '2014-12-10 10:16:54', '2014-12-10 10:16:54'),
(1095, 287, NULL, 'content', '<p style="text-align: right;">\r\n	          Руководителю АНО ДПО «ЦКС»\r\n</p>\r\n<p style="text-align: right;">\r\n	         Шумееву П.А.\r\n</p>\r\n<p style="text-align: right;">\r\n	         от <u>{{ $FIO_listener }}</u>\r\n</p>\r\n<p style="text-align: right;">\r\n	  ___________________________\r\n</p>\r\n<p align="center">\r\n	 <strong></strong>\r\n</p>\r\n<p style="text-align: center;">\r\n	<strong>Заявление</strong>\r\n</p>\r\n<p align="center">\r\n	<strong></strong>\r\n</p>\r\n<p>\r\n	  Прошу допустить меня к прохождению итоговой аттестации в связи с тем, что мною были полностью освоены все учебные модули дополнительной профессиональной программы {{ @$Kod_kursa }}. {{ @$Nazvanie_kursa }} в период с {{ @$DataOplatuZakaza }} г. по {{ @$DataOkonchaniyaObucheniya }} г.\r\n</p>\r\n<table>\r\n<tbody>\r\n<tr>\r\n	<td valign="top" width="260">\r\n		<p>\r\n			                              {{ @$DataOformleniyaZakazaSlovami }}\r\n		</p>\r\n	</td>\r\n	<td valign="top" width="321">\r\n		 <br>\r\n	</td>\r\n	<td valign="top" width="270">\r\n		<p align="right">\r\n			                              {{ @$FIO_initial_listener }}<br>\r\n		</p>\r\n	</td>\r\n</tr>\r\n</tbody>\r\n</table>', '2014-12-10 10:16:54', '2014-12-10 10:16:54'),
(1096, 287, NULL, 'word_template', NULL, '2014-12-10 10:16:54', '2014-12-10 10:16:54'),
(1097, 398, NULL, 'user_id', '2', '2014-12-10 10:16:54', '2014-12-10 10:16:54'),
(1098, 398, NULL, 'action_id', '21', '2014-12-10 10:16:54', '2014-12-10 10:16:54'),
(1099, 398, NULL, 'title', 'Событие за 10.12.2014 в 10:16', '2014-12-10 10:16:54', '2014-12-10 10:16:54'),
(1100, 398, NULL, 'link', NULL, '2014-12-10 10:16:54', '2014-12-10 10:16:54'),
(1101, 398, NULL, 'created_time', '2014-12-10 10:16:54', '2014-12-10 10:16:54', '2014-12-10 10:16:54'),
(1102, 288, NULL, 'variables', '', '2014-12-10 10:26:55', '2014-12-10 10:26:55'),
(1103, 288, NULL, 'content', '<p align="center">\r\n	<strong>Пояснения к документам </strong>\r\n</p>\r\n<p align="center">\r\n	<strong> </strong>\r\n</p>\r\n<p>\r\n	     1. Заявка – точно такая же галочка, как и согласие на обработку персональных данных; ее (галочку) необходимо поставить перед активацией личного кабинета     слушателя\r\n</p>\r\n<p>\r\n	     2. Приказ о зачислении – документ внутреннего пользования\r\n</p>\r\n<p>\r\n	     3. Расписание занятий. Датой в модуле 1 является дата скачивания любой из лекций, представленных в курсе. Датой итоговой аттестации является дата,     состоящая из даты скачивания лекции + количества дней, отведенных на курс\r\n</p>\r\n<p>\r\n	     4. Индивидуальный журнал посещений. Датой в модуле 1 является дата скачивания любой из лекций, представленных в курсе. Датой итоговой аттестации является     дата успешной сдачи итоговой аттестации\r\n</p>\r\n<p>\r\n	     5. Заявление о прохождении итоговой аттестации - точно такая же галочка, как и согласие на обработку персональных данных; ее (галочку) необходимо поставить     перед прохождением итоговой аттестации\r\n</p>\r\n<p>\r\n	     6. Результат итоговой аттестации\r\n</p>\r\n<p>\r\n	     7. Аттестационная ведомость – документ внутреннего пользования\r\n</p>\r\n<p>\r\n	     8. Приказ об отчислении – документ внутреннего пользования\r\n</p>\r\n<p>\r\n	     9. Журнал выдачи документов – документ внутреннего пользования\r\n</p>', '2014-12-10 10:26:55', '2014-12-10 10:26:55'),
(1104, 288, NULL, 'word_template', NULL, '2014-12-10 10:26:55', '2014-12-10 10:26:55'),
(1105, 400, NULL, 'user_id', '2', '2014-12-10 10:26:55', '2014-12-10 10:26:55'),
(1106, 400, NULL, 'action_id', '21', '2014-12-10 10:26:55', '2014-12-10 10:26:55'),
(1107, 400, NULL, 'title', 'Событие за 10.12.2014 в 10:26', '2014-12-10 10:26:55', '2014-12-10 10:26:55'),
(1108, 400, NULL, 'link', NULL, '2014-12-10 10:26:55', '2014-12-10 10:26:55'),
(1109, 400, NULL, 'created_time', '2014-12-10 10:26:55', '2014-12-10 10:26:55', '2014-12-10 10:26:55'),
(1110, 289, NULL, 'variables', '', '2014-12-10 10:38:49', '2014-12-10 10:38:49'),
(1111, 289, NULL, 'content', '<p style="text-align: center;">\r\n	 <strong>Индивидуальный журнал посещений</strong>\r\n</p>\r\n<p>\r\n	 <strong>Группа: </strong>     №{{ @$NomerZakaza }}\r\n</p>\r\n<p>\r\n	 <strong>Слушатель: </strong>{{ @$FIO_listener }}\r\n</p>\r\n<p>\r\n	 <strong>Наименование дополнительной профессиональной программы:</strong> {{ @$Kod_kursa }}. {{ @$Nazvanie_kursa }}\r\n</p>\r\n<p>\r\n	           {{ @$RaspisanieObucheniyaPoKursu }}\r\n</p>\r\n<table>\r\n<tbody>\r\n<tr>\r\n	<td valign="top" width="260">\r\n		<p>\r\n			  Руководитель АНО ДПО «ЦКС»\r\n		</p>\r\n	</td>\r\n	<td valign="top" width="321">\r\n		<br>\r\n	</td>\r\n	<td valign="top" width="270">\r\n		<p align="right">\r\n		</p>\r\n		<p style="text-align: right;">\r\n			  Шумеев П.А.\r\n		</p>\r\n		<p align="right">\r\n		</p>\r\n	</td>\r\n</tr>\r\n</tbody>\r\n</table>', '2014-12-10 10:38:49', '2014-12-10 10:40:02'),
(1112, 289, NULL, 'word_template', NULL, '2014-12-10 10:38:49', '2014-12-10 10:38:49'),
(1113, 402, NULL, 'user_id', '2', '2014-12-10 10:38:49', '2014-12-10 10:38:49'),
(1114, 402, NULL, 'action_id', '21', '2014-12-10 10:38:49', '2014-12-10 10:38:49'),
(1115, 402, NULL, 'title', 'Событие за 10.12.2014 в 10:38', '2014-12-10 10:38:49', '2014-12-10 10:38:49'),
(1116, 402, NULL, 'link', NULL, '2014-12-10 10:38:49', '2014-12-10 10:38:49'),
(1117, 402, NULL, 'created_time', '2014-12-10 10:38:49', '2014-12-10 10:38:49', '2014-12-10 10:38:49'),
(1118, 403, NULL, 'variables', '', '2014-12-10 10:40:02', '2014-12-10 10:40:02'),
(1119, 403, NULL, 'content', '<p style="text-align: center;">\r\n	<strong>Индивидуальный журнал посещений</strong>\r\n</p>\r\n<p>\r\n	<strong>Группа: </strong>     №{{ @$NomerZakaza }}\r\n</p>\r\n<p>\r\n	<strong></strong>\r\n</p>\r\n<p>\r\n	<strong>Слушатель: </strong>{{ @$FIO_listener }}\r\n</p>\r\n<p>\r\n	<strong>Наименование дополнительной профессиональной программы:</strong> {{ @$Kod_kursa }}. {{ @$Nazvanie_kursa }}\r\n</p>\r\n<p>\r\n	          {{ @$RaspisanieObucheniyaPoKursu }}\r\n</p>\r\n<table>\r\n<tbody>\r\n<tr>\r\n	<td valign="top" width="260">\r\n		<p>\r\n			 Руководитель АНО ДПО «ЦКС»\r\n		</p>\r\n	</td>\r\n	<td valign="top" width="321">\r\n		 <br>\r\n	</td>\r\n	<td valign="top" width="270">\r\n		<p align="right">\r\n		</p>\r\n		<p style="text-align: right;">\r\n			 Шумеев П.А.\r\n		</p>\r\n		<p align="right">\r\n		</p>\r\n	</td>\r\n</tr>\r\n</tbody>\r\n</table>', '2014-12-10 10:40:02', '2014-12-10 10:40:02'),
(1120, 403, NULL, 'word_template', NULL, '2014-12-10 10:40:02', '2014-12-10 10:40:02'),
(1121, 404, NULL, 'user_id', '2', '2014-12-10 10:40:02', '2014-12-10 10:40:02'),
(1122, 404, NULL, 'action_id', '21', '2014-12-10 10:40:02', '2014-12-10 10:40:02'),
(1123, 404, NULL, 'title', 'Событие за 10.12.2014 в 10:40', '2014-12-10 10:40:02', '2014-12-10 10:40:02'),
(1124, 404, NULL, 'link', NULL, '2014-12-10 10:40:02', '2014-12-10 10:40:02'),
(1125, 404, NULL, 'created_time', '2014-12-10 10:40:02', '2014-12-10 10:40:02', '2014-12-10 10:40:02'),
(1126, 291, NULL, 'variables', '', '2014-12-10 10:57:41', '2014-12-10 10:57:41'),
(1127, 291, NULL, 'content', '<p align="center">\r\n	 <strong>Аттестационная ведомость</strong>\r\n</p>\r\n<p>\r\n	 <strong>Наименование дополнительной профессиональной программы: </strong>{{ @$Kod_kursa }}. {{ @$Nazvanie_kursa }}\r\n</p>\r\n<p>\r\n	 <strong>Группа:</strong>     № {{ @$NomerZakaza }}\r\n</p>\r\n<p>\r\n	 <strong>Дата проведения аттестации</strong>     : {{ @$DataProvedeniyaAttestacii }} г.\r\n</p>\r\n<table border="1" cellpadding="0" cellspacing="0">\r\n<tbody>\r\n<tr>\r\n	<td valign="top" width="45">\r\n		<p align="center">\r\n			 <strong>№</strong>\r\n		</p>\r\n	</td>\r\n	<td valign="top" width="569">\r\n		<p align="center">\r\n			 <strong>Ф.И.О. слушателя</strong>\r\n		</p>\r\n	</td>\r\n	<td valign="top" width="225">\r\n		<p align="center">\r\n			 <strong>Оценка</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td valign="top" width="45">\r\n		<p align="center">\r\n			                        1\r\n		</p>\r\n	</td>\r\n	<td width="569">\r\n		<p align="center">\r\n			                        {{ @$FIO_listener }}\r\n		</p>\r\n	</td>\r\n	<td valign="top" width="225">\r\n		<p align="center">\r\n			                {{ @$OcenkaAttestacii }} ({{ @$OcenkaAttestaciiSlovami }})\r\n		</p>\r\n	</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<table>\r\n<tbody>\r\n<tr>\r\n	<td valign="top" width="430">\r\n		<p>\r\n			                         Члены аттестационной комиссии <strong></strong>\r\n		</p>\r\n	</td>\r\n	<td valign="top" width="232">\r\n		<p align="center">\r\n			<strong> </strong>\r\n		</p>\r\n		<br>\r\n	</td>\r\n	<td valign="top" width="177">\r\n		<p align="right">\r\n			                         Шаповалова Д.Е.<strong></strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td valign="top" width="430">\r\n		<br>\r\n	</td>\r\n	<td valign="top" width="232">\r\n		<br>\r\n	</td>\r\n	<td valign="top" width="177">\r\n		<p align="right">\r\n			                         Шумеев А.А.\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td valign="top" width="430">\r\n		<p>\r\n			                         Председатель аттестационной комиссии\r\n		</p>\r\n	</td>\r\n	<td valign="top" width="232">\r\n		<br>\r\n	</td>\r\n	<td valign="top" width="177">\r\n		<p align="right">\r\n			                         Шумеев П.А.\r\n		</p>\r\n	</td>\r\n</tr>\r\n</tbody>\r\n</table>', '2014-12-10 10:57:41', '2014-12-17 11:30:21'),
(1128, 291, NULL, 'word_template', NULL, '2014-12-10 10:57:41', '2014-12-10 10:57:41'),
(1129, 406, NULL, 'user_id', '2', '2014-12-10 10:57:41', '2014-12-10 10:57:41'),
(1130, 406, NULL, 'action_id', '21', '2014-12-10 10:57:41', '2014-12-10 10:57:41'),
(1131, 406, NULL, 'title', 'Событие за 10.12.2014 в 10:57', '2014-12-10 10:57:41', '2014-12-10 10:57:41'),
(1132, 406, NULL, 'link', NULL, '2014-12-10 10:57:41', '2014-12-10 10:57:41'),
(1133, 406, NULL, 'created_time', '2014-12-10 10:57:41', '2014-12-10 10:57:41', '2014-12-10 10:57:41'),
(1134, 407, NULL, 'user_id', '8', '2014-12-10 11:03:03', '2014-12-10 11:03:03'),
(1135, 407, NULL, 'action_id', '58', '2014-12-10 11:03:03', '2014-12-10 11:03:03'),
(1136, 407, NULL, 'created_time', '2014-12-10 11:03:03', '2014-12-10 11:03:03', '2014-12-10 11:03:03'),
(1137, 408, NULL, 'user_id', '2', '2014-12-10 11:03:03', '2014-12-10 11:03:03'),
(1138, 408, NULL, 'action_id', '22', '2014-12-10 11:03:03', '2014-12-10 11:03:03'),
(1139, 408, NULL, 'title', 'Заказ №1. Сумма: 13000 руб.', '2014-12-10 11:03:03', '2014-12-10 11:03:03'),
(1140, 408, NULL, 'link', NULL, '2014-12-10 11:03:03', '2014-12-10 11:03:03'),
(1141, 408, NULL, 'created_time', '2014-12-10 11:03:03', '2014-12-10 11:03:03', '2014-12-10 11:03:03'),
(1142, 290, NULL, 'variables', '', '2014-12-10 12:19:09', '2014-12-10 12:19:09'),
(1143, 290, NULL, 'content', '<p style="text-align: center;">\r\n	<strong>Результат итоговой аттестации</strong>\r\n</p>\r\n<p>\r\n	 <strong>Группа: </strong>     №{{ @$NomerZakaza }}\r\n</p>\r\n<p>\r\n	 <strong>Слушатель: </strong>{{ @$FIO_listener }}\r\n</p>\r\n<p>\r\n	<strong>Дата проведения аттестации</strong>     : {{ @$DataProvedeniyaAttestacii }} г.\r\n</p>\r\n<table>\r\n<tbody>\r\n<tr>\r\n	<td valign="top" width="331">\r\n		<p align="center">\r\n			                          Наименование\r\n		</p>\r\n		<p align="center">\r\n			                          дополнительной профессиональной программы\r\n		</p>\r\n	</td>\r\n	<td valign="top" width="106">\r\n		<p align="center">\r\n			                          Задано вопросов\r\n		</p>\r\n	</td>\r\n	<td valign="top" width="118">\r\n		<p align="center">\r\n			                          Правильно ответов\r\n		</p>\r\n	</td>\r\n	<td valign="top" width="142">\r\n		<p align="center">\r\n			                          Фактический процент правильных ответов\r\n		</p>\r\n	</td>\r\n	<td valign="top" width="154">\r\n		<p align="center">\r\n			                          Минимальный процент правильных ответов\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td valign="top" width="331">\r\n		<p align="center">\r\n		</p>\r\n		<p style="text-align: center;">\r\n			     {{ @$Kod_kursa }}. {{ @$Nazvanie_kursa }}\r\n		</p>\r\n		<p align="center">\r\n		</p>\r\n	</td>\r\n	<td valign="top" width="106">\r\n		<p align="center">\r\n			     {{ @$KolichestvoVoprosiv }}\r\n		</p>\r\n	</td>\r\n	<td valign="top" width="118">\r\n		<p align="center">\r\n		</p>\r\n		<p style="text-align: center;">\r\n			    {{ @$KolichestvoPravilnuhOtvetov }}\r\n		</p>\r\n		<p align="center">\r\n		</p>\r\n	</td>\r\n	<td valign="top" width="142">\r\n		<p align="center">\r\n		</p>\r\n		<p align="center">\r\n			    {{ @$OcenkaAttestacii }}%\r\n		</p>\r\n	</td>\r\n	<td valign="top" width="154">\r\n		<p align="center">\r\n		</p>\r\n		<p align="center">\r\n			    {{ @$MinimalnayaOcenkaAttestacii }}%\r\n		</p>\r\n	</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<p>\r\n	    Оценка: {{ @$OcenkaAttestaciiSlovami }}\r\n</p>\r\n<table>\r\n<tbody>\r\n<tr>\r\n	<td valign="top" width="260">\r\n		<p>\r\n			        Руководитель АНО ДПО «ЦКС»\r\n		</p>\r\n	</td>\r\n	<td valign="top" width="321">\r\n		<br>\r\n	</td>\r\n	<td valign="top" width="270">\r\n		<p align="right">\r\n		</p>\r\n		<p style="text-align: right;">\r\n			        Шумеев П.А.\r\n		</p>\r\n		<p align="right">\r\n		</p>\r\n	</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<p>\r\n	    {{ @$TablicaResultatovAttestacii }}\r\n</p>', '2014-12-10 12:19:09', '2014-12-10 16:03:53'),
(1144, 290, NULL, 'word_template', NULL, '2014-12-10 12:19:09', '2014-12-10 12:19:09'),
(1145, 410, NULL, 'user_id', '2', '2014-12-10 12:19:09', '2014-12-10 12:19:09'),
(1146, 410, NULL, 'action_id', '21', '2014-12-10 12:19:09', '2014-12-10 12:19:09'),
(1147, 410, NULL, 'title', 'Событие за 10.12.2014 в 12:19', '2014-12-10 12:19:09', '2014-12-10 12:19:09'),
(1148, 410, NULL, 'link', NULL, '2014-12-10 12:19:09', '2014-12-10 12:19:09'),
(1149, 410, NULL, 'created_time', '2014-12-10 12:19:09', '2014-12-10 12:19:09', '2014-12-10 12:19:09'),
(1153, 412, NULL, 'user_id', '2', '2014-12-10 12:23:31', '2014-12-10 12:23:31'),
(1154, 412, NULL, 'action_id', '21', '2014-12-10 12:23:31', '2014-12-10 12:23:31'),
(1155, 412, NULL, 'title', 'Событие за 10.12.2014 в 12:23', '2014-12-10 12:23:31', '2014-12-10 12:23:31'),
(1156, 412, NULL, 'link', NULL, '2014-12-10 12:23:31', '2014-12-10 12:23:31'),
(1157, 412, NULL, 'created_time', '2014-12-10 12:23:31', '2014-12-10 12:23:31', '2014-12-10 12:23:31'),
(1158, 413, NULL, 'user_id', '0', '2014-12-10 16:03:47', '2014-12-10 16:03:47'),
(1159, 413, NULL, 'action_id', '61', '2014-12-10 16:03:47', '2014-12-10 16:03:47'),
(1160, 413, NULL, 'created_time', '2014-12-10 16:03:47', '2014-12-10 16:03:47', '2014-12-10 16:03:47'),
(1161, 414, NULL, 'variables', '', '2014-12-10 16:03:53', '2014-12-10 16:03:53'),
(1162, 414, NULL, 'content', '<p style="text-align: center;">\r\n	 <strong>Результат итоговой аттестации</strong>\r\n</p>\r\n<p>\r\n	<strong>Группа: </strong>     №{{ @$NomerZakaza }}\r\n</p>\r\n<p>\r\n	<strong>Слушатель: </strong>{{ @$FIO_listener }}\r\n</p>\r\n<p>\r\n	 <strong>Дата проведения аттестации</strong>     : {{ @$DataProvedeniyaAttestacii }} г.\r\n</p>\r\n<table>\r\n<tbody>\r\n<tr>\r\n	<td valign="top" width="331">\r\n		<p align="center">\r\n			                         Наименование\r\n		</p>\r\n		<p align="center">\r\n			                         дополнительной профессиональной программы\r\n		</p>\r\n	</td>\r\n	<td valign="top" width="106">\r\n		<p align="center">\r\n			                         Задано вопросов\r\n		</p>\r\n	</td>\r\n	<td valign="top" width="118">\r\n		<p align="center">\r\n			                         Правильно ответов\r\n		</p>\r\n	</td>\r\n	<td valign="top" width="142">\r\n		<p align="center">\r\n			                         Фактический процент правильных ответов\r\n		</p>\r\n	</td>\r\n	<td valign="top" width="154">\r\n		<p align="center">\r\n			                         Минимальный процент правильных ответов\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td valign="top" width="331">\r\n		<p align="center">\r\n		</p>\r\n		<p style="text-align: center;">\r\n			    {{ @$Kod_kursa }}. {{ @$Nazvanie_kursa }}\r\n		</p>\r\n		<p align="center">\r\n		</p>\r\n	</td>\r\n	<td valign="top" width="106">\r\n		<p align="center">\r\n			    {{ @$KolichestvoVoprosiv }}\r\n		</p>\r\n	</td>\r\n	<td valign="top" width="118">\r\n		<p align="center">\r\n		</p>\r\n		<p>\r\n			   {{ @$KolichestvoPravilnuhOtvetov }}\r\n		</p>\r\n		<p align="center">\r\n		</p>\r\n	</td>\r\n	<td valign="top" width="142">\r\n		<p align="center">\r\n		</p>\r\n		<p align="center">\r\n			   {{ @$OcenkaAttestacii }}%\r\n		</p>\r\n	</td>\r\n	<td valign="top" width="154">\r\n		<p align="center">\r\n		</p>\r\n		<p align="center">\r\n			   {{ @$MinimalnayaOcenkaAttestacii }}%\r\n		</p>\r\n	</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<p>\r\n	   Оценка: {{ @$OcenkaAttestaciiSlovami }}\r\n</p>\r\n<table>\r\n<tbody>\r\n<tr>\r\n	<td valign="top" width="260">\r\n		<p>\r\n			       Руководитель АНО ДПО «ЦКС»\r\n		</p>\r\n	</td>\r\n	<td valign="top" width="321">\r\n		 <br>\r\n	</td>\r\n	<td valign="top" width="270">\r\n		<p align="right">\r\n		</p>\r\n		<p style="text-align: right;">\r\n			       Шумеев П.А.\r\n		</p>\r\n		<p align="right">\r\n		</p>\r\n	</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<p>\r\n	   {{ @$TablicaResultatovAttestacii }}\r\n</p>', '2014-12-10 16:03:53', '2014-12-10 16:03:53'),
(1163, 414, NULL, 'word_template', NULL, '2014-12-10 16:03:53', '2014-12-10 16:03:53'),
(1164, 415, NULL, 'user_id', '2', '2014-12-10 16:03:53', '2014-12-10 16:03:53'),
(1165, 415, NULL, 'action_id', '21', '2014-12-10 16:03:53', '2014-12-10 16:03:53'),
(1166, 415, NULL, 'title', 'Событие за 10.12.2014 в 16:03', '2014-12-10 16:03:53', '2014-12-10 16:03:53'),
(1167, 415, NULL, 'link', NULL, '2014-12-10 16:03:53', '2014-12-10 16:03:53'),
(1168, 415, NULL, 'created_time', '2014-12-10 16:03:53', '2014-12-10 16:03:53', '2014-12-10 16:03:53'),
(1169, 416, NULL, 'user_id', '0', '2014-12-10 16:11:37', '2014-12-10 16:11:37'),
(1170, 416, NULL, 'action_id', '61', '2014-12-10 16:11:37', '2014-12-10 16:11:37'),
(1171, 416, NULL, 'created_time', '2014-12-10 16:11:37', '2014-12-10 16:11:37', '2014-12-10 16:11:37'),
(1172, 417, NULL, 'user_id', '30', '2014-12-10 16:14:00', '2014-12-10 16:14:00'),
(1173, 417, NULL, 'action_id', '47', '2014-12-10 16:14:00', '2014-12-10 16:14:00'),
(1174, 417, NULL, 'created_time', '2014-12-10 16:14:00', '2014-12-10 16:14:00', '2014-12-10 16:14:00'),
(1175, 418, NULL, 'user_id', '30', '2014-12-10 16:14:00', '2014-12-10 16:14:00'),
(1176, 418, NULL, 'action_id', '46', '2014-12-10 16:14:00', '2014-12-10 16:14:00'),
(1177, 418, NULL, 'created_time', '2014-12-10 16:14:00', '2014-12-10 16:14:00', '2014-12-10 16:14:00'),
(1178, 419, NULL, 'user_id', '30', '2014-12-10 16:14:00', '2014-12-10 16:14:00'),
(1179, 419, NULL, 'action_id', '157', '2014-12-10 16:14:00', '2014-12-10 16:14:00'),
(1180, 419, NULL, 'created_time', '2014-12-10 16:14:00', '2014-12-10 16:14:00', '2014-12-10 16:14:00'),
(1181, 420, NULL, 'user_id', '0', '2014-12-10 16:28:17', '2014-12-10 16:28:17'),
(1182, 420, NULL, 'action_id', '63', '2014-12-10 16:28:17', '2014-12-10 16:28:17'),
(1183, 420, NULL, 'created_time', '2014-12-10 16:28:17', '2014-12-10 16:28:17', '2014-12-10 16:28:17'),
(1184, 292, NULL, 'variables', '', '2014-12-10 16:43:22', '2014-12-10 16:43:22'),
(1185, 292, NULL, 'content', '<p align="center">\r\n	 <strong></strong>\r\n</p>\r\n<p style="text-align: center;">\r\n	 <strong>Журнал выдачи удостоверений по дополнительной профессиональной программе «Качество строительства» </strong>\r\n</p>\r\n<p style="text-align: center;">\r\n	 <strong>(период обучения с {{ @$DataOplatuZakaza }} г. по {{ @$DataOkonchaniyaObucheniya }} г.)</strong>\r\n</p>\r\n<p align="center">\r\n	 <strong></strong>\r\n</p>\r\n<p align="center">\r\n	 <strong> </strong>\r\n</p>', '2014-12-10 16:43:22', '2014-12-10 16:43:22'),
(1186, 292, NULL, 'word_template', NULL, '2014-12-10 16:43:22', '2014-12-10 16:43:22'),
(1187, 422, NULL, 'user_id', '2', '2014-12-10 16:43:22', '2014-12-10 16:43:22'),
(1188, 422, NULL, 'action_id', '21', '2014-12-10 16:43:22', '2014-12-10 16:43:22'),
(1189, 422, NULL, 'title', 'Событие за 10.12.2014 в 16:43', '2014-12-10 16:43:22', '2014-12-10 16:43:22'),
(1190, 422, NULL, 'link', NULL, '2014-12-10 16:43:22', '2014-12-10 16:43:22'),
(1191, 422, NULL, 'created_time', '2014-12-10 16:43:22', '2014-12-10 16:43:22', '2014-12-10 16:43:22'),
(1192, 423, NULL, 'user_id', '0', '2014-12-10 16:45:52', '2014-12-10 16:45:52'),
(1193, 423, NULL, 'action_id', '63', '2014-12-10 16:45:52', '2014-12-10 16:45:52'),
(1194, 423, NULL, 'created_time', '2014-12-10 16:45:52', '2014-12-10 16:45:52', '2014-12-10 16:45:52'),
(1195, 424, NULL, 'user_id', '30', '2014-12-10 16:53:01', '2014-12-10 16:53:01'),
(1196, 424, NULL, 'action_id', '78', '2014-12-10 16:53:01', '2014-12-10 16:53:01'),
(1197, 424, NULL, 'created_time', '2014-12-10 16:53:01', '2014-12-10 16:53:01', '2014-12-10 16:53:01'),
(1198, 425, NULL, 'user_id', '0', '2014-12-10 16:53:01', '2014-12-10 16:53:01'),
(1199, 425, NULL, 'action_id', '65', '2014-12-10 16:53:01', '2014-12-10 16:53:01'),
(1200, 425, NULL, 'created_time', '2014-12-10 16:53:01', '2014-12-10 16:53:01', '2014-12-10 16:53:01'),
(1201, 426, NULL, 'user_id', '0', '2014-12-11 06:09:27', '2014-12-11 06:09:27'),
(1202, 426, NULL, 'action_id', '61', '2014-12-11 06:09:27', '2014-12-11 06:09:27'),
(1203, 426, NULL, 'created_time', '2014-12-11 06:09:27', '2014-12-11 06:09:27', '2014-12-11 06:09:27'),
(1204, 427, NULL, 'user_id', '2', '2014-12-11 06:15:02', '2014-12-11 06:15:02'),
(1205, 427, NULL, 'action_id', '28', '2014-12-11 06:15:02', '2014-12-11 06:15:02'),
(1206, 427, NULL, 'title', 'Фирма-3', '2014-12-11 06:15:02', '2014-12-11 06:15:02'),
(1207, 427, NULL, 'link', NULL, '2014-12-11 06:15:02', '2014-12-11 06:15:02'),
(1208, 427, NULL, 'created_time', '2014-12-11 06:15:02', '2014-12-11 06:15:02', '2014-12-11 06:15:02'),
(1209, 428, NULL, 'user_id', '30', '2014-12-11 06:15:02', '2014-12-11 06:15:02'),
(1210, 428, NULL, 'action_id', '159', '2014-12-11 06:15:02', '2014-12-11 06:15:02'),
(1211, 428, NULL, 'created_time', '2014-12-11 06:15:02', '2014-12-11 06:15:02', '2014-12-11 06:15:02'),
(1212, 429, NULL, 'user_id', '2', '2014-12-11 06:15:02', '2014-12-11 06:15:02'),
(1213, 429, NULL, 'action_id', '26', '2014-12-11 06:15:02', '2014-12-11 06:15:02'),
(1214, 429, NULL, 'title', 'Организация: Фирма-3', '2014-12-11 06:15:02', '2014-12-11 06:15:02'),
(1215, 429, NULL, 'link', NULL, '2014-12-11 06:15:02', '2014-12-11 06:15:02'),
(1216, 429, NULL, 'created_time', '2014-12-11 06:15:02', '2014-12-11 06:15:02', '2014-12-11 06:15:02'),
(1217, 430, NULL, 'user_id', '30', '2014-12-11 06:21:43', '2014-12-11 06:21:43'),
(1218, 430, NULL, 'action_id', '57', '2014-12-11 06:21:43', '2014-12-11 06:21:43'),
(1219, 430, NULL, 'created_time', '2014-12-11 06:21:43', '2014-12-11 06:21:43', '2014-12-11 06:21:43'),
(1220, 431, NULL, 'user_id', '2', '2014-12-11 06:21:43', '2014-12-11 06:21:43'),
(1221, 431, NULL, 'action_id', '25', '2014-12-11 06:21:43', '2014-12-11 06:21:43'),
(1222, 431, NULL, 'title', 'Заказ №16', '2014-12-11 06:21:43', '2014-12-11 06:21:43'),
(1223, 431, NULL, 'link', NULL, '2014-12-11 06:21:43', '2014-12-11 06:21:43'),
(1224, 431, NULL, 'created_time', '2014-12-11 06:21:43', '2014-12-11 06:21:43', '2014-12-11 06:21:43'),
(1225, 432, NULL, 'user_id', '30', '2014-12-11 06:35:48', '2014-12-11 06:35:48'),
(1226, 432, NULL, 'action_id', '50', '2014-12-11 06:35:48', '2014-12-11 06:35:48'),
(1227, 432, NULL, 'created_time', '2014-12-11 06:35:48', '2014-12-11 06:35:48', '2014-12-11 06:35:48'),
(1228, 433, NULL, 'user_id', '30', '2014-12-11 06:47:05', '2014-12-11 06:47:05'),
(1229, 433, NULL, 'action_id', '214', '2014-12-11 06:47:05', '2014-12-11 06:47:05'),
(1230, 433, NULL, 'created_time', '2014-12-11 06:47:05', '2014-12-11 06:47:05', '2014-12-11 06:47:05'),
(1231, 434, NULL, 'user_id', '30', '2014-12-11 06:48:55', '2014-12-11 06:48:55');
INSERT INTO `dictionary_fields_values` (`id`, `dicval_id`, `language`, `key`, `value`, `created_at`, `updated_at`) VALUES
(1232, 434, NULL, 'action_id', '51', '2014-12-11 06:48:55', '2014-12-11 06:48:55'),
(1233, 434, NULL, 'created_time', '2014-12-11 06:48:55', '2014-12-11 06:48:55', '2014-12-11 06:48:55'),
(1234, 435, NULL, 'user_id', '30', '2014-12-11 06:51:31', '2014-12-11 06:51:31'),
(1235, 435, NULL, 'action_id', '53', '2014-12-11 06:51:31', '2014-12-11 06:51:31'),
(1236, 435, NULL, 'created_time', '2014-12-11 06:51:31', '2014-12-11 06:51:31', '2014-12-11 06:51:31'),
(1237, 436, NULL, 'user_id', '30', '2014-12-11 06:52:16', '2014-12-11 06:52:16'),
(1238, 436, NULL, 'action_id', '53', '2014-12-11 06:52:16', '2014-12-11 06:52:16'),
(1239, 436, NULL, 'created_time', '2014-12-11 06:52:16', '2014-12-11 06:52:16', '2014-12-11 06:52:16'),
(1240, 437, NULL, 'user_id', '30', '2014-12-11 06:52:21', '2014-12-11 06:52:21'),
(1241, 437, NULL, 'action_id', '52', '2014-12-11 06:52:21', '2014-12-11 06:52:21'),
(1242, 437, NULL, 'created_time', '2014-12-11 06:52:21', '2014-12-11 06:52:21', '2014-12-11 06:52:21'),
(1245, 439, NULL, 'user_id', '0', '2014-12-11 10:40:02', '2014-12-11 10:40:02'),
(1246, 439, NULL, 'action_id', '63', '2014-12-11 10:40:02', '2014-12-11 10:40:02'),
(1247, 439, NULL, 'created_time', '2014-12-11 10:40:02', '2014-12-11 10:40:02', '2014-12-11 10:40:02'),
(1248, 440, NULL, 'user_id', '15', '2014-12-11 10:52:56', '2014-12-11 10:52:56'),
(1249, 440, NULL, 'action_id', '49', '2014-12-11 10:52:56', '2014-12-11 10:52:56'),
(1250, 440, NULL, 'created_time', '2014-12-11 10:52:56', '2014-12-11 10:52:56', '2014-12-11 10:52:56'),
(1251, 441, NULL, 'user_id', '0', '2014-12-11 10:52:56', '2014-12-11 10:52:56'),
(1252, 441, NULL, 'action_id', '65', '2014-12-11 10:52:56', '2014-12-11 10:52:56'),
(1253, 441, NULL, 'created_time', '2014-12-11 10:52:56', '2014-12-11 10:52:56', '2014-12-11 10:52:56'),
(1254, 442, NULL, 'user_id', '15', '2014-12-11 10:53:49', '2014-12-11 10:53:49'),
(1255, 442, NULL, 'action_id', '60', '2014-12-11 10:53:49', '2014-12-11 10:53:49'),
(1256, 442, NULL, 'created_time', '2014-12-11 10:53:49', '2014-12-11 10:53:49', '2014-12-11 10:53:49'),
(1257, 443, NULL, 'user_id', '2', '2014-12-11 10:53:49', '2014-12-11 10:53:49'),
(1258, 443, NULL, 'action_id', '25', '2014-12-11 10:53:49', '2014-12-11 10:53:49'),
(1259, 443, NULL, 'title', 'Заказ №17', '2014-12-11 10:53:49', '2014-12-11 10:53:49'),
(1260, 443, NULL, 'link', NULL, '2014-12-11 10:53:49', '2014-12-11 10:53:49'),
(1261, 443, NULL, 'created_time', '2014-12-11 10:53:49', '2014-12-11 10:53:49', '2014-12-11 10:53:49'),
(1262, 444, NULL, 'user_id', '15', '2014-12-11 10:55:23', '2014-12-11 10:55:23'),
(1263, 444, NULL, 'action_id', '50', '2014-12-11 10:55:23', '2014-12-11 10:55:23'),
(1264, 444, NULL, 'created_time', '2014-12-11 10:55:23', '2014-12-11 10:55:23', '2014-12-11 10:55:23'),
(1265, 445, NULL, 'user_id', '15', '2014-12-11 10:56:03', '2014-12-11 10:56:03'),
(1266, 445, NULL, 'action_id', '50', '2014-12-11 10:56:03', '2014-12-11 10:56:03'),
(1267, 445, NULL, 'created_time', '2014-12-11 10:56:03', '2014-12-11 10:56:03', '2014-12-11 10:56:03'),
(1268, 446, NULL, 'user_id', '2', '2014-12-11 10:56:36', '2014-12-11 10:56:36'),
(1269, 446, NULL, 'action_id', '132', '2014-12-11 10:56:36', '2014-12-11 10:56:36'),
(1270, 446, NULL, 'title', '№017-14', '2014-12-11 10:56:36', '2014-12-11 10:56:36'),
(1271, 446, NULL, 'link', NULL, '2014-12-11 10:56:36', '2014-12-11 10:56:36'),
(1272, 446, NULL, 'created_time', '2014-12-11 10:56:36', '2014-12-11 10:56:36', '2014-12-11 10:56:36'),
(1273, 447, NULL, 'user_id', '15', '2014-12-11 10:57:24', '2014-12-11 10:57:24'),
(1274, 447, NULL, 'action_id', '53', '2014-12-11 10:57:24', '2014-12-11 10:57:24'),
(1275, 447, NULL, 'created_time', '2014-12-11 10:57:24', '2014-12-11 10:57:24', '2014-12-11 10:57:24'),
(1276, 448, NULL, 'user_id', '15', '2014-12-11 11:01:51', '2014-12-11 11:01:51'),
(1277, 448, NULL, 'action_id', '53', '2014-12-11 11:01:51', '2014-12-11 11:01:51'),
(1278, 448, NULL, 'created_time', '2014-12-11 11:01:51', '2014-12-11 11:01:51', '2014-12-11 11:01:51'),
(1279, 449, NULL, 'user_id', '15', '2014-12-11 11:03:04', '2014-12-11 11:03:04'),
(1280, 449, NULL, 'action_id', '50', '2014-12-11 11:03:04', '2014-12-11 11:03:04'),
(1281, 449, NULL, 'created_time', '2014-12-11 11:03:04', '2014-12-11 11:03:04', '2014-12-11 11:03:04'),
(1282, 450, NULL, 'user_id', '15', '2014-12-11 11:03:28', '2014-12-11 11:03:28'),
(1283, 450, NULL, 'action_id', '53', '2014-12-11 11:03:28', '2014-12-11 11:03:28'),
(1284, 450, NULL, 'created_time', '2014-12-11 11:03:28', '2014-12-11 11:03:28', '2014-12-11 11:03:28'),
(1285, 451, NULL, 'user_id', '15', '2014-12-11 11:03:29', '2014-12-11 11:03:29'),
(1286, 451, NULL, 'action_id', '67', '2014-12-11 11:03:29', '2014-12-11 11:03:29'),
(1287, 451, NULL, 'created_time', '2014-12-11 11:03:29', '2014-12-11 11:03:29', '2014-12-11 11:03:29'),
(1288, 452, NULL, 'user_id', '15', '2014-12-11 11:03:29', '2014-12-11 11:03:29'),
(1289, 452, NULL, 'action_id', '160', '2014-12-11 11:03:29', '2014-12-11 11:03:29'),
(1290, 452, NULL, 'created_time', '2014-12-11 11:03:29', '2014-12-11 11:03:29', '2014-12-11 11:03:29'),
(1291, 453, NULL, 'user_id', '0', '2014-12-11 11:03:29', '2014-12-11 11:03:29'),
(1292, 453, NULL, 'action_id', '66', '2014-12-11 11:03:29', '2014-12-11 11:03:29'),
(1293, 453, NULL, 'created_time', '2014-12-11 11:03:29', '2014-12-11 11:03:29', '2014-12-11 11:03:29'),
(1294, 454, NULL, 'property', '86', '2014-12-11 11:28:44', '2014-12-11 11:38:13'),
(1295, 455, NULL, 'user_id', '2', '2014-12-11 11:41:42', '2014-12-11 11:41:42'),
(1296, 455, NULL, 'action_id', '29', '2014-12-11 11:41:42', '2014-12-11 11:41:42'),
(1297, 455, NULL, 'title', 'Слушатель: Огурцов Анатолий Степанович', '2014-12-11 11:41:42', '2014-12-11 11:41:42'),
(1298, 455, NULL, 'link', NULL, '2014-12-11 11:41:42', '2014-12-11 11:41:42'),
(1299, 455, NULL, 'created_time', '2014-12-11 11:41:42', '2014-12-11 11:41:42', '2014-12-11 11:41:42'),
(1300, 456, NULL, 'user_id', '0', '2014-12-11 11:42:44', '2014-12-11 11:42:44'),
(1301, 456, NULL, 'action_id', '63', '2014-12-11 11:42:44', '2014-12-11 11:42:44'),
(1302, 456, NULL, 'created_time', '2014-12-11 11:42:44', '2014-12-11 11:42:44', '2014-12-11 11:42:44'),
(1303, 457, NULL, 'user_id', '0', '2014-12-11 11:43:10', '2014-12-11 11:43:10'),
(1304, 457, NULL, 'action_id', '63', '2014-12-11 11:43:10', '2014-12-11 11:43:10'),
(1305, 457, NULL, 'created_time', '2014-12-11 11:43:10', '2014-12-11 11:43:10', '2014-12-11 11:43:10'),
(1306, 458, NULL, 'user_id', '8', '2014-12-11 11:57:08', '2014-12-11 11:57:08'),
(1307, 458, NULL, 'action_id', '53', '2014-12-11 11:57:08', '2014-12-11 11:57:08'),
(1308, 458, NULL, 'created_time', '2014-12-11 11:57:08', '2014-12-11 11:57:08', '2014-12-11 11:57:08'),
(1312, 460, NULL, 'user_id', '2', '2014-12-11 12:42:19', '2014-12-11 12:42:19'),
(1313, 460, NULL, 'action_id', '25', '2014-12-11 12:42:19', '2014-12-11 12:42:19'),
(1314, 460, NULL, 'title', 'Заказ №16', '2014-12-11 12:42:19', '2014-12-11 12:42:19'),
(1315, 460, NULL, 'link', NULL, '2014-12-11 12:42:19', '2014-12-11 12:42:19'),
(1316, 460, NULL, 'created_time', '2014-12-11 12:42:19', '2014-12-11 12:42:19', '2014-12-11 12:42:19'),
(1320, 462, NULL, 'user_id', '2', '2014-12-11 10:04:23', '2014-12-11 10:04:23'),
(1321, 462, NULL, 'action_id', '25', '2014-12-11 10:04:23', '2014-12-11 10:04:23'),
(1322, 462, NULL, 'title', 'Заказ №16', '2014-12-11 10:04:23', '2014-12-11 10:04:23'),
(1323, 462, NULL, 'link', NULL, '2014-12-11 10:04:23', '2014-12-11 10:04:23'),
(1324, 462, NULL, 'created_time', '2014-12-11 13:04:23', '2014-12-11 10:04:23', '2014-12-11 10:04:23'),
(1328, 464, NULL, 'user_id', '2', '2014-12-11 10:04:26', '2014-12-11 10:04:26'),
(1329, 464, NULL, 'action_id', '25', '2014-12-11 10:04:26', '2014-12-11 10:04:26'),
(1330, 464, NULL, 'title', 'Заказ №16', '2014-12-11 10:04:26', '2014-12-11 10:04:26'),
(1331, 464, NULL, 'link', NULL, '2014-12-11 10:04:26', '2014-12-11 10:04:26'),
(1332, 464, NULL, 'created_time', '2014-12-11 13:04:26', '2014-12-11 10:04:26', '2014-12-11 10:04:26'),
(1336, 466, NULL, 'user_id', '2', '2014-12-11 10:04:48', '2014-12-11 10:04:48'),
(1337, 466, NULL, 'action_id', '25', '2014-12-11 10:04:48', '2014-12-11 10:04:48'),
(1338, 466, NULL, 'title', 'Заказ №16', '2014-12-11 10:04:48', '2014-12-11 10:04:48'),
(1339, 466, NULL, 'link', NULL, '2014-12-11 10:04:48', '2014-12-11 10:04:48'),
(1340, 466, NULL, 'created_time', '2014-12-11 13:04:48', '2014-12-11 10:04:48', '2014-12-11 10:04:48'),
(1341, 467, NULL, 'user_id', '30', '2014-12-11 10:05:20', '2014-12-11 10:05:20'),
(1342, 467, NULL, 'action_id', '60', '2014-12-11 10:05:20', '2014-12-11 10:05:20'),
(1343, 467, NULL, 'created_time', '2014-12-11 13:05:20', '2014-12-11 10:05:20', '2014-12-11 10:05:20'),
(1344, 468, NULL, 'user_id', '2', '2014-12-11 10:05:20', '2014-12-11 10:05:20'),
(1345, 468, NULL, 'action_id', '25', '2014-12-11 10:05:20', '2014-12-11 10:05:20'),
(1346, 468, NULL, 'title', 'Заказ №16', '2014-12-11 10:05:20', '2014-12-11 10:05:20'),
(1347, 468, NULL, 'link', NULL, '2014-12-11 10:05:20', '2014-12-11 10:05:20'),
(1348, 468, NULL, 'created_time', '2014-12-11 13:05:20', '2014-12-11 10:05:20', '2014-12-11 10:05:20'),
(1349, 469, NULL, 'user_id', '0', '2014-12-11 10:29:30', '2014-12-11 10:29:30'),
(1350, 469, NULL, 'action_id', '61', '2014-12-11 10:29:30', '2014-12-11 10:29:30'),
(1351, 469, NULL, 'created_time', '2014-12-11 13:29:30', '2014-12-11 10:29:30', '2014-12-11 10:29:30'),
(1352, 470, NULL, 'user_id', '38', '2014-12-11 10:30:05', '2014-12-11 10:30:05'),
(1353, 470, NULL, 'action_id', '47', '2014-12-11 10:30:05', '2014-12-11 10:30:05'),
(1354, 470, NULL, 'created_time', '2014-12-11 13:30:05', '2014-12-11 10:30:05', '2014-12-11 10:30:05'),
(1355, 471, NULL, 'user_id', '38', '2014-12-11 10:30:05', '2014-12-11 10:30:05'),
(1356, 471, NULL, 'action_id', '46', '2014-12-11 10:30:05', '2014-12-11 10:30:05'),
(1357, 471, NULL, 'created_time', '2014-12-11 13:30:05', '2014-12-11 10:30:05', '2014-12-11 10:30:05'),
(1358, 472, NULL, 'user_id', '38', '2014-12-11 10:30:05', '2014-12-11 10:30:05'),
(1359, 472, NULL, 'action_id', '157', '2014-12-11 10:30:05', '2014-12-11 10:30:05'),
(1360, 472, NULL, 'created_time', '2014-12-11 13:30:05', '2014-12-11 10:30:05', '2014-12-11 10:30:05'),
(1361, 473, NULL, 'user_id', '0', '2014-12-11 10:39:21', '2014-12-11 10:39:21'),
(1362, 473, NULL, 'action_id', '63', '2014-12-11 10:39:21', '2014-12-11 10:39:21'),
(1363, 473, NULL, 'created_time', '2014-12-11 13:39:21', '2014-12-11 10:39:21', '2014-12-11 10:39:21'),
(1364, 474, NULL, 'user_id', '0', '2014-12-11 10:44:14', '2014-12-11 10:44:14'),
(1365, 474, NULL, 'action_id', '63', '2014-12-11 10:44:14', '2014-12-11 10:44:14'),
(1366, 474, NULL, 'created_time', '2014-12-11 13:44:14', '2014-12-11 10:44:14', '2014-12-11 10:44:14'),
(1367, 475, NULL, 'user_id', '38', '2014-12-11 10:54:53', '2014-12-11 10:54:53'),
(1368, 475, NULL, 'action_id', '78', '2014-12-11 10:54:53', '2014-12-11 10:54:53'),
(1369, 475, NULL, 'created_time', '2014-12-11 13:54:53', '2014-12-11 10:54:53', '2014-12-11 10:54:53'),
(1370, 476, NULL, 'user_id', '0', '2014-12-11 10:54:53', '2014-12-11 10:54:53'),
(1371, 476, NULL, 'action_id', '65', '2014-12-11 10:54:53', '2014-12-11 10:54:53'),
(1372, 476, NULL, 'created_time', '2014-12-11 13:54:53', '2014-12-11 10:54:53', '2014-12-11 10:54:53'),
(1373, 477, NULL, 'user_id', '2', '2014-12-11 11:05:47', '2014-12-11 11:05:47'),
(1374, 477, NULL, 'action_id', '2', '2014-12-11 11:05:47', '2014-12-11 11:05:47'),
(1375, 477, NULL, 'title', 'Строительство', '2014-12-11 11:05:47', '2014-12-11 11:05:47'),
(1376, 477, NULL, 'link', NULL, '2014-12-11 11:05:47', '2014-12-11 11:05:47'),
(1377, 477, NULL, 'created_time', '2014-12-11 14:05:47', '2014-12-11 11:05:48', '2014-12-11 11:05:48'),
(1378, 478, NULL, 'user_id', '2', '2014-12-11 11:06:32', '2014-12-11 11:06:32'),
(1379, 478, NULL, 'action_id', '2', '2014-12-11 11:06:32', '2014-12-11 11:06:32'),
(1380, 478, NULL, 'title', 'Строительство', '2014-12-11 11:06:32', '2014-12-11 11:06:32'),
(1381, 478, NULL, 'link', NULL, '2014-12-11 11:06:32', '2014-12-11 11:06:32'),
(1382, 478, NULL, 'created_time', '2014-12-11 14:06:32', '2014-12-11 11:06:32', '2014-12-11 11:06:32'),
(1383, 479, NULL, 'user_id', '2', '2014-12-11 11:11:47', '2014-12-11 11:11:47'),
(1384, 479, NULL, 'action_id', '2', '2014-12-11 11:11:47', '2014-12-11 11:11:47'),
(1385, 479, NULL, 'title', 'Строительство', '2014-12-11 11:11:47', '2014-12-11 11:11:47'),
(1386, 479, NULL, 'link', NULL, '2014-12-11 11:11:47', '2014-12-11 11:11:47'),
(1387, 479, NULL, 'created_time', '2014-12-11 14:11:47', '2014-12-11 11:11:47', '2014-12-11 11:11:47'),
(1388, 480, NULL, 'user_id', '2', '2014-12-11 12:49:06', '2014-12-11 12:49:06'),
(1389, 480, NULL, 'action_id', '5', '2014-12-11 12:49:06', '2014-12-11 12:49:06'),
(1390, 480, NULL, 'title', 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства', '2014-12-11 12:49:06', '2014-12-11 12:49:06'),
(1391, 480, NULL, 'link', NULL, '2014-12-11 12:49:06', '2014-12-11 12:49:06'),
(1392, 480, NULL, 'created_time', '2014-12-11 15:49:06', '2014-12-11 12:49:06', '2014-12-11 12:49:06'),
(1393, 481, NULL, 'user_id', '2', '2014-12-11 12:49:49', '2014-12-11 12:49:49'),
(1394, 481, NULL, 'action_id', '2', '2014-12-11 12:49:49', '2014-12-11 12:49:49'),
(1395, 481, NULL, 'title', 'Строительство', '2014-12-11 12:49:49', '2014-12-11 12:49:49'),
(1396, 481, NULL, 'link', NULL, '2014-12-11 12:49:49', '2014-12-11 12:49:49'),
(1397, 481, NULL, 'created_time', '2014-12-11 15:49:49', '2014-12-11 12:49:49', '2014-12-11 12:49:49'),
(1398, 482, NULL, 'user_id', '2', '2014-12-11 12:51:46', '2014-12-11 12:51:46'),
(1399, 482, NULL, 'action_id', '5', '2014-12-11 12:51:46', '2014-12-11 12:51:46'),
(1400, 482, NULL, 'title', 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства', '2014-12-11 12:51:46', '2014-12-11 12:51:46'),
(1401, 482, NULL, 'link', NULL, '2014-12-11 12:51:46', '2014-12-11 12:51:46'),
(1402, 482, NULL, 'created_time', '2014-12-11 15:51:46', '2014-12-11 12:51:46', '2014-12-11 12:51:46'),
(1403, 483, NULL, 'user_id', '2', '2014-12-11 12:52:43', '2014-12-11 12:52:43'),
(1404, 483, NULL, 'action_id', '5', '2014-12-11 12:52:43', '2014-12-11 12:52:43'),
(1405, 483, NULL, 'title', 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства', '2014-12-11 12:52:43', '2014-12-11 12:52:43'),
(1406, 483, NULL, 'link', NULL, '2014-12-11 12:52:43', '2014-12-11 12:52:43'),
(1407, 483, NULL, 'created_time', '2014-12-11 15:52:43', '2014-12-11 12:52:43', '2014-12-11 12:52:43'),
(1408, 484, NULL, 'user_id', '2', '2014-12-11 12:53:15', '2014-12-11 12:53:15'),
(1409, 484, NULL, 'action_id', '5', '2014-12-11 12:53:15', '2014-12-11 12:53:15'),
(1410, 484, NULL, 'title', 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства', '2014-12-11 12:53:15', '2014-12-11 12:53:15'),
(1411, 484, NULL, 'link', NULL, '2014-12-11 12:53:15', '2014-12-11 12:53:15'),
(1412, 484, NULL, 'created_time', '2014-12-11 15:53:15', '2014-12-11 12:53:15', '2014-12-11 12:53:15'),
(1413, 485, NULL, 'user_id', '2', '2014-12-11 12:54:19', '2014-12-11 12:54:19'),
(1414, 485, NULL, 'action_id', '5', '2014-12-11 12:54:19', '2014-12-11 12:54:19'),
(1415, 485, NULL, 'title', 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства', '2014-12-11 12:54:19', '2014-12-11 12:54:19'),
(1416, 485, NULL, 'link', NULL, '2014-12-11 12:54:19', '2014-12-11 12:54:19'),
(1417, 485, NULL, 'created_time', '2014-12-11 15:54:19', '2014-12-11 12:54:19', '2014-12-11 12:54:19'),
(1418, 31, NULL, 'property', '5', '2014-12-11 12:55:18', '2014-12-11 12:55:18'),
(1419, 32, NULL, 'property', '99', '2014-12-11 12:55:32', '2014-12-11 12:55:32'),
(1420, 486, NULL, 'user_id', '2', '2014-12-11 12:56:38', '2014-12-11 12:56:38'),
(1421, 486, NULL, 'action_id', '5', '2014-12-11 12:56:38', '2014-12-11 12:56:38'),
(1422, 486, NULL, 'title', 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства', '2014-12-11 12:56:38', '2014-12-11 12:56:38'),
(1423, 486, NULL, 'link', NULL, '2014-12-11 12:56:38', '2014-12-11 12:56:38'),
(1424, 486, NULL, 'created_time', '2014-12-11 15:56:38', '2014-12-11 12:56:38', '2014-12-11 12:56:38'),
(1425, 487, NULL, 'user_id', '15', '2014-12-11 12:56:55', '2014-12-11 12:56:55'),
(1426, 487, NULL, 'action_id', '49', '2014-12-11 12:56:55', '2014-12-11 12:56:55'),
(1427, 487, NULL, 'created_time', '2014-12-11 15:56:55', '2014-12-11 12:56:55', '2014-12-11 12:56:55'),
(1428, 488, NULL, 'user_id', '0', '2014-12-11 12:56:55', '2014-12-11 12:56:55'),
(1429, 488, NULL, 'action_id', '65', '2014-12-11 12:56:55', '2014-12-11 12:56:55'),
(1430, 488, NULL, 'created_time', '2014-12-11 15:56:55', '2014-12-11 12:56:55', '2014-12-11 12:56:55'),
(1431, 492, NULL, 'user_id', '3', '2014-12-11 16:20:38', '2014-12-11 16:20:38'),
(1432, 492, NULL, 'action_id', '53', '2014-12-11 16:20:38', '2014-12-11 16:20:38'),
(1433, 492, NULL, 'created_time', '2014-12-11 19:20:38', '2014-12-11 16:20:38', '2014-12-11 16:20:38'),
(1434, 493, NULL, 'user_id', '3', '2014-12-11 16:20:39', '2014-12-11 16:20:39'),
(1435, 493, NULL, 'action_id', '67', '2014-12-11 16:20:39', '2014-12-11 16:20:39'),
(1436, 493, NULL, 'created_time', '2014-12-11 19:20:39', '2014-12-11 16:20:40', '2014-12-11 16:20:40'),
(1437, 494, NULL, 'user_id', '3', '2014-12-11 16:20:40', '2014-12-11 16:20:40'),
(1438, 494, NULL, 'action_id', '160', '2014-12-11 16:20:40', '2014-12-11 16:20:40'),
(1439, 494, NULL, 'created_time', '2014-12-11 19:20:40', '2014-12-11 16:20:40', '2014-12-11 16:20:40'),
(1440, 495, NULL, 'user_id', '0', '2014-12-11 16:20:40', '2014-12-11 16:20:40'),
(1441, 495, NULL, 'action_id', '66', '2014-12-11 16:20:40', '2014-12-11 16:20:40'),
(1442, 495, NULL, 'created_time', '2014-12-11 19:20:40', '2014-12-11 16:20:40', '2014-12-11 16:20:40'),
(1443, 496, NULL, 'user_id', '15', '2014-12-12 08:06:34', '2014-12-12 08:06:34'),
(1444, 496, NULL, 'action_id', '59', '2014-12-12 08:06:34', '2014-12-12 08:06:34'),
(1445, 496, NULL, 'created_time', '2014-12-12 11:06:34', '2014-12-12 08:06:34', '2014-12-12 08:06:34'),
(1446, 497, NULL, 'user_id', '2', '2014-12-12 08:06:34', '2014-12-12 08:06:34'),
(1447, 497, NULL, 'action_id', '25', '2014-12-12 08:06:34', '2014-12-12 08:06:34'),
(1448, 497, NULL, 'title', 'Заказ №19', '2014-12-12 08:06:34', '2014-12-12 08:06:34'),
(1449, 497, NULL, 'link', NULL, '2014-12-12 08:06:34', '2014-12-12 08:06:34'),
(1450, 497, NULL, 'created_time', '2014-12-12 11:06:34', '2014-12-12 08:06:34', '2014-12-12 08:06:34'),
(1451, 498, NULL, 'user_id', '36', '2014-12-12 08:09:42', '2014-12-12 08:09:42'),
(1452, 498, NULL, 'action_id', '490', '2014-12-12 08:09:42', '2014-12-12 08:09:42'),
(1453, 498, NULL, 'created_time', '2014-12-12 11:09:42', '2014-12-12 08:09:42', '2014-12-12 08:09:42'),
(1454, 499, NULL, 'user_id', '15', '2014-12-12 08:09:58', '2014-12-12 08:09:58'),
(1455, 499, NULL, 'action_id', '50', '2014-12-12 08:09:58', '2014-12-12 08:09:58'),
(1456, 499, NULL, 'created_time', '2014-12-12 11:09:58', '2014-12-12 08:09:58', '2014-12-12 08:09:58'),
(1457, 500, NULL, 'user_id', '15', '2014-12-12 08:10:13', '2014-12-12 08:10:13'),
(1458, 500, NULL, 'action_id', '53', '2014-12-12 08:10:13', '2014-12-12 08:10:13'),
(1459, 500, NULL, 'created_time', '2014-12-12 11:10:13', '2014-12-12 08:10:13', '2014-12-12 08:10:13'),
(1460, 501, NULL, 'user_id', '36', '2014-12-12 08:10:13', '2014-12-12 08:10:13'),
(1461, 501, NULL, 'action_id', '491', '2014-12-12 08:10:13', '2014-12-12 08:10:13'),
(1462, 501, NULL, 'created_time', '2014-12-12 11:10:13', '2014-12-12 08:10:13', '2014-12-12 08:10:13'),
(1463, 506, NULL, 'user_id', '0', '2014-12-12 08:55:52', '2014-12-12 08:55:52'),
(1464, 506, NULL, 'action_id', '61', '2014-12-12 08:55:52', '2014-12-12 08:55:52'),
(1465, 506, NULL, 'created_time', '2014-12-12 11:55:52', '2014-12-12 08:55:52', '2014-12-12 08:55:52'),
(1466, 507, NULL, 'user_id', '41', '2014-12-12 09:02:47', '2014-12-12 09:02:47'),
(1467, 507, NULL, 'action_id', '502', '2014-12-12 09:02:47', '2014-12-12 09:02:47'),
(1468, 507, NULL, 'created_time', '2014-12-12 12:02:47', '2014-12-12 09:02:47', '2014-12-12 09:02:47'),
(1469, 508, NULL, 'user_id', '0', '2014-12-12 09:05:16', '2014-12-12 09:05:16'),
(1470, 508, NULL, 'action_id', '63', '2014-12-12 09:05:16', '2014-12-12 09:05:16'),
(1471, 508, NULL, 'created_time', '2014-12-12 12:05:16', '2014-12-12 09:05:16', '2014-12-12 09:05:16'),
(1472, 509, NULL, 'user_id', '41', '2014-12-12 09:05:40', '2014-12-12 09:05:40'),
(1473, 509, NULL, 'action_id', '78', '2014-12-12 09:05:40', '2014-12-12 09:05:40'),
(1474, 509, NULL, 'created_time', '2014-12-12 12:05:40', '2014-12-12 09:05:40', '2014-12-12 09:05:40'),
(1475, 510, NULL, 'user_id', '0', '2014-12-12 09:05:40', '2014-12-12 09:05:40'),
(1476, 510, NULL, 'action_id', '65', '2014-12-12 09:05:40', '2014-12-12 09:05:40'),
(1477, 510, NULL, 'created_time', '2014-12-12 12:05:40', '2014-12-12 09:05:40', '2014-12-12 09:05:40'),
(1478, 511, NULL, 'user_id', '42', '2014-12-12 09:06:11', '2014-12-12 09:06:11'),
(1479, 511, NULL, 'action_id', '490', '2014-12-12 09:06:11', '2014-12-12 09:06:11'),
(1480, 511, NULL, 'created_time', '2014-12-12 12:06:11', '2014-12-12 09:06:11', '2014-12-12 09:06:11'),
(1481, 512, NULL, 'user_id', '41', '2014-12-12 09:06:11', '2014-12-12 09:06:11'),
(1482, 512, NULL, 'action_id', '60', '2014-12-12 09:06:11', '2014-12-12 09:06:11'),
(1483, 512, NULL, 'created_time', '2014-12-12 12:06:11', '2014-12-12 09:06:11', '2014-12-12 09:06:11'),
(1484, 513, NULL, 'user_id', '2', '2014-12-12 09:06:11', '2014-12-12 09:06:11'),
(1485, 513, NULL, 'action_id', '22', '2014-12-12 09:06:11', '2014-12-12 09:06:11'),
(1486, 513, NULL, 'title', 'Заказ №1. Сумма: 560 руб.', '2014-12-12 09:06:11', '2014-12-12 09:06:11'),
(1487, 513, NULL, 'link', NULL, '2014-12-12 09:06:11', '2014-12-12 09:06:11'),
(1488, 513, NULL, 'created_time', '2014-12-12 12:06:11', '2014-12-12 09:06:11', '2014-12-12 09:06:11'),
(1489, 514, NULL, 'user_id', '41', '2014-12-12 09:10:55', '2014-12-12 09:10:55'),
(1490, 514, NULL, 'action_id', '50', '2014-12-12 09:10:55', '2014-12-12 09:10:55'),
(1491, 514, NULL, 'created_time', '2014-12-12 12:10:55', '2014-12-12 09:10:55', '2014-12-12 09:10:55'),
(1492, 515, NULL, 'user_id', '2', '2014-12-12 09:14:56', '2014-12-12 09:14:56'),
(1493, 515, NULL, 'action_id', '132', '2014-12-12 09:14:56', '2014-12-12 09:14:56'),
(1494, 515, NULL, 'title', '№020-14', '2014-12-12 09:14:56', '2014-12-12 09:14:56'),
(1495, 515, NULL, 'link', NULL, '2014-12-12 09:14:56', '2014-12-12 09:14:56'),
(1496, 515, NULL, 'created_time', '2014-12-12 12:14:56', '2014-12-12 09:14:56', '2014-12-12 09:14:56'),
(1497, 516, NULL, 'user_id', '41', '2014-12-12 09:15:21', '2014-12-12 09:15:21'),
(1498, 516, NULL, 'action_id', '53', '2014-12-12 09:15:21', '2014-12-12 09:15:21'),
(1499, 516, NULL, 'created_time', '2014-12-12 12:15:21', '2014-12-12 09:15:21', '2014-12-12 09:15:21'),
(1500, 517, NULL, 'user_id', '42', '2014-12-12 09:15:21', '2014-12-12 09:15:21'),
(1501, 517, NULL, 'action_id', '491', '2014-12-12 09:15:21', '2014-12-12 09:15:21'),
(1502, 517, NULL, 'created_time', '2014-12-12 12:15:21', '2014-12-12 09:15:21', '2014-12-12 09:15:21'),
(1503, 518, NULL, 'user_id', '41', '2014-12-12 09:15:22', '2014-12-12 09:15:22'),
(1504, 518, NULL, 'action_id', '504', '2014-12-12 09:15:22', '2014-12-12 09:15:22'),
(1505, 518, NULL, 'created_time', '2014-12-12 12:15:22', '2014-12-12 09:15:22', '2014-12-12 09:15:22'),
(1506, 519, NULL, 'user_id', '0', '2014-12-12 09:15:22', '2014-12-12 09:15:22'),
(1507, 519, NULL, 'action_id', '66', '2014-12-12 09:15:22', '2014-12-12 09:15:22'),
(1508, 519, NULL, 'created_time', '2014-12-12 12:15:22', '2014-12-12 09:15:22', '2014-12-12 09:15:22'),
(1509, 522, NULL, 'user_id', '0', '2014-12-15 07:46:17', '2014-12-15 07:46:17'),
(1510, 522, NULL, 'action_id', '61', '2014-12-15 07:46:17', '2014-12-15 07:46:17'),
(1511, 522, NULL, 'created_time', '2014-12-15 10:46:17', '2014-12-15 07:46:17', '2014-12-15 07:46:17'),
(1512, 523, NULL, 'user_id', '0', '2014-12-15 07:52:41', '2014-12-15 07:52:41'),
(1513, 523, NULL, 'action_id', '61', '2014-12-15 07:52:41', '2014-12-15 07:52:41'),
(1514, 523, NULL, 'created_time', '2014-12-15 10:52:41', '2014-12-15 07:52:41', '2014-12-15 07:52:41'),
(1515, 524, NULL, 'user_id', '44', '2014-12-15 07:53:25', '2014-12-15 07:53:25'),
(1516, 524, NULL, 'action_id', '502', '2014-12-15 07:53:25', '2014-12-15 07:53:25'),
(1517, 524, NULL, 'created_time', '2014-12-15 10:53:25', '2014-12-15 07:53:25', '2014-12-15 07:53:25'),
(1518, 525, NULL, 'user_id', '0', '2014-12-15 07:57:39', '2014-12-15 07:57:39'),
(1519, 525, NULL, 'action_id', '63', '2014-12-15 07:57:39', '2014-12-15 07:57:39'),
(1520, 525, NULL, 'created_time', '2014-12-15 10:57:39', '2014-12-15 07:57:39', '2014-12-15 07:57:39'),
(1521, 526, NULL, 'user_id', '45', '2014-12-15 07:58:19', '2014-12-15 07:58:19'),
(1522, 526, NULL, 'action_id', '489', '2014-12-15 07:58:19', '2014-12-15 07:58:19'),
(1523, 526, NULL, 'created_time', '2014-12-15 10:58:19', '2014-12-15 07:58:19', '2014-12-15 07:58:19'),
(1524, 527, NULL, 'user_id', '2', '2014-12-15 08:01:31', '2014-12-15 08:01:31'),
(1525, 527, NULL, 'action_id', '28', '2014-12-15 08:01:31', '2014-12-15 08:01:31'),
(1526, 527, NULL, 'title', 'ООО ""Рога и копыта', '2014-12-15 08:01:31', '2014-12-15 08:01:31'),
(1527, 527, NULL, 'link', NULL, '2014-12-15 08:01:31', '2014-12-15 08:01:31'),
(1528, 527, NULL, 'created_time', '2014-12-15 11:01:31', '2014-12-15 08:01:31', '2014-12-15 08:01:31'),
(1529, 528, NULL, 'user_id', '44', '2014-12-15 08:01:31', '2014-12-15 08:01:31'),
(1530, 528, NULL, 'action_id', '159', '2014-12-15 08:01:31', '2014-12-15 08:01:31'),
(1531, 528, NULL, 'created_time', '2014-12-15 11:01:31', '2014-12-15 08:01:31', '2014-12-15 08:01:31'),
(1532, 529, NULL, 'user_id', '2', '2014-12-15 08:01:31', '2014-12-15 08:01:31'),
(1533, 529, NULL, 'action_id', '26', '2014-12-15 08:01:31', '2014-12-15 08:01:31'),
(1534, 529, NULL, 'title', 'Организация: ООО ""Рога и копыта', '2014-12-15 08:01:31', '2014-12-15 08:01:31'),
(1535, 529, NULL, 'link', NULL, '2014-12-15 08:01:31', '2014-12-15 08:01:31'),
(1536, 529, NULL, 'created_time', '2014-12-15 11:01:31', '2014-12-15 08:01:31', '2014-12-15 08:01:31'),
(1537, 530, NULL, 'user_id', '0', '2014-12-15 08:03:44', '2014-12-15 08:03:44'),
(1538, 530, NULL, 'action_id', '63', '2014-12-15 08:03:44', '2014-12-15 08:03:44'),
(1539, 530, NULL, 'created_time', '2014-12-15 11:03:44', '2014-12-15 08:03:44', '2014-12-15 08:03:44'),
(1540, 531, NULL, 'user_id', '46', '2014-12-15 08:05:08', '2014-12-15 08:05:08'),
(1541, 531, NULL, 'action_id', '489', '2014-12-15 08:05:08', '2014-12-15 08:05:08'),
(1542, 531, NULL, 'created_time', '2014-12-15 11:05:08', '2014-12-15 08:05:08', '2014-12-15 08:05:08'),
(1543, 532, NULL, 'user_id', '0', '2014-12-15 08:12:03', '2014-12-15 08:12:03'),
(1544, 532, NULL, 'action_id', '63', '2014-12-15 08:12:03', '2014-12-15 08:12:03'),
(1545, 532, NULL, 'created_time', '2014-12-15 11:12:03', '2014-12-15 08:12:03', '2014-12-15 08:12:03'),
(1546, 533, NULL, 'user_id', '44', '2014-12-15 08:12:35', '2014-12-15 08:12:35'),
(1547, 533, NULL, 'action_id', '49', '2014-12-15 08:12:35', '2014-12-15 08:12:35'),
(1548, 533, NULL, 'created_time', '2014-12-15 11:12:35', '2014-12-15 08:12:35', '2014-12-15 08:12:35'),
(1549, 534, NULL, 'user_id', '0', '2014-12-15 08:12:35', '2014-12-15 08:12:35'),
(1550, 534, NULL, 'action_id', '65', '2014-12-15 08:12:35', '2014-12-15 08:12:35'),
(1551, 534, NULL, 'created_time', '2014-12-15 11:12:35', '2014-12-15 08:12:35', '2014-12-15 08:12:35'),
(1552, 535, NULL, 'user_id', '47', '2014-12-15 08:16:40', '2014-12-15 08:16:40'),
(1553, 535, NULL, 'action_id', '490', '2014-12-15 08:16:40', '2014-12-15 08:16:40'),
(1554, 535, NULL, 'created_time', '2014-12-15 11:16:40', '2014-12-15 08:16:40', '2014-12-15 08:16:40'),
(1555, 536, NULL, 'user_id', '46', '2014-12-15 08:16:41', '2014-12-15 08:16:41'),
(1556, 536, NULL, 'action_id', '490', '2014-12-15 08:16:41', '2014-12-15 08:16:41'),
(1557, 536, NULL, 'created_time', '2014-12-15 11:16:41', '2014-12-15 08:16:41', '2014-12-15 08:16:41'),
(1558, 537, NULL, 'user_id', '45', '2014-12-15 08:16:42', '2014-12-15 08:16:42'),
(1559, 537, NULL, 'action_id', '490', '2014-12-15 08:16:42', '2014-12-15 08:16:42'),
(1560, 537, NULL, 'created_time', '2014-12-15 11:16:42', '2014-12-15 08:16:42', '2014-12-15 08:16:42'),
(1561, 538, NULL, 'user_id', '45', '2014-12-15 08:16:43', '2014-12-15 08:16:43'),
(1562, 538, NULL, 'action_id', '490', '2014-12-15 08:16:43', '2014-12-15 08:16:43'),
(1563, 538, NULL, 'created_time', '2014-12-15 11:16:43', '2014-12-15 08:16:43', '2014-12-15 08:16:43'),
(1564, 539, NULL, 'user_id', '46', '2014-12-15 08:16:44', '2014-12-15 08:16:44'),
(1565, 539, NULL, 'action_id', '490', '2014-12-15 08:16:44', '2014-12-15 08:16:44'),
(1566, 539, NULL, 'created_time', '2014-12-15 11:16:44', '2014-12-15 08:16:44', '2014-12-15 08:16:44'),
(1567, 540, NULL, 'user_id', '46', '2014-12-15 08:16:46', '2014-12-15 08:16:46'),
(1568, 540, NULL, 'action_id', '490', '2014-12-15 08:16:46', '2014-12-15 08:16:46'),
(1569, 540, NULL, 'created_time', '2014-12-15 11:16:46', '2014-12-15 08:16:46', '2014-12-15 08:16:46'),
(1570, 541, NULL, 'user_id', '47', '2014-12-15 08:16:51', '2014-12-15 08:16:51'),
(1571, 542, NULL, 'user_id', '46', '2014-12-15 08:16:51', '2014-12-15 08:16:51'),
(1572, 541, NULL, 'action_id', '490', '2014-12-15 08:16:51', '2014-12-15 08:16:51'),
(1573, 542, NULL, 'action_id', '490', '2014-12-15 08:16:51', '2014-12-15 08:16:51'),
(1574, 542, NULL, 'created_time', '2014-12-15 11:16:51', '2014-12-15 08:16:51', '2014-12-15 08:16:51'),
(1575, 541, NULL, 'created_time', '2014-12-15 11:16:51', '2014-12-15 08:16:51', '2014-12-15 08:16:51'),
(1576, 543, NULL, 'user_id', '45', '2014-12-15 08:16:51', '2014-12-15 08:16:51'),
(1577, 543, NULL, 'action_id', '490', '2014-12-15 08:16:51', '2014-12-15 08:16:51'),
(1578, 543, NULL, 'created_time', '2014-12-15 11:16:51', '2014-12-15 08:16:51', '2014-12-15 08:16:51'),
(1579, 544, NULL, 'user_id', '45', '2014-12-15 08:16:52', '2014-12-15 08:16:52'),
(1580, 545, NULL, 'user_id', '46', '2014-12-15 08:16:52', '2014-12-15 08:16:52'),
(1581, 544, NULL, 'action_id', '490', '2014-12-15 08:16:52', '2014-12-15 08:16:52'),
(1582, 545, NULL, 'action_id', '490', '2014-12-15 08:16:52', '2014-12-15 08:16:52'),
(1583, 545, NULL, 'created_time', '2014-12-15 11:16:52', '2014-12-15 08:16:52', '2014-12-15 08:16:52'),
(1584, 544, NULL, 'created_time', '2014-12-15 11:16:51', '2014-12-15 08:16:52', '2014-12-15 08:16:52'),
(1585, 546, NULL, 'user_id', '46', '2014-12-15 08:16:52', '2014-12-15 08:16:52'),
(1586, 546, NULL, 'action_id', '490', '2014-12-15 08:16:52', '2014-12-15 08:16:52'),
(1587, 546, NULL, 'created_time', '2014-12-15 11:16:52', '2014-12-15 08:16:52', '2014-12-15 08:16:52'),
(1588, 547, NULL, 'user_id', '44', '2014-12-15 08:16:56', '2014-12-15 08:16:56'),
(1589, 547, NULL, 'action_id', '60', '2014-12-15 08:16:56', '2014-12-15 08:16:56'),
(1590, 547, NULL, 'created_time', '2014-12-15 11:16:56', '2014-12-15 08:16:56', '2014-12-15 08:16:56'),
(1591, 548, NULL, 'user_id', '2', '2014-12-15 08:16:56', '2014-12-15 08:16:56'),
(1592, 548, NULL, 'action_id', '25', '2014-12-15 08:16:56', '2014-12-15 08:16:56'),
(1593, 548, NULL, 'title', 'Заказ №21', '2014-12-15 08:16:56', '2014-12-15 08:16:56'),
(1594, 548, NULL, 'link', NULL, '2014-12-15 08:16:56', '2014-12-15 08:16:56'),
(1595, 548, NULL, 'created_time', '2014-12-15 11:16:56', '2014-12-15 08:16:56', '2014-12-15 08:16:56'),
(1596, 549, NULL, 'user_id', '46', '2014-12-15 08:17:12', '2014-12-15 08:17:12'),
(1597, 549, NULL, 'action_id', '490', '2014-12-15 08:17:12', '2014-12-15 08:17:12'),
(1598, 549, NULL, 'created_time', '2014-12-15 11:17:12', '2014-12-15 08:17:12', '2014-12-15 08:17:12'),
(1599, 550, NULL, 'user_id', '47', '2014-12-15 08:17:12', '2014-12-15 08:17:12'),
(1600, 550, NULL, 'action_id', '490', '2014-12-15 08:17:12', '2014-12-15 08:17:12'),
(1601, 550, NULL, 'created_time', '2014-12-15 11:17:12', '2014-12-15 08:17:12', '2014-12-15 08:17:12'),
(1602, 551, NULL, 'user_id', '45', '2014-12-15 08:17:12', '2014-12-15 08:17:12'),
(1603, 551, NULL, 'action_id', '490', '2014-12-15 08:17:12', '2014-12-15 08:17:12'),
(1604, 551, NULL, 'created_time', '2014-12-15 11:17:12', '2014-12-15 08:17:12', '2014-12-15 08:17:12'),
(1605, 552, NULL, 'user_id', '46', '2014-12-15 08:17:12', '2014-12-15 08:17:12'),
(1606, 552, NULL, 'action_id', '490', '2014-12-15 08:17:12', '2014-12-15 08:17:12'),
(1607, 552, NULL, 'created_time', '2014-12-15 11:17:12', '2014-12-15 08:17:12', '2014-12-15 08:17:12'),
(1608, 553, NULL, 'user_id', '45', '2014-12-15 08:17:12', '2014-12-15 08:17:12'),
(1609, 553, NULL, 'action_id', '490', '2014-12-15 08:17:12', '2014-12-15 08:17:12'),
(1610, 553, NULL, 'created_time', '2014-12-15 11:17:12', '2014-12-15 08:17:12', '2014-12-15 08:17:12'),
(1611, 554, NULL, 'user_id', '46', '2014-12-15 08:17:12', '2014-12-15 08:17:12'),
(1612, 554, NULL, 'action_id', '490', '2014-12-15 08:17:12', '2014-12-15 08:17:12'),
(1613, 554, NULL, 'created_time', '2014-12-15 11:17:12', '2014-12-15 08:17:12', '2014-12-15 08:17:12'),
(1614, 555, NULL, 'user_id', '44', '2014-12-15 08:17:12', '2014-12-15 08:17:12'),
(1615, 555, NULL, 'action_id', '60', '2014-12-15 08:17:12', '2014-12-15 08:17:12'),
(1616, 555, NULL, 'created_time', '2014-12-15 11:17:12', '2014-12-15 08:17:12', '2014-12-15 08:17:12'),
(1617, 556, NULL, 'user_id', '2', '2014-12-15 08:17:12', '2014-12-15 08:17:12'),
(1618, 556, NULL, 'action_id', '22', '2014-12-15 08:17:12', '2014-12-15 08:17:12'),
(1619, 556, NULL, 'title', 'Заказ №1. Сумма: 240 руб.', '2014-12-15 08:17:12', '2014-12-15 08:17:12'),
(1620, 556, NULL, 'link', NULL, '2014-12-15 08:17:12', '2014-12-15 08:17:12'),
(1621, 556, NULL, 'created_time', '2014-12-15 11:17:12', '2014-12-15 08:17:12', '2014-12-15 08:17:12'),
(1622, 557, NULL, 'user_id', '45', '2014-12-15 08:22:33', '2014-12-15 08:22:33'),
(1623, 558, NULL, 'user_id', '46', '2014-12-15 08:22:33', '2014-12-15 08:22:33'),
(1624, 557, NULL, 'action_id', '490', '2014-12-15 08:22:33', '2014-12-15 08:22:33'),
(1625, 558, NULL, 'action_id', '490', '2014-12-15 08:22:33', '2014-12-15 08:22:33'),
(1626, 559, NULL, 'user_id', '47', '2014-12-15 08:22:33', '2014-12-15 08:22:33'),
(1627, 557, NULL, 'created_time', '2014-12-15 11:22:33', '2014-12-15 08:22:33', '2014-12-15 08:22:33'),
(1628, 559, NULL, 'action_id', '490', '2014-12-15 08:22:33', '2014-12-15 08:22:33'),
(1629, 558, NULL, 'created_time', '2014-12-15 11:22:33', '2014-12-15 08:22:33', '2014-12-15 08:22:33'),
(1630, 561, NULL, 'user_id', '46', '2014-12-15 08:22:33', '2014-12-15 08:22:33'),
(1631, 559, NULL, 'created_time', '2014-12-15 11:22:33', '2014-12-15 08:22:33', '2014-12-15 08:22:33'),
(1632, 561, NULL, 'action_id', '490', '2014-12-15 08:22:33', '2014-12-15 08:22:33'),
(1633, 560, NULL, 'user_id', '46', '2014-12-15 08:22:33', '2014-12-15 08:22:33'),
(1634, 561, NULL, 'created_time', '2014-12-15 11:22:33', '2014-12-15 08:22:33', '2014-12-15 08:22:33'),
(1635, 560, NULL, 'action_id', '490', '2014-12-15 08:22:33', '2014-12-15 08:22:33'),
(1636, 560, NULL, 'created_time', '2014-12-15 11:22:33', '2014-12-15 08:22:33', '2014-12-15 08:22:33'),
(1637, 562, NULL, 'user_id', '45', '2014-12-15 08:22:33', '2014-12-15 08:22:33'),
(1638, 562, NULL, 'action_id', '490', '2014-12-15 08:22:33', '2014-12-15 08:22:33'),
(1639, 562, NULL, 'created_time', '2014-12-15 11:22:33', '2014-12-15 08:22:33', '2014-12-15 08:22:33'),
(1640, 563, NULL, 'user_id', '44', '2014-12-15 08:22:54', '2014-12-15 08:22:54'),
(1641, 563, NULL, 'action_id', '50', '2014-12-15 08:22:54', '2014-12-15 08:22:54'),
(1642, 563, NULL, 'created_time', '2014-12-15 11:22:54', '2014-12-15 08:22:54', '2014-12-15 08:22:54'),
(1643, 564, NULL, 'user_id', '44', '2014-12-15 08:23:38', '2014-12-15 08:23:38'),
(1644, 564, NULL, 'action_id', '50', '2014-12-15 08:23:38', '2014-12-15 08:23:38'),
(1645, 564, NULL, 'created_time', '2014-12-15 11:23:38', '2014-12-15 08:23:38', '2014-12-15 08:23:38'),
(1646, 565, NULL, 'user_id', '44', '2014-12-15 08:29:59', '2014-12-15 08:29:59'),
(1647, 565, NULL, 'action_id', '59', '2014-12-15 08:29:59', '2014-12-15 08:29:59'),
(1648, 565, NULL, 'created_time', '2014-12-15 11:29:59', '2014-12-15 08:29:59', '2014-12-15 08:29:59'),
(1649, 566, NULL, 'user_id', '2', '2014-12-15 08:29:59', '2014-12-15 08:29:59'),
(1650, 566, NULL, 'action_id', '25', '2014-12-15 08:29:59', '2014-12-15 08:29:59'),
(1651, 566, NULL, 'title', 'Заказ №21', '2014-12-15 08:29:59', '2014-12-15 08:29:59'),
(1652, 566, NULL, 'link', NULL, '2014-12-15 08:29:59', '2014-12-15 08:29:59'),
(1653, 566, NULL, 'created_time', '2014-12-15 11:29:59', '2014-12-15 08:29:59', '2014-12-15 08:29:59'),
(1654, 567, NULL, 'user_id', '44', '2014-12-15 08:30:32', '2014-12-15 08:30:32'),
(1655, 567, NULL, 'action_id', '57', '2014-12-15 08:30:32', '2014-12-15 08:30:32'),
(1656, 567, NULL, 'created_time', '2014-12-15 11:30:32', '2014-12-15 08:30:32', '2014-12-15 08:30:32'),
(1657, 568, NULL, 'user_id', '2', '2014-12-15 08:30:32', '2014-12-15 08:30:32'),
(1658, 568, NULL, 'action_id', '25', '2014-12-15 08:30:32', '2014-12-15 08:30:32'),
(1659, 568, NULL, 'title', 'Заказ №21', '2014-12-15 08:30:32', '2014-12-15 08:30:32'),
(1660, 568, NULL, 'link', NULL, '2014-12-15 08:30:32', '2014-12-15 08:30:32'),
(1661, 568, NULL, 'created_time', '2014-12-15 11:30:32', '2014-12-15 08:30:32', '2014-12-15 08:30:32'),
(1662, 570, NULL, 'user_id', '45', '2014-12-15 08:30:44', '2014-12-15 08:30:44'),
(1663, 569, NULL, 'user_id', '46', '2014-12-15 08:30:44', '2014-12-15 08:30:44'),
(1664, 570, NULL, 'action_id', '490', '2014-12-15 08:30:44', '2014-12-15 08:30:44'),
(1665, 569, NULL, 'action_id', '490', '2014-12-15 08:30:44', '2014-12-15 08:30:44'),
(1666, 572, NULL, 'user_id', '47', '2014-12-15 08:30:44', '2014-12-15 08:30:44'),
(1667, 571, NULL, 'user_id', '46', '2014-12-15 08:30:44', '2014-12-15 08:30:44'),
(1668, 570, NULL, 'created_time', '2014-12-15 11:30:44', '2014-12-15 08:30:44', '2014-12-15 08:30:44'),
(1669, 573, NULL, 'user_id', '45', '2014-12-15 08:30:44', '2014-12-15 08:30:44'),
(1670, 572, NULL, 'action_id', '490', '2014-12-15 08:30:44', '2014-12-15 08:30:44'),
(1671, 569, NULL, 'created_time', '2014-12-15 11:30:44', '2014-12-15 08:30:44', '2014-12-15 08:30:44'),
(1672, 571, NULL, 'action_id', '490', '2014-12-15 08:30:44', '2014-12-15 08:30:44'),
(1673, 573, NULL, 'action_id', '490', '2014-12-15 08:30:44', '2014-12-15 08:30:44'),
(1674, 572, NULL, 'created_time', '2014-12-15 11:30:44', '2014-12-15 08:30:44', '2014-12-15 08:30:44'),
(1675, 571, NULL, 'created_time', '2014-12-15 11:30:44', '2014-12-15 08:30:44', '2014-12-15 08:30:44'),
(1676, 573, NULL, 'created_time', '2014-12-15 11:30:44', '2014-12-15 08:30:44', '2014-12-15 08:30:44'),
(1677, 574, NULL, 'user_id', '46', '2014-12-15 08:30:44', '2014-12-15 08:30:44'),
(1678, 574, NULL, 'action_id', '490', '2014-12-15 08:30:44', '2014-12-15 08:30:44'),
(1679, 574, NULL, 'created_time', '2014-12-15 11:30:44', '2014-12-15 08:30:44', '2014-12-15 08:30:44'),
(1680, 575, NULL, 'user_id', '44', '2014-12-15 08:32:04', '2014-12-15 08:32:04'),
(1681, 575, NULL, 'action_id', '49', '2014-12-15 08:32:04', '2014-12-15 08:32:04'),
(1682, 575, NULL, 'created_time', '2014-12-15 11:32:03', '2014-12-15 08:32:04', '2014-12-15 08:32:04'),
(1683, 576, NULL, 'user_id', '0', '2014-12-15 08:32:04', '2014-12-15 08:32:04'),
(1684, 576, NULL, 'action_id', '65', '2014-12-15 08:32:04', '2014-12-15 08:32:04'),
(1685, 576, NULL, 'created_time', '2014-12-15 11:32:04', '2014-12-15 08:32:04', '2014-12-15 08:32:04'),
(1686, 577, NULL, 'user_id', '45', '2014-12-15 08:32:40', '2014-12-15 08:32:40'),
(1687, 577, NULL, 'action_id', '490', '2014-12-15 08:32:40', '2014-12-15 08:32:40'),
(1688, 577, NULL, 'created_time', '2014-12-15 11:32:40', '2014-12-15 08:32:40', '2014-12-15 08:32:40'),
(1689, 578, NULL, 'user_id', '44', '2014-12-15 08:33:06', '2014-12-15 08:33:06'),
(1690, 578, NULL, 'action_id', '59', '2014-12-15 08:33:06', '2014-12-15 08:33:06'),
(1691, 578, NULL, 'created_time', '2014-12-15 11:33:06', '2014-12-15 08:33:06', '2014-12-15 08:33:06'),
(1692, 579, NULL, 'user_id', '2', '2014-12-15 08:33:06', '2014-12-15 08:33:06'),
(1693, 579, NULL, 'action_id', '25', '2014-12-15 08:33:06', '2014-12-15 08:33:06'),
(1694, 579, NULL, 'title', 'Заказ №22', '2014-12-15 08:33:06', '2014-12-15 08:33:06'),
(1695, 579, NULL, 'link', NULL, '2014-12-15 08:33:06', '2014-12-15 08:33:06'),
(1696, 579, NULL, 'created_time', '2014-12-15 11:33:06', '2014-12-15 08:33:06', '2014-12-15 08:33:06'),
(1697, 580, NULL, 'user_id', '45', '2014-12-15 08:34:22', '2014-12-15 08:34:22'),
(1698, 580, NULL, 'action_id', '490', '2014-12-15 08:34:22', '2014-12-15 08:34:22'),
(1699, 580, NULL, 'created_time', '2014-12-15 11:34:22', '2014-12-15 08:34:22', '2014-12-15 08:34:22'),
(1700, 581, NULL, 'user_id', '2', '2014-12-15 08:42:40', '2014-12-15 08:42:40'),
(1701, 581, NULL, 'action_id', '13', '2014-12-15 08:42:40', '2014-12-15 08:42:40'),
(1702, 581, NULL, 'title', 'Промежуточное тестирование. Курс: Строительство, реконструкция, капитальный ремонт объектов капитального строительства (выполнение монтажных и пусконаладочных работ)', '2014-12-15 08:42:40', '2014-12-15 08:42:40'),
(1703, 581, NULL, 'link', NULL, '2014-12-15 08:42:40', '2014-12-15 08:42:40'),
(1704, 581, NULL, 'created_time', '2014-12-15 11:42:40', '2014-12-15 08:42:40', '2014-12-15 08:42:40'),
(1705, 582, NULL, 'user_id', '44', '2014-12-15 08:43:34', '2014-12-15 08:43:34'),
(1706, 582, NULL, 'action_id', '214', '2014-12-15 08:43:34', '2014-12-15 08:43:34'),
(1707, 582, NULL, 'created_time', '2014-12-15 11:43:34', '2014-12-15 08:43:34', '2014-12-15 08:43:34'),
(1708, 583, NULL, 'user_id', '44', '2014-12-15 08:44:14', '2014-12-15 08:44:14'),
(1709, 583, NULL, 'action_id', '51', '2014-12-15 08:44:14', '2014-12-15 08:44:14'),
(1710, 583, NULL, 'created_time', '2014-12-15 11:44:14', '2014-12-15 08:44:14', '2014-12-15 08:44:14'),
(1729, 597, NULL, 'user_id', '2', '2014-12-17 08:44:39', '2014-12-17 08:44:39'),
(1730, 597, NULL, 'action_id', '21', '2014-12-17 08:44:39', '2014-12-17 08:44:39'),
(1731, 597, NULL, 'title', 'Событие за 17.12.2014 в 11:44', '2014-12-17 08:44:39', '2014-12-17 08:44:39'),
(1732, 597, NULL, 'link', NULL, '2014-12-17 08:44:39', '2014-12-17 08:44:39'),
(1733, 597, NULL, 'created_time', '2014-12-17 11:44:39', '2014-12-17 08:44:39', '2014-12-17 08:44:39'),
(1737, 599, NULL, 'user_id', '2', '2014-12-17 08:46:07', '2014-12-17 08:46:07'),
(1738, 599, NULL, 'action_id', '21', '2014-12-17 08:46:07', '2014-12-17 08:46:07'),
(1739, 599, NULL, 'title', 'Событие за 17.12.2014 в 11:46', '2014-12-17 08:46:07', '2014-12-17 08:46:07'),
(1740, 599, NULL, 'link', NULL, '2014-12-17 08:46:07', '2014-12-17 08:46:07'),
(1741, 599, NULL, 'created_time', '2014-12-17 11:46:07', '2014-12-17 08:46:07', '2014-12-17 08:46:07'),
(1745, 601, NULL, 'user_id', '2', '2014-12-17 08:46:13', '2014-12-17 08:46:13'),
(1746, 601, NULL, 'action_id', '21', '2014-12-17 08:46:13', '2014-12-17 08:46:13'),
(1747, 601, NULL, 'title', 'Событие за 17.12.2014 в 11:46', '2014-12-17 08:46:13', '2014-12-17 08:46:13'),
(1748, 601, NULL, 'link', NULL, '2014-12-17 08:46:13', '2014-12-17 08:46:13'),
(1749, 601, NULL, 'created_time', '2014-12-17 11:46:13', '2014-12-17 08:46:13', '2014-12-17 08:46:13'),
(1750, 595, NULL, 'variables', '', '2014-12-17 08:56:52', '2014-12-17 08:56:52');
INSERT INTO `dictionary_fields_values` (`id`, `dicval_id`, `language`, `key`, `value`, `created_at`, `updated_at`) VALUES
(1751, 595, NULL, 'content', '<p align="center">\r\n	 <strong>Договор №{{ @$NomerZakaza }} ЭПК</strong>\r\n</p>\r\n<p align="center">\r\n	 <strong>на оказание платных образовательных услуг</strong>\r\n</p>\r\n<p>\r\n	             г. Ростов-на-Дону\r\n</p>\r\n<p style="text-align: right;">\r\n	            {{ @$DataOformleniyaZakazaSlovami }}\r\n</p>\r\n<p>\r\n	   Автономная некоммерческая организация дополнительного профессионального образования «Центр качества строительства» (далее – АНО ДПО «ЦКС»), именуемая в дальнейшем Исполнитель, в лице руководителя Шумеева Павла Андреевича, действующего на основании Устава, с одной стороны, и {{ @$FIOIndividualnogoSlushatelya }}, именуемый(ая) в дальнейшем Заказчик (Слушатель), в лице {{ @$FIOIndividualnogoSlushatelyaVRoditelnomPadije }}, действующего(ей) на основании паспорта, с другой стороны, вместе именуемые Стороны, заключили настоящий договор (далее - Договор) о нижеследующем:\r\n</p>\r\n<p align="center">\r\n	 <strong> </strong>\r\n</p>\r\n<p align="center">\r\n	 <strong>1. </strong><strong>Предмет договора</strong>\r\n</p>\r\n<p>\r\n	                          1.1. Исполнитель обязуется предоставить сотрудникам Заказчика (далее – Слушатели) платные образовательные услуги по повышению квалификации в соответствии с утвержденными дополнительными профессиональными программами (далее – ДПП) согласно Приложению №1 (далее – прил. №1), а Заказчик обязуется оплатить данные образовательные услуги.\r\n</p>\r\n<p>\r\n	                          1.2. Повышение квалификации слушателей проводится на основании лицензии на осуществление образовательной деятельности, выданной Региональной службой по надзору и контролю в сфере образования Ростовской области 18.11.2014, серия 61Л01 № 0001674, рег. № 4097.\r\n</p>\r\n<p>\r\n	                          1.3. Общий объем ДПП – 72 часа.\r\n</p>\r\n<p>\r\n	                          1.4. Срок освоения ДПП – 9 дней.\r\n</p>\r\n<p>\r\n	                          1.5. Форма обучения – заочная.\r\n</p>\r\n<p>\r\n	                          1.6. По результатам обучения (при условии успешного освоения ДПП) Исполнитель выдает каждому Слушателю удостоверение о повышении квалификации установленного образца по соответствующей ДПП, указанной в прил. №1.\r\n</p>\r\n<p align="center">\r\n	<strong>2. Права и обязанности Исполнителя, Заказчика и Слушателя</strong>\r\n</p>\r\n<p>\r\n	                    2.1. Права и обязанности Исполнителя.\r\n</p>\r\n<p>\r\n	                    2.1.1. Исполнитель самостоятельно осуществляет образовательный процесс, выбирает системы оценок, формы, порядок и периодичность аттестации Слушателей.\r\n</p>\r\n<p>\r\n	                    2.1.2. Исполнитель имеет право потребовать от Заказчика в письменном виде информацию и разъяснения по любому вопросу, связанному с выполнением         обязательств Исполнителя по договору.\r\n</p>\r\n<p>\r\n	                    2.1.3. Исполнитель обязан обеспечить Заказчику оказание платных образовательных услуг в полном объеме в соответствии с образовательными программами,         утвержденными Исполнителем, и условиями договора.\r\n</p>\r\n<p>\r\n	                    2.1.4. Исполнитель обеспечивает Слушателя учебно-методическими материалами в электронной форме по соответствующей ДПП согласно прил. №1.\r\n</p>\r\n<p>\r\n	                    2.1.5. Исполнитель обязан довести до Заказчика информацию, содержащую сведения о предоставлении платных образовательных услуг в порядке и объеме,         которые предусмотрены Законом Российской Федерации «О защите прав потребителей» и Федеральным законом «Об образовании в Российской Федерации».\r\n</p>\r\n<p>\r\n	                    2.2. Права и обязанности Заказчика.\r\n</p>\r\n<p>\r\n	                    2.2.1. При нарушении Исполнителем сроков оказания платных образовательных услуг (сроков начала и (или) окончания оказания платных образовательных услуг         и (или) промежуточных сроков оказания платной образовательной услуги) Заказчик вправе по своему выбору:\r\n</p>\r\n<p>\r\n	                    - назначить исполнителю новый срок, в течение которого исполнитель должен приступить к оказанию платных образовательных услуг и (или) закончить         оказание платных образовательных услуг;\r\n</p>\r\n<p>\r\n	                    - потребовать уменьшения стоимости платных образовательных услуг.\r\n</p>\r\n<p>\r\n	                    2.2.2. Заказчик обязан оплатить услуги Исполнителя в размере и сроки, предусмотренные условиями договора.\r\n</p>\r\n<p>\r\n	                    2.2.3. Заказчик обязан соблюдать установленный Исполнителем порядок обучения (повышения квалификации).\r\n</p>\r\n<p>\r\n	                    2.2.4. Заказчик обязан в 3-дневный срок с момента получения от Исполнителя запроса предоставлять информацию и разъяснения по любому вопросу, связанному         с выполнением обязательств Исполнителя по договору.\r\n</p>\r\n<p>\r\n	                    2.2.5. Заказчик обязан контролировать освоение Слушателем ДПП в полном объеме (72 часа), а также прохождение слушателем промежуточной и итоговой         аттестаций.\r\n</p>\r\n<p>\r\n	                    2.3. Права и обязанности Слушателя.\r\n</p>\r\n<p>\r\n	                    2.3.1. Слушатель имеет право на бесплатное пользование электронными фондами библиотеки АНО ДПО «ЦКС».\r\n</p>\r\n<p>\r\n	                    2.3.2. Слушатель имеет право своевременно получать информацию об образовательном процессе в необходимом объеме, установленном законодательством.\r\n</p>\r\n<p>\r\n	                    2.3.3. Слушатель имеет право на объективную оценку в соответствии со своими знаниями, умением и навыками.\r\n</p>\r\n<p>\r\n	                    2.3.4. Слушатель имеет право на получение соответствующих документов об уровне образования после итоговой аттестации.\r\n</p>\r\n<p>\r\n	                    2.3.5. Слушатель обязан соблюдать установленный Исполнителем порядок обучения (повышения квалификации), а также порядки и положения, установленные         Исполнителем иными локальными актами.\r\n</p>\r\n<p>\r\n	                    2.3.6. Слушатель обязан выполнять в установленные сроки все виды заданий, предусмотренные программой, в том числе выполнять задания для самостоятельной         подготовки, самостоятельно проходить промежуточную и итоговую аттестацию.\r\n</p>\r\n<p align="center">\r\n	 <strong>3.Стоимость образовательных услуг и порядок оплаты</strong>\r\n</p>\r\n<p>\r\n	                  3.1. За оказание образовательных услуг по повышению квалификации Заказчик оплачивает Исполнителю сумму в размере 10 000 рублей (Десять тысяч рублей) за         1 (одного) слушателя. НДС не облагается на основании п.2 ст.346.11 НК РФ. Стоимость установлена в соответствии с условиями Акции*.\r\n</p>\r\n<p>\r\n	                  3.2. Оплата образовательных услуг в размере, указанном в п.3.1 Договора, осуществляется в течении 3 (трех) банковских дней с момента подписания         Договора.\r\n</p>\r\n<p align="center">\r\n	 <strong>4. </strong><strong>Порядок изменения и расторжения договора</strong><strong></strong>\r\n</p>\r\n<p>\r\n	                  4.1. Условия, на которых заключен настоящий договор, могут быть изменены либо по соглашению сторон, либо в соответствии с действующим законодательством         Российской Федерации. Все изменения оформляются в письменном виде путем подписания Сторонами дополнительных соглашений к настоящему договору. Все         приложения и дополнительные соглашения являются неотъемлемой частью договора. Дополнительные соглашения к настоящему договору вступают в силу с момента         их подписания Сторонами.\r\n</p>\r\n<p>\r\n	                  4.2. Настоящий договор может быть расторгнут по обоюдному соглашению сторон.\r\n</p>\r\n<p>\r\n	                  4.3. Заказчик вправе в одностороннем порядке отказаться от исполнения настоящего договора, предупредив об этом Исполнителя в письменной форме. В случае         отказа Заказчика от исполнения договора до начала обучения (повышения квалификации), уплаченная сумма возвращается ему в полном размере. В случае         отказа Заказчика от выполнения настоящего договора после начала обучения (повышения квалификации), а также в случае не сдачи итоговой аттестации         (тестирования) Слушателями, уплаченная сумма не возвращается.\r\n</p>\r\n<p>\r\n	                  4.4. При нарушении Исполнителем сроков оказания платных образовательных услуг (сроков начала и (или) окончания оказания платных образовательных услуг и         (или) промежуточных сроков оказания платной образовательной услуги) Заказчик вправе в одностороннем порядке расторгнуть договор.\r\n</p>\r\n<p>\r\n	                  4.5. Исполнитель имеет право расторгнуть договор в одностороннем порядке в следующих случаях:\r\n</p>\r\n<p>\r\n	                  - применение к Слушателю отчисления как меры дисциплинарного взыскания;\r\n</p>\r\n<p>\r\n	                  - невыполнение Слушателем обязанностей по добросовестному освоению ДПП и выполнению учебного плана;\r\n</p>\r\n<p>\r\n	                  - установление нарушения порядка приема Слушателя в АНО ДПО «ЦКС», повлекшего по вине Слушателя его незаконное зачисление в АНО ДПО «ЦКС»;\r\n</p>\r\n<p>\r\n	                  - просрочка оплаты стоимости платных образовательных услуг;\r\n</p>\r\n<p>\r\n	                  - невозможность надлежащего исполнения обязательств по оказанию платных образовательных услуг вследствие действий (бездействия) Слушателя.\r\n</p>\r\n<p align="center">\r\n	 <strong>5. </strong><strong>Ответственность </strong><strong>Исполнителя, Заказчика и Слушателя</strong>\r\n</p>\r\n<p>\r\n	                  5.1. В случае неисполнения или ненадлежащего исполнения Исполнителем, Заказчиком и (или) Слушателем обязательств по настоящему договору они несут         ответственность, предусмотренную договором, Гражданским кодексом Российской Федерации, федеральными законами, Законом Российской Федерации «О защите         прав потребителей» и иными нормативными правовыми актами.\r\n</p>\r\n<p>\r\n	                  5.2. Заказчик несет ответственность за достоверность всех предоставленных им сведений, в том числе, но не исключительно: сведений о сотрудниках         Заказчика, реквизитах Заказчика.\r\n</p>\r\n<p>\r\n	 <strong> </strong>\r\n</p>\r\n<p align="center">\r\n	 <strong>6. </strong><strong>Форс-мажорные обстоятельства</strong>\r\n</p>\r\n<p>\r\n	                  6.1. При наступлении обстоятельств невозможности полного или частичного исполнения любой из Сторон обязательств по настоящему договору – непреодолимой         силы (форс-мажор), а именно: землетрясения, стихийного бедствия или других обстоятельств непреодолимой силы, срок исполнения обязательств по настоящему         договору отодвигается соразмерно времени, в течение которого будут действовать такие обстоятельства или их последствия.\r\n</p>\r\n<p>\r\n	                  6.2. Если эти обстоятельства или их последствия будут продолжаться более трех месяцев, каждая из сторон вправе отказаться от дальнейшего исполнения         обязательств по настоящему договору без взаимных претензий друг к другу.\r\n</p>\r\n<p align="center">\r\n	 <strong>7. </strong><strong>Прочие условия</strong>\r\n</p>\r\n<p>\r\n	                  7.1. Настоящий договор вступает в силу с момента его подписания и действует до исполнения сторонами своих обязательств.\r\n</p>\r\n<p>\r\n	                  7.2. Взаимоотношения сторон, неурегулированные договором, регламентируются действующим гражданским Законодательством РФ.\r\n</p>\r\n<p>\r\n	                  7.3. В случае невозможности урегулирования возникающих споров и разногласий путем переговоров стороны обращаются в Арбитражный суд Ростовской области.\r\n</p>\r\n<p>\r\n	                  7.4. Настоящий договор составлен в двух экземплярах, имеющих одинаковую юридическую силу, один из которых находится у Заказчика, второй – у         Исполнителя.\r\n</p>\r\n<p align="center">\r\n	 <strong>8. Юридические адреса и реквизиты сторон</strong>\r\n</p>\r\n<table>\r\n<tbody>\r\n<tr>\r\n	<td valign="top" width="434">\r\n		<p>\r\n			 <strong>Исполнитель:</strong>\r\n		</p>\r\n		<p>\r\n			                                          НОУ ДПО «ЦКС»\r\n		</p>\r\n		<p>\r\n			                                          Место нахождения исполнителя:\r\n		</p>\r\n		<p>\r\n			                                          344002, г. Ростов-на-Дону,\r\n		</p>\r\n		<p>\r\n			                                          пер. Соляной спуск, 8-10\r\n		</p>\r\n		<p>\r\n			                                          ОГРН 1146100003180\r\n		</p>\r\n		<p>\r\n			                                          ИНН 6164990894\r\n		</p>\r\n		<p>\r\n			                                          КПП 616401001\r\n		</p>\r\n		<p>\r\n			                                          р/сч 40703810626050000009\r\n		</p>\r\n		<p>\r\n			                                          к/сч 30101810500000000207\r\n		</p>\r\n		<p>\r\n			         Филиал "Ростовский" ОАО АЛЬФА-БАНК\r\n		</p>\r\n		<p>\r\n			         г. Ростов-на-Дону\r\n		</p>\r\n		<p>\r\n			                                          БИК 046015207\r\n		</p>\r\n		<p>\r\n			                                          телефон: (863) 299-07-14\r\n		</p>\r\n		<p>\r\n			                                          Руководитель\r\n		</p>\r\n		<p>\r\n			                                          ____________________ Шумеев П.А.\r\n		</p>\r\n		<p>\r\n			                                          м.п.\r\n		</p>\r\n		<p>\r\n			 <strong> </strong>\r\n		</p>\r\n	</td>\r\n	<td valign="top" width="434">\r\n		<p>\r\n			 <strong>Заказчик:</strong>\r\n		</p>\r\n		<p>\r\n			                                          {{ @$FIOIndividualnogoSlushatelya }}<br>\r\n		</p>\r\n		<p>\r\n			   паспорт: {{ @$SeriaPasportaIndividualnogoZakazchika }} {{ @$NomerPasportaIndividualnogoZakazchika }}\r\n		</p>\r\n		<p>\r\n			   выдан: {{ @$KemVudanPasportIndividualnogoZakazchika }}\r\n		</p>\r\n		<p>\r\n			   дата выдачи: {{ @$KogdaVadanPasportIndividualnogoZakazchika }}\r\n		</p>\r\n		<p>\r\n			   код подразделения: {{ @$KodPodrazdeleniyaIndividualnogoZakazchika }}\r\n		</p>\r\n		<p>\r\n			   зарегистрирован: {{ @$PochtovuyAdressZakazchika }}\r\n		</p>\r\n		<p>\r\n			    телефон: {{ @$KontaktnuyTelefonZakazchika }}\r\n		</p>\r\n		<p>\r\n			 <br>\r\n			 <br>\r\n		</p>\r\n		<p>\r\n			                                          ____________________  {{ @$ImyaOtvetstvennogoLicaInicialu }}\r\n		</p>\r\n		<p>\r\n			                                          м.п.\r\n		</p>\r\n		<p>\r\n			 <strong> </strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<p>\r\n	       *Стоимость оказания платных образовательных услуг установлена в соответствии с условиями Акции, утвержденной приказом руководителя НОУ ДПО «ЦКС» А №002 от 01.07.2014.\r\n</p>', '2014-12-17 08:56:52', '2014-12-17 12:40:38'),
(1752, 595, NULL, 'word_template', NULL, '2014-12-17 08:56:52', '2014-12-17 08:56:52'),
(1756, 604, NULL, 'user_id', '2', '2014-12-17 09:09:40', '2014-12-17 09:09:40'),
(1757, 604, NULL, 'action_id', '21', '2014-12-17 09:09:40', '2014-12-17 09:09:40'),
(1758, 604, NULL, 'title', 'Событие за 17.12.2014 в 12:09', '2014-12-17 09:09:40', '2014-12-17 09:09:40'),
(1759, 604, NULL, 'link', NULL, '2014-12-17 09:09:40', '2014-12-17 09:09:40'),
(1760, 604, NULL, 'created_time', '2014-12-17 12:09:40', '2014-12-17 09:09:40', '2014-12-17 09:09:40'),
(1761, 605, NULL, 'variables', '', '2014-12-17 09:22:33', '2014-12-17 09:22:33'),
(1762, 605, NULL, 'content', '<p align="right">\r\n	       Приложение №1\r\n</p>\r\n<p align="right">\r\n	       к Договору №{{@$NomerZakaza }} ЭПК\r\n</p>\r\n<p align="right">\r\n	       от {{ @$DataOformleniyaZakazaSlovami }}\r\n</p>\r\n       {{ @$TablicaSluschateleyDlyaDogovora }}\r\n<table>\r\n<tbody>\r\n<tr>\r\n	<td>\r\n		<p>\r\n			 <strong>Исполнитель:</strong>\r\n		</p>\r\n		<p>\r\n			                              Руководитель НОУ ДПО «ЦКС»\r\n		</p>\r\n		<p>\r\n			                              ___________________ П.А. Шумеев\r\n		</p>\r\n		<p>\r\n			                              м.п.\r\n		</p>\r\n	</td>\r\n	<td>\r\n		 <strong>Заказчик:</strong>\r\n		<p>\r\n			<em><u>{{ @$FIOIndividualnogoSlushatelya }}</u></em>\r\n		</p>\r\n		<p>\r\n			                              ___________________ <em><u>ФИО</u></em>\r\n		</p>\r\n		<p>\r\n			                              м.п.\r\n		</p>\r\n	</td>\r\n</tr>\r\n</tbody>\r\n</table>', '2014-12-17 09:22:33', '2014-12-17 09:22:33'),
(1763, 605, NULL, 'word_template', NULL, '2014-12-17 09:22:33', '2014-12-17 09:22:33'),
(1764, 607, NULL, 'variables', '', '2014-12-17 09:24:45', '2014-12-17 09:24:45'),
(1765, 607, NULL, 'content', '<table border="1" cellpadding="0" cellspacing="0">\r\n<tbody>\r\n<tr>\r\n	<td style="padding: 3pt 6pt 3pt 6pt;" valign="top" width="218">\r\n		<p>\r\n			                                          ИНН 6164990894\r\n		</p>\r\n	</td>\r\n	<td style="padding: 3pt;" width="218">\r\n		<p>\r\n			                                          КПП 616401001\r\n		</p>\r\n	</td>\r\n	<td style="padding: 3pt 6pt 3pt 6pt;" valign="top" width="218">\r\n		<p>\r\n			                                          р/с №\r\n		</p>\r\n	</td>\r\n	<td style="padding: 3pt 6pt 3pt 6pt;" rowspan="2" valign="top" width="218">\r\n		<p>\r\n			                                          40703810626050000009\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td style="padding: 3pt 6pt 3pt 6pt;" colspan="3" valign="top" width="654">\r\n		<p>\r\n			                                          Автономная некоммерческая организация дополнительного профессионального образования "Центр качества строительства"\r\n		</p>\r\n		<p>\r\n			                                          Получатель\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td style="padding: 3pt 6pt 3pt 6pt;" rowspan="2" colspan="2" width="436">\r\n		<p>\r\n			                                          Филиал "Ростовский" ОАО АЛЬФА-БАНК г. Ростов-на-Дону\r\n		</p>\r\n		<p>\r\n			                                          Банк получателя\r\n		</p>\r\n	</td>\r\n	<td style="padding: 3pt 6pt 3pt 6pt;" valign="top" width="218">\r\n		<p>\r\n			                                          БИК\r\n		</p>\r\n	</td>\r\n	<td style="padding: 3pt 6pt 3pt 6pt;" rowspan="2" valign="top" width="218">\r\n		<p>\r\n			                                          046015207\r\n		</p>\r\n		<p>\r\n			                                          30101810500000000207\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td style="padding: 3pt;" width="218">\r\n		<p>\r\n			                                          к/с №\r\n		</p>\r\n	</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<h2>                         Счет № {{ @$NomerZakaza }}<strong> </strong>от {{ @$DataOformleniyaZakaza}} </h2>\r\n<table border="1" cellpadding="0" cellspacing="0">\r\n<tbody>\r\n<tr>\r\n	<td style="padding: 3pt 6pt 3pt 6pt;" valign="top" width="108">\r\n		<p>\r\n			                                          Поставщик:\r\n		</p>\r\n	</td>\r\n	<td style="padding: 3pt 6pt 3pt 6pt;" valign="top" width="763">\r\n		<p>\r\n			 <strong>                         Автономная некоммерческая организация дополнительного профессионального образования "Центр качества строительства", ИНН 6164990894, КПП                         616401001, г. Ростов-на-Дону, ул. Соляной спуск, д. 8-10, тел. (863) 299-07-14                     </strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<table border="0" cellpadding="0" cellspacing="0" width="793">\r\n<tbody>\r\n<tr>\r\n	<td style="padding: 3pt;" nowrap="" valign="top" width="98">\r\n		<p>\r\n			                                           Покупатель:\r\n		</p>\r\n	</td>\r\n	<td style="padding: 3pt;" valign="top" width="666">\r\n		<p>\r\n			                     {{ @$Zakazchik}}\r\n		</p>\r\n	</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<p>\r\n	            {{ @$SpisokSluschateleyDlyaScheta }}\r\n</p>\r\n<div align="right">\r\n	<table style="float: right; margin-left: 50%; margin-bottom: 10%; width: 50%;" border="1" cellpadding="0" cellspacing="0" width="">\r\n	<tbody>\r\n	<tr>\r\n		<td style="padding: 3pt;" nowrap="" valign="top" width="150">\r\n			<p align="right">\r\n				<strong>Итого</strong>\r\n			</p>\r\n		</td>\r\n		<td style="padding: 3pt;" nowrap="" valign="top" width="200">\r\n			<p align="right">\r\n				 <strong>{{ @$SummaZakaza }},00</strong>\r\n			</p>\r\n		</td>\r\n	</tr>\r\n	<tr>\r\n		<td style="padding: 3pt;" nowrap="" valign="top" width="133">\r\n			<p align="right">\r\n				<strong>Сумма НДС</strong>\r\n			</p>\r\n		</td>\r\n		<td style="padding: 3pt;" nowrap="" valign="top" width="115">\r\n			<p align="right">\r\n				<strong>0,00</strong>\r\n			</p>\r\n		</td>\r\n	</tr>\r\n	</tbody>\r\n	</table>\r\n</div>\r\n<p>\r\n	                           В поле "Назначение платежа" необходимо указать:\r\n</p>\r\n<p>\r\n	                           Оказание платных образовательных услуг в соответствии с договором №{{ @$NomerZakaza}} от {{ @$DataOformleniyaZakaza}}.\r\n</p>\r\n<p>\r\n	                           Всего наименований: {{ @$VsegoNaimenovaliy }}; количество: {{ @$KolichestvoNaimenovaliy }}\r\n</p>\r\n<p>\r\n	                      на сумму {{ @$SummaZakaza }}.00 Руб\r\n</p>\r\n<p>\r\n	        ({{ @$SummaZakazaSlovami }})\r\n</p>\r\n<p>\r\n	     Руководитель /Шумеев П.А./\r\n</p>', '2014-12-17 09:24:45', '2014-12-17 09:24:45'),
(1766, 607, NULL, 'word_template', NULL, '2014-12-17 09:24:45', '2014-12-17 09:24:45'),
(1776, 611, NULL, 'variables', '', '2014-12-17 11:30:21', '2014-12-17 11:30:21'),
(1777, 611, NULL, 'content', '<p align="center">\r\n	<strong>Аттестационная ведомость</strong>\r\n</p>\r\n<p>\r\n	<strong>Наименование дополнительной профессиональной программы: </strong>{{ @$Kod_kursa }}. {{ @$Nazvanie_kursa }}\r\n</p>\r\n<p>\r\n	<strong>Группа:</strong>     № {{ @$NomerZakaza }}\r\n</p>\r\n<p>\r\n	<strong>Дата проведения аттестации</strong>     : {{ @$DataProvedeniyaAttestacii }} г.\r\n</p>\r\n<table border="1" cellpadding="0" cellspacing="0">\r\n<tbody>\r\n<tr>\r\n	<td valign="top" width="45">\r\n		<p align="center">\r\n			<strong>№</strong>\r\n		</p>\r\n	</td>\r\n	<td valign="top" width="569">\r\n		<p align="center">\r\n			<strong>Ф.И.О. слушателя</strong>\r\n		</p>\r\n	</td>\r\n	<td valign="top" width="225">\r\n		<p align="center">\r\n			<strong>Оценка</strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td valign="top" width="45">\r\n		<p align="center">\r\n			                       1\r\n		</p>\r\n	</td>\r\n	<td width="569">\r\n		<p align="center">\r\n			                       {{ @$FIO_listener }}\r\n		</p>\r\n	</td>\r\n	<td valign="top" width="225">\r\n		<p align="center">\r\n			               {{ @$OcenkaAttestacii }}\r\n		</p>\r\n	</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<table>\r\n<tbody>\r\n<tr>\r\n	<td valign="top" width="430">\r\n		<p>\r\n			                        Члены аттестационной комиссии <strong></strong>\r\n		</p>\r\n	</td>\r\n	<td valign="top" width="232">\r\n		<p align="center">\r\n			 <strong> </strong>\r\n		</p>\r\n		 <br>\r\n	</td>\r\n	<td valign="top" width="177">\r\n		<p align="right">\r\n			                        Шаповалова Д.Е.<strong></strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td valign="top" width="430">\r\n		 <br>\r\n	</td>\r\n	<td valign="top" width="232">\r\n		 <br>\r\n	</td>\r\n	<td valign="top" width="177">\r\n		<p align="right">\r\n			                        Шумеев А.А.\r\n		</p>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td valign="top" width="430">\r\n		<p>\r\n			                        Председатель аттестационной комиссии\r\n		</p>\r\n	</td>\r\n	<td valign="top" width="232">\r\n		 <br>\r\n	</td>\r\n	<td valign="top" width="177">\r\n		<p align="right">\r\n			                        Шумеев П.А.\r\n		</p>\r\n	</td>\r\n</tr>\r\n</tbody>\r\n</table>', '2014-12-17 11:30:21', '2014-12-17 11:30:21'),
(1778, 611, NULL, 'word_template', NULL, '2014-12-17 11:30:21', '2014-12-17 11:30:21'),
(1800, 619, NULL, 'variables', '', '2014-12-17 12:33:01', '2014-12-17 12:33:01'),
(1801, 619, NULL, 'content', '<p>\r\n	<strong></strong>\r\n</p>\r\n<p style="text-align: center;">\r\n	<strong> Акт сдачи-приемки оказанных услуг №{{ @$NomerZakaza }} ЭПК от {{ @$DataOplatuZakaza }}</strong>\r\n</p>\r\n<p style="text-align: center;">\r\n</p>\r\n<p>\r\n	 <strong>Исполнитель: </strong>Автономная некоммерческая организация дополнительного профессионального образования «Центр качества строительства»\r\n</p>\r\n<p>\r\n	 <strong> </strong>\r\n</p>\r\n<p>\r\n	 <strong>Заказчик:</strong> {{ @$Zakazchik }}\r\n</p>\r\n<p>\r\n	 <strong>Наименование услуг:</strong>оказание платных образовательных услуг в соответствии с договором №{{ @$NomerZakaza }} ЭПК от {{ @$DataOplatuZakaza }}\r\n</p>\r\n<p align="right">\r\n	 <strong>Валюта: Руб</strong>\r\n</p>\r\n<p>\r\n	   {{ @$SpisokSluschateleyDlyaAkta }}\r\n</p>\r\n<p align="right">\r\n	 <strong></strong>\r\n</p>\r\n<p>\r\n	 <em>Всего оказано услуг на сумму</em><em>: </em>{{ @$SummaZakazaSlovami }}<em><u>.</u></em>\r\n</p>\r\n<p>\r\n	 <em>НДС не облагается п.2 ст.346.11 НК РФ.</em>\r\n</p>\r\n<p>\r\n	   Вышеперечисленные услуги оказаны в полном объеме и в срок. Заказчик претензий по объему, качеству и срокам оказания услуг не имеет.\r\n</p>\r\n<p>\r\n	 <strong>Исполнитель: Заказчик: </strong>\r\n</p>\r\n<p>\r\n	              Руководитель Директор\r\n</p>\r\n<p>\r\n	              ____________________ П.А. Шумеев ___________________ А.П. Донченко\r\n</p>\r\n<p>\r\n	              м.п.                                                                   м.п.\r\n</p>', '2014-12-17 12:33:01', '2014-12-17 12:33:01'),
(1802, 619, NULL, 'word_template', NULL, '2014-12-17 12:33:01', '2014-12-17 12:33:01'),
(1809, 622, NULL, 'variables', '', '2014-12-17 12:38:55', '2014-12-17 12:38:55');
INSERT INTO `dictionary_fields_values` (`id`, `dicval_id`, `language`, `key`, `value`, `created_at`, `updated_at`) VALUES
(1810, 622, NULL, 'content', '<p align="center">\r\n	<strong>Договор №{{ @$NomerZakaza }} ЭПК</strong>\r\n</p>\r\n<p align="center">\r\n	<strong>на оказание платных образовательных услуг</strong>\r\n</p>\r\n<p>\r\n	            г. Ростов-на-Дону\r\n</p>\r\n<p style="text-align: right;">\r\n	           {{ @$DataOformleniyaZakazaSlovami }}\r\n</p>\r\n<p>\r\n	            Автономная некоммерческая организация дополнительного профессионального образования «Центр качества строительства» (далее – АНО ДПО «ЦКС»), именуемая в дальнейшем Исполнитель, в лице руководителя Шумеева Павла Андреевича, действующего на основании Устава, с одной стороны, и {{ @$NazvanieOrganizacii }}, именуемое в дальнейшем Заказчик, в лице {{ @$DoljnostOtvetstvennogoLicaOrganizacii }} {{ @$ImyaOtvetstvennogoLicaOrganizacii }}, действующего на основании {{ @$DeystvuyucheeOsnovanieOrganizacii }} с другой стороны, вместе именуемые Стороны, заключили настоящий договор (далее - Договор) о нижеследующем:\r\n</p>\r\n<p align="center">\r\n	<strong> </strong>\r\n</p>\r\n<p align="center">\r\n	<strong>1. </strong><strong>Предмет договора</strong>\r\n</p>\r\n<p>\r\n	                         1.1. Исполнитель обязуется предоставить сотрудникам Заказчика (далее – Слушатели) платные образовательные услуги по повышению квалификации в соответствии с утвержденными дополнительными профессиональными программами (далее – ДПП) согласно Приложению №1 (далее – прил. №1), а Заказчик обязуется оплатить данные образовательные услуги.\r\n</p>\r\n<p>\r\n	                         1.2. Повышение квалификации слушателей проводится на основании лицензии на осуществление образовательной деятельности, выданной Региональной службой по надзору и контролю в сфере образования Ростовской области 18.11.2014, серия 61Л01 № 0001674, рег. № 4097.\r\n</p>\r\n<p>\r\n	                         1.3. Общий объем ДПП – 72 часа.\r\n</p>\r\n<p>\r\n	                         1.4. Срок освоения ДПП – 9 дней.\r\n</p>\r\n<p>\r\n	                         1.5. Форма обучения – заочная.\r\n</p>\r\n<p>\r\n	                         1.6. По результатам обучения (при условии успешного освоения ДПП) Исполнитель выдает каждому Слушателю удостоверение о повышении квалификации установленного образца по соответствующей ДПП, указанной в прил. №1.\r\n</p>\r\n<p align="center">\r\n	 <strong>2. Права и обязанности Исполнителя, Заказчика и Слушателя</strong>\r\n</p>\r\n<p>\r\n	                   2.1. Права и обязанности Исполнителя.\r\n</p>\r\n<p>\r\n	                   2.1.1. Исполнитель самостоятельно осуществляет образовательный процесс, выбирает системы оценок, формы, порядок и периодичность аттестации Слушателей.\r\n</p>\r\n<p>\r\n	                   2.1.2. Исполнитель имеет право потребовать от Заказчика в письменном виде информацию и разъяснения по любому вопросу, связанному с выполнением         обязательств Исполнителя по договору.\r\n</p>\r\n<p>\r\n	                   2.1.3. Исполнитель обязан обеспечить Заказчику оказание платных образовательных услуг в полном объеме в соответствии с образовательными программами,         утвержденными Исполнителем, и условиями договора.\r\n</p>\r\n<p>\r\n	                   2.1.4. Исполнитель обеспечивает Слушателя учебно-методическими материалами в электронной форме по соответствующей ДПП согласно прил. №1.\r\n</p>\r\n<p>\r\n	                   2.1.5. Исполнитель обязан довести до Заказчика информацию, содержащую сведения о предоставлении платных образовательных услуг в порядке и объеме,         которые предусмотрены Законом Российской Федерации «О защите прав потребителей» и Федеральным законом «Об образовании в Российской Федерации».\r\n</p>\r\n<p>\r\n	                   2.2. Права и обязанности Заказчика.\r\n</p>\r\n<p>\r\n	                   2.2.1. При нарушении Исполнителем сроков оказания платных образовательных услуг (сроков начала и (или) окончания оказания платных образовательных услуг         и (или) промежуточных сроков оказания платной образовательной услуги) Заказчик вправе по своему выбору:\r\n</p>\r\n<p>\r\n	                   - назначить исполнителю новый срок, в течение которого исполнитель должен приступить к оказанию платных образовательных услуг и (или) закончить         оказание платных образовательных услуг;\r\n</p>\r\n<p>\r\n	                   - потребовать уменьшения стоимости платных образовательных услуг.\r\n</p>\r\n<p>\r\n	                   2.2.2. Заказчик обязан оплатить услуги Исполнителя в размере и сроки, предусмотренные условиями договора.\r\n</p>\r\n<p>\r\n	                   2.2.3. Заказчик обязан соблюдать установленный Исполнителем порядок обучения (повышения квалификации).\r\n</p>\r\n<p>\r\n	                   2.2.4. Заказчик обязан в 3-дневный срок с момента получения от Исполнителя запроса предоставлять информацию и разъяснения по любому вопросу, связанному         с выполнением обязательств Исполнителя по договору.\r\n</p>\r\n<p>\r\n	                   2.2.5. Заказчик обязан контролировать освоение Слушателем ДПП в полном объеме (72 часа), а также прохождение слушателем промежуточной и итоговой         аттестаций.\r\n</p>\r\n<p>\r\n	                   2.3. Права и обязанности Слушателя.\r\n</p>\r\n<p>\r\n	                   2.3.1. Слушатель имеет право на бесплатное пользование электронными фондами библиотеки АНО ДПО «ЦКС».\r\n</p>\r\n<p>\r\n	                   2.3.2. Слушатель имеет право своевременно получать информацию об образовательном процессе в необходимом объеме, установленном законодательством.\r\n</p>\r\n<p>\r\n	                   2.3.3. Слушатель имеет право на объективную оценку в соответствии со своими знаниями, умением и навыками.\r\n</p>\r\n<p>\r\n	                   2.3.4. Слушатель имеет право на получение соответствующих документов об уровне образования после итоговой аттестации.\r\n</p>\r\n<p>\r\n	                   2.3.5. Слушатель обязан соблюдать установленный Исполнителем порядок обучения (повышения квалификации), а также порядки и положения, установленные         Исполнителем иными локальными актами.\r\n</p>\r\n<p>\r\n	                   2.3.6. Слушатель обязан выполнять в установленные сроки все виды заданий, предусмотренные программой, в том числе выполнять задания для самостоятельной         подготовки, самостоятельно проходить промежуточную и итоговую аттестацию.\r\n</p>\r\n<p align="center">\r\n	<strong>3.Стоимость образовательных услуг и порядок оплаты</strong>\r\n</p>\r\n<p>\r\n	                 3.1. За оказание образовательных услуг по повышению квалификации Заказчик оплачивает Исполнителю сумму в размере 10 000 рублей (Десять тысяч рублей) за         1 (одного) слушателя. НДС не облагается на основании п.2 ст.346.11 НК РФ. Стоимость установлена в соответствии с условиями Акции*.\r\n</p>\r\n<p>\r\n	                 3.2. Оплата образовательных услуг в размере, указанном в п.3.1 Договора, осуществляется в течении 3 (трех) банковских дней с момента подписания         Договора.\r\n</p>\r\n<p align="center">\r\n	<strong>4. </strong><strong>Порядок изменения и расторжения договора</strong><strong></strong>\r\n</p>\r\n<p>\r\n	                 4.1. Условия, на которых заключен настоящий договор, могут быть изменены либо по соглашению сторон, либо в соответствии с действующим законодательством         Российской Федерации. Все изменения оформляются в письменном виде путем подписания Сторонами дополнительных соглашений к настоящему договору. Все         приложения и дополнительные соглашения являются неотъемлемой частью договора. Дополнительные соглашения к настоящему договору вступают в силу с момента         их подписания Сторонами.\r\n</p>\r\n<p>\r\n	                 4.2. Настоящий договор может быть расторгнут по обоюдному соглашению сторон.\r\n</p>\r\n<p>\r\n	                 4.3. Заказчик вправе в одностороннем порядке отказаться от исполнения настоящего договора, предупредив об этом Исполнителя в письменной форме. В случае         отказа Заказчика от исполнения договора до начала обучения (повышения квалификации), уплаченная сумма возвращается ему в полном размере. В случае         отказа Заказчика от выполнения настоящего договора после начала обучения (повышения квалификации), а также в случае не сдачи итоговой аттестации         (тестирования) Слушателями, уплаченная сумма не возвращается.\r\n</p>\r\n<p>\r\n	                 4.4. При нарушении Исполнителем сроков оказания платных образовательных услуг (сроков начала и (или) окончания оказания платных образовательных услуг и         (или) промежуточных сроков оказания платной образовательной услуги) Заказчик вправе в одностороннем порядке расторгнуть договор.\r\n</p>\r\n<p>\r\n	                 4.5. Исполнитель имеет право расторгнуть договор в одностороннем порядке в следующих случаях:\r\n</p>\r\n<p>\r\n	                 - применение к Слушателю отчисления как меры дисциплинарного взыскания;\r\n</p>\r\n<p>\r\n	                 - невыполнение Слушателем обязанностей по добросовестному освоению ДПП и выполнению учебного плана;\r\n</p>\r\n<p>\r\n	                 - установление нарушения порядка приема Слушателя в АНО ДПО «ЦКС», повлекшего по вине Слушателя его незаконное зачисление в АНО ДПО «ЦКС»;\r\n</p>\r\n<p>\r\n	                 - просрочка оплаты стоимости платных образовательных услуг;\r\n</p>\r\n<p>\r\n	                 - невозможность надлежащего исполнения обязательств по оказанию платных образовательных услуг вследствие действий (бездействия) Слушателя.\r\n</p>\r\n<p align="center">\r\n	<strong>5. </strong><strong>Ответственность </strong><strong>Исполнителя, Заказчика и Слушателя</strong>\r\n</p>\r\n<p>\r\n	                 5.1. В случае неисполнения или ненадлежащего исполнения Исполнителем, Заказчиком и (или) Слушателем обязательств по настоящему договору они несут         ответственность, предусмотренную договором, Гражданским кодексом Российской Федерации, федеральными законами, Законом Российской Федерации «О защите         прав потребителей» и иными нормативными правовыми актами.\r\n</p>\r\n<p>\r\n	                 5.2. Заказчик несет ответственность за достоверность всех предоставленных им сведений, в том числе, но не исключительно: сведений о сотрудниках         Заказчика, реквизитах Заказчика.\r\n</p>\r\n<p>\r\n	<strong> </strong>\r\n</p>\r\n<p align="center">\r\n	<strong>6. </strong><strong>Форс-мажорные обстоятельства</strong>\r\n</p>\r\n<p>\r\n	                 6.1. При наступлении обстоятельств невозможности полного или частичного исполнения любой из Сторон обязательств по настоящему договору – непреодолимой         силы (форс-мажор), а именно: землетрясения, стихийного бедствия или других обстоятельств непреодолимой силы, срок исполнения обязательств по настоящему         договору отодвигается соразмерно времени, в течение которого будут действовать такие обстоятельства или их последствия.\r\n</p>\r\n<p>\r\n	                 6.2. Если эти обстоятельства или их последствия будут продолжаться более трех месяцев, каждая из сторон вправе отказаться от дальнейшего исполнения         обязательств по настоящему договору без взаимных претензий друг к другу.\r\n</p>\r\n<p align="center">\r\n	<strong>7. </strong><strong>Прочие условия</strong>\r\n</p>\r\n<p>\r\n	                 7.1. Настоящий договор вступает в силу с момента его подписания и действует до исполнения сторонами своих обязательств.\r\n</p>\r\n<p>\r\n	                 7.2. Взаимоотношения сторон, неурегулированные договором, регламентируются действующим гражданским Законодательством РФ.\r\n</p>\r\n<p>\r\n	                 7.3. В случае невозможности урегулирования возникающих споров и разногласий путем переговоров стороны обращаются в Арбитражный суд Ростовской области.\r\n</p>\r\n<p>\r\n	                 7.4. Настоящий договор составлен в двух экземплярах, имеющих одинаковую юридическую силу, один из которых находится у Заказчика, второй – у         Исполнителя.\r\n</p>\r\n<p align="center">\r\n	<strong>8. Юридические адреса и реквизиты сторон</strong>\r\n</p>\r\n<table>\r\n<tbody>\r\n<tr>\r\n	<td valign="top" width="434">\r\n		<p>\r\n			<strong>Исполнитель:</strong>\r\n		</p>\r\n		<p>\r\n			                                         НОУ ДПО «ЦКС»\r\n		</p>\r\n		<p>\r\n			                                         Место нахождения исполнителя:\r\n		</p>\r\n		<p>\r\n			                                         344002, г. Ростов-на-Дону,\r\n		</p>\r\n		<p>\r\n			                                         пер. Соляной спуск, 8-10\r\n		</p>\r\n		<p>\r\n			                                         ОГРН 1146100003180\r\n		</p>\r\n		<p>\r\n			                                         ИНН 6164990894\r\n		</p>\r\n		<p>\r\n			                                         КПП 616401001\r\n		</p>\r\n		<p>\r\n			                                         р/сч 40703810626050000009\r\n		</p>\r\n		<p>\r\n			                                         к/сч 30101810500000000207\r\n		</p>\r\n		<p>\r\n			        Филиал "Ростовский" ОАО АЛЬФА-БАНК\r\n		</p>\r\n		<p>\r\n			        г. Ростов-на-Дону\r\n		</p>\r\n		<p>\r\n			                                         БИК 046015207\r\n		</p>\r\n		<p>\r\n			                                         телефон: (863) 299-07-14\r\n		</p>\r\n		<p>\r\n			                                         Руководитель\r\n		</p>\r\n		<p>\r\n			                                         ____________________П.А. Шумеев\r\n		</p>\r\n		<p>\r\n			                                         м.п.\r\n		</p>\r\n		<p>\r\n			<strong> </strong>\r\n		</p>\r\n	</td>\r\n	<td valign="top" width="434">\r\n		<p>\r\n			<strong>Заказчик:</strong>\r\n		</p>\r\n		<p>\r\n			                                         {{ @$NazvanieOrganizacii }}<br>\r\n			              Место нахождения заказчика:\r\n		</p>\r\n		<p>\r\n			              {{ @$UridicheskiyAdresOrganizacii }}\r\n		</p>\r\n		<p>\r\n			                                         {{ @$OGNROrganizacii }}\r\n		</p>\r\n		<p>\r\n			                                         {{ @$INNOrganizacii }}\r\n		</p>\r\n		<p>\r\n			                                         {{ @$KPPOrganizacii }}\r\n		</p>\r\n		<p>\r\n			                                         {{ @$RaschetnuySchetOrganizacii }}\r\n		</p>\r\n		<p>\r\n			                                         {{ @$KorrespondentskuyChetOrganizacii }}\r\n		</p>\r\n		<p>\r\n			                                         {{ @$NazvanieBankaOrganizacii }}\r\n		</p>\r\n		<p>\r\n			                                         {{ @$BIKOrganizacii }}\r\n		</p>\r\n		<p>\r\n			                                         телефон: {{ @$KontaktnuyTelefonZakazchika }}\r\n		</p>\r\n		<p>\r\n			<br>\r\n			<br>\r\n		</p>\r\n		<p>\r\n			        {{ @$DoljnostOtvetstvennogoLicaOrganizacii }}\r\n		</p>\r\n		<p>\r\n			                                         ____________________  {{ @$ImyaOtvetstvennogoLicaInicialu }}\r\n		</p>\r\n		<p>\r\n			                                         м.п.\r\n		</p>\r\n		<p>\r\n			<strong> </strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<p>\r\n	      *Стоимость оказания платных образовательных услуг установлена в соответствии с условиями Акции, утвержденной приказом руководителя НОУ ДПО «ЦКС» А №002 от 01.07.2014.\r\n</p>', '2014-12-17 12:38:55', '2014-12-17 12:38:55'),
(1811, 622, NULL, 'word_template', NULL, '2014-12-17 12:38:55', '2014-12-17 12:38:55'),
(1812, 623, NULL, 'variables', '', '2014-12-17 12:40:38', '2014-12-17 12:40:38'),
(1813, 623, NULL, 'content', '<p align="center">\r\n	<strong>Договор №{{ @$NomerZakaza }} ЭПК</strong>\r\n</p>\r\n<p align="center">\r\n	<strong>на оказание платных образовательных услуг</strong>\r\n</p>\r\n<p>\r\n	            г. Ростов-на-Дону\r\n</p>\r\n<p style="text-align: right;">\r\n	           {{ @$DataOformleniyaZakazaSlovami }}\r\n</p>\r\n<p>\r\n	  Автономная некоммерческая организация дополнительного профессионального образования «Центр качества строительства» (далее – АНО ДПО «ЦКС»), именуемая в дальнейшем Исполнитель, в лице руководителя Шумеева Павла Андреевича, действующего на основании Устава, с одной стороны, и {{ @$FIOIndividualnogoSlushatelya }}, именуемый(ая) в дальнейшем Заказчик (Слушатель), в лице {{ @$FIOIndividualnogoSlushatelyaVRoditelnomPadije }}, действующего(ей) на основании паспорта, с другой стороны, вместе именуемые Стороны, заключили настоящий договор (далее - Договор) о нижеследующем:\r\n</p>\r\n<p align="center">\r\n	<strong> </strong>\r\n</p>\r\n<p align="center">\r\n	<strong>1. </strong><strong>Предмет договора</strong>\r\n</p>\r\n<p>\r\n	                         1.1. Исполнитель обязуется предоставить сотрудникам Заказчика (далее – Слушатели) платные образовательные услуги по повышению квалификации в соответствии с утвержденными дополнительными профессиональными программами (далее – ДПП) согласно Приложению №1 (далее – прил. №1), а Заказчик обязуется оплатить данные образовательные услуги.\r\n</p>\r\n<p>\r\n	                         1.2. Повышение квалификации слушателей проводится на основании лицензии на осуществление образовательной деятельности, выданной Региональной службой по надзору и контролю в сфере образования Ростовской области 18.11.2014, серия 61Л01 № 0001674, рег. № 4097.\r\n</p>\r\n<p>\r\n	                         1.3. Общий объем ДПП – 72 часа.\r\n</p>\r\n<p>\r\n	                         1.4. Срок освоения ДПП – 9 дней.\r\n</p>\r\n<p>\r\n	                         1.5. Форма обучения – заочная.\r\n</p>\r\n<p>\r\n	                         1.6. По результатам обучения (при условии успешного освоения ДПП) Исполнитель выдает каждому Слушателю удостоверение о повышении квалификации установленного образца по соответствующей ДПП, указанной в прил. №1.\r\n</p>\r\n<p align="center">\r\n	 <strong>2. Права и обязанности Исполнителя, Заказчика и Слушателя</strong>\r\n</p>\r\n<p>\r\n	                   2.1. Права и обязанности Исполнителя.\r\n</p>\r\n<p>\r\n	                   2.1.1. Исполнитель самостоятельно осуществляет образовательный процесс, выбирает системы оценок, формы, порядок и периодичность аттестации Слушателей.\r\n</p>\r\n<p>\r\n	                   2.1.2. Исполнитель имеет право потребовать от Заказчика в письменном виде информацию и разъяснения по любому вопросу, связанному с выполнением         обязательств Исполнителя по договору.\r\n</p>\r\n<p>\r\n	                   2.1.3. Исполнитель обязан обеспечить Заказчику оказание платных образовательных услуг в полном объеме в соответствии с образовательными программами,         утвержденными Исполнителем, и условиями договора.\r\n</p>\r\n<p>\r\n	                   2.1.4. Исполнитель обеспечивает Слушателя учебно-методическими материалами в электронной форме по соответствующей ДПП согласно прил. №1.\r\n</p>\r\n<p>\r\n	                   2.1.5. Исполнитель обязан довести до Заказчика информацию, содержащую сведения о предоставлении платных образовательных услуг в порядке и объеме,         которые предусмотрены Законом Российской Федерации «О защите прав потребителей» и Федеральным законом «Об образовании в Российской Федерации».\r\n</p>\r\n<p>\r\n	                   2.2. Права и обязанности Заказчика.\r\n</p>\r\n<p>\r\n	                   2.2.1. При нарушении Исполнителем сроков оказания платных образовательных услуг (сроков начала и (или) окончания оказания платных образовательных услуг         и (или) промежуточных сроков оказания платной образовательной услуги) Заказчик вправе по своему выбору:\r\n</p>\r\n<p>\r\n	                   - назначить исполнителю новый срок, в течение которого исполнитель должен приступить к оказанию платных образовательных услуг и (или) закончить         оказание платных образовательных услуг;\r\n</p>\r\n<p>\r\n	                   - потребовать уменьшения стоимости платных образовательных услуг.\r\n</p>\r\n<p>\r\n	                   2.2.2. Заказчик обязан оплатить услуги Исполнителя в размере и сроки, предусмотренные условиями договора.\r\n</p>\r\n<p>\r\n	                   2.2.3. Заказчик обязан соблюдать установленный Исполнителем порядок обучения (повышения квалификации).\r\n</p>\r\n<p>\r\n	                   2.2.4. Заказчик обязан в 3-дневный срок с момента получения от Исполнителя запроса предоставлять информацию и разъяснения по любому вопросу, связанному         с выполнением обязательств Исполнителя по договору.\r\n</p>\r\n<p>\r\n	                   2.2.5. Заказчик обязан контролировать освоение Слушателем ДПП в полном объеме (72 часа), а также прохождение слушателем промежуточной и итоговой         аттестаций.\r\n</p>\r\n<p>\r\n	                   2.3. Права и обязанности Слушателя.\r\n</p>\r\n<p>\r\n	                   2.3.1. Слушатель имеет право на бесплатное пользование электронными фондами библиотеки АНО ДПО «ЦКС».\r\n</p>\r\n<p>\r\n	                   2.3.2. Слушатель имеет право своевременно получать информацию об образовательном процессе в необходимом объеме, установленном законодательством.\r\n</p>\r\n<p>\r\n	                   2.3.3. Слушатель имеет право на объективную оценку в соответствии со своими знаниями, умением и навыками.\r\n</p>\r\n<p>\r\n	                   2.3.4. Слушатель имеет право на получение соответствующих документов об уровне образования после итоговой аттестации.\r\n</p>\r\n<p>\r\n	                   2.3.5. Слушатель обязан соблюдать установленный Исполнителем порядок обучения (повышения квалификации), а также порядки и положения, установленные         Исполнителем иными локальными актами.\r\n</p>\r\n<p>\r\n	                   2.3.6. Слушатель обязан выполнять в установленные сроки все виды заданий, предусмотренные программой, в том числе выполнять задания для самостоятельной         подготовки, самостоятельно проходить промежуточную и итоговую аттестацию.\r\n</p>\r\n<p align="center">\r\n	<strong>3.Стоимость образовательных услуг и порядок оплаты</strong>\r\n</p>\r\n<p>\r\n	                 3.1. За оказание образовательных услуг по повышению квалификации Заказчик оплачивает Исполнителю сумму в размере 10 000 рублей (Десять тысяч рублей) за         1 (одного) слушателя. НДС не облагается на основании п.2 ст.346.11 НК РФ. Стоимость установлена в соответствии с условиями Акции*.\r\n</p>\r\n<p>\r\n	                 3.2. Оплата образовательных услуг в размере, указанном в п.3.1 Договора, осуществляется в течении 3 (трех) банковских дней с момента подписания         Договора.\r\n</p>\r\n<p align="center">\r\n	<strong>4. </strong><strong>Порядок изменения и расторжения договора</strong><strong></strong>\r\n</p>\r\n<p>\r\n	                 4.1. Условия, на которых заключен настоящий договор, могут быть изменены либо по соглашению сторон, либо в соответствии с действующим законодательством         Российской Федерации. Все изменения оформляются в письменном виде путем подписания Сторонами дополнительных соглашений к настоящему договору. Все         приложения и дополнительные соглашения являются неотъемлемой частью договора. Дополнительные соглашения к настоящему договору вступают в силу с момента         их подписания Сторонами.\r\n</p>\r\n<p>\r\n	                 4.2. Настоящий договор может быть расторгнут по обоюдному соглашению сторон.\r\n</p>\r\n<p>\r\n	                 4.3. Заказчик вправе в одностороннем порядке отказаться от исполнения настоящего договора, предупредив об этом Исполнителя в письменной форме. В случае         отказа Заказчика от исполнения договора до начала обучения (повышения квалификации), уплаченная сумма возвращается ему в полном размере. В случае         отказа Заказчика от выполнения настоящего договора после начала обучения (повышения квалификации), а также в случае не сдачи итоговой аттестации         (тестирования) Слушателями, уплаченная сумма не возвращается.\r\n</p>\r\n<p>\r\n	                 4.4. При нарушении Исполнителем сроков оказания платных образовательных услуг (сроков начала и (или) окончания оказания платных образовательных услуг и         (или) промежуточных сроков оказания платной образовательной услуги) Заказчик вправе в одностороннем порядке расторгнуть договор.\r\n</p>\r\n<p>\r\n	                 4.5. Исполнитель имеет право расторгнуть договор в одностороннем порядке в следующих случаях:\r\n</p>\r\n<p>\r\n	                 - применение к Слушателю отчисления как меры дисциплинарного взыскания;\r\n</p>\r\n<p>\r\n	                 - невыполнение Слушателем обязанностей по добросовестному освоению ДПП и выполнению учебного плана;\r\n</p>\r\n<p>\r\n	                 - установление нарушения порядка приема Слушателя в АНО ДПО «ЦКС», повлекшего по вине Слушателя его незаконное зачисление в АНО ДПО «ЦКС»;\r\n</p>\r\n<p>\r\n	                 - просрочка оплаты стоимости платных образовательных услуг;\r\n</p>\r\n<p>\r\n	                 - невозможность надлежащего исполнения обязательств по оказанию платных образовательных услуг вследствие действий (бездействия) Слушателя.\r\n</p>\r\n<p align="center">\r\n	<strong>5. </strong><strong>Ответственность </strong><strong>Исполнителя, Заказчика и Слушателя</strong>\r\n</p>\r\n<p>\r\n	                 5.1. В случае неисполнения или ненадлежащего исполнения Исполнителем, Заказчиком и (или) Слушателем обязательств по настоящему договору они несут         ответственность, предусмотренную договором, Гражданским кодексом Российской Федерации, федеральными законами, Законом Российской Федерации «О защите         прав потребителей» и иными нормативными правовыми актами.\r\n</p>\r\n<p>\r\n	                 5.2. Заказчик несет ответственность за достоверность всех предоставленных им сведений, в том числе, но не исключительно: сведений о сотрудниках         Заказчика, реквизитах Заказчика.\r\n</p>\r\n<p>\r\n	<strong> </strong>\r\n</p>\r\n<p align="center">\r\n	<strong>6. </strong><strong>Форс-мажорные обстоятельства</strong>\r\n</p>\r\n<p>\r\n	                 6.1. При наступлении обстоятельств невозможности полного или частичного исполнения любой из Сторон обязательств по настоящему договору – непреодолимой         силы (форс-мажор), а именно: землетрясения, стихийного бедствия или других обстоятельств непреодолимой силы, срок исполнения обязательств по настоящему         договору отодвигается соразмерно времени, в течение которого будут действовать такие обстоятельства или их последствия.\r\n</p>\r\n<p>\r\n	                 6.2. Если эти обстоятельства или их последствия будут продолжаться более трех месяцев, каждая из сторон вправе отказаться от дальнейшего исполнения         обязательств по настоящему договору без взаимных претензий друг к другу.\r\n</p>\r\n<p align="center">\r\n	<strong>7. </strong><strong>Прочие условия</strong>\r\n</p>\r\n<p>\r\n	                 7.1. Настоящий договор вступает в силу с момента его подписания и действует до исполнения сторонами своих обязательств.\r\n</p>\r\n<p>\r\n	                 7.2. Взаимоотношения сторон, неурегулированные договором, регламентируются действующим гражданским Законодательством РФ.\r\n</p>\r\n<p>\r\n	                 7.3. В случае невозможности урегулирования возникающих споров и разногласий путем переговоров стороны обращаются в Арбитражный суд Ростовской области.\r\n</p>\r\n<p>\r\n	                 7.4. Настоящий договор составлен в двух экземплярах, имеющих одинаковую юридическую силу, один из которых находится у Заказчика, второй – у         Исполнителя.\r\n</p>\r\n<p align="center">\r\n	<strong>8. Юридические адреса и реквизиты сторон</strong>\r\n</p>\r\n<table>\r\n<tbody>\r\n<tr>\r\n	<td valign="top" width="434">\r\n		<p>\r\n			<strong>Исполнитель:</strong>\r\n		</p>\r\n		<p>\r\n			                                         НОУ ДПО «ЦКС»\r\n		</p>\r\n		<p>\r\n			                                         Место нахождения исполнителя:\r\n		</p>\r\n		<p>\r\n			                                         344002, г. Ростов-на-Дону,\r\n		</p>\r\n		<p>\r\n			                                         пер. Соляной спуск, 8-10\r\n		</p>\r\n		<p>\r\n			                                         ОГРН 1146100003180\r\n		</p>\r\n		<p>\r\n			                                         ИНН 6164990894\r\n		</p>\r\n		<p>\r\n			                                         КПП 616401001\r\n		</p>\r\n		<p>\r\n			                                         р/сч 40703810626050000009\r\n		</p>\r\n		<p>\r\n			                                         к/сч 30101810500000000207\r\n		</p>\r\n		<p>\r\n			        Филиал "Ростовский" ОАО АЛЬФА-БАНК\r\n		</p>\r\n		<p>\r\n			        г. Ростов-на-Дону\r\n		</p>\r\n		<p>\r\n			                                         БИК 046015207\r\n		</p>\r\n		<p>\r\n			                                         телефон: (863) 299-07-14\r\n		</p>\r\n		<p>\r\n			                                         Руководитель\r\n		</p>\r\n		<p>\r\n			                                         ____________________П.А. Шумеев\r\n		</p>\r\n		<p>\r\n			                                         м.п.\r\n		</p>\r\n		<p>\r\n			<strong> </strong>\r\n		</p>\r\n	</td>\r\n	<td valign="top" width="434">\r\n		<p>\r\n			<strong>Заказчик:</strong>\r\n		</p>\r\n		<p>\r\n			                                         {{ @$FIOIndividualnogoSlushatelya }}<br>\r\n		</p>\r\n		<p>\r\n			  паспорт: {{ @$SeriaPasportaIndividualnogoZakazchika }} {{ @$NomerPasportaIndividualnogoZakazchika }}\r\n		</p>\r\n		<p>\r\n			  выдан: {{ @$KemVudanPasportIndividualnogoZakazchika }}\r\n		</p>\r\n		<p>\r\n			  дата выдачи: {{ @$KogdaVadanPasportIndividualnogoZakazchika }}\r\n		</p>\r\n		<p>\r\n			  код подразделения: {{ @$KodPodrazdeleniyaIndividualnogoZakazchika }}\r\n		</p>\r\n		<p>\r\n			  зарегистрирован: {{ @$PochtovuyAdressZakazchika }}\r\n		</p>\r\n		<p>\r\n			   телефон: {{ @$KontaktnuyTelefonZakazchika }}\r\n		</p>\r\n		<p>\r\n			<br>\r\n			<br>\r\n		</p>\r\n		<p>\r\n			                                         ____________________  {{ @$ImyaOtvetstvennogoLicaInicialu }}\r\n		</p>\r\n		<p>\r\n			                                         м.п.\r\n		</p>\r\n		<p>\r\n			<strong> </strong>\r\n		</p>\r\n	</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<p>\r\n	      *Стоимость оказания платных образовательных услуг установлена в соответствии с условиями Акции, утвержденной приказом руководителя НОУ ДПО «ЦКС» А №002 от 01.07.2014.\r\n</p>', '2014-12-17 12:40:38', '2014-12-17 12:40:38'),
(1814, 623, NULL, 'word_template', NULL, '2014-12-17 12:40:38', '2014-12-17 12:40:38'),
(1815, 624, NULL, 'user_id', '0', '2014-12-18 08:58:07', '2014-12-18 08:58:07'),
(1816, 624, NULL, 'action_id', '63', '2014-12-18 08:58:07', '2014-12-18 08:58:07'),
(1817, 624, NULL, 'created_time', '2014-12-18 11:58:07', '2014-12-18 08:58:07', '2014-12-18 08:58:07');

-- --------------------------------------------------------

--
-- Структура таблицы `dictionary_textfields_values`
--

DROP TABLE IF EXISTS `dictionary_textfields_values`;
CREATE TABLE IF NOT EXISTS `dictionary_textfields_values` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `dicval_id` int(10) unsigned DEFAULT NULL,
  `language` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `value` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `dictionary_textfields_values_dicval_id_index` (`dicval_id`),
  KEY `dictionary_textfields_values_language_index` (`language`),
  KEY `dictionary_textfields_values_key_index` (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `dictionary_values`
--

DROP TABLE IF EXISTS `dictionary_values`;
CREATE TABLE IF NOT EXISTS `dictionary_values` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `version_of` int(10) unsigned DEFAULT NULL,
  `dic_id` int(10) unsigned DEFAULT NULL,
  `slug` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` text COLLATE utf8_unicode_ci,
  `order` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `dictionary_values_version_of_index` (`version_of`),
  KEY `dictionary_values_dic_id_index` (`dic_id`),
  KEY `dictionary_values_slug_index` (`slug`),
  KEY `dictionary_values_order_index` (`order`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=625 ;

--
-- Дамп данных таблицы `dictionary_values`
--

INSERT INTO `dictionary_values` (`id`, `version_of`, `dic_id`, `slug`, `name`, `order`, `created_at`, `updated_at`) VALUES
(1, NULL, 1, 'directions.store', 'Добавлено направление', 0, '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(2, NULL, 1, 'directions.update', 'Обновлено направление', 1, '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(3, NULL, 1, 'directions.destroy', 'Удалено направление', 2, '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(4, NULL, 1, 'courses.store', 'Добавлен курс', 3, '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(5, NULL, 1, 'courses.update', 'Обновлен курс', 4, '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(6, NULL, 1, 'courses.destroy', 'Удален курс', 5, '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(7, NULL, 1, 'chapters.store', 'Добавлена глава', 6, '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(8, NULL, 1, 'chapters.update', 'Обновлена глава', 7, '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(9, NULL, 1, 'chapters.destroy', 'Удалена глава', 8, '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(10, NULL, 1, 'lectures.store', 'Добавлена лекция', 9, '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(11, NULL, 1, 'lectures.update', 'Обновлена лекция', 10, '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(12, NULL, 1, 'lectures.destroy', 'Удалена лекция', 11, '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(13, NULL, 1, 'testing.index', 'Добавлен тест', 12, '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(14, NULL, 1, 'testing.destroy', 'Удален тест', 13, '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(15, NULL, 1, 'dobavlen-otzuv', 'Добавлен отзыв', 14, '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(16, NULL, 1, 'otredaktirovan-otzuv', 'Обновлен отзыв', 15, '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(17, NULL, 1, 'udalen-otzuv', 'Удален отзыв', 16, '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(18, NULL, 1, 'dobavlena-novost', 'Добавлена новость', 17, '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(19, NULL, 1, 'otredaktirovana-novost', 'Обновлена новость', 18, '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(20, NULL, 1, 'udalena-novost', 'Удалена новость', 19, '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(21, NULL, 1, 'otredaktirovan-document', 'Обновлен документ', 20, '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(22, NULL, 1, 'payment-order-number-store', 'Добавлен платеж', 21, '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(23, NULL, 1, 'payment-order-number-update', 'Обновлен платеж', 22, '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(24, NULL, 1, 'payment-order-number-delete', 'Удален платеж', 23, '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(25, NULL, 1, 'change-order-status', 'Изменен статус заказа', 24, '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(26, NULL, 1, 'moderator-company-profile-update', 'Изменен профиль компании', 25, '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(27, NULL, 1, 'moderator-company-profile-activated', 'Активирован аккаунт компании', 26, '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(28, NULL, 1, 'moderator-company-profile-approved', 'Подтвержден аккаунт компании', 27, '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(29, NULL, 1, 'moderator-listener-profile-update', 'Изменен профиль слушателя', 28, '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(30, NULL, 1, 'moderator-listener-profile-activated', 'Активирован аккаунт слушателя', 29, '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(31, NULL, 5, 'count-by-course-discount', 'Количество позиций для применения скидки', 1, '2014-10-29 08:18:38', '2014-12-11 12:55:18'),
(32, NULL, 5, 'count-by-course-discount-percent', 'Величина скидки при оформлении заказа', 0, '2014-10-29 08:18:38', '2014-12-11 12:55:32'),
(33, NULL, 6, 'order-documents-contract', 'Договор для организации', 1, '2014-10-29 08:18:38', '2014-12-17 12:38:55'),
(34, NULL, 6, 'order-documents-invoice', 'Счет (Общий)', 2, '2014-10-29 08:18:38', '2014-12-17 09:24:45'),
(35, NULL, 6, 'order-documents-act', 'Акт (Общий)', 3, '2014-10-29 08:18:38', '2014-12-17 12:33:01'),
(36, NULL, 6, 'order-documents-certificate-first', 'Сертификат первый ', 4, '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(37, NULL, 6, 'order-documents-certificate-second', 'Сертификат второй ', 5, '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(39, NULL, 2, 'otredaktirovan-document.2014-10-30 12:10:23', 'Событие за 30.10.2014 в 12:10', NULL, '2014-10-30 12:10:23', '2014-10-30 12:10:23'),
(41, NULL, 2, 'otredaktirovan-document.2014-10-30 12:10:48', 'Событие за 30.10.2014 в 12:10', NULL, '2014-10-30 12:10:48', '2014-10-30 12:10:48'),
(43, NULL, 2, 'otredaktirovan-document.2014-10-30 12:11:03', 'Событие за 30.10.2014 в 12:11', NULL, '2014-10-30 12:11:03', '2014-10-30 12:11:03'),
(44, NULL, 7, 'organization.approve-email', 'Для активации Вашего личного кабинета и получения доступа к документации Вам необходимо подтвердить e-mail, указанный при регистрации.', 0, '2014-11-05 14:26:33', '2014-12-08 14:19:32'),
(45, NULL, 7, 'organization.save-profile', 'Заполните анкету компании и сможете покупать курсы.', 1, '2014-11-05 14:26:33', '2014-12-08 14:19:32'),
(46, NULL, 7, 'organization.register-listeners', 'Необходимо добавить слушателей – сотрудников Вашей организации, которых необходимо обучить', 2, '2014-11-05 14:26:33', '2014-12-08 14:19:32'),
(47, NULL, 7, 'organization.select-courses', 'Необходимо выбрать курс(ы) и оформить заказ', 3, '2014-11-05 14:26:33', '2014-12-08 14:19:32'),
(48, NULL, 7, 'organization.account-blocked', 'Ваша учетная запись заблокирована. За уточнениями обратитесь к администрации системы.', 4, '2014-11-05 14:26:33', '2014-12-08 14:19:32'),
(49, NULL, 7, 'organization.order-puy', 'Ваш заказ <a href="[order_link]">№[order]</a> оформлен. Для получения доступа к лекционным материалам Вам необходимо оплатить <a href="[document_link]">счет</a>. Доступ предоставляется в течение 2 часов с момента поступления денежных средств на расчетный счет образовательного портала ТЕХВУЗ.РФ', 5, '2014-11-05 14:26:33', '2014-12-08 14:19:32'),
(50, NULL, 7, 'organization.study.begin', '[listener] приступил(а) к обучению по программе [course]. К итоговому тестированию по программе [course] можно будет приступить через 72 академических часа.', 6, '2014-11-05 14:26:33', '2014-12-09 10:59:11'),
(51, NULL, 7, 'organization.study.control', '[listener] успешно завершил(а) промежуточное тестирования по программе [course] с результатом [percent]%.', 7, '2014-11-05 14:26:33', '2014-12-08 14:20:55'),
(52, NULL, 7, 'organization.study.fail-control', '[listener] неудачно завершил(а) промежуточное тестирование по программе [course] с результатом [percent]%.', 9, '2014-11-05 14:26:33', '2014-12-08 14:21:41'),
(53, NULL, 7, 'organization.study.finish', '[listener] прошел(а) итоговое тестирование по программе [course] с результатом [percent]%.', 10, '2014-11-05 14:26:33', '2014-11-05 14:26:33'),
(54, NULL, 7, 'organization.order.new', 'Новый заказ ожидает отправки', 11, '2014-11-05 14:26:33', '2014-11-05 14:26:33'),
(55, NULL, 7, 'organization.order.approve', 'Заказ №[order] ожидает подтверждения администратором', 12, '2014-11-05 14:26:33', '2014-11-05 14:26:33'),
(56, NULL, 7, 'organization.order.not-puy-not-access', 'Заказ <a href="[link]">№[order]</a> не оплачен, доступ к обучению не предоставлен.', 13, '2014-11-05 14:26:33', '2014-12-08 14:22:40'),
(57, NULL, 7, 'organization.order.not-puy-yes-access', 'Заказ <a href="[link]">№[order]</a> не оплачен, но доступ к обучению предоставлен.', 14, '2014-11-05 14:26:33', '2014-12-08 14:23:00'),
(58, NULL, 7, 'organization.order.part-puy-not-access', 'Заказ <a href="[link]">№[order]</a> оплачен частично.', 15, '2014-11-05 14:26:33', '2014-12-08 14:23:14'),
(59, NULL, 7, 'organization.order.part-puy-yes-access', 'Заказ <a href="[link]">№[order]</a> оплачен частично, но доступ к обучению предоставлен.', 16, '2014-11-05 14:26:33', '2014-12-08 14:23:39'),
(60, NULL, 7, 'organization.order.yes-puy-yes-access', 'Заказ <a href="[link]">№[order]</a> оплачен. Сотрудники Вашей организации могут приступить к обучению.', 17, '2014-11-05 14:26:33', '2014-11-05 14:26:33'),
(61, NULL, 7, 'moderator.register-organization', 'Зарегистрирована организация <a href="[link]">[organization]</a>', 18, '2014-11-05 14:26:33', '2014-11-05 14:26:33'),
(62, NULL, 7, 'moderator.update-profile-organization', 'Организация [organization] обновила регистрационные данные', 19, '2014-11-05 14:26:33', '2014-11-05 14:26:33'),
(63, NULL, 7, 'moderator.register-listener', '[listener] добавлен(а) к слушателям – сотрудникам [organization]', 20, '2014-11-05 14:26:33', '2014-11-14 14:57:36'),
(64, NULL, 7, 'moderator.update-profile-listener', 'Сотрудник организации [organization], [listener],  обновил(-а) регистрационные данные', 21, '2014-11-05 14:26:33', '2014-11-05 14:26:33'),
(65, NULL, 7, 'moderator.order.new', 'Оформлен заказ №[order]', 22, '2014-11-05 14:26:33', '2014-11-05 14:26:33'),
(66, NULL, 7, 'moderator.order.closed', 'Заказ №[order] закрыт', 23, '2014-11-05 11:32:22', '2014-11-05 08:23:28'),
(67, NULL, 7, 'organization.order.closed', 'Заказ <a href="[link]">№[order]</a> закрыт. Все сотрудники Вашей организации успешно прошли итоговые тестирования по заданным курсам.', 24, '2014-11-05 08:21:37', '2014-11-05 07:25:33'),
(68, NULL, 7, 'organization.order.yes-puy-not-access', 'Заказ [order] оплачен, но доступ к обучению не предоставлен.', 25, '2014-11-05 13:36:34', '2014-11-05 14:39:30'),
(69, NULL, 1, 'moderator-order-arhived', 'Заказ помещен в архив', 30, '2014-11-06 07:22:38', '2014-11-06 06:28:18'),
(70, NULL, 1, 'moderator-order-delete', 'Заказ удален', 31, '2014-11-06 05:23:31', '2014-11-06 05:21:33'),
(73, NULL, 8, 'organization.approve-email.2014-11-06 14:14:44', 'Подтвердите свой e-mail (пройдите по ссылке, направленной на указанный при регистрации адрес)', NULL, '2014-11-06 14:14:44', '2014-11-06 14:14:44'),
(74, NULL, 8, 'organization.save-profile.2014-11-06 14:14:44', 'Заполните анкету компании и сможете покупать курсы.', NULL, '2014-11-06 14:14:44', '2014-11-06 14:14:44'),
(75, NULL, 8, 'organization.register-listeners.2014-11-06 14:14:44', 'Добавьте слушателей — сотрудников, которых нужно обучить.', NULL, '2014-11-06 14:14:44', '2014-11-06 14:14:44'),
(76, NULL, 8, 'organization.select-courses.2014-11-06 14:14:44', 'Выберите нужные курсы, назначьте слушателей и оформите заказ.', NULL, '2014-11-06 14:14:44', '2014-11-06 14:14:44'),
(77, NULL, 8, 'moderator.register-organization.2014-11-06 14:14:44', 'Зарегистрирована организация Управление финансового контроля Ростовской области', NULL, '2014-11-06 14:14:44', '2014-11-06 14:14:44'),
(78, NULL, 7, 'organization.order-puy-no-approve', 'Ваш заказ <a href="[link]">№[order]</a> оформлен. Для получения договора на обучение и счета на оплату платных образовательных услуг необходимо дождаться окончания проверки администратором сайта. Проверка занимает не более 12 часов с момента активации личного кабинета', 26, '2014-11-06 06:27:17', '2014-11-06 11:24:22'),
(90, NULL, 8, 'moderator.register-listener.2014-11-06 15:47:24', 'Организация Управление финансового контроля Ростовской области зарегистрировала Сорбат Владимир Николаевич как сотрудника', NULL, '2014-11-06 15:47:24', '2014-11-06 15:47:24'),
(91, NULL, 8, 'organization.order-puy.2014-11-06 16:19:44', 'Для начала обучения оплатите счет <a href="http://techvuz.dev.grapheme.ru/organization/order/1">№001-14</a>.', NULL, '2014-11-06 16:19:44', '2014-11-06 16:19:44'),
(92, NULL, 8, 'moderator.order.new.2014-11-06 16:19:44', 'Оформлен заказ №001-14', NULL, '2014-11-06 16:19:44', '2014-11-06 16:19:44'),
(93, NULL, 2, 'moderator-company-profile-approved.2014-11-06 16:27:42', 'Управление финансового контроля Ростовской области', NULL, '2014-11-06 16:27:42', '2014-11-06 16:27:42'),
(94, NULL, 2, 'moderator-company-profile-update.2014-11-06 16:27:42', 'Организация: Управление финансового контроля Ростовской области', NULL, '2014-11-06 16:27:42', '2014-11-06 16:27:42'),
(95, NULL, 8, 'organization.order.yes-puy-yes-access.2014-11-06 16:29:43', 'Заказ №001-14 оплачен, доступ к обучению предоставлен.', NULL, '2014-11-06 16:29:43', '2014-11-06 16:29:43'),
(96, NULL, 2, 'change-order-status.2014-11-06 16:29:43', 'Заказ №1', NULL, '2014-11-06 16:29:43', '2014-11-06 16:29:43'),
(97, NULL, 2, 'payment-order-number-store.2014-11-06 16:30:04', 'Заказ №1. Сумма: 8000.00 руб.', NULL, '2014-11-06 16:30:04', '2014-11-06 16:30:04'),
(98, NULL, 8, 'organization.study.begin.2014-11-06 16:32:12', 'Начало обучения — сотрудник Сорбат Владимир Николаевич открыл первую лекцию курса Строительство, реконструкция, капитальный ремонт объектов капитального строительства', NULL, '2014-11-06 16:32:12', '2014-11-06 16:32:12'),
(99, NULL, 8, 'organization.study.fail.2014-11-06 16:54:44', 'Неудачные попытки — курс Строительство, реконструкция, капитальный ремонт объектов капитального строительства: сотрудник Сорбат Владимир Николаевич неудачно завершил промежуточное/итоговое тестирование с результатом 0%.', NULL, '2014-11-06 16:54:44', '2014-11-06 16:54:44'),
(100, NULL, 8, 'organization.study.fail.2014-11-06 17:01:52', 'Неудачные попытки — курс Строительство, реконструкция, капитальный ремонт объектов капитального строительства: сотрудник Сорбат Владимир Николаевич неудачно завершил промежуточное/итоговое тестирование с результатом 0%.', NULL, '2014-11-06 17:01:52', '2014-11-06 17:01:52'),
(101, NULL, 8, 'organization.study.control.2014-11-06 17:19:37', 'Контрольные точки — курс Строительство, реконструкция, капитальный ремонт объектов капитального строительства: сотрудник Сорбат Владимир Николаевич успешно завершил промежуточное тестирования с результатом 100%.', NULL, '2014-11-06 17:19:37', '2014-11-06 17:19:37'),
(102, NULL, 8, 'organization.study.fail.2014-11-06 17:21:58', 'Неудачные попытки — курс Строительство, реконструкция, капитальный ремонт объектов капитального строительства: сотрудник Сорбат Владимир Николаевич неудачно завершил промежуточное/итоговое тестирование с результатом 0%.', NULL, '2014-11-06 17:21:58', '2014-11-06 17:21:58'),
(103, NULL, 8, 'organization.study.fail.2014-11-06 17:21:59', 'Неудачные попытки — курс Строительство, реконструкция, капитальный ремонт объектов капитального строительства: сотрудник Сорбат Владимир Николаевич неудачно завершил промежуточное/итоговое тестирование с результатом 0%.', NULL, '2014-11-06 17:21:59', '2014-11-06 17:21:59'),
(104, NULL, 8, 'organization.study.control.2014-11-06 17:22:04', 'Контрольные точки — курс Строительство, реконструкция, капитальный ремонт объектов капитального строительства: сотрудник Сорбат Владимир Николаевич успешно завершил промежуточное тестирования с результатом 100%.', NULL, '2014-11-06 17:22:04', '2014-11-06 17:22:04'),
(105, NULL, 8, 'organization.study.finish.2014-11-06 17:22:55', 'Итоговый результат — сотрудник Сорбат Владимир Николаевич завершил обучение по курсу Строительство, реконструкция, капитальный ремонт объектов капитального строительства. Итоговое тестирование завершено с результатом 100%.', NULL, '2014-11-06 17:22:55', '2014-11-06 17:22:55'),
(106, NULL, 8, 'organization.order.closed.2014-11-06 17:22:55', 'Заказ <a href="http://techvuz.dev.grapheme.ru/organization/order/1">№001-14</a> закрылся', NULL, '2014-11-06 17:22:55', '2014-11-06 17:22:55'),
(107, NULL, 8, 'moderator.order.closed.2014-11-06 17:22:55', 'Заказ №001-14 закрыт', NULL, '2014-11-06 17:22:55', '2014-11-06 17:22:55'),
(108, NULL, 8, 'organization.study.finish.2014-11-06 17:30:56', 'Итоговый результат — сотрудник Сорбат Владимир Николаевич завершил обучение по курсу Строительство, реконструкция, капитальный ремонт объектов капитального строительства (выполнение геодезических, подготовительных и земляных работ, устройства оснований и ', NULL, '2014-11-06 17:30:56', '2014-11-06 17:30:56'),
(109, NULL, 8, 'organization.order.closed.2014-11-06 17:30:56', 'Заказ <a href="http://techvuz.dev.grapheme.ru/organization/order/1">№001-14</a> закрылся', NULL, '2014-11-06 17:30:56', '2014-11-06 17:30:56'),
(110, NULL, 8, 'moderator.order.closed.2014-11-06 17:30:56', 'Заказ №001-14 закрыт', NULL, '2014-11-06 17:30:56', '2014-11-06 17:30:56'),
(111, NULL, 8, 'organization.study.finish.2014-11-06 17:33:15', 'Итоговый результат — сотрудник Сорбат Владимир Николаевич завершил обучение по курсу Строительство, реконструкция, капитальный ремонт объектов капитального строительства (выполнение геодезических, подготовительных и земляных работ, устройства оснований и ', NULL, '2014-11-06 17:33:15', '2014-11-06 17:33:15'),
(112, NULL, 8, 'organization.order.closed.2014-11-06 17:33:15', 'Заказ <a href="http://techvuz.dev.grapheme.ru/organization/order/1">№001-14</a> закрылся', NULL, '2014-11-06 17:33:15', '2014-11-06 17:33:15'),
(113, NULL, 8, 'moderator.order.closed.2014-11-06 17:33:15', 'Заказ №001-14 закрыт', NULL, '2014-11-06 17:33:15', '2014-11-06 17:33:15'),
(114, NULL, 8, 'organization.study.finish.2014-11-06 17:34:19', 'Итоговый результат — сотрудник Сорбат Владимир Николаевич завершил обучение по курсу Строительство, реконструкция, капитальный ремонт объектов капитального строительства (выполнение геодезических, подготовительных и земляных работ, устройства оснований и ', NULL, '2014-11-06 17:34:19', '2014-11-06 17:34:19'),
(115, NULL, 8, 'organization.order.closed.2014-11-06 17:34:19', 'Заказ <a href="http://techvuz.dev.grapheme.ru/organization/order/1">№001-14</a> закрылся', NULL, '2014-11-06 17:34:19', '2014-11-06 17:34:19'),
(116, NULL, 8, 'moderator.order.closed.2014-11-06 17:34:19', 'Заказ №001-14 закрыт', NULL, '2014-11-06 17:34:19', '2014-11-06 17:34:19'),
(117, NULL, 8, 'organization.approve-email.2014-11-07 14:20:04', 'Подтвердите свой e-mail (пройдите по ссылке, направленной на указанный при регистрации адрес)', NULL, '2014-11-07 14:20:04', '2014-11-07 14:20:04'),
(118, NULL, 8, 'organization.register-listeners.2014-11-07 14:20:04', 'Добавьте слушателей — сотрудников, которых нужно обучить.', NULL, '2014-11-07 14:20:04', '2014-11-07 14:20:04'),
(120, NULL, 8, 'moderator.register-organization.2014-11-07 14:20:04', 'Зарегистрирована организация Графема', NULL, '2014-11-07 14:20:04', '2014-11-07 14:20:04'),
(121, NULL, 8, 'moderator.register-listener.2014-11-07 14:20:58', 'Организация Графема зарегистрировала Харсеев Владимир Александрович как сотрудника', NULL, '2014-11-07 14:20:58', '2014-11-07 14:20:58'),
(123, NULL, 8, 'moderator.order.new.2014-11-07 14:30:13', 'Оформлен заказ №002-14', NULL, '2014-11-07 14:30:13', '2014-11-07 14:30:13'),
(124, NULL, 8, 'organization.order-puy.2014-11-07 14:31:45', 'Для начала обучения оплатите счет <a href="http://techvuz.dev.grapheme.ru/organization/order/3/invoice/pdf">№003-14</a>.', NULL, '2014-11-07 14:31:45', '2014-11-07 14:31:45'),
(125, NULL, 8, 'moderator.order.new.2014-11-07 14:31:45', 'Оформлен заказ №003-14', NULL, '2014-11-07 14:31:45', '2014-11-07 14:31:45'),
(127, NULL, 2, 'otredaktirovan-document.2014-11-07 14:33:02', 'Событие за 07.11.2014 в 14:33', NULL, '2014-11-07 14:33:02', '2014-11-07 14:33:02'),
(129, NULL, 2, 'otredaktirovan-document.2014-11-07 14:33:22', 'Событие за 07.11.2014 в 14:33', NULL, '2014-11-07 14:33:22', '2014-11-07 14:33:22'),
(131, NULL, 2, 'otredaktirovan-document.2014-11-07 14:33:43', 'Событие за 07.11.2014 в 14:33', NULL, '2014-11-07 14:33:43', '2014-11-07 14:33:43'),
(132, NULL, 1, 'moderator-order-update', 'Заказ обновлен', 32, '2014-11-10 07:25:40', '2014-11-10 05:16:27'),
(134, NULL, 2, 'otredaktirovan-document.2014-11-10 13:27:27', 'Событие за 10.11.2014 в 13:27', NULL, '2014-11-10 13:27:27', '2014-11-10 13:27:27'),
(136, NULL, 2, 'otredaktirovan-document.2014-11-10 13:27:51', 'Событие за 10.11.2014 в 13:27', NULL, '2014-11-10 13:27:51', '2014-11-10 13:27:51'),
(138, NULL, 2, 'otredaktirovan-document.2014-11-10 14:10:14', 'Событие за 10.11.2014 в 14:10', NULL, '2014-11-10 14:10:14', '2014-11-10 14:10:14'),
(140, NULL, 2, 'otredaktirovan-document.2014-11-10 14:11:10', 'Событие за 10.11.2014 в 14:11', NULL, '2014-11-10 14:11:10', '2014-11-10 14:11:10'),
(142, NULL, 2, 'otredaktirovan-document.2014-11-10 14:11:29', 'Событие за 10.11.2014 в 14:11', NULL, '2014-11-10 14:11:29', '2014-11-10 14:11:29'),
(144, NULL, 2, 'otredaktirovan-document.2014-11-10 15:16:47', 'Событие за 10.11.2014 в 15:16', NULL, '2014-11-10 15:16:47', '2014-11-10 15:16:47'),
(146, NULL, 2, 'otredaktirovan-document.2014-11-10 15:17:08', 'Событие за 10.11.2014 в 15:17', NULL, '2014-11-10 15:17:08', '2014-11-10 15:17:08'),
(148, NULL, 2, 'otredaktirovan-document.2014-11-10 15:17:25', 'Событие за 10.11.2014 в 15:17', NULL, '2014-11-10 15:17:25', '2014-11-10 15:17:25'),
(150, NULL, 2, 'moderator-order-delete.2014-11-10 15:42:46', '№003-14', NULL, '2014-11-10 15:42:46', '2014-11-10 15:42:46'),
(151, NULL, 2, 'moderator-order-delete.2014-11-10 15:42:46', '№003-14', NULL, '2014-11-10 15:42:46', '2014-11-10 15:42:46'),
(152, NULL, 2, 'moderator-order-delete.2014-11-10 15:42:55', '№002-14', NULL, '2014-11-10 15:42:55', '2014-11-10 15:42:55'),
(153, NULL, 2, 'moderator-order-delete.2014-11-10 15:42:55', '№002-14', NULL, '2014-11-10 15:42:55', '2014-11-10 15:42:55'),
(154, NULL, 8, 'organization.order-puy.2014-11-10 15:43:28', 'Для начала обучения оплатите счет <a href="http://techvuz.dev.grapheme.ru/organization/order/4/invoice/pdf">№002-14</a>.', NULL, '2014-11-10 15:43:28', '2014-11-10 15:43:28'),
(155, NULL, 8, 'moderator.order.new.2014-11-10 15:43:28', 'Оформлен заказ №002-14', NULL, '2014-11-10 15:43:28', '2014-11-10 15:43:28'),
(156, NULL, 2, 'moderator-order-update.2014-11-11 14:38:46', '№001-14', NULL, '2014-11-11 14:38:46', '2014-11-11 14:38:46'),
(157, NULL, 7, 'account.approved-email', 'Ваш личный кабинет активирован. Происходит проверка администратором сайта', 27, '2014-11-14 07:18:28', '2014-12-11 09:31:26'),
(159, NULL, 7, 'account.approved-profile', 'Вы успешно прошли проверку администратора сайта ТЕХВУЗ.РФ. Теперь у Вас появился доступ к документации (договоры, счета, акты).', 28, '2014-11-18 07:17:34', '2014-11-18 07:18:35'),
(160, NULL, 7, 'organization.order.closed-documents', 'Для получения сканированных копий документов Ваших сотрудников пройдите по <a href="[link]">ссылке</a>. Для получения оригиналов документов отправьте Почтой России, подписанные с Вашей стороны в 2-х экземплярах договор на оказание платных образовательных услуг и акт о выполнении работ.', 29, '2014-11-18 06:25:25', '2014-11-18 06:29:18'),
(162, NULL, 2, 'otredaktirovan-document.2014-11-19 11:30:37', 'Событие за 19.11.2014 в 11:30', NULL, '2014-11-19 11:30:37', '2014-11-19 11:30:37'),
(164, NULL, 2, 'otredaktirovan-document.2014-11-19 11:31:07', 'Событие за 19.11.2014 в 11:31', NULL, '2014-11-19 11:31:07', '2014-11-19 11:31:07'),
(166, NULL, 2, 'otredaktirovan-document.2014-11-19 11:44:15', 'Событие за 19.11.2014 в 11:44', NULL, '2014-11-19 11:44:15', '2014-11-19 11:44:15'),
(167, NULL, 6, 'order-documents-contract-listeners', 'Приложение №1 к договору организации', 2, '2014-10-29 11:18:38', '2014-12-04 12:00:07'),
(169, NULL, 2, 'otredaktirovan-document.2014-11-19 12:01:44', 'Событие за 19.11.2014 в 12:01', NULL, '2014-11-19 12:01:44', '2014-11-19 12:01:44'),
(170, NULL, 6, 'order-documents-contract-consent', 'Согласие на обработку персональных данных к договору', 3, '2014-10-29 11:18:38', '2014-11-19 13:39:37'),
(172, NULL, 2, 'otredaktirovan-document.2014-11-19 13:39:37', 'Событие за 19.11.2014 в 13:39', NULL, '2014-11-19 13:39:37', '2014-11-19 13:39:37'),
(174, NULL, 2, 'otredaktirovan-document.2014-11-19 14:36:05', 'Событие за 19.11.2014 в 14:36', NULL, '2014-11-19 14:36:05', '2014-11-19 14:36:05'),
(176, NULL, 2, 'otredaktirovan-document.2014-11-19 14:58:27', 'Событие за 19.11.2014 в 14:58', NULL, '2014-11-19 14:58:27', '2014-11-19 14:58:27'),
(178, NULL, 2, 'otredaktirovan-document.2014-11-19 16:24:40', 'Событие за 19.11.2014 в 16:24', NULL, '2014-11-19 16:24:40', '2014-11-19 16:24:40'),
(180, NULL, 2, 'otredaktirovan-document.2014-11-19 16:30:58', 'Событие за 19.11.2014 в 16:30', NULL, '2014-11-19 16:30:58', '2014-11-19 16:30:58'),
(182, NULL, 2, 'otredaktirovan-document.2014-11-19 16:31:30', 'Событие за 19.11.2014 в 16:31', NULL, '2014-11-19 16:31:30', '2014-11-19 16:31:30'),
(184, NULL, 2, 'otredaktirovan-document.2014-11-19 16:32:40', 'Событие за 19.11.2014 в 16:32', NULL, '2014-11-19 16:32:40', '2014-11-19 16:32:40'),
(185, NULL, 8, 'moderator.register-organization.2014-11-26 13:13:31', 'Зарегистрирована организация ПМЖ-11', NULL, '2014-11-26 13:13:31', '2014-11-26 13:13:31'),
(186, NULL, 8, 'moderator.register-organization.2014-11-26 13:18:38', 'Зарегистрирована организация ПМЖ-12', NULL, '2014-11-26 13:18:38', '2014-11-26 13:18:38'),
(187, NULL, 8, 'organization.select-courses.2014-11-26 13:19:49', '«Необходимо выбрать курс(ы) и оформить заказ»', NULL, '2014-11-26 13:19:49', '2014-11-26 13:19:49'),
(188, NULL, 8, 'organization.register-listeners.2014-11-26 13:19:49', '«Необходимо добавить слушателей – сотрудников Вашей организации, которых необходимо обучить»', NULL, '2014-11-26 13:19:49', '2014-11-26 13:19:49'),
(189, NULL, 8, 'account.approved-email.2014-11-26 13:19:49', '«Ваш личный кабинет активирован. Происходит проверка администратором сайта»', NULL, '2014-11-26 13:19:49', '2014-11-26 13:19:49'),
(191, NULL, 8, 'moderator.register-listener.2014-11-26 13:31:15', 'Иванов Иван Иванович добавлен(а) к слушателям – сотрудникам ПМЖ-12', NULL, '2014-11-26 13:31:15', '2014-11-26 13:31:15'),
(192, NULL, 8, 'organization.order-puy-no-approve.2014-11-26 13:31:46', 'Ваш заказ <a href="http://techvuz.dev.grapheme.ru/organization/order/5">№002-14</a> оформлен. Для получения договора на обучение и счета на оплату платных образовательных услуг необходимо дождаться окончания проверки администратором сайта. Проверка занимает не более 12 часов с момента активации личного кабинета', NULL, '2014-11-26 13:31:46', '2014-11-26 13:31:46'),
(193, NULL, 8, 'moderator.order.new.2014-11-26 13:31:46', 'Оформлен заказ №002-14', NULL, '2014-11-26 13:31:46', '2014-11-26 13:31:46'),
(194, NULL, 8, 'moderator.register-organization.2014-11-27 08:40:55', 'Зарегистрирована организация ООО "Ковровский механический завод"', NULL, '2014-11-27 08:40:55', '2014-11-27 08:40:55'),
(195, NULL, 8, 'moderator.register-listener.2014-11-27 13:39:01', 'Помидоров Аркадий Иванович добавлен(а) к слушателям – сотрудникам ПМЖ-12', NULL, '2014-11-27 13:39:01', '2014-11-27 13:39:01'),
(196, NULL, 8, 'organization.order-puy-no-approve.2014-11-28 10:51:33', 'Ваш заказ <a href="http://techvuz.dev.grapheme.ru/organization/order/6">№003-14</a> оформлен. Для получения договора на обучение и счета на оплату платных образовательных услуг необходимо дождаться окончания проверки администратором сайта. Проверка занимает не более 12 часов с момента активации личного кабинета', NULL, '2014-11-28 10:51:33', '2014-11-28 10:51:33'),
(197, NULL, 8, 'moderator.order.new.2014-11-28 10:51:33', 'Оформлен заказ №003-14', NULL, '2014-11-28 10:51:33', '2014-11-28 10:51:33'),
(198, NULL, 8, 'organization.order.not-puy-yes-access.2014-11-28 11:15:30', 'Заказ №003-14 не оплачен, но доступ к обучению предоставлен.', NULL, '2014-11-28 11:15:30', '2014-11-28 11:15:30'),
(199, NULL, 2, 'change-order-status.2014-11-28 11:15:30', 'Заказ №3', NULL, '2014-11-28 11:15:30', '2014-11-28 11:15:30'),
(200, NULL, 8, 'organization.study.begin.2014-11-28 11:16:11', 'Помидоров Аркадий Иванович приступил к обучению по программе БС-03. К итоговому тестированию по программе БС-03 можно будет приступить через 72 академических часа.', NULL, '2014-11-28 11:16:11', '2014-11-28 11:16:11'),
(201, NULL, 2, 'moderator-company-profile-approved.2014-11-28 11:27:09', 'ПМЖ-12', NULL, '2014-11-28 11:27:09', '2014-11-28 11:27:09'),
(202, NULL, 8, 'account.approved-profile.2014-11-28 11:27:09', 'Вы успешно прошли проверку администратора сайта ТЕХВУЗ.РФ. Теперь у Вас появился доступ к документации (договоры, счета, акты).', NULL, '2014-11-28 11:27:09', '2014-11-28 11:27:09'),
(203, NULL, 2, 'moderator-company-profile-update.2014-11-28 11:27:09', 'Организация: ПМЖ-12', NULL, '2014-11-28 11:27:09', '2014-11-28 11:27:09'),
(204, NULL, 2, 'testing.index.2014-11-28 14:30:40', 'Промежуточное тестирование. Курс: Строительство, реконструкция, капитальный ремонт объектов капитального строительства (возведение каменных, металлических и деревянных строительных конструкций)', NULL, '2014-11-28 14:30:40', '2014-11-28 14:30:40'),
(206, NULL, 8, 'moderator.register-listener.2014-11-28 15:02:13', 'Огурцов Анатолий Степонович добавлен(а) к слушателям – сотрудникам ПМЖ-12', NULL, '2014-11-28 15:02:13', '2014-11-28 15:02:13'),
(207, NULL, 8, 'account.approved-email.2014-11-28 15:10:13', '«Ваш личный кабинет активирован. Происходит проверка администратором сайта»', NULL, '2014-11-28 15:10:13', '2014-11-28 15:10:13'),
(208, NULL, 8, 'account.approved-email.2014-11-28 15:10:13', '«Ваш личный кабинет активирован. Происходит проверка администратором сайта»', NULL, '2014-11-28 15:10:13', '2014-11-28 15:10:13'),
(209, NULL, 8, 'organization.study.fail.2014-11-28 16:34:34', 'Помидоров Аркадий Иванович неудачно завершил(ла) промежуточное/итоговое тестирование по программе БС-03 с результатом 0%.', NULL, '2014-11-28 16:34:34', '2014-11-28 16:34:34'),
(210, NULL, 8, 'organization.study.fail.2014-11-28 16:56:18', 'Помидоров Аркадий Иванович неудачно завершил(ла) промежуточное/итоговое тестирование по программе БС-03 с результатом 0%.', NULL, '2014-11-28 16:56:18', '2014-11-28 16:56:18'),
(211, NULL, 8, 'moderator.register-organization.2014-12-01 13:34:18', 'Зарегистрирована организация Test', NULL, '2014-12-01 13:34:18', '2014-12-01 13:34:18'),
(212, NULL, 8, 'organization.study.control.2014-12-01 14:29:15', 'Помидоров Аркадий Иванович успешно завершил(ла) промежуточное тестирования по программе БС-03 с результатом 100%.', NULL, '2014-12-01 14:29:15', '2014-12-01 14:29:15'),
(214, NULL, 7, 'organization.study.fail-finish', '[listener] неудачно завершил(а) итоговое тестирование по программе [course] с результатом [percent]%.', 8, '2014-11-05 14:26:33', '2014-12-08 14:21:13'),
(215, NULL, 8, 'organization.study.control.2014-12-01 15:29:49', 'Помидоров Аркадий Иванович успешно завершил(ла) промежуточное тестирования по программе БС-03 с результатом 100%.', NULL, '2014-12-01 15:29:49', '2014-12-01 15:29:49'),
(216, NULL, 8, 'organization.study.fail-finish.2014-12-01 15:30:26', 'Помидоров Аркадий Иванович неудачно завершил(ла) итоговое тестирование по программе БС-03 с результатом 0%.', NULL, '2014-12-01 15:30:26', '2014-12-01 15:30:26'),
(217, NULL, 8, 'organization.study.control.2014-12-01 15:30:50', 'Помидоров Аркадий Иванович успешно завершил(ла) промежуточное тестирования по программе БС-03 с результатом 100%.', NULL, '2014-12-01 15:30:50', '2014-12-01 15:30:50'),
(218, NULL, 8, 'organization.study.control.2014-12-01 16:08:49', 'Помидоров Аркадий Иванович успешно завершил(ла) промежуточное тестирования по программе БС-03 с результатом 100%.', NULL, '2014-12-01 16:08:49', '2014-12-01 16:08:49'),
(219, NULL, 8, 'moderator.register-organization.2014-12-02 08:49:55', 'Зарегистрирована организация ООО "Ковровский механический завод"', NULL, '2014-12-02 08:49:55', '2014-12-02 08:49:55'),
(220, NULL, 8, 'organization.select-courses.2014-12-02 08:51:25', '«Необходимо выбрать курс(ы) и оформить заказ»', NULL, '2014-12-02 08:51:25', '2014-12-02 08:51:25'),
(221, NULL, 8, 'organization.register-listeners.2014-12-02 08:51:25', '«Необходимо добавить слушателей – сотрудников Вашей организации, которых необходимо обучить»', NULL, '2014-12-02 08:51:25', '2014-12-02 08:51:25'),
(222, NULL, 8, 'account.approved-email.2014-12-02 08:51:25', '«Ваш личный кабинет активирован. Происходит проверка администратором сайта»', NULL, '2014-12-02 08:51:25', '2014-12-02 08:51:25'),
(223, NULL, 8, 'account.approved-email.2014-12-02 08:51:25', '«Ваш личный кабинет активирован. Происходит проверка администратором сайта»', NULL, '2014-12-02 08:51:25', '2014-12-02 08:51:25'),
(224, NULL, 8, 'moderator.register-organization.2014-12-02 09:01:42', 'Зарегистрирована организация ООО "Ковровский механический завод"', NULL, '2014-12-02 09:01:42', '2014-12-02 09:01:42'),
(225, NULL, 8, 'organization.select-courses.2014-12-02 09:02:03', '«Необходимо выбрать курс(ы) и оформить заказ»', NULL, '2014-12-02 09:02:03', '2014-12-02 09:02:03'),
(226, NULL, 8, 'organization.register-listeners.2014-12-02 09:02:03', '«Необходимо добавить слушателей – сотрудников Вашей организации, которых необходимо обучить»', NULL, '2014-12-02 09:02:03', '2014-12-02 09:02:03'),
(227, NULL, 8, 'account.approved-email.2014-12-02 09:02:04', '«Ваш личный кабинет активирован. Происходит проверка администратором сайта»', NULL, '2014-12-02 09:02:04', '2014-12-02 09:02:04'),
(229, NULL, 2, 'otredaktirovan-document.2014-12-02 12:09:33', 'Событие за 02.12.2014 в 12:09', NULL, '2014-12-02 12:09:33', '2014-12-02 12:09:33'),
(230, NULL, 8, 'organization.order.yes-puy-yes-access.2014-12-02 12:18:06', 'Заказ <a href="http://techvuz.dev.grapheme.ru/organization/order/5">№002-14</a> оплачен. Сотрудники Вашей организации могут приступить к обучению.', NULL, '2014-12-02 12:18:06', '2014-12-02 12:18:06'),
(231, NULL, 2, 'change-order-status.2014-12-02 12:18:06', 'Заказ №2', NULL, '2014-12-02 12:18:06', '2014-12-02 12:18:06'),
(232, NULL, 8, 'organization.order.yes-puy-yes-access.2014-12-02 12:19:04', 'Заказ <a href="http://techvuz.dev.grapheme.ru/organization/order/5">№002-14</a> оплачен. Сотрудники Вашей организации могут приступить к обучению.', NULL, '2014-12-02 12:19:04', '2014-12-02 12:19:04'),
(233, NULL, 2, 'payment-order-number-store.2014-12-02 12:19:04', 'Заказ №1. Сумма: 4000 руб.', NULL, '2014-12-02 12:19:04', '2014-12-02 12:19:04'),
(234, NULL, 2, 'testing.index.2014-12-02 12:30:00', 'Итоговое тестирование. Курс: Строительство, реконструкция, капитальный ремонт объектов капитального строительства (возведение каменных, металлических и деревянных строительных конструкций)', NULL, '2014-12-02 12:30:00', '2014-12-02 12:30:00'),
(235, NULL, 8, 'organization.study.finish.2014-12-02 12:30:53', 'Помидоров Аркадий Иванович прошел(ла) итоговое тестирование по программе БС-03 с результатом 100%.', NULL, '2014-12-02 12:30:53', '2014-12-02 12:30:53'),
(236, NULL, 8, 'organization.study.begin.2014-12-02 12:37:38', 'Помидоров Аркадий Иванович приступил к обучению по программе БС-16. К итоговому тестированию по программе БС-16 можно будет приступить через 72 академических часа.', NULL, '2014-12-02 12:37:38', '2014-12-02 12:37:38'),
(238, NULL, 2, 'otredaktirovan-document.2014-12-02 12:45:25', 'Событие за 02.12.2014 в 12:45', NULL, '2014-12-02 12:45:25', '2014-12-02 12:45:25'),
(239, NULL, 8, 'moderator.register-organization.2014-12-02 13:08:42', 'Зарегистрирована организация Общество с ограниченной ответственностью Техническая Экспертиза Зданий и Сооружений ', NULL, '2014-12-02 13:08:42', '2014-12-02 13:08:42'),
(240, NULL, 8, 'moderator.register-listener.2014-12-02 13:15:51', 'Жуков Игорь Алексеевич добавлен(а) к слушателям – сотрудникам Общество с ограниченной ответственностью Техническая Экспертиза Зданий и Сооружений ', NULL, '2014-12-02 13:15:51', '2014-12-02 13:15:51'),
(241, NULL, 8, 'moderator.register-listener.2014-12-02 13:21:37', 'Бирючинский Алексей Николаевич добавлен(а) к слушателям – сотрудникам Общество с ограниченной ответственностью Техническая Экспертиза Зданий и Сооружений ', NULL, '2014-12-02 13:21:37', '2014-12-02 13:21:37'),
(242, NULL, 8, 'organization.order-puy-no-approve.2014-12-02 13:23:02', 'Ваш заказ <a href="http://techvuz.dev.grapheme.ru/organization/order/7">№004-14</a> оформлен. Для получения договора на обучение и счета на оплату платных образовательных услуг необходимо дождаться окончания проверки администратором сайта. Проверка занимает не более 12 часов с момента активации личного кабинета', NULL, '2014-12-02 13:23:02', '2014-12-02 13:23:02'),
(243, NULL, 8, 'moderator.order.new.2014-12-02 13:23:02', 'Оформлен заказ №004-14', NULL, '2014-12-02 13:23:02', '2014-12-02 13:23:02'),
(244, NULL, 8, 'organization.order-puy.2014-12-02 15:24:28', 'Ваш заказ №005-14 оформлен. Для получения доступа к лекционным материалам Вам необходимо оплатить <a href="http://techvuz.dev.grapheme.ru/organization/order/8/invoice/pdf">счет</a>. Доступ предоставляется в течение 2 часов с момента поступления денежных средств на расчетный счет образовательного портала ТЕХВУЗ.РФ', NULL, '2014-12-02 15:24:28', '2014-12-02 15:24:28'),
(245, NULL, 8, 'moderator.order.new.2014-12-02 15:24:28', 'Оформлен заказ №005-14', NULL, '2014-12-02 15:24:28', '2014-12-02 15:24:28'),
(246, NULL, 8, 'organization.order.yes-puy-yes-access.2014-12-02 15:24:53', 'Заказ <a href="http://techvuz.dev.grapheme.ru/organization/order/8">№005-14</a> оплачен. Сотрудники Вашей организации могут приступить к обучению.', NULL, '2014-12-02 15:24:53', '2014-12-02 15:24:53'),
(247, NULL, 2, 'change-order-status.2014-12-02 15:24:53', 'Заказ №5', NULL, '2014-12-02 15:24:53', '2014-12-02 15:24:53'),
(248, NULL, 8, 'organization.order.part-puy-yes-access.2014-12-02 15:25:07', 'Заказ №005-14 оплачен частично, но доступ к обучению предоставлен.', NULL, '2014-12-02 15:25:07', '2014-12-02 15:25:07'),
(249, NULL, 2, 'change-order-status.2014-12-02 15:25:07', 'Заказ №5', NULL, '2014-12-02 15:25:07', '2014-12-02 15:25:07'),
(251, NULL, 2, 'change-order-status.2014-12-02 16:10:03', 'Заказ №5', NULL, '2014-12-02 16:10:03', '2014-12-02 16:10:03'),
(252, NULL, 8, 'organization.order-puy.2014-12-02 16:45:12', 'Ваш заказ №006-14 оформлен. Для получения доступа к лекционным материалам Вам необходимо оплатить <a href="http://techvuz.dev.grapheme.ru/organization/order/9/invoice/pdf">счет</a>. Доступ предоставляется в течение 2 часов с момента поступления денежных средств на расчетный счет образовательного портала ТЕХВУЗ.РФ', NULL, '2014-12-02 16:45:12', '2014-12-02 16:45:12'),
(253, NULL, 8, 'moderator.order.new.2014-12-02 16:45:12', 'Оформлен заказ №006-14', NULL, '2014-12-02 16:45:12', '2014-12-02 16:45:12'),
(254, NULL, 8, 'moderator.register-organization.2014-12-02 21:08:51', 'Зарегистрирована организация Фирма-2', NULL, '2014-12-02 21:08:51', '2014-12-02 21:08:51'),
(256, NULL, 8, 'organization.register-listeners.2014-12-02 21:15:17', '«Необходимо добавить слушателей – сотрудников Вашей организации, которых необходимо обучить»', NULL, '2014-12-02 21:15:17', '2014-12-02 21:15:17'),
(257, NULL, 8, 'account.approved-email.2014-12-02 21:15:17', '«Ваш личный кабинет активирован. Происходит проверка администратором сайта»', NULL, '2014-12-02 21:15:17', '2014-12-02 21:15:17'),
(258, NULL, 8, 'moderator.register-listener.2014-12-02 21:21:09', 'Анеглова АнгелА добавлен(а) к слушателям – сотрудникам Фирма-2', NULL, '2014-12-02 21:21:09', '2014-12-02 21:21:09'),
(259, NULL, 8, 'moderator.register-listener.2014-12-02 21:28:35', 'Шумеев Павел Андреевич добавлен(а) к слушателям – сотрудникам Фирма-2', NULL, '2014-12-02 21:28:35', '2014-12-02 21:28:35');
INSERT INTO `dictionary_values` (`id`, `version_of`, `dic_id`, `slug`, `name`, `order`, `created_at`, `updated_at`) VALUES
(260, NULL, 8, 'organization.order-puy-no-approve.2014-12-02 21:36:56', 'Ваш заказ <a href="http://techvuz.dev.grapheme.ru/organization/order/10">№007-14</a> оформлен. Для получения договора на обучение и счета на оплату платных образовательных услуг необходимо дождаться окончания проверки администратором сайта. Проверка занимает не более 12 часов с момента активации личного кабинета', NULL, '2014-12-02 21:36:56', '2014-12-02 21:36:56'),
(261, NULL, 8, 'moderator.order.new.2014-12-02 21:36:56', 'Оформлен заказ №007-14', NULL, '2014-12-02 21:36:56', '2014-12-02 21:36:56'),
(262, NULL, 2, 'moderator-company-profile-approved.2014-12-02 22:42:07', 'Фирма-2', NULL, '2014-12-02 22:42:07', '2014-12-02 22:42:07'),
(263, NULL, 8, 'account.approved-profile.2014-12-02 22:42:07', 'Вы успешно прошли проверку администратора сайта ТЕХВУЗ.РФ. Теперь у Вас появился доступ к документации (договоры, счета, акты).', NULL, '2014-12-02 22:42:07', '2014-12-02 22:42:07'),
(264, NULL, 2, 'moderator-company-profile-update.2014-12-02 22:42:07', 'Организация: Фирма-2', NULL, '2014-12-02 22:42:07', '2014-12-02 22:42:07'),
(265, NULL, 8, 'organization.order.part-puy-yes-access.2014-12-02 22:51:41', 'Заказ №007-14 оплачен частично, но доступ к обучению предоставлен.', NULL, '2014-12-02 22:51:41', '2014-12-02 22:51:41'),
(266, NULL, 2, 'change-order-status.2014-12-02 22:51:41', 'Заказ №7', NULL, '2014-12-02 22:51:41', '2014-12-02 22:51:41'),
(267, NULL, 8, 'organization.order.part-puy-not-access.2014-12-02 22:52:02', 'Заказ №007-14 оплачен частично, доступ к обучению не предоставлен.', NULL, '2014-12-02 22:52:02', '2014-12-02 22:52:02'),
(268, NULL, 2, 'payment-order-number-store.2014-12-02 22:52:02', 'Заказ №1. Сумма: 10000 руб.', NULL, '2014-12-02 22:52:02', '2014-12-02 22:52:02'),
(269, NULL, 8, 'organization.study.begin.2014-12-02 23:00:13', 'Анеглова АнгелА приступил к обучению по программе БС-00. К итоговому тестированию по программе БС-00 можно будет приступить через 72 академических часа.', NULL, '2014-12-02 23:00:13', '2014-12-02 23:00:13'),
(270, NULL, 8, 'organization.study.fail-finish.2014-12-02 23:05:39', 'Анеглова АнгелА неудачно завершил(ла) итоговое тестирование по программе БС-00 с результатом 0%.', NULL, '2014-12-02 23:05:39', '2014-12-02 23:05:39'),
(271, NULL, 8, 'organization.study.control.2014-12-02 23:07:48', 'Анеглова АнгелА успешно завершил(ла) промежуточное тестирования по программе БС-00 с результатом 100%.', NULL, '2014-12-02 23:07:48', '2014-12-02 23:07:48'),
(272, NULL, 8, 'organization.study.begin.2014-12-02 23:08:13', 'Анеглова АнгелА приступил к обучению по программе БС-08. К итоговому тестированию по программе БС-08 можно будет приступить через 72 академических часа.', NULL, '2014-12-02 23:08:13', '2014-12-02 23:08:13'),
(273, NULL, 8, 'moderator.register-listener.2014-12-03 09:35:51', 'Баклажанов Сергей Дмитриевич добавлен(а) к слушателям – сотрудникам ПМЖ-12', NULL, '2014-12-03 09:35:51', '2014-12-03 09:35:51'),
(274, NULL, 8, 'organization.order.part-puy-yes-access.2014-12-03 10:20:14', 'Заказ №006-14 оплачен частично, но доступ к обучению предоставлен.', NULL, '2014-12-03 10:20:14', '2014-12-03 10:20:14'),
(275, NULL, 2, 'change-order-status.2014-12-03 10:20:14', 'Заказ №6', NULL, '2014-12-03 10:20:14', '2014-12-03 10:20:14'),
(277, NULL, 2, 'payment-order-number-store.2014-12-03 10:20:25', 'Заказ №1. Сумма: 12000 руб.', NULL, '2014-12-03 10:20:25', '2014-12-03 10:20:25'),
(278, NULL, 8, 'organization.study.begin.2014-12-03 10:21:30', 'Помидоров Аркадий Иванович приступил к обучению по программе БС-01. К итоговому тестированию по программе БС-01 можно будет приступить через 72 академических часа.', NULL, '2014-12-03 10:21:30', '2014-12-03 10:21:30'),
(279, NULL, 8, 'moderator.register-listener.2014-12-03 10:23:27', 'Иванов Иван Иванович добавлен(а) к слушателям – сотрудникам ООО "Ковровский механический завод"', NULL, '2014-12-03 10:23:27', '2014-12-03 10:23:27'),
(280, NULL, 8, 'organization.order-puy-no-approve.2014-12-03 10:24:29', 'Ваш заказ <a href="http://techvuz.dev.grapheme.ru/organization/order/11">№008-14</a> оформлен. Для получения договора на обучение и счета на оплату платных образовательных услуг необходимо дождаться окончания проверки администратором сайта. Проверка занимает не более 12 часов с момента активации личного кабинета', NULL, '2014-12-03 10:24:29', '2014-12-03 10:24:29'),
(281, NULL, 8, 'moderator.order.new.2014-12-03 10:24:29', 'Оформлен заказ №008-14', NULL, '2014-12-03 10:24:29', '2014-12-03 10:24:29'),
(282, NULL, 8, 'moderator.register-listener.2014-12-03 14:39:12', 'Иванов Иван Иванович добавлен(а) к слушателям – сотрудникам ООО "Ковровский механический завод"', NULL, '2014-12-03 14:39:12', '2014-12-03 14:39:12'),
(283, NULL, 6, 'order-documents-request', 'Заявка на повышение квалификации ', 8, '2014-12-04 10:32:11', '2014-12-04 11:35:04'),
(284, NULL, 6, 'order-documents-enrollment', 'Приказ о зачислении ', 9, '2014-12-04 10:32:11', '2014-12-05 10:24:28'),
(285, NULL, 6, 'order-documents-completion', 'Приказ об окончании ', 10, '2014-12-04 10:32:11', '2014-12-05 12:21:51'),
(286, NULL, 6, 'order-documents-class-schedule', 'Расписание занятий ', 11, '2014-12-04 10:32:11', '2014-12-05 14:15:36'),
(287, NULL, 6, 'order-documents-statements', 'Заявления на аттестацию ', 12, '2014-12-04 10:32:11', '2014-12-10 10:16:54'),
(288, NULL, 6, 'order-documents-explanations', 'Пояснения к документам ', 13, '2014-12-04 10:32:11', '2014-12-10 10:26:55'),
(289, NULL, 6, 'order-documents-browsing-history', 'Индивидуальный журнал посещений', 14, '2014-12-04 10:32:11', '2014-12-10 10:40:02'),
(290, NULL, 6, 'order-documents-result-certification', 'Результаты аттестации', 15, '2014-12-04 10:32:11', '2014-12-10 16:03:53'),
(291, NULL, 6, 'order-documents-attestation-sheet', 'Аттестационные ведомости', 16, '2014-12-04 10:32:11', '2014-12-17 11:30:21'),
(292, NULL, 6, 'order-documents-journal-issuance', 'Журнал выдачи удостоверений', 17, '2014-12-04 10:32:11', '2014-12-10 16:43:22'),
(293, NULL, 8, 'moderator.register-organization.2014-12-04 10:47:02', 'Зарегистрирована организация Полное наименование организации', NULL, '2014-12-04 10:47:02', '2014-12-04 10:47:02'),
(295, NULL, 2, 'otredaktirovan-document.2014-12-04 11:09:54', 'Событие за 04.12.2014 в 11:09', NULL, '2014-12-04 11:09:54', '2014-12-04 11:09:54'),
(296, 283, 6, 'order-documents-request', 'Заявка на повышение квалификации ', 8, '2014-12-04 11:35:04', '2014-12-04 11:35:04'),
(297, NULL, 2, 'otredaktirovan-document.2014-12-04 11:35:04', 'Событие за 04.12.2014 в 11:35', NULL, '2014-12-04 11:35:04', '2014-12-04 11:35:04'),
(299, NULL, 2, 'otredaktirovan-document.2014-12-04 11:58:34', 'Событие за 04.12.2014 в 11:58', NULL, '2014-12-04 11:58:34', '2014-12-04 11:58:34'),
(301, NULL, 2, 'otredaktirovan-document.2014-12-04 11:59:36', 'Событие за 04.12.2014 в 11:59', NULL, '2014-12-04 11:59:36', '2014-12-04 11:59:36'),
(302, 167, 6, 'order-documents-contract-listeners', 'Приложение №1 к договору', 2, '2014-12-04 12:00:07', '2014-12-04 12:00:07'),
(303, NULL, 2, 'otredaktirovan-document.2014-12-04 12:00:07', 'Событие за 04.12.2014 в 12:00', NULL, '2014-12-04 12:00:07', '2014-12-04 12:00:07'),
(304, NULL, 8, 'organization.order-puy.2014-12-04 12:15:14', 'Ваш заказ №009-14 оформлен. Для получения доступа к лекционным материалам Вам необходимо оплатить <a href="http://techvuz.dev.grapheme.ru/organization/order/12/invoice/pdf">счет</a>. Доступ предоставляется в течение 2 часов с момента поступления денежных средств на расчетный счет образовательного портала ТЕХВУЗ.РФ', NULL, '2014-12-04 12:15:14', '2014-12-04 12:15:14'),
(305, NULL, 8, 'moderator.order.new.2014-12-04 12:15:14', 'Оформлен заказ №009-14', NULL, '2014-12-04 12:15:14', '2014-12-04 12:15:14'),
(306, NULL, 8, 'moderator.register-listener.2014-12-04 12:34:29', 'Иванов Иван Иванович добавлен(а) к слушателям – сотрудникам ООО "Ковровский механический завод"', NULL, '2014-12-04 12:34:29', '2014-12-04 12:34:29'),
(307, NULL, 8, 'moderator.register-organization.2014-12-04 12:43:37', 'Зарегистрирована организация test', NULL, '2014-12-04 12:43:37', '2014-12-04 12:43:37'),
(308, NULL, 8, 'organization.order-puy-no-approve.2014-12-04 13:30:07', 'Ваш заказ <a href="http://techvuz.dev.grapheme.ru/organization/order/13">№010-14</a> оформлен. Для получения договора на обучение и счета на оплату платных образовательных услуг необходимо дождаться окончания проверки администратором сайта. Проверка занимает не более 12 часов с момента активации личного кабинета', NULL, '2014-12-04 13:30:07', '2014-12-04 13:30:07'),
(309, NULL, 8, 'moderator.order.new.2014-12-04 13:30:07', 'Оформлен заказ №010-14', NULL, '2014-12-04 13:30:07', '2014-12-04 13:30:07'),
(310, NULL, 8, 'moderator.register-listener.2014-12-04 13:47:14', 'Иванов Иван Иванович добавлен(а) к слушателям – сотрудникам ООО "Ковровский механический завод"', NULL, '2014-12-04 13:47:14', '2014-12-04 13:47:14'),
(311, NULL, 8, 'organization.order.yes-puy-yes-access.2014-12-04 14:22:42', 'Заказ <a href="http://techvuz.dev.grapheme.ru/organization/order/13">№010-14</a> оплачен. Сотрудники Вашей организации могут приступить к обучению.', NULL, '2014-12-04 14:22:42', '2014-12-04 14:22:42'),
(312, NULL, 2, 'change-order-status.2014-12-04 14:22:42', 'Заказ №10', NULL, '2014-12-04 14:22:42', '2014-12-04 14:22:42'),
(313, NULL, 8, 'organization.order.yes-puy-yes-access.2014-12-04 14:22:52', 'Заказ <a href="http://techvuz.dev.grapheme.ru/organization/order/11">№008-14</a> оплачен. Сотрудники Вашей организации могут приступить к обучению.', NULL, '2014-12-04 14:22:52', '2014-12-04 14:22:52'),
(314, NULL, 2, 'change-order-status.2014-12-04 14:22:52', 'Заказ №8', NULL, '2014-12-04 14:22:52', '2014-12-04 14:22:52'),
(315, NULL, 8, 'organization.study.begin.2014-12-04 14:24:08', 'Иванов Иван Иванович приступил к обучению по программе БС-00. К итоговому тестированию по программе БС-00 можно будет приступить через 72 академических часа.', NULL, '2014-12-04 14:24:08', '2014-12-04 14:24:08'),
(316, NULL, 8, 'organization.order-puy-no-approve.2014-12-04 15:35:09', 'Ваш заказ <a href="http://techvuz.dev.grapheme.ru/organization/order/14">№011-14</a> оформлен. Для получения договора на обучение и счета на оплату платных образовательных услуг необходимо дождаться окончания проверки администратором сайта. Проверка занимает не более 12 часов с момента активации личного кабинета', NULL, '2014-12-04 15:35:09', '2014-12-04 15:35:09'),
(317, NULL, 8, 'moderator.order.new.2014-12-04 15:35:09', 'Оформлен заказ №011-14', NULL, '2014-12-04 15:35:09', '2014-12-04 15:35:09'),
(318, NULL, 8, 'organization.order-puy-no-approve.2014-12-04 15:35:52', 'Ваш заказ <a href="http://techvuz.dev.grapheme.ru/organization/order/15">№011-14</a> оформлен. Для получения договора на обучение и счета на оплату платных образовательных услуг необходимо дождаться окончания проверки администратором сайта. Проверка занимает не более 12 часов с момента активации личного кабинета', NULL, '2014-12-04 15:35:52', '2014-12-04 15:35:52'),
(319, NULL, 8, 'moderator.order.new.2014-12-04 15:35:52', 'Оформлен заказ №011-14', NULL, '2014-12-04 15:35:52', '2014-12-04 15:35:52'),
(321, NULL, 2, 'otredaktirovan-document.2014-12-05 09:47:45', 'Событие за 05.12.2014 в 09:47', NULL, '2014-12-05 09:47:45', '2014-12-05 09:47:45'),
(323, NULL, 2, 'otredaktirovan-document.2014-12-05 10:15:37', 'Событие за 05.12.2014 в 10:15', NULL, '2014-12-05 10:15:37', '2014-12-05 10:15:37'),
(325, NULL, 2, 'otredaktirovan-document.2014-12-05 10:18:49', 'Событие за 05.12.2014 в 10:18', NULL, '2014-12-05 10:18:49', '2014-12-05 10:18:49'),
(326, NULL, 2, 'testing.index.2014-12-05 10:19:30', 'Промежуточное тестирование. Курс: Строительство, реконструкция, капитальный ремонт объектов капитального строительства (выполнение геодезических, подготовительных и земляных работ, устройства оснований и фундаментов)', NULL, '2014-12-05 10:19:30', '2014-12-05 10:19:30'),
(327, 284, 6, 'order-documents-enrollment', 'Приказ о зачислении ', 9, '2014-12-05 10:24:28', '2014-12-05 10:24:28'),
(328, NULL, 2, 'otredaktirovan-document.2014-12-05 10:24:28', 'Событие за 05.12.2014 в 10:24', NULL, '2014-12-05 10:24:28', '2014-12-05 10:24:28'),
(329, NULL, 8, 'organization.study.fail-finish.2014-12-05 10:24:40', 'Помидоров Аркадий Иванович неудачно завершил(ла) итоговое тестирование по программе БС-01 с результатом 50%.', NULL, '2014-12-05 10:24:40', '2014-12-05 10:24:40'),
(330, NULL, 8, 'organization.study.fail-finish.2014-12-05 10:27:57', 'Помидоров Аркадий Иванович неудачно завершил(ла) итоговое тестирование по программе БС-01 с результатом 50%.', NULL, '2014-12-05 10:27:57', '2014-12-05 10:27:57'),
(332, NULL, 2, 'otredaktirovan-document.2014-12-05 10:46:10', 'Событие за 05.12.2014 в 10:46', NULL, '2014-12-05 10:46:10', '2014-12-05 10:46:10'),
(333, NULL, 8, 'organization.study.fail-finish.2014-12-05 11:07:47', 'Помидоров Аркадий Иванович неудачно завершил(ла) итоговое тестирование по программе БС-01 с результатом 50%.', NULL, '2014-12-05 11:07:47', '2014-12-05 11:07:47'),
(334, NULL, 8, 'organization.study.control.2014-12-05 11:13:18', 'Помидоров Аркадий Иванович успешно завершил(ла) промежуточное тестирования по программе БС-01 с результатом 100%.', NULL, '2014-12-05 11:13:18', '2014-12-05 11:13:18'),
(335, NULL, 8, 'organization.study.control.2014-12-05 11:24:37', 'Помидоров Аркадий Иванович успешно завершил(ла) промежуточное тестирования по программе БС-01 с результатом 100%.', NULL, '2014-12-05 11:24:37', '2014-12-05 11:24:37'),
(336, 285, 6, 'order-documents-completion', 'Приказ об окончании ', 10, '2014-12-05 12:21:51', '2014-12-05 12:21:51'),
(337, NULL, 2, 'otredaktirovan-document.2014-12-05 12:21:51', 'Событие за 05.12.2014 в 12:21', NULL, '2014-12-05 12:21:51', '2014-12-05 12:21:51'),
(339, NULL, 2, 'otredaktirovan-document.2014-12-05 12:32:23', 'Событие за 05.12.2014 в 12:32', NULL, '2014-12-05 12:32:23', '2014-12-05 12:32:23'),
(341, NULL, 2, 'otredaktirovan-document.2014-12-05 13:14:27', 'Событие за 05.12.2014 в 13:14', NULL, '2014-12-05 13:14:27', '2014-12-05 13:14:27'),
(343, NULL, 2, 'otredaktirovan-document.2014-12-05 13:28:15', 'Событие за 05.12.2014 в 13:28', NULL, '2014-12-05 13:28:15', '2014-12-05 13:28:15'),
(344, NULL, 8, 'organization.order-puy.2014-12-05 13:49:16', 'Ваш заказ №009-14 оформлен. Для получения доступа к лекционным материалам Вам необходимо оплатить <a href="http://techvuz.dev.grapheme.ru/organization/order/16/invoice/pdf">счет</a>. Доступ предоставляется в течение 2 часов с момента поступления денежных средств на расчетный счет образовательного портала ТЕХВУЗ.РФ', NULL, '2014-12-05 13:49:16', '2014-12-05 13:49:16'),
(345, NULL, 8, 'moderator.order.new.2014-12-05 13:49:16', 'Оформлен заказ №009-14', NULL, '2014-12-05 13:49:16', '2014-12-05 13:49:16'),
(346, NULL, 8, 'organization.order-puy.2014-12-05 13:50:33', 'Ваш заказ №009-14 оформлен. Для получения доступа к лекционным материалам Вам необходимо оплатить <a href="http://techvuz.dev.grapheme.ru/organization/order/17/invoice/pdf">счет</a>. Доступ предоставляется в течение 2 часов с момента поступления денежных средств на расчетный счет образовательного портала ТЕХВУЗ.РФ', NULL, '2014-12-05 13:50:33', '2014-12-05 13:50:33'),
(347, NULL, 8, 'moderator.order.new.2014-12-05 13:50:33', 'Оформлен заказ №009-14', NULL, '2014-12-05 13:50:33', '2014-12-05 13:50:33'),
(348, NULL, 8, 'organization.order-puy.2014-12-05 13:50:59', 'Ваш заказ №009-14 оформлен. Для получения доступа к лекционным материалам Вам необходимо оплатить <a href="http://techvuz.dev.grapheme.ru/organization/order/18/invoice/pdf">счет</a>. Доступ предоставляется в течение 2 часов с момента поступления денежных средств на расчетный счет образовательного портала ТЕХВУЗ.РФ', NULL, '2014-12-05 13:50:59', '2014-12-05 13:50:59'),
(349, NULL, 8, 'moderator.order.new.2014-12-05 13:50:59', 'Оформлен заказ №009-14', NULL, '2014-12-05 13:50:59', '2014-12-05 13:50:59'),
(350, 286, 6, 'order-documents-class-schedule', 'Расписание занятий ', 11, '2014-12-05 14:15:36', '2014-12-05 14:15:36'),
(351, NULL, 2, 'otredaktirovan-document.2014-12-05 14:15:36', 'Событие за 05.12.2014 в 14:15', NULL, '2014-12-05 14:15:36', '2014-12-05 14:15:36'),
(352, NULL, 8, 'organization.study.control.2014-12-05 17:21:42', 'Помидоров Аркадий Иванович успешно завершил(ла) промежуточное тестирования по программе БС-01 с результатом 100%.', NULL, '2014-12-05 17:21:42', '2014-12-05 17:21:42'),
(353, NULL, 8, 'organization.study.fail-finish.2014-12-05 17:22:58', 'Помидоров Аркадий Иванович неудачно завершил(ла) итоговое тестирование по программе БС-01 с результатом 50%.', NULL, '2014-12-05 17:22:58', '2014-12-05 17:22:58'),
(354, NULL, 8, 'organization.order-puy.2014-12-08 16:24:14', 'Ваш заказ №009-14 оформлен. Для получения доступа к лекционным материалам Вам необходимо оплатить <a href="http://techvuz.dev.grapheme.ru/organization/order/19/invoice/pdf">счет</a>. Доступ предоставляется в течение 2 часов с момента поступления денежных средств на расчетный счет образовательного портала ТЕХВУЗ.РФ', NULL, '2014-12-08 16:24:14', '2014-12-08 16:24:14'),
(355, NULL, 8, 'moderator.order.new.2014-12-08 16:24:14', 'Оформлен заказ №009-14', NULL, '2014-12-08 16:24:14', '2014-12-08 16:24:14'),
(356, NULL, 8, 'organization.order-puy.2014-12-08 16:25:48', 'Ваш заказ №011-14 оформлен. Для получения доступа к лекционным материалам Вам необходимо оплатить <a href="http://techvuz.dev.grapheme.ru/organization/order/20/invoice/pdf">счет</a>. Доступ предоставляется в течение 2 часов с момента поступления денежных средств на расчетный счет образовательного портала ТЕХВУЗ.РФ', NULL, '2014-12-08 16:25:48', '2014-12-08 16:25:48'),
(357, NULL, 8, 'moderator.order.new.2014-12-08 16:25:48', 'Оформлен заказ №011-14', NULL, '2014-12-08 16:25:48', '2014-12-08 16:25:48'),
(358, NULL, 8, 'organization.study.fail-finish.2014-12-09 09:05:15', 'Иванов Иван Иванович неудачно завершил(а) итоговое тестирование по программе БС-00 с результатом 0%.', NULL, '2014-12-09 09:05:15', '2014-12-09 09:05:15'),
(359, NULL, 8, 'organization.study.control.2014-12-09 09:06:08', 'Иванов Иван Иванович успешно завершил(а) промежуточное тестирования по программе БС-00 с результатом 100%.', NULL, '2014-12-09 09:06:08', '2014-12-09 09:06:08'),
(360, NULL, 8, 'organization.study.fail-finish.2014-12-09 09:28:38', 'Иванов Иван Иванович неудачно завершил(а) итоговое тестирование по программе БС-00 с результатом 0%.', NULL, '2014-12-09 09:28:38', '2014-12-09 09:28:38'),
(361, NULL, 8, 'organization.order-puy-no-approve.2014-12-09 10:51:17', 'Ваш заказ <a href="http://techvuz.dev.grapheme.ru/organization/order/21">№012-14</a> оформлен. Для получения договора на обучение и счета на оплату платных образовательных услуг необходимо дождаться окончания проверки администратором сайта. Проверка занимает не более 12 часов с момента активации личного кабинета', NULL, '2014-12-09 10:51:17', '2014-12-09 10:51:17'),
(362, NULL, 8, 'moderator.order.new.2014-12-09 10:51:17', 'Оформлен заказ №012-14', NULL, '2014-12-09 10:51:17', '2014-12-09 10:51:17'),
(363, NULL, 2, 'moderator-company-profile-approved.2014-12-09 10:51:48', 'ООО "Ковровский механический завод"', NULL, '2014-12-09 10:51:48', '2014-12-09 10:51:48'),
(364, NULL, 8, 'account.approved-profile.2014-12-09 10:51:48', 'Вы успешно прошли проверку администратора сайта ТЕХВУЗ.РФ. Теперь у Вас появился доступ к документации (договоры, счета, акты).', NULL, '2014-12-09 10:51:48', '2014-12-09 10:51:48'),
(365, NULL, 2, 'moderator-company-profile-update.2014-12-09 10:51:48', 'Организация: ООО "Ковровский механический завод"', NULL, '2014-12-09 10:51:48', '2014-12-09 10:51:48'),
(366, NULL, 8, 'organization.order-puy.2014-12-09 10:52:15', 'Ваш заказ <a href="http://techvuz.dev.grapheme.ru/organization/order/22">№013-14</a> оформлен. Для получения доступа к лекционным материалам Вам необходимо оплатить <a href="http://techvuz.dev.grapheme.ru/organization/order/22/invoice/pdf">счет</a>. Доступ предоставляется в течение 2 часов с момента поступления денежных средств на расчетный счет образовательного портала ТЕХВУЗ.РФ', NULL, '2014-12-09 10:52:15', '2014-12-09 10:52:15'),
(367, NULL, 8, 'moderator.order.new.2014-12-09 10:52:15', 'Оформлен заказ №013-14', NULL, '2014-12-09 10:52:15', '2014-12-09 10:52:15'),
(368, NULL, 8, 'organization.order.part-puy-yes-access.2014-12-09 10:52:47', 'Заказ <a href="[link]">№013-14</a> оплачен частично, но доступ к обучению предоставлен.', NULL, '2014-12-09 10:52:47', '2014-12-09 10:52:47'),
(369, NULL, 2, 'change-order-status.2014-12-09 10:52:47', 'Заказ №13', NULL, '2014-12-09 10:52:47', '2014-12-09 10:52:47'),
(370, NULL, 8, 'organization.order.yes-puy-yes-access.2014-12-09 10:56:05', 'Заказ <a href="http://techvuz.dev.grapheme.ru/organization/order/22">№013-14</a> оплачен. Сотрудники Вашей организации могут приступить к обучению.', NULL, '2014-12-09 10:56:05', '2014-12-09 10:56:05'),
(371, NULL, 2, 'change-order-status.2014-12-09 10:56:05', 'Заказ №13', NULL, '2014-12-09 10:56:05', '2014-12-09 10:56:05'),
(372, NULL, 8, 'organization.order.part-puy-not-access.2014-12-09 10:56:33', 'Заказ <a href="http://techvuz.dev.grapheme.ru/organization/order/22">№013-14</a> оплачен частично, доступ к обучению не предоставлен.', NULL, '2014-12-09 10:56:33', '2014-12-09 10:56:33'),
(373, NULL, 2, 'change-order-status.2014-12-09 10:56:33', 'Заказ №13', NULL, '2014-12-09 10:56:33', '2014-12-09 10:56:33'),
(374, NULL, 8, 'organization.order.part-puy-yes-access.2014-12-09 10:56:52', 'Заказ <a href="[link]">№013-14</a> оплачен частично, но доступ к обучению предоставлен.', NULL, '2014-12-09 10:56:52', '2014-12-09 10:56:52'),
(375, NULL, 2, 'change-order-status.2014-12-09 10:56:52', 'Заказ №13', NULL, '2014-12-09 10:56:52', '2014-12-09 10:56:52'),
(376, NULL, 8, 'organization.order.yes-puy-yes-access.2014-12-09 10:57:52', 'Заказ <a href="http://techvuz.dev.grapheme.ru/organization/order/22">№013-14</a> оплачен. Сотрудники Вашей организации могут приступить к обучению.', NULL, '2014-12-09 10:57:52', '2014-12-09 10:57:52'),
(377, NULL, 2, 'change-order-status.2014-12-09 10:57:52', 'Заказ №13', NULL, '2014-12-09 10:57:52', '2014-12-09 10:57:52'),
(378, NULL, 8, 'organization.order.not-puy-yes-access.2014-12-09 10:57:55', 'Заказ <a href="http://techvuz.dev.grapheme.ru/organization/order/22">№013-14</a> не оплачен, но доступ к обучению предоставлен.', NULL, '2014-12-09 10:57:55', '2014-12-09 10:57:55'),
(379, NULL, 2, 'change-order-status.2014-12-09 10:57:55', 'Заказ №13', NULL, '2014-12-09 10:57:55', '2014-12-09 10:57:55'),
(380, NULL, 8, 'organization.order.part-puy-yes-access.2014-12-09 10:57:59', 'Заказ <a href="http://techvuz.dev.grapheme.ru/organization/order/22">№013-14</a> оплачен частично, но доступ к обучению предоставлен.', NULL, '2014-12-09 10:57:59', '2014-12-09 10:57:59'),
(381, NULL, 2, 'change-order-status.2014-12-09 10:57:59', 'Заказ №13', NULL, '2014-12-09 10:57:59', '2014-12-09 10:57:59'),
(382, NULL, 8, 'organization.order-puy.2014-12-09 11:49:59', 'Ваш заказ <a href="http://techvuz.dev.grapheme.ru/organization/order/23">№014-14</a> оформлен. Для получения доступа к лекционным материалам Вам необходимо оплатить <a href="http://techvuz.dev.grapheme.ru/organization/order/23/invoice/pdf">счет</a>. Доступ предоставляется в течение 2 часов с момента поступления денежных средств на расчетный счет образовательного портала ТЕХВУЗ.РФ', NULL, '2014-12-09 11:49:59', '2014-12-09 11:49:59'),
(383, NULL, 8, 'moderator.order.new.2014-12-09 11:49:59', 'Оформлен заказ №014-14', NULL, '2014-12-09 11:49:59', '2014-12-09 11:49:59'),
(384, NULL, 8, 'organization.order.part-puy-not-access.2014-12-09 12:29:07', 'Заказ <a href="http://techvuz.dev.grapheme.ru/organization/order/23">№014-14</a> оплачен частично, доступ к обучению не предоставлен.', NULL, '2014-12-09 12:29:07', '2014-12-09 12:29:07'),
(385, NULL, 2, 'change-order-status.2014-12-09 12:29:08', 'Заказ №14', NULL, '2014-12-09 12:29:08', '2014-12-09 12:29:08'),
(386, NULL, 8, 'organization.order-puy.2014-12-09 12:33:01', 'Ваш заказ <a href="http://techvuz.dev.grapheme.ru/organization/order/24">№015-14</a> оформлен. Для получения доступа к лекционным материалам Вам необходимо оплатить <a href="http://techvuz.dev.grapheme.ru/organization/order/24/invoice/pdf">счет</a>. Доступ предоставляется в течение 2 часов с момента поступления денежных средств на расчетный счет образовательного портала ТЕХВУЗ.РФ', NULL, '2014-12-09 12:33:01', '2014-12-09 12:33:01'),
(387, NULL, 8, 'moderator.order.new.2014-12-09 12:33:01', 'Оформлен заказ №015-14', NULL, '2014-12-09 12:33:01', '2014-12-09 12:33:01'),
(388, NULL, 8, 'organization.study.begin.2014-12-09 12:33:56', 'Сорбат Владимир Николаевич приступил(а) к обучению по программе БС-01. К итоговому тестированию по программе БС-01 можно будет приступить через 72 академических часа.', NULL, '2014-12-09 12:33:56', '2014-12-09 12:33:56'),
(389, NULL, 8, 'organization.study.control.2014-12-09 12:34:31', 'Сорбат Владимир Николаевич успешно завершил(а) промежуточное тестирования по программе БС-01 с результатом 100%.', NULL, '2014-12-09 12:34:31', '2014-12-09 12:34:31'),
(395, NULL, 2, 'dobavlen-otzuv.2014-12-10 09:30:29', 'Событие за 10.12.2014 в 09:30', NULL, '2014-12-10 09:30:29', '2014-12-10 09:30:29'),
(396, NULL, 2, 'udalen-otzuv.2014-12-10 09:31:53', 'Событие за 10.12.2014 в 09:31', NULL, '2014-12-10 09:31:53', '2014-12-10 09:31:53'),
(397, 287, 6, 'order-documents-statements', 'Заявления на аттестацию ', 12, '2014-12-10 10:16:54', '2014-12-10 10:16:54'),
(398, NULL, 2, 'otredaktirovan-document.2014-12-10 10:16:54', 'Событие за 10.12.2014 в 10:16', NULL, '2014-12-10 10:16:54', '2014-12-10 10:16:54'),
(399, 288, 6, 'order-documents-explanations', 'Пояснения к документам ', 13, '2014-12-10 10:26:55', '2014-12-10 10:26:55'),
(400, NULL, 2, 'otredaktirovan-document.2014-12-10 10:26:55', 'Событие за 10.12.2014 в 10:26', NULL, '2014-12-10 10:26:55', '2014-12-10 10:26:55'),
(402, NULL, 2, 'otredaktirovan-document.2014-12-10 10:38:49', 'Событие за 10.12.2014 в 10:38', NULL, '2014-12-10 10:38:49', '2014-12-10 10:38:49'),
(403, 289, 6, 'order-documents-browsing-history', 'Индивидуальный журнал посещений', 14, '2014-12-10 10:40:02', '2014-12-10 10:40:02'),
(404, NULL, 2, 'otredaktirovan-document.2014-12-10 10:40:02', 'Событие за 10.12.2014 в 10:40', NULL, '2014-12-10 10:40:02', '2014-12-10 10:40:02'),
(406, NULL, 2, 'otredaktirovan-document.2014-12-10 10:57:41', 'Событие за 10.12.2014 в 10:57', NULL, '2014-12-10 10:57:41', '2014-12-10 10:57:41'),
(407, NULL, 8, 'organization.order.part-puy-not-access.2014-12-10 11:03:03', 'Заказ <a href="http://techvuz.dev.grapheme.ru/organization/order/20">№011-14</a> оплачен частично, доступ к обучению не предоставлен.', NULL, '2014-12-10 11:03:03', '2014-12-10 11:03:03'),
(408, NULL, 2, 'payment-order-number-store.2014-12-10 11:03:03', 'Заказ №1. Сумма: 13000 руб.', NULL, '2014-12-10 11:03:03', '2014-12-10 11:03:03'),
(410, NULL, 2, 'otredaktirovan-document.2014-12-10 12:19:09', 'Событие за 10.12.2014 в 12:19', NULL, '2014-12-10 12:19:09', '2014-12-10 12:19:09'),
(412, NULL, 2, 'otredaktirovan-document.2014-12-10 12:23:31', 'Событие за 10.12.2014 в 12:23', NULL, '2014-12-10 12:23:31', '2014-12-10 12:23:31'),
(413, NULL, 8, 'moderator.register-organization.2014-12-10 16:03:47', 'Зарегистрирована организация Фирма-3', NULL, '2014-12-10 16:03:47', '2014-12-10 16:03:47'),
(414, 290, 6, 'order-documents-result-certification', 'Результаты аттестации', 15, '2014-12-10 16:03:53', '2014-12-10 16:03:53'),
(415, NULL, 2, 'otredaktirovan-document.2014-12-10 16:03:53', 'Событие за 10.12.2014 в 16:03', NULL, '2014-12-10 16:03:53', '2014-12-10 16:03:53'),
(416, NULL, 8, 'moderator.register-organization.2014-12-10 16:11:37', 'Зарегистрирована организация tyyyyyyyyyyyy', NULL, '2014-12-10 16:11:37', '2014-12-10 16:11:37'),
(417, NULL, 8, 'organization.select-courses.2014-12-10 16:14:00', 'Необходимо выбрать курс(ы) и оформить заказ', NULL, '2014-12-10 16:14:00', '2014-12-10 16:14:00'),
(418, NULL, 8, 'organization.register-listeners.2014-12-10 16:14:00', 'Необходимо добавить слушателей – сотрудников Вашей организации, которых необходимо обучить', NULL, '2014-12-10 16:14:00', '2014-12-10 16:14:00'),
(419, NULL, 8, 'account.approved-email.2014-12-10 16:14:00', '«Ваш личный кабинет активирован. Происходит проверка администратором сайта»', NULL, '2014-12-10 16:14:00', '2014-12-10 16:14:00'),
(420, NULL, 8, 'moderator.register-listener.2014-12-10 16:28:17', 'пррррррррррggggggggggg добавлен(а) к слушателям – сотрудникам Фирма-3', NULL, '2014-12-10 16:28:17', '2014-12-10 16:28:17'),
(421, 292, 6, 'order-documents-journal-issuance', 'Журнал выдачи удостоверений', 17, '2014-12-10 16:43:22', '2014-12-10 16:43:22'),
(422, NULL, 2, 'otredaktirovan-document.2014-12-10 16:43:22', 'Событие за 10.12.2014 в 16:43', NULL, '2014-12-10 16:43:22', '2014-12-10 16:43:22'),
(423, NULL, 8, 'moderator.register-listener.2014-12-10 16:45:52', 'Тищенко Андрей Михайлович добавлен(а) к слушателям – сотрудникам Фирма-3', NULL, '2014-12-10 16:45:52', '2014-12-10 16:45:52'),
(424, NULL, 8, 'organization.order-puy-no-approve.2014-12-10 16:53:01', 'Ваш заказ <a href="http://techvuz.dev.grapheme.ru/organization/order/25">№016-14</a> оформлен. Для получения договора на обучение и счета на оплату платных образовательных услуг необходимо дождаться окончания проверки администратором сайта. Проверка занимает не более 12 часов с момента активации личного кабинета', NULL, '2014-12-10 16:53:01', '2014-12-10 16:53:01'),
(425, NULL, 8, 'moderator.order.new.2014-12-10 16:53:01', 'Оформлен заказ №016-14', NULL, '2014-12-10 16:53:01', '2014-12-10 16:53:01'),
(426, NULL, 8, 'moderator.register-organization.2014-12-11 06:09:27', 'Зарегистрирована организация gggggjkkkkkkkkkkkkkkkk', NULL, '2014-12-11 06:09:27', '2014-12-11 06:09:27'),
(427, NULL, 2, 'moderator-company-profile-approved.2014-12-11 06:15:02', 'Фирма-3', NULL, '2014-12-11 06:15:02', '2014-12-11 06:15:02'),
(428, NULL, 8, 'account.approved-profile.2014-12-11 06:15:02', 'Вы успешно прошли проверку администратора сайта ТЕХВУЗ.РФ. Теперь у Вас появился доступ к документации (договоры, счета, акты).', NULL, '2014-12-11 06:15:02', '2014-12-11 06:15:02'),
(429, NULL, 2, 'moderator-company-profile-update.2014-12-11 06:15:02', 'Организация: Фирма-3', NULL, '2014-12-11 06:15:02', '2014-12-11 06:15:02'),
(430, NULL, 8, 'organization.order.not-puy-yes-access.2014-12-11 06:21:43', 'Заказ <a href="http://techvuz.dev.grapheme.ru/organization/order/25">№016-14</a> не оплачен, но доступ к обучению предоставлен.', NULL, '2014-12-11 06:21:43', '2014-12-11 06:21:43'),
(431, NULL, 2, 'change-order-status.2014-12-11 06:21:43', 'Заказ №16', NULL, '2014-12-11 06:21:43', '2014-12-11 06:21:43'),
(432, NULL, 8, 'organization.study.begin.2014-12-11 06:35:48', 'пррррррррррggggggggggg приступил(а) к обучению по программе БС-00. К итоговому тестированию по программе БС-00 можно будет приступить через 72 академических часа.', NULL, '2014-12-11 06:35:48', '2014-12-11 06:35:48'),
(433, NULL, 8, 'organization.study.fail-finish.2014-12-11 06:47:05', 'пррррррррррggggggggggg неудачно завершил(а) итоговое тестирование по программе БС-00 с результатом 0%.', NULL, '2014-12-11 06:47:05', '2014-12-11 06:47:05'),
(434, NULL, 8, 'organization.study.control.2014-12-11 06:48:55', 'пррррррррррggggggggggg успешно завершил(а) промежуточное тестирования по программе БС-00 с результатом 100%.', NULL, '2014-12-11 06:48:55', '2014-12-11 06:48:55'),
(435, NULL, 8, 'organization.study.finish.2014-12-11 06:51:31', 'пррррррррррggggggggggg прошел(а) итоговое тестирование по программе БС-00 с результатом 100%.', NULL, '2014-12-11 06:51:31', '2014-12-11 06:51:31'),
(436, NULL, 8, 'organization.study.finish.2014-12-11 06:52:16', 'пррррррррррggggggggggg прошел(а) итоговое тестирование по программе БС-00 с результатом 100%.', NULL, '2014-12-11 06:52:16', '2014-12-11 06:52:16'),
(437, NULL, 8, 'organization.study.fail-control.2014-12-11 06:52:21', 'пррррррррррggggggggggg неудачно завершил(а) промежуточное тестирование по программе БС-00 с результатом 0%.', NULL, '2014-12-11 06:52:21', '2014-12-11 06:52:21'),
(439, NULL, 8, 'moderator.register-listener.2014-12-11 10:40:02', 'Володя добавлен(а) к слушателям – сотрудникам ООО "Ковровский механический завод"', NULL, '2014-12-11 10:40:02', '2014-12-11 10:40:02'),
(440, NULL, 8, 'organization.order-puy.2014-12-11 10:52:56', 'Ваш заказ <a href="http://techvuz.dev.grapheme.ru/organization/order/26">№017-14</a> оформлен. Для получения доступа к лекционным материалам Вам необходимо оплатить <a href="http://techvuz.dev.grapheme.ru/organization/order/26/invoice/pdf">счет</a>. Доступ предоставляется в течение 2 часов с момента поступления денежных средств на расчетный счет образовательного портала ТЕХВУЗ.РФ', NULL, '2014-12-11 10:52:56', '2014-12-11 10:52:56'),
(441, NULL, 8, 'moderator.order.new.2014-12-11 10:52:56', 'Оформлен заказ №017-14', NULL, '2014-12-11 10:52:56', '2014-12-11 10:52:56'),
(442, NULL, 8, 'organization.order.yes-puy-yes-access.2014-12-11 10:53:49', 'Заказ <a href="http://techvuz.dev.grapheme.ru/organization/order/26">№017-14</a> оплачен. Сотрудники Вашей организации могут приступить к обучению.', NULL, '2014-12-11 10:53:49', '2014-12-11 10:53:49'),
(443, NULL, 2, 'change-order-status.2014-12-11 10:53:49', 'Заказ №17', NULL, '2014-12-11 10:53:49', '2014-12-11 10:53:49'),
(444, NULL, 8, 'organization.study.begin.2014-12-11 10:55:23', 'Иванов Иван Иванович приступил(а) к обучению по программе БС-01. К итоговому тестированию по программе БС-01 можно будет приступить через 72 академических часа.', NULL, '2014-12-11 10:55:23', '2014-12-11 10:55:23'),
(445, NULL, 8, 'organization.study.begin.2014-12-11 10:56:03', 'Иванов Иван Иванович приступил(а) к обучению по программе БС-02. К итоговому тестированию по программе БС-02 можно будет приступить через 72 академических часа.', NULL, '2014-12-11 10:56:03', '2014-12-11 10:56:03'),
(446, NULL, 2, 'moderator-order-update.2014-12-11 10:56:36', '№017-14', NULL, '2014-12-11 10:56:36', '2014-12-11 10:56:36'),
(447, NULL, 8, 'organization.study.finish.2014-12-11 10:57:24', 'Иванов Иван Иванович прошел(а) итоговое тестирование по программе БС-01 с результатом 100%.', NULL, '2014-12-11 10:57:24', '2014-12-11 10:57:24'),
(448, NULL, 8, 'organization.study.finish.2014-12-11 11:01:51', 'Иванов Иван Иванович прошел(а) итоговое тестирование по программе БС-01 с результатом 100%.', NULL, '2014-12-11 11:01:51', '2014-12-11 11:01:51'),
(449, NULL, 8, 'organization.study.begin.2014-12-11 11:03:04', 'Володя Питерсикий приступил(а) к обучению по программе БС-00. К итоговому тестированию по программе БС-00 можно будет приступить через 72 академических часа.', NULL, '2014-12-11 11:03:04', '2014-12-11 11:03:04'),
(450, NULL, 8, 'organization.study.finish.2014-12-11 11:03:28', 'Володя Питерсикий прошел(а) итоговое тестирование по программе БС-00 с результатом 100%.', NULL, '2014-12-11 11:03:28', '2014-12-11 11:03:28'),
(451, NULL, 8, 'organization.order.closed.2014-12-11 11:03:29', 'Заказ <a href="http://techvuz.dev.grapheme.ru/organization/order/26">№017-14</a> закрыт. Все сотрудники Вашей организации успешно прошли итоговые тестирования по заданным курсам.', NULL, '2014-12-11 11:03:29', '2014-12-11 11:03:29'),
(452, NULL, 8, 'organization.order.closed-documents.2014-12-11 11:03:29', 'Для получения сканированных копий документов Ваших сотрудников пройдите по <a href="http://techvuz.dev.grapheme.ru/organization/order/26">ссылке</a>. Для получения оригиналов документов отправьте Почтой России, подписанные с Вашей стороны в 2-х экземплярах договор на оказание платных образовательных услуг и акт о выполнении работ.', NULL, '2014-12-11 11:03:29', '2014-12-11 11:03:29'),
(453, NULL, 8, 'moderator.order.closed.2014-12-11 11:03:29', 'Заказ №017-14 закрыт', NULL, '2014-12-11 11:03:29', '2014-12-11 11:03:29'),
(454, NULL, 5, 'global-discount-percent', 'Общая скидка', 0, '2014-10-29 11:18:38', '2014-12-11 11:38:13'),
(455, NULL, 2, 'moderator-listener-profile-update.2014-12-11 11:41:42', 'Слушатель: Огурцов Анатолий Степанович', NULL, '2014-12-11 11:41:42', '2014-12-11 11:41:42'),
(456, NULL, 8, 'moderator.register-listener.2014-12-11 11:42:44', 'Володя добавлен(а) к слушателям – сотрудникам ООО "Ковровский механический завод"', NULL, '2014-12-11 11:42:44', '2014-12-11 11:42:44'),
(457, NULL, 8, 'moderator.register-listener.2014-12-11 11:43:10', 'Самсонов Аркадий Степонович добавлен(а) к слушателям – сотрудникам ПМЖ-12', NULL, '2014-12-11 11:43:10', '2014-12-11 11:43:10'),
(458, NULL, 8, 'organization.study.finish.2014-12-11 11:57:08', 'Помидоров Аркадий Иванович прошел(а) итоговое тестирование по программе БС-01 с результатом 100%.', NULL, '2014-12-11 11:57:08', '2014-12-11 11:57:08'),
(460, NULL, 2, 'change-order-status.2014-12-11 12:42:19', 'Заказ №16', NULL, '2014-12-11 12:42:19', '2014-12-11 12:42:19'),
(462, NULL, 2, 'change-order-status.2014-12-11 13:04:23', 'Заказ №16', NULL, '2014-12-11 10:04:23', '2014-12-11 10:04:23'),
(464, NULL, 2, 'change-order-status.2014-12-11 13:04:26', 'Заказ №16', NULL, '2014-12-11 10:04:26', '2014-12-11 10:04:26'),
(466, NULL, 2, 'change-order-status.2014-12-11 13:04:48', 'Заказ №16', NULL, '2014-12-11 10:04:48', '2014-12-11 10:04:48'),
(467, NULL, 8, 'organization.order.yes-puy-yes-access.2014-12-11 13:05:20', 'Заказ <a href="http://techvuz.dev.grapheme.ru/organization/order/25">№016-14</a> оплачен. Сотрудники Вашей организации могут приступить к обучению.', NULL, '2014-12-11 10:05:20', '2014-12-11 10:05:20'),
(468, NULL, 2, 'change-order-status.2014-12-11 13:05:20', 'Заказ №16', NULL, '2014-12-11 10:05:20', '2014-12-11 10:05:20'),
(469, NULL, 8, 'moderator.register-organization.2014-12-11 13:29:30', 'Зарегистрирована организация ООО Компания', NULL, '2014-12-11 10:29:30', '2014-12-11 10:29:30'),
(470, NULL, 8, 'organization.select-courses.2014-12-11 13:30:05', 'Необходимо выбрать курс(ы) и оформить заказ', NULL, '2014-12-11 10:30:05', '2014-12-11 10:30:05'),
(471, NULL, 8, 'organization.register-listeners.2014-12-11 13:30:05', 'Необходимо добавить слушателей – сотрудников Вашей организации, которых необходимо обучить', NULL, '2014-12-11 10:30:05', '2014-12-11 10:30:05'),
(472, NULL, 8, 'account.approved-email.2014-12-11 13:30:05', 'Ваш личный кабинет активирован. Происходит проверка администратором сайта', NULL, '2014-12-11 10:30:05', '2014-12-11 10:30:05'),
(473, NULL, 8, 'moderator.register-listener.2014-12-11 13:39:21', 'Иванов Иван Иванович добавлен(а) к слушателям – сотрудникам ООО Компания', NULL, '2014-12-11 10:39:21', '2014-12-11 10:39:21'),
(474, NULL, 8, 'moderator.register-listener.2014-12-11 13:44:14', 'Иванову Ивану Ивановичу добавлен(а) к слушателям – сотрудникам ООО Компания', NULL, '2014-12-11 10:44:14', '2014-12-11 10:44:14');
INSERT INTO `dictionary_values` (`id`, `version_of`, `dic_id`, `slug`, `name`, `order`, `created_at`, `updated_at`) VALUES
(475, NULL, 8, 'organization.order-puy-no-approve.2014-12-11 13:54:53', 'Ваш заказ <a href="http://techvuz.dev.grapheme.ru/organization/order/27">№018-14</a> оформлен. Для получения договора на обучение и счета на оплату платных образовательных услуг необходимо дождаться окончания проверки администратором сайта. Проверка занимает не более 12 часов с момента активации личного кабинета', NULL, '2014-12-11 10:54:53', '2014-12-11 10:54:53'),
(476, NULL, 8, 'moderator.order.new.2014-12-11 13:54:53', 'Оформлен заказ №018-14', NULL, '2014-12-11 10:54:53', '2014-12-11 10:54:53'),
(477, NULL, 2, 'directions.update.2014-12-11 14:05:47', 'Строительство', NULL, '2014-12-11 11:05:47', '2014-12-11 11:05:47'),
(478, NULL, 2, 'directions.update.2014-12-11 14:06:32', 'Строительство', NULL, '2014-12-11 11:06:32', '2014-12-11 11:06:32'),
(479, NULL, 2, 'directions.update.2014-12-11 14:11:47', 'Строительство', NULL, '2014-12-11 11:11:47', '2014-12-11 11:11:47'),
(480, NULL, 2, 'courses.update.2014-12-11 15:49:06', 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства', NULL, '2014-12-11 12:49:06', '2014-12-11 12:49:06'),
(481, NULL, 2, 'directions.update.2014-12-11 15:49:49', 'Строительство', NULL, '2014-12-11 12:49:49', '2014-12-11 12:49:49'),
(482, NULL, 2, 'courses.update.2014-12-11 15:51:46', 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства', NULL, '2014-12-11 12:51:46', '2014-12-11 12:51:46'),
(483, NULL, 2, 'courses.update.2014-12-11 15:52:43', 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства', NULL, '2014-12-11 12:52:43', '2014-12-11 12:52:43'),
(484, NULL, 2, 'courses.update.2014-12-11 15:53:15', 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства', NULL, '2014-12-11 12:53:15', '2014-12-11 12:53:15'),
(485, NULL, 2, 'courses.update.2014-12-11 15:54:19', 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства', NULL, '2014-12-11 12:54:19', '2014-12-11 12:54:19'),
(486, NULL, 2, 'courses.update.2014-12-11 15:56:38', 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства', NULL, '2014-12-11 12:56:38', '2014-12-11 12:56:38'),
(487, NULL, 8, 'organization.order-puy.2014-12-11 15:56:55', 'Ваш заказ <a href="http://techvuz.dev.grapheme.ru/organization/order/28">№019-14</a> оформлен. Для получения доступа к лекционным материалам Вам необходимо оплатить <a href="http://techvuz.dev.grapheme.ru/organization/order/28/invoice/pdf">счет</a>. Доступ предоставляется в течение 2 часов с момента поступления денежных средств на расчетный счет образовательного портала ТЕХВУЗ.РФ', NULL, '2014-12-11 12:56:55', '2014-12-11 12:56:55'),
(488, NULL, 8, 'moderator.order.new.2014-12-11 15:56:55', 'Оформлен заказ №019-14', NULL, '2014-12-11 12:56:55', '2014-12-11 12:56:55'),
(489, NULL, 7, 'listener.approved-email', 'Ваш личный кабинет активирован.', 30, '2014-11-18 06:25:25', '2014-11-18 06:29:18'),
(490, NULL, 7, 'listener.study-access', 'Вам предоставлен доступ к обучению по курсу <a href="[link]">[course]</a>. Вы сможете приступить к итоговому тестированию [date].', 31, '2014-11-18 06:25:25', '2014-11-18 06:29:18'),
(491, NULL, 7, 'listener.study-finish', 'Вы завершили обучение по курсу [course].', 32, '2014-11-18 06:25:25', '2014-11-18 06:29:18'),
(492, NULL, 8, 'organization.study.finish.2014-12-11 19:20:38', 'Сорбат Владимир Николаевич прошел(а) итоговое тестирование по программе БС-01 с результатом 100%.', NULL, '2014-12-11 16:20:38', '2014-12-11 16:20:38'),
(493, NULL, 8, 'organization.order.closed.2014-12-11 19:20:39', 'Заказ <a href="http://techvuz.dev.grapheme.ru/organization/order/1">№001-14</a> закрыт. Все сотрудники Вашей организации успешно прошли итоговые тестирования по заданным курсам.', NULL, '2014-12-11 16:20:39', '2014-12-11 16:20:39'),
(494, NULL, 8, 'organization.order.closed-documents.2014-12-11 19:20:40', 'Для получения сканированных копий документов Ваших сотрудников пройдите по <a href="http://techvuz.dev.grapheme.ru/organization/order/1">ссылке</a>. Для получения оригиналов документов отправьте Почтой России, подписанные с Вашей стороны в 2-х экземплярах договор на оказание платных образовательных услуг и акт о выполнении работ.', NULL, '2014-12-11 16:20:40', '2014-12-11 16:20:40'),
(495, NULL, 8, 'moderator.order.closed.2014-12-11 19:20:40', 'Заказ №001-14 закрыт', NULL, '2014-12-11 16:20:40', '2014-12-11 16:20:40'),
(496, NULL, 8, 'organization.order.part-puy-yes-access.2014-12-12 11:06:34', 'Заказ <a href="http://techvuz.dev.grapheme.ru/organization/order/28">№019-14</a> оплачен частично, но доступ к обучению предоставлен.', NULL, '2014-12-12 08:06:34', '2014-12-12 08:06:34'),
(497, NULL, 2, 'change-order-status.2014-12-12 11:06:34', 'Заказ №19', NULL, '2014-12-12 08:06:34', '2014-12-12 08:06:34'),
(498, NULL, 8, 'listener.study-access.2014-12-12 11:09:42', 'Вам предоставлен доступ к обучению по курсу <a href="http://techvuz.dev.grapheme.ru/listener/study/course/74-stroitelstvo-rekonstrukciya-kapitalnyiy-remont-obektov-kapitalnogo-stroitelstva">БС-00</a>. Вы сможете приступить к итоговому тестированию 21.12.2014.', NULL, '2014-12-12 08:09:42', '2014-12-12 08:09:42'),
(499, NULL, 8, 'organization.study.begin.2014-12-12 11:09:58', 'Володя Питерсикий приступил(а) к обучению по программе БС-00. К итоговому тестированию по программе БС-00 можно будет приступить через 72 академических часа.', NULL, '2014-12-12 08:09:58', '2014-12-12 08:09:58'),
(500, NULL, 8, 'organization.study.finish.2014-12-12 11:10:13', 'Володя Питерсикий прошел(а) итоговое тестирование по программе БС-00 с результатом 100%.', NULL, '2014-12-12 08:10:13', '2014-12-12 08:10:13'),
(501, NULL, 8, 'listener.study-finish.2014-12-12 11:10:13', 'Вы завершили обучение по курсу БС-00.', NULL, '2014-12-12 08:10:13', '2014-12-12 08:10:13'),
(502, NULL, 7, 'organization.approved-email', 'Ваш личный кабинет активирован. Происходит проверка администратором сайта.<br>Необходимо добавить слушателей – сотрудников Вашей организации, которых необходимо обучить.<br>Необходимо выбрать курс(ы) и оформить заказ.', 33, '2014-11-14 07:18:28', '2014-11-14 06:22:38'),
(503, NULL, 7, 'individual.approved-email', 'Ваш личный кабинет активирован. Происходит проверка администратором сайта.<br>Необходимо выбрать курс(ы) и оформить заказ.', 34, '2014-11-14 07:18:28', '2014-11-14 06:22:38'),
(504, NULL, 7, 'organization.order.closed-join', 'Заказ <a href="[link]">№[order]</a> закрыт. Все сотрудники Вашей организации успешно прошли итоговые тестирования по заданным курсам.<br>Для получения сканированных копий документов Ваших сотрудников пройдите по <a href="[link]">ссылке</a>. Для получения оригиналов документов отправьте Почтой России, подписанные с Вашей стороны в 2-х экземплярах договор на оказание платных образовательных услуг и акт о выполнении работ.', 33, '2014-11-14 07:18:28', '2014-11-14 06:22:38'),
(505, NULL, 7, 'individual.order.closed-join', 'Заказ <a href="[link]">№[order]</a> закрыт. Вы успешно прошли итоговые тестирования по заданным курсам.<br>Для получения сканированных копий документов пройдите по <a href="[link]">ссылке</a>. Для получения оригиналов документов отправьте Почтой России, подписанные с Вашей стороны в 2-х экземплярах договор на оказание платных образовательных услуг и акт о выполнении работ.', 34, '2014-11-14 07:18:28', '2014-11-14 06:22:38'),
(506, NULL, 8, 'moderator.register-organization.2014-12-12 11:55:52', 'Зарегистрирована организация ООО "Ковровский механический завод"', NULL, '2014-12-12 08:55:52', '2014-12-12 08:55:52'),
(507, NULL, 8, 'organization.approved-email.2014-12-12 12:02:47', 'Ваш личный кабинет активирован. Происходит проверка администратором сайта.<br>Необходимо добавить слушателей – сотрудников Вашей организации, которых необходимо обучить.<br>Необходимо выбрать курс(ы) и оформить заказ.', NULL, '2014-12-12 09:02:47', '2014-12-12 09:02:47'),
(508, NULL, 8, 'moderator.register-listener.2014-12-12 12:05:16', 'Володя добавлен(а) к слушателям – сотрудникам ООО "Ковровский механический завод"', NULL, '2014-12-12 09:05:16', '2014-12-12 09:05:16'),
(509, NULL, 8, 'organization.order-puy-no-approve.2014-12-12 12:05:40', 'Ваш заказ <a href="http://techvuz.dev.grapheme.ru/organization/order/29">№020-14</a> оформлен. Для получения договора на обучение и счета на оплату платных образовательных услуг необходимо дождаться окончания проверки администратором сайта. Проверка занимает не более 12 часов с момента активации личного кабинета', NULL, '2014-12-12 09:05:40', '2014-12-12 09:05:40'),
(510, NULL, 8, 'moderator.order.new.2014-12-12 12:05:40', 'Оформлен заказ №020-14', NULL, '2014-12-12 09:05:40', '2014-12-12 09:05:40'),
(511, NULL, 8, 'listener.study-access.2014-12-12 12:06:11', 'Вам предоставлен доступ к обучению по курсу <a href="http://techvuz.dev.grapheme.ru/listener/study/course//78-stroitelstvo-rekonstrukciya-kapitalnyiy-remont-obektov-kapitalnogo-stroitelstva-vypolnenie-geodezich">БС-01</a>. Вы сможете приступить к итоговому тестированию 21.12.2014.', NULL, '2014-12-12 09:06:11', '2014-12-12 09:06:11'),
(512, NULL, 8, 'organization.order.yes-puy-yes-access.2014-12-12 12:06:11', 'Заказ <a href="http://techvuz.dev.grapheme.ru/organization/order/29">№020-14</a> оплачен. Сотрудники Вашей организации могут приступить к обучению.', NULL, '2014-12-12 09:06:11', '2014-12-12 09:06:11'),
(513, NULL, 2, 'payment-order-number-store.2014-12-12 12:06:11', 'Заказ №1. Сумма: 560 руб.', NULL, '2014-12-12 09:06:11', '2014-12-12 09:06:11'),
(514, NULL, 8, 'organization.study.begin.2014-12-12 12:10:55', 'Володя приступил(а) к обучению по программе БС-01. К итоговому тестированию по программе БС-01 можно будет приступить через 72 академических часа.', NULL, '2014-12-12 09:10:55', '2014-12-12 09:10:55'),
(515, NULL, 2, 'moderator-order-update.2014-12-12 12:14:56', '№020-14', NULL, '2014-12-12 09:14:56', '2014-12-12 09:14:56'),
(516, NULL, 8, 'organization.study.finish.2014-12-12 12:15:21', 'Володя прошел(а) итоговое тестирование по программе БС-01 с результатом 100%.', NULL, '2014-12-12 09:15:21', '2014-12-12 09:15:21'),
(517, NULL, 8, 'listener.study-finish.2014-12-12 12:15:21', 'Вы завершили обучение по курсу БС-01.', NULL, '2014-12-12 09:15:21', '2014-12-12 09:15:21'),
(518, NULL, 8, 'organization.order.closed-join.2014-12-12 12:15:22', 'Заказ <a href="http://techvuz.dev.grapheme.ru/organization/order/29">№020-14</a> закрыт. Все сотрудники Вашей организации успешно прошли итоговые тестирования по заданным курсам.<br>Для получения сканированных копий документов Ваших сотрудников пройдите по <a href="http://techvuz.dev.grapheme.ru/organization/order/29">ссылке</a>. Для получения оригиналов документов отправьте Почтой России, подписанные с Вашей стороны в 2-х экземплярах договор на оказание платных образовательных услуг и акт о выполнении работ.', NULL, '2014-12-12 09:15:22', '2014-12-12 09:15:22'),
(519, NULL, 8, 'moderator.order.closed.2014-12-12 12:15:22', 'Заказ №020-14 закрыт', NULL, '2014-12-12 09:15:22', '2014-12-12 09:15:22'),
(520, NULL, 7, 'moderator.update-profile-individual', 'Индивидуальный слушатель [listener] обновил регистрационные данные', 35, '2014-11-05 14:26:33', '2014-11-05 14:26:33'),
(521, NULL, 1, 'moderator-listener-profile-approved', 'Подтвержден аккаунт индивидуального слушателя', 33, '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(522, NULL, 8, 'moderator.register-organization.2014-12-15 10:46:17', 'Зарегистрирована организация ропропроппрапроавапвап34343 @@""', NULL, '2014-12-15 07:46:17', '2014-12-15 07:46:17'),
(523, NULL, 8, 'moderator.register-organization.2014-12-15 10:52:41', 'Зарегистрирована организация ООО ""Рога и копыта', NULL, '2014-12-15 07:52:41', '2014-12-15 07:52:41'),
(524, NULL, 8, 'organization.approved-email.2014-12-15 10:53:25', 'Ваш личный кабинет активирован. Происходит проверка администратором сайта.<br>Необходимо добавить слушателей – сотрудников Вашей организации, которых необходимо обучить.<br>Необходимо выбрать курс(ы) и оформить заказ.', NULL, '2014-12-15 07:53:25', '2014-12-15 07:53:25'),
(525, NULL, 8, 'moderator.register-listener.2014-12-15 10:57:39', 'Кулебякин Анатолий Анатольевич  добавлен(а) к слушателям – сотрудникам ООО ""Рога и копыта', NULL, '2014-12-15 07:57:39', '2014-12-15 07:57:39'),
(526, NULL, 8, 'listener.approved-email.2014-12-15 10:58:19', 'Ваш личный кабинет активирован.', NULL, '2014-12-15 07:58:19', '2014-12-15 07:58:19'),
(527, NULL, 2, 'moderator-company-profile-approved.2014-12-15 11:01:31', 'ООО ""Рога и копыта', NULL, '2014-12-15 08:01:31', '2014-12-15 08:01:31'),
(528, NULL, 8, 'account.approved-profile.2014-12-15 11:01:31', 'Вы успешно прошли проверку администратора сайта ТЕХВУЗ.РФ. Теперь у Вас появился доступ к документации (договоры, счета, акты).', NULL, '2014-12-15 08:01:31', '2014-12-15 08:01:31'),
(529, NULL, 2, 'moderator-company-profile-update.2014-12-15 11:01:31', 'Организация: ООО ""Рога и копыта', NULL, '2014-12-15 08:01:31', '2014-12-15 08:01:31'),
(530, NULL, 8, 'moderator.register-listener.2014-12-15 11:03:44', 'fut6ujr добавлен(а) к слушателям – сотрудникам ООО ""Рога и копыта', NULL, '2014-12-15 08:03:44', '2014-12-15 08:03:44'),
(531, NULL, 8, 'listener.approved-email.2014-12-15 11:05:08', 'Ваш личный кабинет активирован.', NULL, '2014-12-15 08:05:08', '2014-12-15 08:05:08'),
(532, NULL, 8, 'moderator.register-listener.2014-12-15 11:12:03', '6757r6yrt добавлен(а) к слушателям – сотрудникам ООО ""Рога и копыта', NULL, '2014-12-15 08:12:03', '2014-12-15 08:12:03'),
(533, NULL, 8, 'organization.order-puy.2014-12-15 11:12:35', 'Ваш заказ <a href="http://techvuz.dev.grapheme.ru/organization/order/30">№021-14</a> оформлен. Для получения доступа к лекционным материалам Вам необходимо оплатить <a href="http://techvuz.dev.grapheme.ru/organization/order/30/invoice/pdf">счет</a>. Доступ предоставляется в течение 2 часов с момента поступления денежных средств на расчетный счет образовательного портала ТЕХВУЗ.РФ', NULL, '2014-12-15 08:12:35', '2014-12-15 08:12:35'),
(534, NULL, 8, 'moderator.order.new.2014-12-15 11:12:35', 'Оформлен заказ №021-14', NULL, '2014-12-15 08:12:35', '2014-12-15 08:12:35'),
(535, NULL, 8, 'listener.study-access.2014-12-15 11:16:40', 'Вам предоставлен доступ к обучению по курсу <a href="http://techvuz.dev.grapheme.ru/listener/study/course/80-stroitelstvo-rekonstrukciya-kapitalnyiy-remont-obektov-kapitalnogo-stroitelstva-vypolnenie-geodezich">БС-01</a>. Вы сможете приступить к итоговому тестированию 24.12.2014.', NULL, '2014-12-15 08:16:40', '2014-12-15 08:16:40'),
(536, NULL, 8, 'listener.study-access.2014-12-15 11:16:41', 'Вам предоставлен доступ к обучению по курсу <a href="http://techvuz.dev.grapheme.ru/listener/study/course/79-stroitelstvo-rekonstrukciya-kapitalnyiy-remont-obektov-kapitalnogo-stroitelstva-vypolnenie-geodezich">БС-01</a>. Вы сможете приступить к итоговому тестированию 24.12.2014.', NULL, '2014-12-15 08:16:41', '2014-12-15 08:16:41'),
(537, NULL, 8, 'listener.study-access.2014-12-15 11:16:42', 'Вам предоставлен доступ к обучению по курсу <a href="http://techvuz.dev.grapheme.ru/listener/study/course/81-stroitelstvo-rekonstrukciya-kapitalnyiy-remont-obektov-kapitalnogo-stroitelstva-vypolnenie-montajnyh">БС-08</a>. Вы сможете приступить к итоговому тестированию 24.12.2014.', NULL, '2014-12-15 08:16:42', '2014-12-15 08:16:42'),
(538, NULL, 8, 'listener.study-access.2014-12-15 11:16:43', 'Вам предоставлен доступ к обучению по курсу <a href="http://techvuz.dev.grapheme.ru/listener/study/course/83-stroitelstvo-rekonstrukciya-kapitalnyiy-remont-obektov-kapitalnogo-stroitelstva-organizaciya-stroite">БС-16</a>. Вы сможете приступить к итоговому тестированию 24.12.2014.', NULL, '2014-12-15 08:16:43', '2014-12-15 08:16:43'),
(539, NULL, 8, 'listener.study-access.2014-12-15 11:16:44', 'Вам предоставлен доступ к обучению по курсу <a href="http://techvuz.dev.grapheme.ru/listener/study/course/82-stroitelstvo-rekonstrukciya-kapitalnyiy-remont-obektov-kapitalnogo-stroitelstva-vypolnenie-montajnyh">БС-08</a>. Вы сможете приступить к итоговому тестированию 24.12.2014.', NULL, '2014-12-15 08:16:44', '2014-12-15 08:16:44'),
(540, NULL, 8, 'listener.study-access.2014-12-15 11:16:46', 'Вам предоставлен доступ к обучению по курсу <a href="http://techvuz.dev.grapheme.ru/listener/study/course/84-stroitelstvo-rekonstrukciya-kapitalnyiy-remont-obektov-kapitalnogo-stroitelstva-organizaciya-stroite">БС-16</a>. Вы сможете приступить к итоговому тестированию 24.12.2014.', NULL, '2014-12-15 08:16:46', '2014-12-15 08:16:46'),
(541, NULL, 8, 'listener.study-access.2014-12-15 11:16:51', 'Вам предоставлен доступ к обучению по курсу <a href="http://techvuz.dev.grapheme.ru/listener/study/course/80-stroitelstvo-rekonstrukciya-kapitalnyiy-remont-obektov-kapitalnogo-stroitelstva-vypolnenie-geodezich">БС-01</a>. Вы сможете приступить к итоговому тестированию 24.12.2014.', NULL, '2014-12-15 08:16:51', '2014-12-15 08:16:51'),
(542, NULL, 8, 'listener.study-access.2014-12-15 11:16:51', 'Вам предоставлен доступ к обучению по курсу <a href="http://techvuz.dev.grapheme.ru/listener/study/course/79-stroitelstvo-rekonstrukciya-kapitalnyiy-remont-obektov-kapitalnogo-stroitelstva-vypolnenie-geodezich">БС-01</a>. Вы сможете приступить к итоговому тестированию 24.12.2014.', NULL, '2014-12-15 08:16:51', '2014-12-15 08:16:51'),
(543, NULL, 8, 'listener.study-access.2014-12-15 11:16:51', 'Вам предоставлен доступ к обучению по курсу <a href="http://techvuz.dev.grapheme.ru/listener/study/course/81-stroitelstvo-rekonstrukciya-kapitalnyiy-remont-obektov-kapitalnogo-stroitelstva-vypolnenie-montajnyh">БС-08</a>. Вы сможете приступить к итоговому тестированию 24.12.2014.', NULL, '2014-12-15 08:16:51', '2014-12-15 08:16:51'),
(544, NULL, 8, 'listener.study-access.2014-12-15 11:16:51', 'Вам предоставлен доступ к обучению по курсу <a href="http://techvuz.dev.grapheme.ru/listener/study/course/83-stroitelstvo-rekonstrukciya-kapitalnyiy-remont-obektov-kapitalnogo-stroitelstva-organizaciya-stroite">БС-16</a>. Вы сможете приступить к итоговому тестированию 24.12.2014.', NULL, '2014-12-15 08:16:52', '2014-12-15 08:16:52'),
(545, NULL, 8, 'listener.study-access.2014-12-15 11:16:52', 'Вам предоставлен доступ к обучению по курсу <a href="http://techvuz.dev.grapheme.ru/listener/study/course/82-stroitelstvo-rekonstrukciya-kapitalnyiy-remont-obektov-kapitalnogo-stroitelstva-vypolnenie-montajnyh">БС-08</a>. Вы сможете приступить к итоговому тестированию 24.12.2014.', NULL, '2014-12-15 08:16:52', '2014-12-15 08:16:52'),
(546, NULL, 8, 'listener.study-access.2014-12-15 11:16:52', 'Вам предоставлен доступ к обучению по курсу <a href="http://techvuz.dev.grapheme.ru/listener/study/course/84-stroitelstvo-rekonstrukciya-kapitalnyiy-remont-obektov-kapitalnogo-stroitelstva-organizaciya-stroite">БС-16</a>. Вы сможете приступить к итоговому тестированию 24.12.2014.', NULL, '2014-12-15 08:16:52', '2014-12-15 08:16:52'),
(547, NULL, 8, 'organization.order.yes-puy-yes-access.2014-12-15 11:16:56', 'Заказ <a href="http://techvuz.dev.grapheme.ru/organization/order/30">№021-14</a> оплачен. Сотрудники Вашей организации могут приступить к обучению.', NULL, '2014-12-15 08:16:56', '2014-12-15 08:16:56'),
(548, NULL, 2, 'change-order-status.2014-12-15 11:16:56', 'Заказ №21', NULL, '2014-12-15 08:16:56', '2014-12-15 08:16:56'),
(549, NULL, 8, 'listener.study-access.2014-12-15 11:17:12', 'Вам предоставлен доступ к обучению по курсу <a href="http://techvuz.dev.grapheme.ru/listener/study/course/79-stroitelstvo-rekonstrukciya-kapitalnyiy-remont-obektov-kapitalnogo-stroitelstva-vypolnenie-geodezich">БС-01</a>. Вы сможете приступить к итоговому тестированию 24.12.2014.', NULL, '2014-12-15 08:17:12', '2014-12-15 08:17:12'),
(550, NULL, 8, 'listener.study-access.2014-12-15 11:17:12', 'Вам предоставлен доступ к обучению по курсу <a href="http://techvuz.dev.grapheme.ru/listener/study/course/80-stroitelstvo-rekonstrukciya-kapitalnyiy-remont-obektov-kapitalnogo-stroitelstva-vypolnenie-geodezich">БС-01</a>. Вы сможете приступить к итоговому тестированию 24.12.2014.', NULL, '2014-12-15 08:17:12', '2014-12-15 08:17:12'),
(551, NULL, 8, 'listener.study-access.2014-12-15 11:17:12', 'Вам предоставлен доступ к обучению по курсу <a href="http://techvuz.dev.grapheme.ru/listener/study/course/81-stroitelstvo-rekonstrukciya-kapitalnyiy-remont-obektov-kapitalnogo-stroitelstva-vypolnenie-montajnyh">БС-08</a>. Вы сможете приступить к итоговому тестированию 24.12.2014.', NULL, '2014-12-15 08:17:12', '2014-12-15 08:17:12'),
(552, NULL, 8, 'listener.study-access.2014-12-15 11:17:12', 'Вам предоставлен доступ к обучению по курсу <a href="http://techvuz.dev.grapheme.ru/listener/study/course/82-stroitelstvo-rekonstrukciya-kapitalnyiy-remont-obektov-kapitalnogo-stroitelstva-vypolnenie-montajnyh">БС-08</a>. Вы сможете приступить к итоговому тестированию 24.12.2014.', NULL, '2014-12-15 08:17:12', '2014-12-15 08:17:12'),
(553, NULL, 8, 'listener.study-access.2014-12-15 11:17:12', 'Вам предоставлен доступ к обучению по курсу <a href="http://techvuz.dev.grapheme.ru/listener/study/course/83-stroitelstvo-rekonstrukciya-kapitalnyiy-remont-obektov-kapitalnogo-stroitelstva-organizaciya-stroite">БС-16</a>. Вы сможете приступить к итоговому тестированию 24.12.2014.', NULL, '2014-12-15 08:17:12', '2014-12-15 08:17:12'),
(554, NULL, 8, 'listener.study-access.2014-12-15 11:17:12', 'Вам предоставлен доступ к обучению по курсу <a href="http://techvuz.dev.grapheme.ru/listener/study/course/84-stroitelstvo-rekonstrukciya-kapitalnyiy-remont-obektov-kapitalnogo-stroitelstva-organizaciya-stroite">БС-16</a>. Вы сможете приступить к итоговому тестированию 24.12.2014.', NULL, '2014-12-15 08:17:12', '2014-12-15 08:17:12'),
(555, NULL, 8, 'organization.order.yes-puy-yes-access.2014-12-15 11:17:12', 'Заказ <a href="http://techvuz.dev.grapheme.ru/organization/order/30">№021-14</a> оплачен. Сотрудники Вашей организации могут приступить к обучению.', NULL, '2014-12-15 08:17:12', '2014-12-15 08:17:12'),
(556, NULL, 2, 'payment-order-number-store.2014-12-15 11:17:12', 'Заказ №1. Сумма: 240 руб.', NULL, '2014-12-15 08:17:12', '2014-12-15 08:17:12'),
(557, NULL, 8, 'listener.study-access.2014-12-15 11:22:33', 'Вам предоставлен доступ к обучению по курсу <a href="http://techvuz.dev.grapheme.ru/listener/study/course/83-stroitelstvo-rekonstrukciya-kapitalnyiy-remont-obektov-kapitalnogo-stroitelstva-organizaciya-stroite">БС-16</a>. Вы сможете приступить к итоговому тестированию 24.12.2014.', NULL, '2014-12-15 08:22:33', '2014-12-15 08:22:33'),
(558, NULL, 8, 'listener.study-access.2014-12-15 11:22:33', 'Вам предоставлен доступ к обучению по курсу <a href="http://techvuz.dev.grapheme.ru/listener/study/course/84-stroitelstvo-rekonstrukciya-kapitalnyiy-remont-obektov-kapitalnogo-stroitelstva-organizaciya-stroite">БС-16</a>. Вы сможете приступить к итоговому тестированию 24.12.2014.', NULL, '2014-12-15 08:22:33', '2014-12-15 08:22:33'),
(559, NULL, 8, 'listener.study-access.2014-12-15 11:22:33', 'Вам предоставлен доступ к обучению по курсу <a href="http://techvuz.dev.grapheme.ru/listener/study/course/80-stroitelstvo-rekonstrukciya-kapitalnyiy-remont-obektov-kapitalnogo-stroitelstva-vypolnenie-geodezich">БС-01</a>. Вы сможете приступить к итоговому тестированию 24.12.2014.', NULL, '2014-12-15 08:22:33', '2014-12-15 08:22:33'),
(560, NULL, 8, 'listener.study-access.2014-12-15 11:22:33', 'Вам предоставлен доступ к обучению по курсу <a href="http://techvuz.dev.grapheme.ru/listener/study/course/79-stroitelstvo-rekonstrukciya-kapitalnyiy-remont-obektov-kapitalnogo-stroitelstva-vypolnenie-geodezich">БС-01</a>. Вы сможете приступить к итоговому тестированию 24.12.2014.', NULL, '2014-12-15 08:22:33', '2014-12-15 08:22:33'),
(561, NULL, 8, 'listener.study-access.2014-12-15 11:22:33', 'Вам предоставлен доступ к обучению по курсу <a href="http://techvuz.dev.grapheme.ru/listener/study/course/82-stroitelstvo-rekonstrukciya-kapitalnyiy-remont-obektov-kapitalnogo-stroitelstva-vypolnenie-montajnyh">БС-08</a>. Вы сможете приступить к итоговому тестированию 24.12.2014.', NULL, '2014-12-15 08:22:33', '2014-12-15 08:22:33'),
(562, NULL, 8, 'listener.study-access.2014-12-15 11:22:33', 'Вам предоставлен доступ к обучению по курсу <a href="http://techvuz.dev.grapheme.ru/listener/study/course/81-stroitelstvo-rekonstrukciya-kapitalnyiy-remont-obektov-kapitalnogo-stroitelstva-vypolnenie-montajnyh">БС-08</a>. Вы сможете приступить к итоговому тестированию 24.12.2014.', NULL, '2014-12-15 08:22:33', '2014-12-15 08:22:33'),
(563, NULL, 8, 'organization.study.begin.2014-12-15 11:22:54', 'Кулебякин Анатолий Анатольевич  приступил(а) к обучению по программе БС-08. К итоговому тестированию по программе БС-08 можно будет приступить через 72 академических часа.', NULL, '2014-12-15 08:22:54', '2014-12-15 08:22:54'),
(564, NULL, 8, 'organization.study.begin.2014-12-15 11:23:38', 'Кулебякин Анатолий Анатольевич  приступил(а) к обучению по программе БС-16. К итоговому тестированию по программе БС-16 можно будет приступить через 72 академических часа.', NULL, '2014-12-15 08:23:38', '2014-12-15 08:23:38'),
(565, NULL, 8, 'organization.order.part-puy-yes-access.2014-12-15 11:29:59', 'Заказ <a href="http://techvuz.dev.grapheme.ru/organization/order/30">№021-14</a> оплачен частично, но доступ к обучению предоставлен.', NULL, '2014-12-15 08:29:59', '2014-12-15 08:29:59'),
(566, NULL, 2, 'change-order-status.2014-12-15 11:29:59', 'Заказ №21', NULL, '2014-12-15 08:29:59', '2014-12-15 08:29:59'),
(567, NULL, 8, 'organization.order.not-puy-yes-access.2014-12-15 11:30:32', 'Заказ <a href="http://techvuz.dev.grapheme.ru/organization/order/30">№021-14</a> не оплачен, но доступ к обучению предоставлен.', NULL, '2014-12-15 08:30:32', '2014-12-15 08:30:32'),
(568, NULL, 2, 'change-order-status.2014-12-15 11:30:32', 'Заказ №21', NULL, '2014-12-15 08:30:32', '2014-12-15 08:30:32'),
(569, NULL, 8, 'listener.study-access.2014-12-15 11:30:44', 'Вам предоставлен доступ к обучению по курсу <a href="http://techvuz.dev.grapheme.ru/listener/study/course/84-stroitelstvo-rekonstrukciya-kapitalnyiy-remont-obektov-kapitalnogo-stroitelstva-organizaciya-stroite">БС-16</a>. Вы сможете приступить к итоговому тестированию 24.12.2014.', NULL, '2014-12-15 08:30:44', '2014-12-15 08:30:44'),
(570, NULL, 8, 'listener.study-access.2014-12-15 11:30:44', 'Вам предоставлен доступ к обучению по курсу <a href="http://techvuz.dev.grapheme.ru/listener/study/course/83-stroitelstvo-rekonstrukciya-kapitalnyiy-remont-obektov-kapitalnogo-stroitelstva-organizaciya-stroite">БС-16</a>. Вы сможете приступить к итоговому тестированию 24.12.2014.', NULL, '2014-12-15 08:30:44', '2014-12-15 08:30:44'),
(571, NULL, 8, 'listener.study-access.2014-12-15 11:30:44', 'Вам предоставлен доступ к обучению по курсу <a href="http://techvuz.dev.grapheme.ru/listener/study/course/79-stroitelstvo-rekonstrukciya-kapitalnyiy-remont-obektov-kapitalnogo-stroitelstva-vypolnenie-geodezich">БС-01</a>. Вы сможете приступить к итоговому тестированию 24.12.2014.', NULL, '2014-12-15 08:30:44', '2014-12-15 08:30:44'),
(572, NULL, 8, 'listener.study-access.2014-12-15 11:30:44', 'Вам предоставлен доступ к обучению по курсу <a href="http://techvuz.dev.grapheme.ru/listener/study/course/80-stroitelstvo-rekonstrukciya-kapitalnyiy-remont-obektov-kapitalnogo-stroitelstva-vypolnenie-geodezich">БС-01</a>. Вы сможете приступить к итоговому тестированию 24.12.2014.', NULL, '2014-12-15 08:30:44', '2014-12-15 08:30:44'),
(573, NULL, 8, 'listener.study-access.2014-12-15 11:30:44', 'Вам предоставлен доступ к обучению по курсу <a href="http://techvuz.dev.grapheme.ru/listener/study/course/81-stroitelstvo-rekonstrukciya-kapitalnyiy-remont-obektov-kapitalnogo-stroitelstva-vypolnenie-montajnyh">БС-08</a>. Вы сможете приступить к итоговому тестированию 24.12.2014.', NULL, '2014-12-15 08:30:44', '2014-12-15 08:30:44'),
(574, NULL, 8, 'listener.study-access.2014-12-15 11:30:44', 'Вам предоставлен доступ к обучению по курсу <a href="http://techvuz.dev.grapheme.ru/listener/study/course/82-stroitelstvo-rekonstrukciya-kapitalnyiy-remont-obektov-kapitalnogo-stroitelstva-vypolnenie-montajnyh">БС-08</a>. Вы сможете приступить к итоговому тестированию 24.12.2014.', NULL, '2014-12-15 08:30:44', '2014-12-15 08:30:44'),
(575, NULL, 8, 'organization.order-puy.2014-12-15 11:32:03', 'Ваш заказ <a href="http://techvuz.dev.grapheme.ru/organization/order/31">№022-14</a> оформлен. Для получения доступа к лекционным материалам Вам необходимо оплатить <a href="http://techvuz.dev.grapheme.ru/organization/order/31/invoice/pdf">счет</a>. Доступ предоставляется в течение 2 часов с момента поступления денежных средств на расчетный счет образовательного портала ТЕХВУЗ.РФ', NULL, '2014-12-15 08:32:03', '2014-12-15 08:32:03'),
(576, NULL, 8, 'moderator.order.new.2014-12-15 11:32:04', 'Оформлен заказ №022-14', NULL, '2014-12-15 08:32:04', '2014-12-15 08:32:04'),
(577, NULL, 8, 'listener.study-access.2014-12-15 11:32:40', 'Вам предоставлен доступ к обучению по курсу <a href="http://techvuz.dev.grapheme.ru/listener/study/course/85-stroitelstvo-rekonstrukciya-kapitalnyiy-remont-obektov-kapitalnogo-stroitelstva">БС-00</a>. Вы сможете приступить к итоговому тестированию 24.12.2014.', NULL, '2014-12-15 08:32:40', '2014-12-15 08:32:40'),
(578, NULL, 8, 'organization.order.part-puy-yes-access.2014-12-15 11:33:06', 'Заказ <a href="http://techvuz.dev.grapheme.ru/organization/order/31">№022-14</a> оплачен частично, но доступ к обучению предоставлен.', NULL, '2014-12-15 08:33:06', '2014-12-15 08:33:06'),
(579, NULL, 2, 'change-order-status.2014-12-15 11:33:06', 'Заказ №22', NULL, '2014-12-15 08:33:06', '2014-12-15 08:33:06'),
(580, NULL, 8, 'listener.study-access.2014-12-15 11:34:22', 'Вам предоставлен доступ к обучению по курсу <a href="http://techvuz.dev.grapheme.ru/listener/study/course/85-stroitelstvo-rekonstrukciya-kapitalnyiy-remont-obektov-kapitalnogo-stroitelstva">БС-00</a>. Вы сможете приступить к итоговому тестированию 24.12.2014.', NULL, '2014-12-15 08:34:22', '2014-12-15 08:34:22'),
(581, NULL, 2, 'testing.index.2014-12-15 11:42:40', 'Промежуточное тестирование. Курс: Строительство, реконструкция, капитальный ремонт объектов капитального строительства (выполнение монтажных и пусконаладочных работ)', NULL, '2014-12-15 08:42:40', '2014-12-15 08:42:40'),
(582, NULL, 8, 'organization.study.fail-finish.2014-12-15 11:43:34', 'Кулебякин Анатолий Анатольевич  неудачно завершил(а) итоговое тестирование по программе БС-08 с результатом 0%.', NULL, '2014-12-15 08:43:34', '2014-12-15 08:43:34'),
(583, NULL, 8, 'organization.study.control.2014-12-15 11:44:14', 'Кулебякин Анатолий Анатольевич  успешно завершил(а) промежуточное тестирования по программе БС-08 с результатом 100%.', NULL, '2014-12-15 08:44:14', '2014-12-15 08:44:14'),
(584, NULL, 7, 'individual.order-puy-no-approve', 'Ваш заказ <a href="[link]">№[order]</a> оформлен. Для получения договора на обучение и счета на оплату платных образовательных услуг необходимо дождаться окончания проверки администратором сайта. Проверка занимает не более 12 часов с момента активации личного кабинета', 36, '2014-11-06 06:27:17', '2014-11-06 11:24:22'),
(585, NULL, 7, 'individual.order-puy', 'Ваш заказ <a href="[order_link]">№[order]</a> оформлен. Для получения доступа к лекционным материалам Вам необходимо оплатить <a href="[document_link]">счет</a>. Доступ предоставляется в течение 2 часов с момента поступления денежных средств на расчетный счет образовательного портала ТЕХВУЗ.РФ', 37, '2014-11-05 14:26:33', '2014-11-05 14:26:33'),
(586, NULL, 7, 'individual.order.part-puy-not-access', 'Заказ <a href="[link]">№[order]</a> оплачен частично.', 38, '2014-11-05 14:26:33', '2014-11-05 14:26:33'),
(587, NULL, 7, 'individual.order.yes-puy-yes-access', 'Заказ <a href="[link]">№[order]</a> оплачен.', 39, '2014-11-05 14:26:33', '2014-11-05 14:26:33'),
(588, NULL, 7, 'moderator.register-organization', 'Зарегистрировался индивидуальный слушатель <a href="[link]">[listener]</a>', 40, '2014-11-05 14:26:33', '2014-11-05 14:26:33'),
(589, NULL, 7, 'individual.study.begin', '[listener] приступил к обучению по программе [course]. К итоговому тестированию по программе [course] можно будет приступить через 72 академических часа.', 41, '2014-11-05 14:26:33', '2014-11-05 14:26:33'),
(595, NULL, 6, 'fiz-order-documents-contract', 'Договор для индивидуального слушателя', 18, '2014-12-17 07:19:55', '2014-12-17 12:40:38'),
(597, NULL, 2, 'otredaktirovan-document.2014-12-17 11:44:39', 'Событие за 17.12.2014 в 11:44', NULL, '2014-12-17 08:44:39', '2014-12-17 08:44:39'),
(599, NULL, 2, 'otredaktirovan-document.2014-12-17 11:46:07', 'Событие за 17.12.2014 в 11:46', NULL, '2014-12-17 08:46:07', '2014-12-17 08:46:07'),
(601, NULL, 2, 'otredaktirovan-document.2014-12-17 11:46:13', 'Событие за 17.12.2014 в 11:46', NULL, '2014-12-17 08:46:13', '2014-12-17 08:46:13'),
(604, NULL, 2, 'otredaktirovan-document.2014-12-17 12:09:40', 'Событие за 17.12.2014 в 12:09', NULL, '2014-12-17 09:09:40', '2014-12-17 09:09:40'),
(605, NULL, 6, 'fiz-order-documents-contract-listeners', 'Приложение №1 к договору индивидуального слушателя', 19, '2014-10-29 11:18:38', '2014-12-17 09:22:33'),
(606, 605, 6, 'fiz-order-documents-contract-listeners', 'Приложение №1 к договору индивидуального слушателя', 19, '2014-12-17 09:22:33', '2014-12-17 09:22:33'),
(607, 34, 6, 'order-documents-invoice', 'Счет', 2, '2014-12-17 09:24:45', '2014-12-17 09:24:45'),
(611, 291, 6, 'order-documents-attestation-sheet', 'Аттестационные ведомости', 16, '2014-12-17 11:30:21', '2014-12-17 11:30:21'),
(619, 35, 6, 'order-documents-act', 'Акт (Общий)', 3, '2014-12-17 12:33:01', '2014-12-17 12:33:01'),
(622, 33, 6, 'order-documents-contract', 'Договор для организации', 1, '2014-12-17 12:38:55', '2014-12-17 12:38:55'),
(623, 595, 6, 'fiz-order-documents-contract', 'Договор для индивидуального слушателя', 18, '2014-12-17 12:40:38', '2014-12-17 12:40:38'),
(624, NULL, 8, 'moderator.register-listener.2014-12-18 11:58:07', 'Картошкин Игорь Владимирович добавлен(а) к слушателям – сотрудникам ПМЖ-12', NULL, '2014-12-18 08:58:07', '2014-12-18 08:58:07');

-- --------------------------------------------------------

--
-- Структура таблицы `dictionary_values_meta`
--

DROP TABLE IF EXISTS `dictionary_values_meta`;
CREATE TABLE IF NOT EXISTS `dictionary_values_meta` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `dicval_id` int(10) unsigned DEFAULT NULL,
  `language` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `dictionary_values_meta_dicval_id_index` (`dicval_id`),
  KEY `dictionary_values_meta_language_index` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `dictionary_values_rel`
--

DROP TABLE IF EXISTS `dictionary_values_rel`;
CREATE TABLE IF NOT EXISTS `dictionary_values_rel` (
  `dicval_parent_id` int(10) unsigned NOT NULL DEFAULT '0',
  `dicval_child_id` int(10) unsigned NOT NULL DEFAULT '0',
  `dicval_child_dic` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`dicval_parent_id`,`dicval_child_id`),
  KEY `dictionary_values_rel_dicval_parent_id_index` (`dicval_parent_id`),
  KEY `dictionary_values_rel_dicval_child_id_index` (`dicval_child_id`),
  KEY `dictionary_values_rel_dicval_child_dic_index` (`dicval_child_dic`(255))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `directions`
--

DROP TABLE IF EXISTS `directions`;
CREATE TABLE IF NOT EXISTS `directions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `order` int(10) unsigned DEFAULT NULL,
  `code` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `photo_id` int(10) unsigned DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `discount` tinyint(4) DEFAULT '0',
  `use_discount` tinyint(1) DEFAULT '1',
  `active` tinyint(1) unsigned DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Дамп данных таблицы `directions`
--

INSERT INTO `directions` (`id`, `order`, `code`, `title`, `photo_id`, `description`, `discount`, `use_discount`, `active`, `created_at`, `updated_at`) VALUES
(1, 1, 'БС', 'Строительство', 1, '', 0, 1, 1, '2014-10-29 08:22:26', '2014-12-11 12:49:49'),
(2, 2, 'П', 'Проектирование', 2, '', 0, 1, 1, '2014-10-29 08:22:26', '2014-10-30 06:48:00'),
(3, 3, 'И', 'Инженерные изыскания', 3, '', 0, 1, 1, '2014-10-29 08:22:26', '2014-10-30 06:48:17');

-- --------------------------------------------------------

--
-- Структура таблицы `galleries`
--

DROP TABLE IF EXISTS `galleries`;
CREATE TABLE IF NOT EXISTS `galleries` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `settings` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `groups`
--

DROP TABLE IF EXISTS `groups`;
CREATE TABLE IF NOT EXISTS `groups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `desc` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `dashboard` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `start_url` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `groups_name_unique` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=7 ;

--
-- Дамп данных таблицы `groups`
--

INSERT INTO `groups` (`id`, `name`, `desc`, `dashboard`, `start_url`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'Администраторы', 'admin', '', '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(3, 'moderator', 'Модераторы', 'moderator', '', '2014-10-29 08:18:38', '2014-10-29 09:00:28'),
(4, 'organization', 'Юридическое лицо', 'organization', '', '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(5, 'listener', 'Сотрудник организаци', 'listener', '', '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(6, 'individual', 'Индивидуальный слуша', 'individual-listener', '', '2014-10-29 08:18:38', '2014-10-29 08:18:38');

-- --------------------------------------------------------

--
-- Структура таблицы `individuals`
--

DROP TABLE IF EXISTS `individuals`;
CREATE TABLE IF NOT EXISTS `individuals` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT '0',
  `fio` varchar(160) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fio_rod` varchar(160) COLLATE utf8_unicode_ci DEFAULT NULL,
  `passport_seria` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `passport_number` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `passport_data` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `passport_date` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `code` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `postaddress` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `position` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `education` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `document_education` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `specialty` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `educational_institution` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `discount` tinyint(4) DEFAULT '0',
  `moderator_approve` tinyint(1) DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `individuals_user_id_index` (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Дамп данных таблицы `individuals`
--

INSERT INTO `individuals` (`id`, `user_id`, `fio`, `fio_rod`, `passport_seria`, `passport_number`, `passport_data`, `passport_date`, `code`, `postaddress`, `phone`, `position`, `education`, `document_education`, `specialty`, `educational_institution`, `discount`, `moderator_approve`, `created_at`, `updated_at`) VALUES
(1, 29, 'Шаповалова Дарья Евгеньевна', NULL, '6009', '601965', 'Отделом УФМС России по ростовской области', '14.10.2009', '610-013', '344064, г. Ростов-на-Дону, ул.Рахманинова, 78', '+7 (928) 296 95 99', NULL, NULL, NULL, NULL, NULL, 0, 0, '2014-12-08 13:18:29', '2014-12-08 13:18:29'),
(2, 48, 'Харсеев Владимир Александрович', 'Харсееву Владимиру Александровичу', 'КО', '184004', 'Украиной Кременчугом УМВД', '31.12.2001', '9846980', '601909, г. Ковров, ул. Социалистическая,26', '+7 (919) 891 97 21', 'Начальник ПТО, ведущий инженер', 'Высшее', 'РВ №112233 от 17.06.2003', 'Промышленное и гражданское строительство', 'ЮФУ', 0, 0, '2014-12-16 09:34:34', '2014-12-16 09:34:34');

-- --------------------------------------------------------

--
-- Структура таблицы `lectures`
--

DROP TABLE IF EXISTS `lectures`;
CREATE TABLE IF NOT EXISTS `lectures` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `course_id` int(10) unsigned DEFAULT NULL,
  `chapter_id` int(10) unsigned DEFAULT NULL,
  `order` int(10) unsigned DEFAULT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `hours` int(10) unsigned DEFAULT '0',
  `document` int(10) unsigned DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `lectures_course_id_index` (`course_id`),
  KEY `lectures_chapter_id_index` (`chapter_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=133 ;

--
-- Дамп данных таблицы `lectures`
--

INSERT INTO `lectures` (`id`, `course_id`, `chapter_id`, `order`, `title`, `description`, `hours`, `document`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 1, 'Модуль №1. Законодательное и нормативное правовое обеспечение строительства', '', 6, 1, '2014-10-29 12:16:41', '2014-10-29 12:16:41'),
(2, 1, 1, 2, 'Модуль №2. Организация инвестиционно-строительных процессов', '', 6, 2, '2014-10-29 12:17:31', '2014-10-29 12:17:31'),
(3, 1, 1, 3, 'Модуль №3. Экономика строительного производства', '', 6, 3, '2014-10-29 12:18:15', '2014-10-29 12:18:15'),
(4, 1, 1, 4, 'Модуль №4. Государственный строительный надзор и строительный контроль', '', 10, 4, '2014-10-29 12:19:18', '2014-10-29 12:19:18'),
(5, 1, 2, 1, 'Модуль №5. Инновации в технологии выполнения общестроительных работ. Показатели и критерии качества выполнения общестроительных работ', '', 24, 5, '2014-10-29 12:20:37', '2014-10-29 12:20:37'),
(6, 1, 2, 2, 'Модуль №6. Техника безопасности строительного производства', '', 6, 6, '2014-10-29 12:21:09', '2014-10-29 12:21:09'),
(7, 1, 3, 1, 'Модуль №7. Региональные особенности организации строительства', '', 8, 7, '2014-10-29 12:22:20', '2014-10-29 12:22:20'),
(8, 1, 3, 2, 'Модуль №8. Особенности выполнения строительных работ в региональных условиях осуществления строительства ', '', 2, 8, '2014-10-29 12:22:46', '2014-10-29 12:22:46'),
(9, 2, 4, 1, 'Модуль №1. Законодательное и нормативное правовое обеспечение строительства', '', 6, 9, '2014-10-29 12:34:58', '2014-10-29 12:34:58'),
(10, 2, 4, 2, 'Модуль №2. Организация инвестиционно-строительных процессов', '', 6, 10, '2014-10-29 12:35:20', '2014-10-29 12:35:20'),
(11, 2, 4, 3, 'Модуль №3. Экономика строительного производства', '', 6, 11, '2014-10-29 12:35:40', '2014-10-29 12:35:40'),
(12, 2, 4, 4, 'Модуль №4. Государственный строительный надзор и строительный контроль', '', 10, 12, '2014-10-29 12:36:07', '2014-10-29 12:36:07'),
(13, 2, 5, 1, 'Модуль №5. Инновации в технологии геодезических, подготовительных и земляных работ, устройства оснований и фундаментов. Показатели и критерии качества выполнения геодезических, подготовительных и земляных работ, устройства оснований и фундаментов ', '', 24, 13, '2014-10-29 12:37:37', '2014-10-29 12:37:37'),
(14, 2, 5, 2, 'Модуль №6. Техника безопасности строительного производства', '', 6, 14, '2014-10-29 12:38:37', '2014-10-29 12:38:37'),
(15, 2, 6, 1, 'Модуль №7. Региональные особенности организации строительства', '', 8, 15, '2014-10-29 12:40:03', '2014-10-29 12:40:03'),
(16, 2, 6, 2, 'Модуль №8. Особенности выполнения строительных работ в региональных условиях осуществления строительства ', '', 2, 16, '2014-10-29 12:40:34', '2014-10-29 12:40:34'),
(17, 3, 7, 1, 'Модуль №1. Законодательное и нормативное правовое обеспечение строительства', '', 6, 17, '2014-10-29 12:42:29', '2014-10-29 12:42:29'),
(18, 3, 7, 2, 'Модуль №2. Организация инвестиционно-строительных процессов', '', 6, 18, '2014-10-29 12:42:47', '2014-10-29 12:42:47'),
(19, 3, 7, 3, 'Модуль №3. Экономика строительного производства', '', 6, 19, '2014-10-29 12:43:05', '2014-10-29 12:43:05'),
(20, 3, 7, 4, 'Модуль №4. Государственный строительный надзор и строительный контроль', '', 10, 20, '2014-10-29 12:43:57', '2014-10-29 12:43:57'),
(21, 3, 8, 1, 'Модуль №5. Инновации в технологии возведения бетонных и железобетонных конструкций. Показатели и критерии качества возведения бетонных и железобетонных конструкций', '', 24, 21, '2014-10-29 12:44:47', '2014-10-29 12:44:47'),
(22, 3, 8, 2, 'Модуль №6. Техника безопасности строительного производства', '', 6, 22, '2014-10-29 12:45:11', '2014-10-29 12:45:11'),
(23, 3, 9, 1, 'Модуль №7. Региональные особенности организации строительства', '', 8, 23, '2014-10-29 12:46:35', '2014-10-29 12:46:35'),
(24, 3, 9, 2, 'Модуль №8. Особенности выполнения строительных работ в региональных условиях осуществления строительства ', '', 2, 24, '2014-10-29 12:46:58', '2014-10-29 12:46:58'),
(25, 4, 10, 1, 'Модуль №1. Законодательное и нормативное правовое обеспечение строительства', '', 6, 25, '2014-10-29 12:55:05', '2014-10-29 12:55:05'),
(26, 4, 10, 2, 'Модуль №2. Организация инвестиционно-строительных процессов', '', 6, 26, '2014-10-29 12:56:00', '2014-10-29 12:56:00'),
(27, 4, 10, 3, 'Модуль №3. Экономика строительного производства', '', 6, 27, '2014-10-29 12:56:27', '2014-10-29 12:56:27'),
(28, 4, 10, 4, 'Модуль №4. Государственный строительный надзор и строительный контроль', '', 10, 28, '2014-10-29 12:57:40', '2014-10-29 12:57:40'),
(29, 4, 11, 1, 'Модуль №5. Инновации в технологии возведения каменных, металлических и деревянных строительных конструкций. Показатели и критерии качества возведения каменных, металлических и деревянных строительных конструкций', '', 24, 29, '2014-10-29 12:58:43', '2014-10-29 12:58:43'),
(30, 4, 11, 2, 'Модуль №6. Техника безопасности строительного производства', '', 6, 30, '2014-10-29 13:16:43', '2014-10-29 13:16:43'),
(31, 4, 12, 1, 'Модуль №7. Региональные особенности организации строительства', '', 8, 31, '2014-10-29 13:18:08', '2014-10-29 13:18:08'),
(32, 4, 12, 2, 'Модуль №8. Особенности выполнения строительных работ в региональных условиях осуществления строительства ', '', 2, 32, '2014-10-29 13:18:46', '2014-10-29 13:18:46'),
(33, 5, 13, 1, 'Модуль №1. Законодательное и нормативное правовое обеспечение строительства', '', 6, 33, '2014-10-29 13:22:05', '2014-10-29 13:22:05'),
(34, 5, 13, 2, 'Модуль №2. Организация инвестиционно-строительных процессов', '', 6, 34, '2014-10-29 13:28:15', '2014-10-29 13:28:15'),
(35, 5, 13, 3, 'Модуль №3. Экономика строительного производства', '', 6, 35, '2014-10-29 13:28:35', '2014-10-29 13:28:35'),
(36, 5, 13, 4, 'Модуль №4. Государственный строительный надзор и строительный контроль', '', 10, 36, '2014-10-29 13:28:59', '2014-10-29 13:28:59'),
(37, 5, 14, 1, 'Модуль №5. Инновации в технологии обеспечения качества выполнения фасадных работ, устройства кровель, защиты строительных конструкций, трубопроводов и оборудования. Показатели и критерии качества выполнения фасадных работ, устройства кровель, защиты строи', '', 24, 37, '2014-10-29 13:30:09', '2014-10-29 13:33:39'),
(38, 5, 14, 2, 'Модуль №6. Техника безопасности строительного производства', '', 6, 38, '2014-10-29 13:31:00', '2014-10-29 13:31:00'),
(39, 5, 15, 1, 'Модуль №7. Региональные особенности организации строительства', '', 8, 39, '2014-10-29 13:32:24', '2014-10-29 13:32:24'),
(40, 5, 15, 2, 'Модуль №8. Особенности выполнения строительных работ в региональных условиях осуществления строительства ', '', 2, 40, '2014-10-29 13:32:43', '2014-10-29 13:32:43'),
(41, 6, 16, 1, 'Модуль №1. Законодательное и нормативное правовое обеспечение строительства', '', 6, 41, '2014-10-29 13:39:09', '2014-10-29 13:39:09'),
(42, 6, 16, 2, 'Модуль №2. Организация инвестиционно-строительных процессов', '', 6, 42, '2014-10-29 13:39:32', '2014-10-29 13:39:32'),
(43, 6, 16, 3, 'Модуль №3. Экономика строительного производства', '', 6, 43, '2014-10-29 13:39:52', '2014-10-29 13:39:52'),
(44, 6, 16, 4, 'Модуль №4. Государственный строительный надзор и строительный контроль', '', 10, 44, '2014-10-29 13:40:18', '2014-10-29 13:40:18'),
(45, 6, 17, 1, 'Модуль №5. Инновации в технологии устройства инженерных систем и сетей. Показатели и критерии качества устройства инженерных систем и сетей', '', 24, 45, '2014-10-29 13:41:56', '2014-10-29 13:41:56'),
(46, 6, 17, 2, 'Модуль №6. Техника безопасности строительного производства', '', 6, 46, '2014-10-29 13:42:25', '2014-10-29 13:42:25'),
(47, 6, 18, 1, 'Модуль №7. Региональные особенности организации строительства', '', 8, 47, '2014-10-29 13:43:27', '2014-10-29 13:43:27'),
(48, 6, 18, 2, 'Модуль №8. Особенности выполнения строительных работ в региональных условиях осуществления строительства ', '', 2, 48, '2014-10-29 13:43:48', '2014-10-29 13:43:48'),
(49, 7, 19, 1, 'Модуль №1. Законодательное и нормативное правовое обеспечение строительства', '', 6, 49, '2014-10-29 14:00:03', '2014-10-29 14:00:03'),
(50, 7, 19, 2, 'Модуль №2. Организация инвестиционно-строительных процессов', '', 6, 50, '2014-10-29 14:00:29', '2014-10-29 14:00:29'),
(51, 7, 19, 3, 'Модуль №3. Экономика строительного производства', '', 6, 51, '2014-10-29 14:00:50', '2014-10-29 14:00:50'),
(52, 7, 19, 4, 'Модуль №4. Государственный строительный надзор и строительный контроль', '', 10, 52, '2014-10-29 14:01:18', '2014-10-29 14:01:18'),
(53, 7, 20, 1, 'Модуль №5. Инновации в технологии устройства электрических сетей и линий связи. Показатели и критерии качества устройства электрических сетей и линий связи', '', 24, 53, '2014-10-29 14:02:25', '2014-10-29 14:02:25'),
(54, 7, 20, 2, 'Модуль №6. Техника безопасности строительного производства', '', 6, 54, '2014-10-29 14:03:00', '2014-10-29 14:03:00'),
(55, 7, 21, 1, 'Модуль №7. Региональные особенности организации строительства', '', 8, 55, '2014-10-29 14:04:15', '2014-10-29 14:04:15'),
(56, 7, 21, 2, 'Модуль №8. Особенности выполнения строительных работ в региональных условиях осуществления строительства ', '', 2, 56, '2014-10-29 14:04:38', '2014-10-29 14:04:38'),
(57, 8, 22, 1, 'Модуль №1. Законодательное и нормативное правовое обеспечение строительства', '', 6, 57, '2014-10-29 14:07:00', '2014-10-29 14:07:00'),
(58, 8, 22, 2, 'Модуль №2. Организация инвестиционно-строительных процессов', '', 6, 58, '2014-10-29 14:07:29', '2014-10-29 14:07:29'),
(59, 8, 22, 3, 'Модуль №3. Экономика строительного производства', '', 6, 59, '2014-10-29 14:15:30', '2014-10-29 14:15:30'),
(60, 8, 22, 4, 'Модуль №4. Государственный строительный надзор и строительный контроль', '', 10, 60, '2014-10-29 14:16:48', '2014-10-29 14:16:48'),
(61, 8, 23, 1, 'Модуль №5. Инновации в технологии устройства объектов нефтяной и газовой промышленности, устройства скважин. Показатели и критерии качества устройства объектов нефтяной и газовой промышленности, устройства скважин', '', 24, 61, '2014-10-29 14:19:19', '2014-10-29 14:19:19'),
(62, 8, 23, 2, 'Модуль №6. Техника безопасности строительного производства', '', 6, 62, '2014-10-29 14:19:49', '2014-10-29 14:19:49'),
(63, 8, 24, 1, 'Модуль №7. Региональные особенности организации строительства', '', 8, 63, '2014-10-29 14:21:02', '2014-10-29 14:21:02'),
(64, 8, 24, 2, 'Модуль №8. Особенности выполнения строительных работ в региональных условиях осуществления строительства ', '', 2, 64, '2014-10-29 14:21:23', '2014-10-29 14:21:23'),
(65, 9, 25, 1, 'Модуль №1. Законодательное и нормативное правовое обеспечение строительства', '', 6, 65, '2014-10-29 14:24:46', '2014-10-29 14:24:46'),
(66, 9, 25, 2, 'Модуль №2. Организация инвестиционно-строительных процессов', '', 6, 66, '2014-10-29 14:25:25', '2014-10-29 14:25:25'),
(67, 9, 25, 3, 'Модуль №3. Экономика строительного производства', '', 6, 67, '2014-10-29 14:27:15', '2014-10-29 14:27:15'),
(68, 9, 25, 4, 'Модуль №4. Государственный строительный надзор и строительный контроль', '', 10, 68, '2014-10-29 14:27:56', '2014-10-29 14:27:56'),
(69, 9, 26, 1, 'Модуль №5. Инновации в технологии выполнения монтажных и пусконаладочных работ лифтового оборудования. Показатели и критерии качества выполнения монтажных и пусконаладочных работ лифтового оборудования', '', 24, 69, '2014-10-29 14:28:57', '2014-10-29 14:28:57'),
(70, 9, 26, 2, 'Модуль №6. Техника безопасности строительного производства', '', 6, 70, '2014-10-29 14:29:24', '2014-10-29 14:29:24'),
(71, 9, 27, 1, 'Модуль №7. Региональные особенности организации строительства', '', 8, 71, '2014-10-29 14:30:07', '2014-10-29 14:30:07'),
(72, 9, 27, 2, 'Модуль №8. Особенности выполнения строительных работ в региональных условиях осуществления строительства ', '', 2, 72, '2014-10-29 14:30:35', '2014-10-29 14:30:35'),
(73, 10, 28, 1, 'Модуль №1. Законодательное и нормативное правовое обеспечение строительства', '', 6, 73, '2014-10-29 14:35:21', '2014-10-29 14:35:21'),
(74, 10, 28, 2, 'Модуль №2. Организация инвестиционно-строительных процессов', '', 6, 74, '2014-10-29 14:35:55', '2014-10-29 14:35:55'),
(75, 10, 28, 3, 'Модуль №3. Экономика строительного производства', '', 6, 75, '2014-10-29 14:36:13', '2014-10-29 14:36:13'),
(76, 10, 28, 4, 'Модуль №4. Государственный строительный надзор и строительный контроль', '', 10, 76, '2014-10-29 14:36:41', '2014-10-29 14:36:41'),
(77, 10, 29, 1, 'Модуль №5. Инновации в технологии устройства автомобильных дорог и аэродромов. Показатели и критерии качества устройства автомобильных дорог и аэродромов', '', 24, 77, '2014-10-29 14:38:08', '2014-10-29 14:38:08'),
(78, 10, 29, 2, 'Модуль №6. Техника безопасности строительного производства', '', 6, 78, '2014-10-29 14:39:16', '2014-10-29 14:39:16'),
(79, 10, 30, 1, 'Модуль №7. Региональные особенности организации строительства', '', 8, 79, '2014-10-29 14:40:18', '2014-10-29 14:40:18'),
(80, 10, 30, 2, 'Модуль №8. Особенности выполнения строительных работ в региональных условиях осуществления строительства ', '', 2, 80, '2014-10-29 14:40:50', '2014-10-29 14:40:50'),
(81, 11, 31, 1, 'Модуль №1. Законодательное и нормативное правовое обеспечение строительства', '', 6, 81, '2014-10-29 14:51:12', '2014-10-29 14:51:12'),
(82, 11, 31, 2, 'Модуль №2. Организация инвестиционно-строительных процессов', '', 6, 82, '2014-10-29 15:05:35', '2014-10-29 15:05:35'),
(83, 11, 31, 3, 'Модуль №3. Экономика строительного производства', '', 6, 83, '2014-10-29 15:12:20', '2014-10-29 15:12:20'),
(84, 11, 31, 4, 'Модуль №4. Государственный строительный надзор и строительный контроль', '', 10, 84, '2014-10-29 15:12:38', '2014-10-29 15:12:38'),
(85, 11, 32, 1, 'Модуль №5. Инновации в технологии устройства железнодорожных и трамвайных путей. Показатели и критерии качества устройства железнодорожных и трамвайных путей', '', 24, 85, '2014-10-29 15:13:28', '2014-10-29 15:13:28'),
(86, 11, 32, 2, 'Модуль №6. Техника безопасности строительного производства', '', 6, 86, '2014-10-29 15:13:52', '2014-10-29 15:13:52'),
(87, 11, 33, 1, 'Модуль №7. Региональные особенности организации строительства', '', 8, 87, '2014-10-29 15:14:29', '2014-10-29 15:14:29'),
(88, 11, 33, 2, 'Модуль №8. Особенности выполнения строительных работ в региональных условиях осуществления строительства ', '', 2, 88, '2014-10-29 15:15:48', '2014-10-29 15:15:48'),
(89, 12, 34, 1, 'Модуль №1. Законодательное и нормативное правовое обеспечение строительства', '', 6, 89, '2014-10-29 15:17:39', '2014-10-29 15:17:39'),
(90, 12, 34, 2, 'Модуль №2. Организация инвестиционно-строительных процессов', '', 6, 90, '2014-10-29 15:17:58', '2014-10-29 15:17:58'),
(91, 12, 34, 3, 'Модуль №3. Экономика строительного производства', '', 6, 91, '2014-10-29 15:18:12', '2014-10-29 15:18:12'),
(92, 12, 34, 4, 'Модуль №4. Государственный строительный надзор и строительный контроль', '', 10, 92, '2014-10-29 15:18:30', '2014-10-29 15:18:30'),
(93, 12, 35, 1, 'Модуль №5. Инновации в технологии устройства подземных сооружений, осуществления специальных земляных и буровзрывных работ при строительстве. Показатели и критерии качества устройства подземных сооружений, осуществления специальных земляных и буровзрывных', '', 24, 93, '2014-10-29 15:19:29', '2014-10-29 15:19:29'),
(94, 12, 35, 2, 'Модуль №6. Техника безопасности строительного производства', '', 6, 94, '2014-10-29 15:19:48', '2014-10-29 15:19:48'),
(95, 12, 36, 1, 'Модуль №7. Региональные особенности организации строительства', '', 8, 95, '2014-10-29 15:20:28', '2014-10-29 15:20:28'),
(96, 12, 36, 2, 'Модуль №8. Особенности выполнения строительных работ в региональных условиях осуществления строительства ', '', 2, 96, '2014-10-29 15:20:47', '2014-10-29 15:20:47'),
(97, 13, 37, 1, 'Модуль №1. Законодательное и нормативное правовое обеспечение строительства', '', 6, 97, '2014-10-29 15:22:29', '2014-10-29 15:22:29'),
(98, 13, 37, 2, 'Модуль №2. Организация инвестиционно-строительных процессов', '', 6, 98, '2014-10-29 15:22:44', '2014-10-29 15:22:44'),
(99, 13, 37, 3, 'Модуль №3. Экономика строительного производства', '', 6, 99, '2014-10-29 15:23:01', '2014-10-29 15:23:01'),
(100, 13, 37, 4, 'Модуль №4. Государственный строительный надзор и строительный контроль', '', 10, 100, '2014-10-29 15:23:18', '2014-10-29 15:23:18'),
(101, 13, 38, 1, 'Модуль №5. Инновации в технологии устройства мостов, эстакад, путепроводов. Показатели и критерии качества устройства мостов, эстакад, путепроводов', '', 24, 101, '2014-10-29 15:25:10', '2014-10-29 15:25:10'),
(102, 13, 38, 2, 'Модуль №6. Техника безопасности строительного производства', '', 6, 102, '2014-10-29 15:25:34', '2014-10-29 15:25:34'),
(103, 13, 39, 1, 'Модуль №7. Региональные особенности организации строительства', '', 8, 103, '2014-10-29 15:26:19', '2014-10-29 15:26:19'),
(104, 13, 39, 2, 'Модуль №8. Особенности выполнения строительных работ в региональных условиях осуществления строительства ', '', 2, 104, '2014-10-29 15:26:40', '2014-10-29 15:26:40'),
(105, 14, 40, 1, 'Модуль №1. Законодательное и нормативное правовое обеспечение строительства', '', 6, 105, '2014-10-29 15:28:52', '2014-10-29 15:28:52'),
(106, 14, 40, 2, 'Модуль №2. Организация инвестиционно-строительных процессов', '', 6, 106, '2014-10-29 15:29:23', '2014-10-29 15:29:23'),
(107, 14, 40, 3, 'Модуль №3. Экономика строительного производства', '', 6, 107, '2014-10-29 15:30:04', '2014-10-29 15:30:04'),
(108, 14, 40, 4, 'Модуль №4. Государственный строительный надзор и строительный контроль', '', 10, 108, '2014-10-29 15:30:41', '2014-10-29 15:30:41'),
(109, 14, 41, 1, 'Модуль №5. Инновации в технологии выполнения гидротехнических и водолазных работ. Показатели и критерии качества выполнения гидротехнических и водолазных работ', '', 24, 109, '2014-10-29 15:31:29', '2014-10-29 15:31:29'),
(110, 14, 41, 2, 'Модуль №6. Техника безопасности строительного производства', '', 6, 110, '2014-10-29 15:32:06', '2014-10-29 15:32:06'),
(111, 14, 42, 1, 'Модуль №7. Региональные особенности организации строительства', '', 8, 111, '2014-10-29 15:32:41', '2014-10-29 15:32:41'),
(112, 14, 42, 2, 'Модуль №8. Особенности выполнения строительных работ в региональных условиях осуществления строительства ', '', 2, 112, '2014-10-29 15:32:58', '2014-10-29 15:32:58'),
(113, 15, 43, 1, 'Модуль №1. Законодательное и нормативное правовое обеспечение строительства', '', 6, 113, '2014-10-29 15:35:16', '2014-10-29 15:35:16'),
(114, 15, 43, 2, 'Модуль №2. Организация инвестиционно-строительных процессов', '', 6, 114, '2014-10-29 15:35:35', '2014-10-29 15:35:35'),
(115, 15, 43, 3, 'Модуль №3. Экономика строительного производства', '', 6, 115, '2014-10-29 15:35:48', '2014-10-29 15:35:48'),
(116, 15, 43, 4, 'Модуль №4. Государственный строительный надзор и строительный контроль', '', 10, 116, '2014-10-29 15:36:04', '2014-10-29 15:36:04'),
(117, 15, 44, 1, 'Модуль №5. Инновации в технологии устройства промышленных печей и домовых труб. Показатели и критерии качества устройства промышленных печей и дымовых труб', '', 24, 117, '2014-10-29 15:37:07', '2014-10-29 15:37:07'),
(118, 15, 44, 2, 'Модуль №6. Техника безопасности строительного производства', '', 6, 118, '2014-10-29 15:37:32', '2014-10-29 15:37:32'),
(119, 15, 45, 1, 'Модуль №7. Региональные особенности организации строительства', '', 8, 119, '2014-10-29 15:38:10', '2014-10-29 15:38:10'),
(120, 15, 45, 2, 'Модуль №8. Особенности выполнения строительных работ в региональных условиях осуществления строительства ', '', 2, 120, '2014-10-29 15:38:31', '2014-10-29 15:38:31'),
(121, 16, 46, 1, 'Модуль №1. Законодательное и нормативное правовое обеспечение строительства', '', 6, 121, '2014-10-29 15:40:24', '2014-10-29 15:40:24'),
(122, 16, 46, 2, 'Модуль №2. Организация инвестиционно-строительных процессов', '', 6, 122, '2014-10-29 15:40:49', '2014-10-29 15:40:49'),
(123, 16, 46, 3, 'Модуль №3. Экономика строительного производства', '', 6, 123, '2014-10-29 15:41:06', '2014-10-29 15:41:06'),
(124, 16, 46, 4, 'Модуль №4. Техника безопасности строительного производства', '', 6, 124, '2014-10-29 15:41:28', '2014-10-29 15:41:28'),
(125, 16, 46, 5, 'Модуль №5. Региональные особенности организации строительства', '', 6, 125, '2014-10-29 15:41:44', '2014-10-29 15:41:44'),
(126, 16, 47, 1, 'Модуль №6. Осуществление строительного контроля', '', 38, 126, '2014-10-29 15:42:30', '2014-10-29 15:42:30'),
(127, 17, 48, 1, 'Модуль №1. Законодательное и нормативное правовое обеспечение строительства', '', 6, 127, '2014-10-29 15:44:06', '2014-10-29 15:44:06'),
(128, 17, 48, 2, 'Модуль №2. Экономика строительного производства', '', 6, 128, '2014-10-29 15:44:24', '2014-10-29 15:44:24'),
(129, 17, 48, 3, 'Модуль №3. Государственный строительный надзор и строительный контроль', '', 6, 129, '2014-10-29 15:44:41', '2014-10-29 15:44:41'),
(130, 17, 48, 4, 'Модуль №4. Техника безопасности строительного производства', '', 6, 130, '2014-10-29 15:44:56', '2014-10-29 15:44:56'),
(131, 17, 48, 5, 'Модуль №5. Региональные особенности организации строительства', '', 6, 131, '2014-10-29 15:46:05', '2014-10-29 15:46:05'),
(132, 17, 49, 1, 'Модуль №6. Организация строительства', '', 38, 132, '2014-10-29 15:46:21', '2014-10-29 15:46:21');

-- --------------------------------------------------------

--
-- Структура таблицы `listeners`
--

DROP TABLE IF EXISTS `listeners`;
CREATE TABLE IF NOT EXISTS `listeners` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT '0',
  `organization_id` int(10) unsigned DEFAULT '0',
  `fio` varchar(160) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fio_dat` varchar(160) COLLATE utf8_unicode_ci DEFAULT NULL,
  `position` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `postaddress` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `education` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `education_document_data` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `educational_institution` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `specialty` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `approved` tinyint(1) unsigned DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `listeners_user_id_index` (`user_id`),
  KEY `listeners_organization_id_index` (`organization_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=27 ;

--
-- Дамп данных таблицы `listeners`
--

INSERT INTO `listeners` (`id`, `user_id`, `organization_id`, `fio`, `fio_dat`, `position`, `postaddress`, `phone`, `education`, `education_document_data`, `educational_institution`, `specialty`, `approved`, `created_at`, `updated_at`) VALUES
(1, 4, 3, 'Сорбат Владимир Николаевич', 'Сорбату Владимиру Николаевичу', 'Главный специалист сектора контрольных обследований отдела внутреннего государственного финансового контроля за использованием межбюджетных трансфертов', '344089 г. Зерноград, ул.Самохвалова, д.55', '+7 (928) 105 75 15', 'Высшее', 'ВСГ 2646394 от 16.06.2008', 'ГОУ ВПО «Ростовский государственный экономический университет «РИНХ»', 'Бухгалтерский учет, анализ и аудит', 1, '2014-11-06 15:47:23', '2014-12-09 12:33:38'),
(2, 6, 5, 'Харсеев Владимир Александрович', 'Иванову Ивану Ивановичу', 'Программист', '344039. Ростов-на-Дону', '+7 (919) 895 48 48', 'Высшее техническое', 'Диплом Д-001', 'КДПУ', 'Программист', 1, '2014-11-07 14:20:57', '2014-11-11 14:24:58'),
(3, 9, 8, 'Иванов Иван Иванович', 'Иванову Ивану Ивановичу', 'Начальник ПТО, ведущий инженер', '121343, г. Москва, ул. Кутузова 54', '+7 (988) 999 99 99', 'Высшее', 'РБ №122231, 21.12.00', 'ЮФУ', 'Промышленное и гражданское строительство', 0, '2014-11-26 13:31:14', '2014-11-26 13:31:14'),
(4, 11, 8, 'Помидоров Аркадий Иванович', 'Помидорову Аркадию Ивановичу', 'Великий Царь', '000000', '+7 (000) 000 00 00', 'никакое', '000', 'Царское село', 'царь', 1, '2014-11-27 13:38:59', '2014-11-27 13:56:09'),
(5, 12, 8, 'Огурцов Анатолий Степанович', 'Огурцову Анатолию Степановичу', 'ведущий', '000000', '+7 (000) 000 00 00', 'среднее', '5345345', '34534534', '53453455', 1, '2014-11-28 15:02:12', '2014-12-11 11:41:42'),
(6, 17, 16, 'Жуков Игорь Алексеевич', 'Жукову Игорю Алексеевичу', 'Заместитель директора', 'г. Ростов-на-Дону, пр. 40-летия Победы д. 37Е, кв. 49', '+7 (863) 231 84 52', 'Высшее', 'ФВ №115739 от 20.06.1993', 'Ростовская-на-Дону государственная академия строительства', 'Промышленное и гражданское строительство', 0, '2014-12-02 13:15:50', '2014-12-02 13:15:50'),
(7, 18, 16, 'Бирючинский Алексей Николаевич', 'Бирючинскому Алексею Николаевичу', 'Заместитель директора', 'г. Ростов-на-Дону, ул. Добровольского, д. 44/1, кв. 16', '+7 (905) 454 54 45', 'Высшее', 'ФВ №115710 от 29.06.1993', 'Ростовская-на-Дону государственная академия строительства', 'Промышленное и гражданское строительство', 0, '2014-12-02 13:21:36', '2014-12-02 13:21:36'),
(8, 20, 19, 'Анеглова АнгелА', 'Ангеловой АнгелЕ', 'инженер', '34567, Москва, ЦАО', '+7 (233) 322 33 32', 'Среднее', 'РВ №35345345 от 23.24.25.', 'РГСУ', 'ПГС', 1, '2014-12-02 21:21:09', '2014-12-02 21:21:53'),
(9, 21, 19, 'Шумеев Павел Андреевич', 'Шумееву Павлу Андреевичу', 'Руководитель группы конструктора', '34400, г. Ростов-на-Дону', '+7 (233) 322 23 33', 'Высшее', 'ЯЯ №23423425 ', 'РИСИ', 'ЭУН', 1, '2014-12-02 21:28:35', '2014-12-02 21:30:08'),
(10, 22, 8, 'Баклажанов Сергей Дмитриевич', 'Баклажанову Сергею Дмитриевичу', 'ведущий инжинер', '000000, Ростов-на-Дону, Петровская, 54', '+7 (999) 092 00 92', 'Высшее', 'РВ 543 45435', 'ГОУ ВПО ПВО', 'Специальность', 0, '2014-12-03 09:35:50', '2014-12-03 09:35:50'),
(11, 23, 15, 'Иванов Иван Иванович', 'Иванову Ивану Ивановичу', 'Начальник ПТО, ведущий инженер', '601909, г. Ковров, ул. Социалистическая,26', '+7 (999) 999 99 99', 'Высшее', 'РВ №112233 от 17.06.2003', 'ЮФУ', 'Промышленное и гражданское строительство', 1, '2014-12-03 10:23:26', '2014-12-04 14:21:43'),
(14, 28, 15, 'Иванов Иван Иванович', 'Иванову Ивану Ивановичу', 'Начальник ПТО, ведущий инженер', '601909, г. Ковров, ул. Социалистическая,26', '+7 (888) 888 88 88', 'Высшее', 'РВ №112233 от 17.06.2003', 'ЮФУ', 'Промышленное и гражданское строительство', 0, '2014-12-04 13:47:13', '2014-12-04 13:47:13'),
(15, 32, 30, 'пррррррррррggggggggggg', 'fyghhhhhhhh', 'hhggggggggggggg', 'jjjjjjjjjjjjjjjjjjjjjjjj', '+7 (546) 666 66 66', 'ghhhhhhhhhhhhhhhhhhh', 'hggggggggggggggggggggg', 'hgggggggggggggg55555555', 'hgggggggggggggggggggggg', 1, '2014-12-10 16:28:17', '2014-12-10 17:12:45'),
(16, 33, 30, 'Тищенко Андрей Михайлович', 'Тищенко Андрею Михайловичу', 'инженер', '344000, Ростов-на-Дону, ул. Социалистическая, 35', '+7 (546) 578 78 78', 'Высшее', 'ВВК №156896 от 15.06.2001', 'РГСУ', 'Водоснабжение и водоотведение', 0, '2014-12-10 16:45:51', '2014-12-10 16:45:51'),
(17, 35, 15, 'Володя Питерсикий', 'Володи Питерскому', 'Начальник ПТО, ведущий инженер', '601909, г. Ковров, ул. Социалистическая,26', '+7 (919) 891 97 21', 'Высшее', 'РВ №112233 от 17.06.2003', 'ЮФУ', 'Промышленное и гражданское строительство', 1, '2014-12-11 10:40:01', '2014-12-11 10:41:10'),
(18, 36, 15, 'Володя Питерсикий', 'Володи Питерскому', 'Начальник ПТО, ведущий инженер', '601909, г. Ковров, ул. Социалистическая,26', '+7 (848) 484 84 84', 'Высшее', 'РВ №112233 от 17.06.2003', 'ЮФУ', 'Промышленное и гражданское строительство', 1, '2014-12-11 11:42:43', '2014-12-11 11:45:58'),
(19, 37, 8, 'Самойлов Андрей Геннадьевич', 'Самойлов Андрей Геннадьевич', 'Самойлов Андрей Геннадьевич', 'Самойлов Андрей Геннадьевич', '+7 (000) 000 00 00', 'Самсонов Аркадий Степонович', 'Самсонов Аркадий Степонович', 'Самсонов Аркадий Степонович', 'Самсонов Аркадий Степонович', 1, '2014-12-11 11:43:10', '2014-12-11 11:47:06'),
(20, 39, 38, 'Иванову Ивану Ивановичу', 'Иванову Ивану Ивановичу', 'Иванову Ивану Ивановичу', 'Иванову Ивану Ивановичу', '+7 (111) 111 11 11', 'Иванову Ивану Ивановичу', 'Иванову Ивану Ивановичу', 'Иванову Ивану Ивановичу', 'Иванову Ивану Ивановичу', 1, '2014-12-11 10:39:20', '2014-12-11 10:40:49'),
(21, 40, 38, 'Иванову Ивану Ивановичу', 'Иванову Ивану Ивановичу', 'Иванову Ивану Ивановичу', 'Иванову Ивану Ивановичу', '+7 (333) 333 33 33', 'Иванову Ивану Ивановичу', 'Иванову Ивану Ивановичу', 'Иванову Ивану Ивановичу', 'Иванову Ивану Ивановичу', 0, '2014-12-11 10:44:14', '2014-12-11 10:44:14'),
(22, 42, 41, 'Володя', 'Володи', 'Начальник ПТО, ведущий инженер', '601909, г. Ковров, ул. Социалистическая,26', '+7 (888) 888 88 88', 'Высшее', 'РВ №112233 от 17.06.2003', 'ЮФУ', 'Промышленное и гражданское строительство', 1, '2014-12-12 09:05:15', '2014-12-12 09:08:00'),
(23, 45, 44, 'Кулебякин Анатолий Анатольевич ', 'Кулебякину Анатолию Анатольевичу', 'Старший помощник младшего менеджера 3-ого звена 5-ого порядка', '344000, Ростов-на-дону, переулок Дальний, 5678', '+7 (233) 222 56 65', 'высшее неоконченное', 'бла бла бла бла блоа бла ', 'f xnj plt drguyb drgljkn ', '346ец45наверав овег56', 1, '2014-12-15 07:57:38', '2014-12-15 07:58:46'),
(24, 46, 44, 'fut6ujr', 'utr6utu', 'u5u5', 'u5u5u', '+7 (55X) XXX XX XX', '5u5u', '5u5u', 'u5u5u5u', '5u5u5u5u', 1, '2014-12-15 08:03:43', '2014-12-15 08:09:11'),
(25, 47, 44, '6757r6yrt', 'ry575y', 'y5y5y5', 'y5y55y', 'y5y55y', 'y5y5y5y', '345345ert', '4353t4etdrt', '345345rt', 0, '2014-12-15 08:12:02', '2014-12-15 08:12:02'),
(26, 49, 8, 'Картошкин Игорь Владимирович', 'Картошкину Игорю Владимировичу', 'Начальник ПТО', '132333 Москва', '+7 (646) 546 54 65', 'Отличное', '123 123 тест', '123 123 тест', '123 123 тест', 0, '2014-12-18 08:58:06', '2014-12-18 08:58:06');

-- --------------------------------------------------------

--
-- Структура таблицы `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `migrations`
--

INSERT INTO `migrations` (`migration`, `batch`) VALUES
('2014_01_01_100000_create_groups_table', 1),
('2014_01_01_100010_create_users_table', 1),
('2014_01_01_100020_create_modules_table', 1),
('2014_01_01_100030_create_actions_table', 1),
('2014_01_01_100040_create_session_table', 1),
('2014_01_01_100050_create_settings_table', 1),
('2014_01_01_100051_create_storages_table', 1),
('2014_01_01_100060_create_pages_tables', 1),
('2014_01_01_100070_create_news_tables', 1),
('2014_01_01_100080_create_galleries_table', 1),
('2014_01_01_100090_create_photos_table', 1),
('2014_01_01_100100_create_rel_mod_gallery_table', 1),
('2014_01_01_100110_create_seo_table', 1),
('2014_07_03_161130_create_dics_tables', 1),
('2014_09_02_161130_create_uploads_tables', 1),
('2014_09_02_161140_create_video_tables', 1),
('2014_09_04_150007_create_directions_table', 1),
('2014_09_04_151141_create_courses_table', 1),
('2014_09_08_113541_create_chapter_table', 1),
('2014_09_08_113712_create_lectures_table', 1),
('2014_09_09_113857_create_tests_table', 1),
('2014_09_09_134300_create_tests_questions_table', 1),
('2014_09_09_134539_create_tests_answers_table', 1),
('2014_09_12_111807_create_account_types_table', 1),
('2014_09_24_130138_create_organization_table', 1),
('2014_09_24_131546_create_individual_table', 1),
('2014_09_25_082127_create_listener_table', 1),
('2014_10_01_081703_create_password_reminders_table', 1),
('2014_10_03_124653_create_orders_table', 1),
('2014_10_03_125652_create_payment_status_table', 1),
('2014_10_09_121118_create_order_payments', 1),
('2014_11_12_083946_create_course_metodical', 2),
('2014_12_01_105253_create_user_settings', 2),
('2014_12_04_155031_create_user_download_lectures', 3);

-- --------------------------------------------------------

--
-- Структура таблицы `modules`
--

DROP TABLE IF EXISTS `modules`;
CREATE TABLE IF NOT EXISTS `modules` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `on` tinyint(1) NOT NULL DEFAULT '0',
  `order` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=11 ;

--
-- Дамп данных таблицы `modules`
--

INSERT INTO `modules` (`id`, `name`, `on`, `order`, `created_at`, `updated_at`) VALUES
(1, 'system', 1, 0, '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(2, 'pages', 1, 0, '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(3, 'news', 1, 0, '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(4, 'galleries', 1, 0, '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(5, 'seo', 1, 0, '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(6, 'dictionaries', 1, 0, '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(7, 'education', 1, 0, '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(8, 'logging', 1, 0, '2014-10-29 08:19:26', '2014-10-29 08:19:26'),
(9, 'uploads', 1, 0, '2014-10-29 08:19:27', '2014-10-29 08:19:27'),
(10, 'video', 0, 0, '2014-10-29 08:19:28', '2014-10-29 08:19:29');

-- --------------------------------------------------------

--
-- Структура таблицы `news`
--

DROP TABLE IF EXISTS `news`;
CREATE TABLE IF NOT EXISTS `news` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `template` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `type_id` int(10) unsigned DEFAULT NULL,
  `publication` tinyint(1) unsigned DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `published_at` date NOT NULL,
  PRIMARY KEY (`id`),
  KEY `news_type_id_index` (`type_id`),
  KEY `news_publication_index` (`publication`),
  KEY `news_published_at_index` (`published_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `news_meta`
--

DROP TABLE IF EXISTS `news_meta`;
CREATE TABLE IF NOT EXISTS `news_meta` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `news_id` int(10) unsigned DEFAULT NULL,
  `language` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `title` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `preview` text COLLATE utf8_unicode_ci,
  `content` mediumtext COLLATE utf8_unicode_ci,
  `photo_id` int(10) unsigned DEFAULT NULL,
  `gallery_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `news_meta_news_id_index` (`news_id`),
  KEY `news_meta_language_index` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `orders`
--

DROP TABLE IF EXISTS `orders`;
CREATE TABLE IF NOT EXISTS `orders` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT '0',
  `number` int(10) unsigned DEFAULT '0',
  `completed` tinyint(1) DEFAULT '0',
  `payment_status` tinyint(3) unsigned DEFAULT '1',
  `payment_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `discount` tinyint(4) DEFAULT '0',
  `close_status` tinyint(1) DEFAULT '0',
  `close_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `study_status` tinyint(1) unsigned DEFAULT '0',
  `study_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `archived` tinyint(1) DEFAULT '0',
  `contract_id` int(10) unsigned DEFAULT '0',
  `invoice_id` int(10) unsigned DEFAULT '0',
  `act_id` int(10) unsigned DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `orders_user_id_index` (`user_id`),
  KEY `orders_payment_status_index` (`payment_status`),
  KEY `contract_id` (`contract_id`,`invoice_id`,`act_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=32 ;

--
-- Дамп данных таблицы `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `number`, `completed`, `payment_status`, `payment_date`, `discount`, `close_status`, `close_date`, `study_status`, `study_date`, `archived`, `contract_id`, `invoice_id`, `act_id`, `created_at`, `updated_at`) VALUES
(1, 3, 1, 1, 6, '0000-00-00 00:00:00', 0, 1, '2014-12-11 16:20:39', 0, '2014-12-15 15:19:52', 0, 139, 140, 141, '2014-11-06 16:19:44', '2014-12-11 16:20:39'),
(5, 8, 2, 1, 2, '2014-12-02 12:19:04', 0, 0, '0000-00-00 00:00:00', 0, '2014-12-15 15:19:52', 0, 0, 0, 0, '2014-11-26 13:31:46', '2014-12-02 12:19:04'),
(6, 8, 3, 1, 5, '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', 0, '2014-12-15 15:19:52', 0, 0, 0, 0, '2014-11-28 10:51:33', '2014-11-28 11:15:30'),
(7, 16, 4, 1, 1, '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', 0, '2014-12-15 15:19:52', 0, 0, 0, 0, '2014-12-02 13:23:02', '2014-12-02 13:23:02'),
(8, 8, 5, 1, 5, '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', 0, '2014-12-15 15:19:52', 0, 0, 0, 0, '2014-12-02 15:24:28', '2014-12-02 16:10:03'),
(9, 8, 6, 1, 3, '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', 0, '2014-12-15 15:19:52', 0, 0, 0, 0, '2014-12-02 16:45:12', '2014-12-03 10:20:25'),
(10, 19, 7, 1, 3, '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', 0, '2014-12-15 15:19:52', 0, 0, 0, 0, '2014-12-02 21:36:56', '2014-12-02 22:52:02'),
(11, 15, 8, 1, 2, '2014-12-04 14:22:52', 0, 0, '0000-00-00 00:00:00', 0, '2014-12-15 15:19:52', 0, 0, 0, 0, '2014-12-03 10:24:29', '2014-12-04 14:22:52'),
(13, 15, 10, 1, 2, '2014-12-04 14:22:42', 0, 0, '0000-00-00 00:00:00', 0, '2014-12-15 15:19:52', 0, 0, 0, 0, '2014-12-04 13:30:07', '2014-12-04 14:22:42'),
(19, 8, 9, 1, 1, '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', 0, '2014-12-15 15:19:52', 0, 0, 0, 0, '2014-12-08 16:24:14', '2014-12-08 16:24:14'),
(20, 8, 11, 1, 3, '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', 0, '2014-12-15 15:19:52', 0, 0, 0, 0, '2014-12-08 16:25:48', '2014-12-10 11:03:03'),
(21, 15, 12, 1, 1, '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', 0, '2014-12-15 15:19:52', 0, 0, 0, 0, '2014-12-09 10:51:17', '2014-12-10 11:14:08'),
(22, 15, 13, 1, 4, '2014-12-09 10:57:59', 0, 0, '0000-00-00 00:00:00', 0, '2014-12-15 15:19:52', 0, 0, 0, 0, '2014-12-09 10:52:15', '2014-12-09 10:57:59'),
(23, 8, 14, 1, 3, '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', 0, '2014-12-15 15:19:52', 0, 0, 0, 0, '2014-12-09 11:49:59', '2014-12-09 12:29:08'),
(24, 3, 15, 1, 1, '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', 0, '2014-12-15 15:19:52', 0, 0, 0, 0, '2014-12-09 12:33:01', '2014-12-10 09:18:52'),
(25, 30, 16, 1, 2, '2014-12-11 10:05:20', 0, 0, '0000-00-00 00:00:00', 0, '2014-12-15 15:19:52', 0, 0, 0, 0, '2014-12-10 16:53:01', '2014-12-11 10:05:20'),
(26, 15, 17, 1, 2, '2014-12-01 10:53:49', 0, 1, '2014-12-11 11:03:29', 0, '2014-12-15 15:19:52', 0, 136, 137, 138, '2014-12-11 10:52:56', '2014-12-11 11:03:29'),
(27, 38, 18, 1, 1, '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', 0, '2014-12-15 15:19:52', 0, 0, 0, 0, '2014-12-11 10:54:53', '2014-12-11 10:54:53'),
(28, 15, 19, 1, 4, '2014-12-12 08:06:34', 0, 0, '0000-00-00 00:00:00', 0, '2014-12-15 15:19:52', 0, 0, 0, 0, '2014-12-11 12:56:55', '2014-12-12 08:06:34'),
(29, 41, 20, 1, 2, '2014-12-02 09:06:11', 0, 1, '2014-12-12 09:15:22', 0, '2014-12-15 15:19:52', 0, 142, 143, 144, '2014-12-01 09:05:40', '2014-12-12 09:15:22'),
(30, 44, 21, 1, 6, '2014-12-15 08:30:32', 0, 0, '0000-00-00 00:00:00', 0, '2014-12-15 15:19:52', 0, 0, 0, 0, '2014-12-15 08:12:35', '2014-12-15 08:30:32'),
(31, 44, 22, 1, 4, '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', 0, '2014-12-15 15:19:52', 0, 0, 0, 0, '2014-12-15 08:32:03', '2014-12-15 08:34:22');

-- --------------------------------------------------------

--
-- Структура таблицы `order_listeners`
--

DROP TABLE IF EXISTS `order_listeners`;
CREATE TABLE IF NOT EXISTS `order_listeners` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` int(10) unsigned DEFAULT '0',
  `course_id` int(10) unsigned DEFAULT '0',
  `user_id` int(10) unsigned DEFAULT '0',
  `price` float(8,2) unsigned DEFAULT '0.00',
  `access_status` tinyint(1) unsigned DEFAULT '0',
  `start_status` tinyint(1) unsigned DEFAULT '0',
  `over_status` tinyint(1) unsigned DEFAULT '0',
  `start_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `over_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `order_listeners_order_id_index` (`order_id`),
  KEY `order_listeners_course_id_index` (`course_id`),
  KEY `order_listeners_user_id_index` (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=86 ;

--
-- Дамп данных таблицы `order_listeners`
--

INSERT INTO `order_listeners` (`id`, `order_id`, `course_id`, `user_id`, `price`, `access_status`, `start_status`, `over_status`, `start_date`, `over_date`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 4, 4000.00, 1, 1, 1, '2014-11-06 16:32:12', '2014-11-06 17:22:55', '2014-11-06 16:19:44', '2014-12-10 10:28:27'),
(2, 1, 2, 4, 4000.00, 1, 1, 1, '2014-12-09 12:33:56', '2014-12-11 16:20:38', '2014-11-06 16:19:44', '2014-12-11 16:20:38'),
(8, 5, 1, 9, 4000.00, 1, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2014-11-26 13:31:46', '2014-12-02 12:19:04'),
(9, 6, 4, 9, 4000.00, 1, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2014-11-28 10:51:33', '2014-11-28 11:15:30'),
(10, 6, 4, 11, 4000.00, 1, 1, 1, '2014-11-28 11:16:11', '2014-12-02 12:30:53', '2014-11-28 10:51:33', '2014-12-02 12:30:53'),
(11, 6, 17, 11, 4000.00, 1, 1, 0, '2014-12-02 12:37:38', '0000-00-00 00:00:00', '2014-11-28 10:51:33', '2014-12-02 12:37:38'),
(12, 7, 2, 17, 4000.00, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2014-12-02 13:23:02', '2014-12-02 13:23:02'),
(13, 7, 11, 18, 4000.00, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2014-12-02 13:23:02', '2014-12-02 13:23:02'),
(14, 7, 17, 17, 4000.00, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2014-12-02 13:23:02', '2014-12-02 13:23:02'),
(15, 7, 17, 18, 4000.00, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2014-12-02 13:23:02', '2014-12-02 13:23:02'),
(16, 8, 1, 9, 4000.00, 1, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2014-12-02 15:24:28', '2014-12-02 16:10:03'),
(17, 8, 1, 12, 4000.00, 1, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2014-12-02 15:24:28', '2014-12-02 16:10:03'),
(18, 9, 1, 12, 4000.00, 1, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2014-12-02 16:45:12', '2014-12-03 10:20:14'),
(19, 9, 2, 9, 4000.00, 1, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2014-12-02 16:45:12', '2014-12-03 10:20:14'),
(20, 9, 2, 11, 4000.00, 1, 1, 1, '2014-12-03 10:21:30', '2014-12-11 11:57:08', '2014-12-02 16:45:12', '2014-12-11 11:57:08'),
(21, 9, 2, 12, 4000.00, 1, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2014-12-02 16:45:12', '2014-12-03 10:20:14'),
(22, 10, 1, 20, 4000.00, 1, 1, 0, '2014-12-02 23:00:14', '0000-00-00 00:00:00', '2014-12-02 21:36:56', '2014-12-02 23:00:14'),
(23, 10, 4, 21, 4000.00, 1, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2014-12-02 21:36:56', '2014-12-02 22:51:41'),
(24, 10, 9, 20, 4000.00, 1, 1, 0, '2014-12-02 23:08:13', '0000-00-00 00:00:00', '2014-12-02 21:36:56', '2014-12-02 23:08:13'),
(25, 10, 17, 20, 4000.00, 1, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2014-12-02 21:36:56', '2014-12-02 22:51:41'),
(26, 10, 17, 21, 4000.00, 1, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2014-12-02 21:36:56', '2014-12-02 22:51:41'),
(27, 11, 1, 23, 4000.00, 1, 1, 0, '2014-12-09 09:06:08', '0000-00-00 00:00:00', '2014-12-03 10:24:29', '2014-12-09 09:06:08'),
(30, 13, 1, 23, 4000.00, 1, 1, 0, '2014-12-04 14:24:08', '0000-00-00 00:00:00', '2014-12-04 13:30:07', '2014-12-04 14:24:08'),
(50, 19, 1, 9, 4000.00, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2014-12-08 16:24:14', '2014-12-08 16:24:14'),
(51, 19, 1, 11, 4000.00, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2014-12-08 16:24:14', '2014-12-08 16:24:14'),
(52, 19, 2, 11, 4000.00, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2014-12-08 16:24:14', '2014-12-08 16:24:14'),
(53, 19, 2, 12, 4000.00, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2014-12-08 16:24:14', '2014-12-08 16:24:14'),
(54, 20, 1, 9, 4000.00, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2014-12-08 16:25:48', '2014-12-08 16:25:48'),
(55, 20, 1, 11, 4000.00, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2014-12-08 16:25:48', '2014-12-08 16:25:48'),
(56, 20, 2, 9, 4000.00, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2014-12-08 16:25:48', '2014-12-08 16:25:48'),
(57, 20, 2, 11, 4000.00, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2014-12-08 16:25:48', '2014-12-08 16:25:48'),
(58, 21, 2, 23, 4000.00, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2014-12-09 10:51:17', '2014-12-10 11:14:08'),
(59, 21, 2, 28, 4000.00, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2014-12-09 10:51:17', '2014-12-10 11:14:08'),
(60, 22, 3, 23, 4000.00, 1, 1, 0, '2014-12-11 10:56:03', '0000-00-00 00:00:00', '2014-12-09 10:52:15', '2014-12-11 10:56:03'),
(61, 23, 1, 9, 4000.00, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2014-12-09 11:49:59', '2014-12-09 12:29:05'),
(62, 24, 2, 4, 4000.00, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2014-12-09 12:33:01', '2014-12-10 09:18:52'),
(63, 24, 7, 4, 4000.00, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2014-12-09 12:33:01', '2014-12-10 09:18:52'),
(64, 24, 9, 4, 4000.00, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2014-12-09 12:33:01', '2014-12-10 09:18:52'),
(65, 25, 1, 32, 4000.00, 1, 1, 1, '2014-12-11 06:35:48', '2014-12-11 06:51:31', '2014-12-10 16:53:01', '2014-12-11 10:05:20'),
(66, 25, 6, 33, 4000.00, 1, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2014-12-10 16:53:01', '2014-12-11 10:05:20'),
(67, 26, 1, 35, 4000.00, 1, 1, 1, '2014-12-11 11:03:04', '2014-12-11 11:03:28', '2014-12-11 10:52:56', '2014-12-11 11:03:28'),
(68, 26, 2, 23, 4000.00, 1, 1, 1, '2014-12-11 10:55:23', '2014-12-11 10:57:24', '2014-12-11 10:52:56', '2014-12-11 10:57:24'),
(69, 27, 1, 39, 4000.00, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2014-12-11 10:54:53', '2014-12-11 10:54:53'),
(70, 27, 1, 40, 4000.00, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2014-12-11 10:54:53', '2014-12-11 10:54:53'),
(71, 27, 2, 39, 4000.00, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2014-12-11 10:54:53', '2014-12-11 10:54:53'),
(72, 28, 1, 23, 4000.00, 1, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2014-12-11 12:56:55', '2014-12-12 08:06:34'),
(73, 28, 1, 35, 4000.00, 1, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2014-12-11 12:56:55', '2014-12-12 08:06:34'),
(74, 28, 1, 36, 4000.00, 1, 1, 1, '2014-12-12 08:09:58', '2014-12-12 08:10:13', '2014-12-11 12:56:55', '2014-12-12 08:10:13'),
(75, 28, 3, 28, 40.00, 1, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2014-12-11 12:56:55', '2014-12-12 08:06:34'),
(76, 28, 3, 35, 40.00, 1, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2014-12-11 12:56:55', '2014-12-12 08:06:34'),
(77, 28, 3, 36, 40.00, 1, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2014-12-11 12:56:55', '2014-12-12 08:06:34'),
(78, 29, 2, 42, 560.00, 1, 1, 1, '2014-12-12 09:10:55', '2014-12-12 09:15:21', '2014-12-12 09:05:40', '2014-12-12 09:15:21'),
(79, 30, 2, 46, 40.00, 1, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2014-12-15 08:12:35', '2014-12-15 08:30:44'),
(80, 30, 2, 47, 40.00, 1, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2014-12-15 08:12:35', '2014-12-15 08:30:44'),
(81, 30, 9, 45, 40.00, 1, 1, 0, '2014-12-15 08:22:54', '0000-00-00 00:00:00', '2014-12-15 08:12:35', '2014-12-15 08:30:44'),
(82, 30, 9, 46, 40.00, 1, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2014-12-15 08:12:35', '2014-12-15 08:30:44'),
(83, 30, 17, 45, 40.00, 1, 1, 0, '2014-12-15 08:23:38', '0000-00-00 00:00:00', '2014-12-15 08:12:35', '2014-12-15 08:30:44'),
(84, 30, 17, 46, 40.00, 1, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2014-12-15 08:12:35', '2014-12-15 08:30:44'),
(85, 31, 1, 45, 4000.00, 1, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2014-12-15 08:32:03', '2014-12-15 08:34:22');

-- --------------------------------------------------------

--
-- Структура таблицы `order_listener_tests`
--

DROP TABLE IF EXISTS `order_listener_tests`;
CREATE TABLE IF NOT EXISTS `order_listener_tests` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `order_listeners_id` int(10) unsigned DEFAULT '0',
  `chapter_id` int(10) unsigned DEFAULT '0',
  `test_id` int(10) unsigned DEFAULT '0',
  `data_results` text COLLATE utf8_unicode_ci,
  `result_attempt` tinyint(3) unsigned DEFAULT '0',
  `time_attempt` int(10) unsigned DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `order_listener_tests_order_listeners_id_index` (`order_listeners_id`),
  KEY `order_listener_tests_chapter_id_index` (`chapter_id`),
  KEY `order_listener_tests_test_id_index` (`test_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=48 ;

--
-- Дамп данных таблицы `order_listener_tests`
--

INSERT INTO `order_listener_tests` (`id`, `order_listeners_id`, `chapter_id`, `test_id`, `data_results`, `result_attempt`, `time_attempt`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 1, '{"1":"1"}', 0, 0, '2014-11-06 16:54:44', '2014-11-06 16:54:44'),
(2, 1, 1, 1, '{"1":"1"}', 0, 0, '2014-11-06 17:01:52', '2014-11-06 17:01:52'),
(3, 1, 1, 1, '{"1":"4"}', 100, 0, '2014-11-06 17:19:37', '2014-11-06 17:19:37'),
(4, 1, 1, 1, '{"1":"1"}', 0, 0, '2014-11-06 17:21:58', '2014-11-06 17:21:58'),
(5, 1, 1, 1, '{"1":"1"}', 0, 0, '2014-11-06 17:21:59', '2014-11-06 17:21:59'),
(6, 1, 1, 1, '{"1":"4"}', 100, 0, '2014-11-06 17:22:04', '2014-11-06 17:22:04'),
(7, 1, 0, 2, '{"2":"5"}', 100, 0, '2014-11-06 17:22:55', '2014-11-06 17:22:55'),
(8, 2, 0, 3, '{"3":"9"}', 100, 0, '2014-11-06 17:30:56', '2014-11-06 17:30:56'),
(9, 2, 0, 3, '{"3":"9"}', 100, 0, '2014-11-06 17:33:15', '2014-11-06 17:33:15'),
(10, 2, 0, 3, '{"3":"9"}', 100, 0, '2014-11-06 17:34:19', '2014-11-06 17:34:19'),
(11, 10, 10, 4, '{"4":"12"}', 0, 0, '2014-11-28 14:35:20', '2014-11-28 14:35:20'),
(12, 10, 10, 4, '{"4":"12"}', 0, 0, '2014-11-28 16:34:34', '2014-11-28 16:34:34'),
(13, 10, 10, 4, '{"4":"12"}', 0, 0, '2014-11-28 16:56:18', '2014-11-28 16:56:18'),
(14, 10, 10, 4, '{"4":"11"}', 100, 0, '2014-12-01 14:29:15', '2014-12-01 14:29:15'),
(15, 10, 10, 4, '{"4":"11"}', 100, 0, '2014-12-01 14:29:46', '2014-12-01 14:29:46'),
(16, 10, 10, 4, '{"4":"11"}', 100, 0, '2014-12-01 15:29:49', '2014-12-01 15:29:49'),
(17, 10, 10, 4, '{"4":"12"}', 0, 0, '2014-12-01 15:30:26', '2014-12-01 15:30:26'),
(18, 10, 10, 4, '{"4":"11"}', 100, 0, '2014-12-01 15:30:50', '2014-12-01 15:30:50'),
(19, 10, 10, 4, '{"4":"11"}', 100, 0, '2014-12-01 16:08:49', '2014-12-01 16:08:49'),
(20, 10, 0, 5, '{"5":"13"}', 100, 0, '2014-12-02 12:30:53', '2014-12-02 12:30:53'),
(21, 22, 1, 1, '{"1":"1"}', 0, 0, '2014-12-02 23:05:39', '2014-12-02 23:05:39'),
(22, 22, 1, 1, '{"1":"4"}', 100, 0, '2014-12-02 23:07:48', '2014-12-02 23:07:48'),
(23, 20, 4, 6, '{"6":"17","7":"20"}', 50, 0, '2014-12-05 10:24:40', '2014-12-05 10:24:40'),
(24, 20, 4, 6, '{"6":"17","7":"20"}', 50, 0, '2014-12-05 10:27:57', '2014-12-05 10:27:57'),
(25, 20, 4, 6, '{"6":"17","7":"20"}', 50, 0, '2014-12-05 11:07:47', '2014-12-05 11:07:47'),
(26, 20, 4, 6, '{"6":"16","7":"20"}', 100, 0, '2014-12-05 11:13:18', '2014-12-05 11:13:18'),
(27, 20, 4, 6, '{"6":"16","7":"20"}', 100, 0, '2014-12-05 11:24:37', '2014-12-05 11:24:37'),
(28, 20, 4, 6, '{"6":"16","7":"20"}', 100, 0, '2014-12-05 17:21:42', '2014-12-05 17:21:42'),
(29, 20, 4, 6, '{"6":"16","7":"18"}', 50, 0, '2014-12-05 17:22:58', '2014-12-05 17:22:58'),
(30, 30, 1, 1, '{"1":"2"}', 0, 0, '2014-12-09 09:05:15', '2014-12-09 09:05:15'),
(31, 27, 1, 1, '{"1":"4"}', 100, 0, '2014-12-09 09:06:08', '2014-12-09 09:06:08'),
(32, 30, 1, 1, '{"1":"3"}', 75, 0, '2014-12-09 09:28:38', '2014-12-09 09:28:38'),
(33, 2, 4, 6, '{"6":"16","7":"20"}', 100, 0, '2014-12-09 12:34:31', '2014-12-09 12:34:31'),
(34, 65, 1, 1, '{"1":"1"}', 0, 0, '2014-12-11 06:47:05', '2014-12-11 06:47:05'),
(35, 65, 1, 1, '{"1":"4"}', 100, 0, '2014-12-11 06:48:55', '2014-12-11 06:48:55'),
(36, 65, 0, 2, '{"2":"5"}', 100, 0, '2014-12-11 06:51:31', '2014-12-11 06:51:31'),
(37, 65, 0, 2, '{"2":"5"}', 100, 0, '2014-12-11 06:52:16', '2014-12-11 06:52:16'),
(38, 65, 0, 2, '{"2":"7"}', 0, 0, '2014-12-11 06:52:21', '2014-12-11 06:52:21'),
(39, 68, 0, 3, '{"3":"9"}', 100, 0, '2014-12-11 10:57:23', '2014-12-11 10:57:23'),
(40, 68, 0, 3, '{"3":"9"}', 100, 0, '2014-12-11 11:01:51', '2014-12-11 11:01:51'),
(41, 67, 0, 2, '{"2":"5"}', 100, 0, '2014-12-11 11:03:28', '2014-12-11 11:03:28'),
(42, 20, 0, 3, '{"3":"9"}', 100, 0, '2014-12-11 11:57:08', '2014-12-11 11:57:08'),
(43, 2, 0, 3, '{"3":"9"}', 100, 0, '2014-12-11 16:20:38', '2014-12-11 16:20:38'),
(44, 74, 0, 2, '{"2":"5"}', 100, 0, '2014-12-12 08:10:13', '2014-12-12 08:10:13'),
(45, 78, 0, 3, '{"3":"9"}', 100, 0, '2014-12-12 09:15:20', '2014-12-12 09:15:20'),
(46, 81, 26, 7, '{"8":"21"}', 0, 0, '2014-12-15 08:43:34', '2014-12-15 08:43:34'),
(47, 81, 26, 7, '{"8":"22"}', 100, 0, '2014-12-15 08:44:14', '2014-12-15 08:44:14');

-- --------------------------------------------------------

--
-- Структура таблицы `order_payments`
--

DROP TABLE IF EXISTS `order_payments`;
CREATE TABLE IF NOT EXISTS `order_payments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` int(10) unsigned DEFAULT '0',
  `price` float(8,2) unsigned DEFAULT '0.00',
  `payment_number` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `payment_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `order_payments_order_id_index` (`order_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=8 ;

--
-- Дамп данных таблицы `order_payments`
--

INSERT INTO `order_payments` (`id`, `order_id`, `price`, `payment_number`, `payment_date`, `created_at`, `updated_at`) VALUES
(1, 1, 8000.00, '123', '2014-11-06 00:00:00', '2014-11-06 16:30:04', '2014-11-06 16:30:04'),
(2, 5, 4000.00, '1', '2014-12-02 00:00:00', '2014-12-02 12:19:04', '2014-12-02 12:19:04'),
(3, 10, 10000.00, '234', '2014-12-02 00:00:00', '2014-12-02 22:52:02', '2014-12-02 22:52:02'),
(4, 9, 12000.00, '-', '2014-12-03 00:00:00', '2014-12-03 10:20:25', '2014-12-03 10:20:25'),
(5, 20, 13000.00, '12', '2014-12-10 00:00:00', '2014-12-10 11:03:03', '2014-12-10 11:03:03'),
(6, 29, 560.00, '1', '2014-12-11 21:00:00', '2014-12-12 09:06:11', '2014-12-12 09:06:11'),
(7, 30, 240.00, '4387983', '2014-12-16 21:00:00', '2014-12-15 08:17:12', '2014-12-15 08:17:12');

-- --------------------------------------------------------

--
-- Структура таблицы `organizations`
--

DROP TABLE IF EXISTS `organizations`;
CREATE TABLE IF NOT EXISTS `organizations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT '0',
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fio_manager` varchar(160) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fio_manager_rod` varchar(160) COLLATE utf8_unicode_ci DEFAULT NULL,
  `manager` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `statutory` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `inn` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ogrn` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `kpp` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `uraddress` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `postaddress` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `account_type` smallint(5) unsigned DEFAULT '0',
  `account_number` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `account_kor_number` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bank` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bik` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `discount` tinyint(4) DEFAULT '0',
  `moderator_approve` tinyint(1) DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `organizations_user_id_index` (`user_id`),
  KEY `organizations_account_type_index` (`account_type`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=20 ;

--
-- Дамп данных таблицы `organizations`
--

INSERT INTO `organizations` (`id`, `user_id`, `title`, `fio_manager`, `fio_manager_rod`, `manager`, `statutory`, `inn`, `ogrn`, `kpp`, `uraddress`, `postaddress`, `account_type`, `account_number`, `account_kor_number`, `bank`, `bik`, `name`, `phone`, `discount`, `moderator_approve`, `created_at`, `updated_at`) VALUES
(1, 3, 'Управление финансового контроля Ростовской области', 'Папушенко Максим Валерьевич', 'Папушенко Максима Валерьевича', 'Начальник', 'Положения, утвержденного постановлением Правительства Ростовской области от 01.12.2011 № 185', '6163100482', '1106195000450', '616401001', '344050, г. Ростов-на-Дону, ул. Московская, 51/15/46', '344050, г. Ростов-на-Дону, ул. Московская, 51/15/46', 1, '40201810800000000017', '03582404450', 'Управлении Федерального казначейства по Ростовской области ', '046015001', 'Папушенко Максим Валерьевич', '+7 (951) 483 00 03', 0, 1, '2014-11-06 14:14:42', '2014-11-06 16:27:42'),
(2, 5, 'Графема', 'Харсеев Владимир Александрович', 'Харсееву Владимиру Александровичу', 'Программист', 'Устав', '6163100482', '9846980', '9846980', '344039. Ростов-на-Дону', '344050, г. Ростов-на-Дону, ул. Московская, 51/15/46', 1, '9846980', '9846980', 'Альфа-банк', '9846980', 'Харсеев Владимир Александрович', '+7 (919) 891 97 21', 0, 1, '2014-11-07 14:20:03', '2014-11-07 14:20:03'),
(3, 7, 'ПМЖ-11', 'Андрей', 'Андрея', 'Царь', 'Понятий', '0', '0', '0', '00', '00', 1, '0', '0', '0', '0', 'Петруха', '+7 (000) 000 00 00', 0, 0, '2014-11-26 13:13:29', '2014-11-26 13:13:29'),
(4, 8, 'ПМЖ-12', 'Артем', 'Артема', 'Царь', 'Устав', '0', '0', '0', '0', '0', 1, '0', '0', '0', '0', '0', '+7 (000) 000 00 00', 0, 1, '2014-11-26 13:18:36', '2014-11-28 11:27:09'),
(5, 10, 'ООО "Ковровский механический завод"', 'Харсеев Владимир Александрович', 'Харсеева Владимира Александровича', 'программист', 'доверенность №125/47', '3305004397', '1033302200458', '997850001', '601909, г. Ковров, ул. Социалистическая,26', '601909, г. Ковров, ул. Социалистическая,26', 1, '40702810210160100410', '30101810000000000602', 'Отделении № 8611 Сбербанка России г. Владимир', '041708602', 'Харсеев Владимир Александрович', '+7 (919) 891 97 21', 0, 0, '2014-11-27 08:40:54', '2014-11-27 08:40:54'),
(6, 13, 'Test', 'Test', 'Test', 'Test', 'Test', 'Test', 'Test', 'Test', 'Test', 'Test', 1, 'Test', 'test', 'test', 'test', 'Test', '+7 (999) 999 99 99', 0, 0, '2014-12-01 13:34:17', '2014-12-01 13:34:17'),
(7, 14, 'ООО "Ковровский механический завод"', 'Харсеев Владимир Александрович', 'Харсеева Владимира Александровича', 'программист', 'доверенность №125/47', '3305004397', '1033302200458', '997850001', '601909, г. Ковров, ул. Социалистическая,26', '601909, г. Ковров, ул. Социалистическая,26', 1, '40702810210160100410', '30101810000000000602', 'Отделении № 8611 Сбербанка России г. Владимир', '041708602', 'Харсеев Владимир Александрович', '+7 (919) 891 97 21', 0, 0, '2014-12-02 08:49:54', '2014-12-02 08:49:54'),
(8, 15, 'ООО "Ковровский механический завод"', 'Харсеев Владимир Александрович', 'Харсеева Владимира Александровича', 'программист', 'доверенность №125/47', '3305004397', '1033302200458', '997850001', '601909, г. Ковров, ул. Социалистическая,26', '601909, г. Ковров, ул. Социалистическая,26', 1, '40702810210160100410', '30101810000000000602', 'Отделении № 8611 Сбербанка России г. Владимир', '041708602', 'Харсеев Владимир Александрович', '+7 (919) 891 97 21', 0, 1, '2014-12-02 09:01:41', '2014-12-09 10:51:48'),
(9, 16, 'Общество с ограниченной ответственностью Техническая Экспертиза Зданий и Сооружений ', 'Нихаева Алена Владимировна', 'Нихаевой Алены Владимировны', 'Директор', 'Устав', '6165144083', '1076165012626', '616501001', '344012, г. Ростов-на-Дону, ул. Юфимцева, 17', '344012, г. Ростов-на-Дону, ул. Юфимцева, 17', 1, '40702810300000012397', '30101810100000000762', 'ОАО КБ "Центр-Инвест"', '046015762', 'Нихаева Алена Владимировна', '+7 (988) 541 89 49', 0, 0, '2014-12-02 13:08:42', '2014-12-02 13:08:42'),
(10, 19, 'Фирма-2', 'Иванов И.И.', 'Иванова И.И.', 'руководитель', 'Доверенность №50 от 12.12.2056', '6163109862', '1116195010843', '616301001', '3440, г. Ростов-на-Дону', '3440, г. Ростов-на-Дону', 1, '40702810300000016432', '40702810300000016432', 'Сбербанк России', '046015762', 'Иванов И.И.', '+7 (667) 676 78 68', 0, 1, '2014-12-02 21:08:50', '2014-12-02 22:42:07'),
(11, 25, 'Полное наименование организации', 'Полное наименование организации', 'Полное наименование организации', 'Полное наименование организации', 'Полное наименование организации', 'Полное наименование организации', 'Полное наименование организации', '', 'Полное наименование организации', 'Полное наименование организации', 1, 'Полное наименование организации', 'Полное наименование организации', 'Полное наименование организации', 'Полное наименование организации', 'Полное наименование организации', '+7 (000) 000 00 00', 0, 0, '2014-12-04 10:47:01', '2014-12-04 10:47:01'),
(12, 27, 'test', 'test', 'test', 'test', 'test', 'test', 'test', 'test', 'test', 'test', 1, 'test', 'test', 'test', 'test', 'test', '+7 (000) 000 00 00', 0, 0, '2014-12-04 12:43:36', '2014-12-04 12:43:36'),
(13, 30, 'Фирма-3', 'Иванова Екатерина Сергеевна', 'Ивановой Екатерины Сергеевны', 'Директор', 'Устав', '6165144083', '1076165012626', '616501001', '344012, г.Ростов-на-Дону, ул. Юфимцева, 17', '344012, г.Ростов-на-Дону, ул. Юфимцева, 17', 1, '140702810300000012397', '3101810100000000762', 'Центр-Инвест', '046015762', 'Петров Сергей Николаевич', '+7 (888) 864 65 46', 0, 1, '2014-12-10 16:03:46', '2014-12-11 06:15:02'),
(14, 31, 'tyyyyyyyyyyyy', 'yyyyyyhyfddddddddddd', 'bhhhhhhhhhhhhhhhh', 'hhhhffffffffffffffffffff', 'ffffggggggggggggggggggggggg', '4899999999', '5999999999999', '333333333', 'fffffffffffffffff', 'fffffffhhhhhhhhhhhhhhhhhhhhf', 1, '45555555555555555', '888888888888888888888', '555555555fyyyyyyyyyyyyyyyy', '66666666666666666666', 'hgggggggggggggg', '+7 (977) 777 77 77', 0, 0, '2014-12-10 16:11:36', '2014-12-10 16:11:36'),
(15, 34, 'gggggjkkkkkkkkkkkkkkkk', 'gyddddddddddddddddd', 'uigggggggggggggggggggg', 'fgggggggggggggggggggggggggg', 'hggggggggggggggggg', '8888888886', '5444444444444', '455555555', 'hggggggggggggggg', 'ggghggggggggggggggggg', 1, '87777777777777777777777777777777777777', '78888888888888888888888888888888', '6999999999999ghhhhhhhhhhhhh468888', '8ghhhhhhhhh46666666666', 'ghhhhhhhhhhh45756666666', '+7 (688) 888 88 88', 0, 0, '2014-12-11 06:09:26', '2014-12-11 06:09:26'),
(16, 38, 'ООО Компания', 'Иванов Иван Иванович', 'Иванова Ивана Иванович', 'Директ', 'двлрдыптр 89789789 "№#', '8889787987', '3056164052000', '', 'апврвапро56785678еноапроапро н', 'неогенг56856гкновео', 1, '40802810126050000099', '40703810626050000009', '876лоплополрп9879786876лртобьипропорвавhfhhfghf', '35132484987897678979', 'шкгщшкоеоатрол рщшкеорщкшеро кещшрокещрш', '+7 (312) 313 13 13', 0, 0, '2014-12-11 10:29:29', '2014-12-11 10:29:29'),
(17, 41, 'ООО "Ковровский механический завод"', 'Харсеев Владимир Александрович', 'Харсеева Владимира Александровича', 'программист', 'доверенность №125/47', '8888888888', '9999999999999', '888888888', '601909, г. Ковров, ул. Социалистическая,26', '601909, г. Ковров, ул. Социалистическая,26', 1, '40702810210160100410', '40702810210160100410', 'Отделении № 8611 Сбербанка России г. Владимир', '041708602', 'Харсеев Владимир Александрович', '+7 (919) 891 97 21', 0, 0, '2014-12-12 08:55:51', '2014-12-12 08:55:51'),
(18, 43, 'ропропроппрапроавапвап34343 @@""', 'ы', 'ернкн', 'авправовег', '4567457', '1234567___', '12345678901__', '', '54655', ' 6756', 1, '786786', '78676786', '5565754675678чвапвапвапвапвовеоаоаео', '78676____', 'ыпвероео аеоаео', '+7 (233) 322 __ __', 0, 0, '2014-12-15 07:46:16', '2014-12-15 07:46:16'),
(19, 44, 'ООО ""Рога и копыта', 'Емельянин Виктор Яннович ', 'Емельянина Виктора Янновича ', 'Управляющий партнер ', 'Доверенность №457 от 31.12.1999', '012345____', '0123456789___', '45278287272', '34400, россия, Ставрополь, Семикаракорская улица победы, 95, строение 81, кв. 5986', '34400, россия, Ставрополь, Семикаракорская улица победы, 95, строение 81, кв. 5986', 1, '123456789', '123456789', 'центральный банк российской федерации, отделение в Ростове-на-Дону, 15-е северное', '123456___', 'Емельянин Виктор Яннович ', '+7 (988) 899 98 98', 50, 1, '2014-12-15 07:52:40', '2014-12-15 08:01:31');

-- --------------------------------------------------------

--
-- Структура таблицы `pages`
--

DROP TABLE IF EXISTS `pages`;
CREATE TABLE IF NOT EXISTS `pages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `version_of` int(10) unsigned DEFAULT NULL,
  `name` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `slug` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `template` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `type_id` int(10) unsigned DEFAULT NULL,
  `publication` tinyint(1) unsigned DEFAULT '1',
  `start_page` tinyint(1) unsigned DEFAULT NULL,
  `in_menu` tinyint(1) unsigned DEFAULT NULL,
  `order` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `pages_version_of_index` (`version_of`),
  KEY `pages_slug_index` (`slug`),
  KEY `pages_type_id_index` (`type_id`),
  KEY `pages_publication_index` (`publication`),
  KEY `pages_start_page_index` (`start_page`),
  KEY `pages_in_menu_index` (`in_menu`),
  KEY `pages_order_index` (`order`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=7 ;

--
-- Дамп данных таблицы `pages`
--

INSERT INTO `pages` (`id`, `version_of`, `name`, `slug`, `template`, `type_id`, `publication`, `start_page`, `in_menu`, `order`, `created_at`, `updated_at`) VALUES
(1, NULL, 'Главная страница', 'glavnaya-stranica', 'index-page', NULL, 1, 1, NULL, NULL, '2014-09-25 06:44:13', '2014-10-08 11:44:48'),
(2, NULL, 'Оформление заявки', 'registration', 'by-slug', NULL, 1, NULL, NULL, NULL, '2014-09-25 06:45:04', '2014-09-25 06:46:20'),
(3, NULL, 'Каталог курсов', 'catalog', 'by-slug', NULL, 1, NULL, 1, NULL, '2014-10-01 11:39:57', '2014-10-01 11:39:57'),
(4, NULL, 'Как это работает', 'how-it-works', 'by-slug', NULL, 1, NULL, NULL, NULL, '2014-10-07 06:48:57', '2014-10-07 06:48:57'),
(5, NULL, 'Контакты', 'contacts', 'by-slug', NULL, 1, NULL, NULL, NULL, '2014-10-08 10:45:01', '2014-10-08 11:41:11'),
(6, NULL, 'О портале', 'about', 'by-slug', NULL, 1, NULL, NULL, NULL, '2014-10-09 03:59:01', '2014-10-09 03:59:01');

-- --------------------------------------------------------

--
-- Структура таблицы `pages_blocks`
--

DROP TABLE IF EXISTS `pages_blocks`;
CREATE TABLE IF NOT EXISTS `pages_blocks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `page_id` int(10) unsigned DEFAULT NULL,
  `name` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `slug` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `desc` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `template` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `order` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `pages_blocks_page_id_index` (`page_id`),
  KEY `pages_blocks_slug_index` (`slug`),
  KEY `pages_blocks_order_index` (`order`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=62 ;

--
-- Дамп данных таблицы `pages_blocks`
--

INSERT INTO `pages_blocks` (`id`, `page_id`, `name`, `slug`, `desc`, `template`, `order`, `created_at`, `updated_at`) VALUES
(1, 1, 'Название страницы', 'top_h2', NULL, NULL, 0, '2014-09-25 06:44:13', '2014-12-04 16:26:34'),
(2, 2, 'Название страницы', 'top_h2', NULL, NULL, 0, '2014-09-25 06:45:04', '2014-09-25 06:45:04'),
(3, 3, 'Название страницы', 'top_h2', NULL, NULL, 0, '2014-10-01 11:39:57', '2014-10-01 11:39:57'),
(4, 3, 'Описание страницы', 'top_desc', NULL, NULL, 1, '2014-10-01 11:39:57', '2014-10-01 11:39:57'),
(5, 2, 'Описание страницы', 'top_desc', NULL, NULL, 1, '2014-10-01 11:43:27', '2014-10-01 11:43:27'),
(6, 4, 'Название страницы', 'top_h2', NULL, NULL, 0, '2014-10-07 06:48:57', '2014-10-07 06:48:57'),
(7, 4, 'Описание страницы', 'top_desc', NULL, NULL, 1, '2014-10-07 06:48:57', '2014-10-07 06:48:57'),
(8, 4, 'Контент страницы', 'content', NULL, NULL, 2, '2014-10-07 06:55:58', '2014-10-07 06:55:58'),
(9, 5, 'Название страницы', 'top_h2', NULL, NULL, 0, '2014-10-08 10:45:01', '2014-10-15 10:37:36'),
(10, 5, 'Описание страницы', 'top_desc', NULL, NULL, 1, '2014-10-08 10:45:01', '2014-10-15 10:39:54'),
(11, 5, 'Адрес', 'address', NULL, NULL, 2, '2014-10-08 10:45:01', '2014-10-15 10:39:54'),
(12, 5, 'Контактные номера', 'phones', NULL, NULL, 3, '2014-10-08 10:45:01', '2014-10-15 10:39:54'),
(25, 5, 'Email адрес', 'email', NULL, NULL, 4, '2014-10-08 10:49:48', '2014-10-15 10:39:54'),
(26, 5, 'Банковские реквизиты (Название)', 'center_h2', NULL, NULL, 5, '2014-10-08 10:49:48', '2014-10-15 10:39:54'),
(27, 6, 'Название страницы', 'top_h2', NULL, NULL, 0, '2014-10-09 03:59:02', '2014-10-09 03:59:02'),
(28, 6, 'Описание страницы', 'top_desc', NULL, NULL, 1, '2014-10-09 03:59:02', '2014-10-09 03:59:02'),
(30, 1, 'Описание страницы', 'top_desc', NULL, NULL, 1, '2014-10-15 10:31:08', '2014-10-15 10:31:08'),
(31, 1, 'Преимущества название', 'benefits_title', NULL, NULL, 2, '2014-10-15 10:31:08', '2014-10-15 10:31:08'),
(32, 1, 'Преимущества описание', 'benefits_list', NULL, NULL, 3, '2014-10-15 10:31:08', '2014-10-15 10:31:25'),
(49, 5, 'ИНН', 'inn', NULL, NULL, 6, '2014-10-15 10:39:54', '2014-10-15 10:39:54'),
(50, 5, 'ОГРН', 'ogrn', NULL, NULL, 7, '2014-10-15 10:39:54', '2014-10-15 10:39:54'),
(51, 5, 'КПП', 'kpp', NULL, NULL, 8, '2014-10-15 10:39:54', '2014-10-15 10:39:54'),
(52, 5, 'ОКПО', 'okpo', NULL, NULL, 9, '2014-10-15 10:39:54', '2014-10-15 10:39:54'),
(53, 5, 'ОКАТО', 'okato', NULL, NULL, 10, '2014-10-15 10:39:54', '2014-10-15 10:39:54'),
(54, 5, 'ОКВЭД', 'pkved', NULL, NULL, 11, '2014-10-15 10:39:54', '2014-10-15 10:39:54'),
(55, 5, 'р/сч', 'rasschet', NULL, NULL, 12, '2014-10-15 10:39:54', '2014-10-15 10:39:54'),
(56, 5, 'к/сч', 'kschet', NULL, NULL, 13, '2014-10-15 10:39:54', '2014-10-15 10:39:54'),
(57, 5, 'Банк', 'bank', NULL, NULL, 14, '2014-10-15 10:39:54', '2014-10-15 10:39:54'),
(58, 5, 'БИК', 'bik', NULL, NULL, 15, '2014-10-15 10:39:54', '2014-10-15 10:39:54'),
(61, 6, 'Лицензии', 'center_h3', NULL, NULL, 2, '2014-10-15 10:43:32', '2014-10-15 10:44:02');

-- --------------------------------------------------------

--
-- Структура таблицы `pages_blocks_meta`
--

DROP TABLE IF EXISTS `pages_blocks_meta`;
CREATE TABLE IF NOT EXISTS `pages_blocks_meta` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `block_id` int(10) unsigned DEFAULT NULL,
  `name` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `content` text COLLATE utf8_unicode_ci,
  `language` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `template` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `pages_blocks_meta_block_id_index` (`block_id`),
  KEY `pages_blocks_meta_language_index` (`language`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=49 ;

--
-- Дамп данных таблицы `pages_blocks_meta`
--

INSERT INTO `pages_blocks_meta` (`id`, `block_id`, `name`, `content`, `language`, `template`, `created_at`, `updated_at`) VALUES
(1, 3, NULL, '<h1>Каталог курсов</h1>', 'ru', NULL, '2014-10-01 11:40:30', '2014-11-21 14:40:17'),
(2, 4, NULL, '<p>В каталоге Образовательного портала ТЕХВУЗ.РФ представлен широкий выбор курсов повышения квалификации для руководителей и специалистов по различным направлениям. Обучение по всем курсам проводится с применением образовательных технологий электронного обучения. </p>', 'ru', NULL, '2014-10-01 11:41:25', '2014-12-05 08:04:07'),
(3, 6, NULL, '<h1>Как это работает</h1>', 'ru', NULL, '2014-10-07 06:55:12', '2014-11-21 15:28:04'),
(4, 7, NULL, '', 'ru', NULL, '2014-10-07 06:55:25', '2014-12-05 13:37:39'),
(5, 8, NULL, '<ul class="htw-ul">\r\n	<li class="htw-li htw-num-1">\r\n	<h3 class="htw-head">                                 Оформление заявки                             </h3>\r\n	<div class="htw-text">\r\n		<ol>\r\n			<li><a href="/registration">Зарегистрируйтесь</a></li>\r\n			<li>Выберите <a href="/catalog">курсы</a></li>\r\n			<li>Зарегистрируйте сотрудников, которых планируете обучить</li>\r\n			<li>Получите счет и договор</li>\r\n		</ol>\r\n	</div>\r\n	 </li>\r\n	<li class="htw-li htw-num-2">\r\n	<h3 class="htw-head">                                 Оплата                             </h3>\r\n	<div class="htw-text">\r\n		                                    Счет Вы получите автоматически по завершении оформления заявки.                                 Совершить оплату Вы можете в любом банке. Доступ к лекциям открывается                                 в течение 1-2 дней после оплаты.\r\n	</div>\r\n	 </li>\r\n	<li class="htw-li htw-num-3">\r\n	<h3 class="htw-head">                                 Обучение                             </h3>\r\n	<div class="htw-text">\r\n		                                    Слушатели обучаются в своих личных кабинетах на сайте. Для завершения обучения слушатели выполняют итоговое тестирование.\r\n	</div>\r\n	 </li>\r\n	<li class="htw-li htw-num-4">\r\n	<h3 class="htw-head">                                 Получение удостоверения                             </h3>\r\n	<div class="htw-text">\r\n		                                    Как только слушатели успешно завершают обучение, мы выдаем удостоверения о повышении квалификации. Документы можно получить лично либо высылаются по месту нахождения заказчика курьерской службой, бесплатно!\r\n	</div>\r\n	 </li>\r\n</ul>', 'ru', NULL, '2014-10-07 06:56:19', '2014-12-05 13:42:00'),
(6, 1, NULL, 'Дистанционные курсы повышения квалификации с выдачей удостоверения', 'ru', NULL, '2014-10-08 10:14:23', '2014-12-04 16:29:12'),
(7, 9, NULL, 'Контакты', 'ru', NULL, '2014-10-08 11:31:47', '2014-10-15 10:35:49'),
(11, 10, NULL, 'Автономная некоммерческая организация                         дополнительного профессионального образования                          «Центр качества строительства»', 'ru', NULL, '2014-10-08 11:47:08', '2014-12-05 05:43:54'),
(12, 2, NULL, 'Регистрация', 'ru', NULL, '2014-10-09 03:29:47', '2014-12-04 15:04:16'),
(13, 5, NULL, '<p>\r\n                        Уважаемый заказчик! Для оформления заявок на повышение<br>\r\n                        квалификации Вам необходимо пройти систему регистрации. \r\n                    </p>', 'ru', NULL, '2014-10-09 03:29:54', '2014-12-04 15:04:53'),
(14, 27, NULL, 'О портале', 'ru', NULL, '2014-10-15 10:28:52', '2014-10-15 10:42:53'),
(15, 28, NULL, '<p class="margin-bottom-20">\r\n	 Образовательный портал ТЕХВУЗ.РФ — система электронного обучения, позволяющая организовать образовательный процесс без отрыва от основной работы в наиболее удобной для слушателей форме. С помощью электронных учебных курсов посредством глобальных <nobr>информационно-телекоммуникационных</nobr> сетей успешно реализуется повышение квалификации специалистов не зависимо от территориального местоположения.\r\n</p>\r\n<p>\r\n	В каталоге Образовательного портала ТЕХВУЗ.РФ представлен широкий выбор курсов повышения квалификации для руководителей и специалистов по различным направлениям. Учебные материалы образовательных программ составлены на основании действующих нормативных документов.\r\n</p>\r\n<p>\r\n	Система обучения Образовательного портала ТЕХВУЗ.РФ проста в обращении и подходит для пользователей любого уровня подготовки. Вы с легкостью сможете контролировать весь процесс обучения в своем личном кабинете, включая документооборот.\r\n</p>', 'ru', NULL, '2014-10-15 10:28:58', '2014-12-05 13:46:12'),
(18, 30, NULL, '<p>\r\n	                         Система электронного обучения Образовательного портала ТЕХВУЗ.РФ позволяет организовать образовательный процесс в наиболее удобной для Слушателей форме с помощью электронных учебных курсов посредством глобальных информационно-телекоммуникационных сетей.\r\n</p>\r\n<p>\r\n	                          Срок освоения учебного курса зависит от выбранной  дополнительной профессиональной программы и составляет от 16 до 72 часов. Результатом обучения и успешного прохождения тестирования в электронной форме является выдача Слушателю удостоверения о повышении квалификации установленного образца. \r\n</p>', 'ru', NULL, '2014-10-15 10:32:01', '2014-12-04 15:05:38'),
(19, 31, NULL, '<h3>\r\n	Преимущества\r\n</h3>', 'ru', NULL, '2014-10-15 10:32:12', '2014-10-22 06:17:52'),
(20, 32, NULL, '<ul class="benefits-ul clearfix">\r\n	<li class="benefits-li benefit-num-1"><strong>Удобная система</strong> – подойдет для пользователей любого уровня подготовки.                         </li>\r\n	<li class="benefits-li benefit-num-2"><strong>Широкий набор образовательных программ</strong> – обязательно найдете то, что нужно именно Вам.                         </li>\r\n	<li class="benefits-li benefit-num-3"><strong>Дистанционное электронное обучение</strong> – повышайте свою квалификацию где и когда удобно.                          </li>\r\n	<li class="benefits-li benefit-num-4"><strong>Качество обучения</strong> – все программы составлены на основании действующих нормативных документов.                         </li>\r\n</ul>', 'ru', NULL, '2014-10-15 10:32:26', '2014-12-04 16:34:49'),
(21, 11, NULL, '344 002, г. Ростов-на-Дону,<br>\r\n                            пер. Соляной Спуск, 8-10<br>', 'ru', NULL, '2014-10-15 10:36:21', '2014-12-05 05:44:30'),
(22, 12, NULL, '<p>\r\n	+7 (863) 299-07-14<br>\r\n	+7 (863) 299-07-15\r\n</p>', 'ru', NULL, '2014-10-15 10:37:01', '2014-12-05 05:48:53'),
(23, 25, NULL, 'tehvuz@gmail.ru', 'ru', NULL, '2014-10-15 10:37:12', '2014-10-15 10:37:12'),
(29, 26, NULL, 'Банковские реквизиты', 'ru', NULL, '2014-10-15 10:37:48', '2014-10-15 10:37:48'),
(36, 49, NULL, '6164990260', 'ru', NULL, '2014-10-15 10:40:19', '2014-10-15 10:40:19'),
(37, 50, NULL, '1126100001720', 'ru', NULL, '2014-10-15 10:40:25', '2014-10-15 10:40:25'),
(38, 51, NULL, '616401001', 'ru', NULL, '2014-10-15 10:40:34', '2014-10-15 10:40:34'),
(39, 52, NULL, '38426411', 'ru', NULL, '2014-10-15 10:40:40', '2014-10-15 10:40:40'),
(40, 53, NULL, '60401372000', 'ru', NULL, '2014-10-15 10:40:48', '2014-10-15 10:40:48'),
(41, 54, NULL, 'ОКВЭД', 'ru', NULL, '2014-10-15 10:40:56', '2014-10-15 10:40:56'),
(42, 55, NULL, '4070381082605000000', 'ru', NULL, '2014-10-15 10:41:07', '2014-10-15 10:41:07'),
(43, 56, NULL, '30101810500000000207', 'ru', NULL, '2014-10-15 10:41:15', '2014-10-15 10:41:15'),
(44, 57, NULL, 'ОАО Альфа-Банк г.  Ростов-на-Дону', 'ru', NULL, '2014-10-15 10:41:25', '2014-10-15 10:41:25'),
(45, 58, NULL, '046015207', 'ru', NULL, '2014-10-15 10:41:32', '2014-10-15 10:41:32'),
(48, 61, NULL, 'Наши лицензии и сертификаты', 'ru', NULL, '2014-10-15 10:43:37', '2014-10-15 10:43:37');

-- --------------------------------------------------------

--
-- Структура таблицы `pages_meta`
--

DROP TABLE IF EXISTS `pages_meta`;
CREATE TABLE IF NOT EXISTS `pages_meta` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `page_id` int(10) unsigned DEFAULT NULL,
  `language` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `template` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `pages_meta_page_id_index` (`page_id`),
  KEY `pages_meta_language_index` (`language`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=7 ;

--
-- Дамп данных таблицы `pages_meta`
--

INSERT INTO `pages_meta` (`id`, `page_id`, `language`, `template`, `created_at`, `updated_at`) VALUES
(1, 1, 'ru', NULL, '2014-09-25 06:44:13', '2014-09-25 06:44:13'),
(2, 2, 'ru', NULL, '2014-09-25 06:45:04', '2014-09-25 06:45:04'),
(3, 3, 'ru', NULL, '2014-10-01 11:39:57', '2014-10-01 11:39:57'),
(4, 4, 'ru', NULL, '2014-10-07 06:48:57', '2014-10-07 06:48:57'),
(5, 5, 'ru', NULL, '2014-10-08 10:45:01', '2014-10-08 10:45:01'),
(6, 6, 'ru', NULL, '2014-10-09 03:59:01', '2014-10-09 03:59:01');

-- --------------------------------------------------------

--
-- Структура таблицы `password_reminders`
--

DROP TABLE IF EXISTS `password_reminders`;
CREATE TABLE IF NOT EXISTS `password_reminders` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  KEY `password_reminders_email_index` (`email`),
  KEY `password_reminders_token_index` (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `password_reminders`
--

INSERT INTO `password_reminders` (`email`, `token`, `created_at`) VALUES
('firma-proverka-3@yandex.ru', 'e995749c5c4e7757849f1c58fa9631f1e32556c2', '2014-12-10 16:59:42');

-- --------------------------------------------------------

--
-- Структура таблицы `payment_status`
--

DROP TABLE IF EXISTS `payment_status`;
CREATE TABLE IF NOT EXISTS `payment_status` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `class` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=7 ;

--
-- Дамп данных таблицы `payment_status`
--

INSERT INTO `payment_status` (`id`, `title`, `class`, `created_at`, `updated_at`) VALUES
(1, 'Не оплачен', 'non-paid-order', '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(2, 'Оплачен', 'paid-order', '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(3, 'Частично оплачен', 'part-order', '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(4, 'Частично оплачен но доступ разрешен', 'part-order', '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(5, 'Не оплачен но доступ разрешен', 'non-paid-order', '2014-10-29 08:18:38', '2014-10-29 08:18:38'),
(6, 'Оплачен но доступ запрещен', 'paid-order', '2014-10-29 08:18:38', '2014-10-29 08:18:38');

-- --------------------------------------------------------

--
-- Структура таблицы `photos`
--

DROP TABLE IF EXISTS `photos`;
CREATE TABLE IF NOT EXISTS `photos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `gallery_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `photos_gallery_id_index` (`gallery_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=7 ;

--
-- Дамп данных таблицы `photos`
--

INSERT INTO `photos` (`id`, `name`, `gallery_id`, `created_at`, `updated_at`) VALUES
(1, '1414571488_1330.png', 0, '2014-10-29 08:31:28', '2014-10-29 08:31:28'),
(2, '1412239705_1367.png', 0, '2014-10-02 04:48:25', '2014-10-02 04:48:25'),
(3, '1412239721_1122.png', 0, '2014-10-02 04:48:41', '2014-10-02 04:48:41'),
(4, '1412239737_1059.png', 0, '2014-10-02 04:48:57', '2014-10-02 04:48:57'),
(5, '1412239752_1941.png', 0, '2014-10-02 04:49:12', '2014-10-02 04:49:12'),
(6, '1412239767_1820.png', 0, '2014-10-02 04:49:27', '2014-10-02 04:49:27');

-- --------------------------------------------------------

--
-- Структура таблицы `rel_mod_gallery`
--

DROP TABLE IF EXISTS `rel_mod_gallery`;
CREATE TABLE IF NOT EXISTS `rel_mod_gallery` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `module` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `unit_id` int(10) unsigned DEFAULT '0',
  `gallery_id` int(10) unsigned DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `rel_mod_gallery_module_index` (`module`),
  KEY `unit_id` (`module`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `seo`
--

DROP TABLE IF EXISTS `seo`;
CREATE TABLE IF NOT EXISTS `seo` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `module` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `unit_id` int(10) unsigned DEFAULT NULL,
  `language` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `title` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `keywords` text COLLATE utf8_unicode_ci,
  `url` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `h1` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `unit_id` (`module`),
  KEY `seo_module_index` (`module`),
  KEY `seo_unit_id_index` (`unit_id`),
  KEY `seo_language_index` (`language`),
  KEY `seo_url_index` (`url`(255))
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=38 ;

--
-- Дамп данных таблицы `seo`
--

INSERT INTO `seo` (`id`, `module`, `unit_id`, `language`, `title`, `description`, `keywords`, `url`, `h1`, `created_at`, `updated_at`) VALUES
(1, 'page_meta', 1, NULL, 'Главная страница', '', '', '', '', '2014-09-25 06:44:13', '2014-09-25 06:44:24'),
(2, 'page_meta', 2, NULL, 'Оформление заявки', '', '', 'registration', '', '2014-09-25 06:45:04', '2014-09-25 06:45:04'),
(3, 'page_meta', 3, NULL, 'Каталог курсов', '', '', 'catalog', '', '2014-10-01 11:39:57', '2014-10-01 11:39:57'),
(4, 'page_meta', 4, NULL, 'Как это работает', '', '', 'how-it-works', '', '2014-10-07 06:48:57', '2014-10-07 06:48:57'),
(5, 'Page', 5, 'ru', 'Контакты', '', '', 'contacts', '', '2014-10-08 10:45:01', '2014-10-08 10:45:01'),
(11, 'Page', 1, 'ru', '', '', '', '', '', '2014-10-08 11:44:48', '2014-10-08 11:44:48'),
(12, 'Page', 6, 'ru', 'О портале', '', '', 'about', '', '2014-10-09 03:59:01', '2014-10-09 03:59:01'),
(19, 'news_meta', 1, NULL, '', '', '', '', '', '2014-10-22 11:19:45', '2014-10-22 11:19:45'),
(20, 'news_meta', 2, NULL, '', '', '', '', '', '2014-10-22 13:12:24', '2014-10-22 13:12:24'),
(21, 'education-courses', 1, NULL, 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства', '', '', 'stroitelstvo-rekonstrukciya-kapitalnyiy-remont-obektov-kapitalnogo-stroitelstva', 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства', '2014-10-29 12:08:46', '2014-10-30 07:56:09'),
(22, 'education-courses', 2, NULL, 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (выполнение геодезических, подготовительных и земляных работ, устройства оснований и фундаментов)', '', '', 'stroitelstvo-rekonstrukciya-kapitalnyiy-remont-obektov-kapitalnogo-stroitelstva-vypolnenie-geodezicheskih-podgotovitelnyh-i-zemlyanyh-rabot-ustroiystva-osnovaniiy-i-fundamentov', 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (выполнение геодезических, подготовительных и земляных работ, устройства оснований и фундаментов)', '2014-10-29 12:33:23', '2014-10-31 12:17:10'),
(23, 'education-courses', 3, NULL, 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (возведение бетонных и железобетонных конструкций)', '', '', 'stroitelstvo-rekonstrukciya-kapitalnyiy-remont-obektov-kapitalnogo-stroitelstva-vozvedenie-betonnyh-i-jelezobetonnyh-konstrukciiy', 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (возведение бетонных и железобетонных конструкций)', '2014-10-29 12:41:38', '2014-10-31 15:00:45'),
(24, 'education-courses', 4, NULL, 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (возведение каменных, металлических и деревянных строительных конструкций)', '', '', 'stroitelstvo-rekonstrukciya-kapitalnyiy-remont-obektov-kapitalnogo-stroitelstva-vozvedenie-kamennyh-metallicheskih-i-derevyannyh-stroitelnyh-konstrukciiy', 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (возведение каменных, металлических и деревянных строительных конструкций)', '2014-10-29 12:48:42', '2014-10-31 15:02:54'),
(25, 'education-courses', 5, NULL, 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (выполнение фасадных работ, устройство кровель, защита строительных конструкций, трубопроводов и оборудования)', '', '', 'stroitelstvo-rekonstrukciya-kapitalnyiy-remont-obektov-kapitalnogo-stroitelstva-vypolnenie-fasadnyh-rabot-ustroiystvo-krovel-zashita-stroitelnyh-konstrukciiy-truboprovodov-i-oborudovaniya', 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (выполнение фасадных работ, устройство кровель, защита строительных конструкций, трубопроводов и оборудования)', '2014-10-29 13:20:47', '2014-10-31 15:12:20'),
(26, 'education-courses', 6, NULL, 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (устройство инженерных систем и сетей)', '', '', 'stroitelstvo-rekonstrukciya-kapitalnyiy-remont-obektov-kapitalnogo-stroitelstva-ustroiystvo-injenernyh-sistem-i-seteiy', 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (устройство инженерных систем и сетей)', '2014-10-29 13:38:24', '2014-10-31 15:14:06'),
(27, 'education-courses', 7, NULL, 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (устройство электрических сетей и линий связи)', '', '', 'stroitelstvo-rekonstrukciya-kapitalnyiy-remont-obektov-kapitalnogo-stroitelstva-ustroiystvo-lektricheskih-seteiy-i-liniiy-svyazi', 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (устройство электрических сетей и линий связи)', '2014-10-29 13:45:11', '2014-10-31 15:15:43'),
(28, 'education-courses', 8, NULL, 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (устройство объектов нефтяной и газовой промышленности, устройство скважин)', '', '', 'stroitelstvo-rekonstrukciya-kapitalnyiy-remont-obektov-kapitalnogo-stroitelstva-ustroiystvo-obektov-neftyanoiy-i-gazovoiy-promyshlennosti-ustroiystvo-skvajin', 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (устройство объектов нефтяной и газовой промышленности, устройство скважин)', '2014-10-29 14:05:57', '2014-10-31 15:17:27'),
(29, 'education-courses', 9, NULL, 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (выполнение монтажных и пусконаладочных работ)', '', '', 'stroitelstvo-rekonstrukciya-kapitalnyiy-remont-obektov-kapitalnogo-stroitelstva-vypolnenie-montajnyh-i-puskonaladochnyh-rabot', 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (выполнение монтажных и пусконаладочных работ)', '2014-10-29 14:23:31', '2014-10-31 15:19:05'),
(30, 'education-courses', 10, NULL, 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (устройство автомобильных дорог и аэродромов)', '', '', 'stroitelstvo-rekonstrukciya-kapitalnyiy-remont-obektov-kapitalnogo-stroitelstva-ustroiystvo-avtomobilnyh-dorog-i-arodromov', 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (устройство автомобильных дорог и аэродромов)', '2014-10-29 14:32:22', '2014-10-31 15:24:31'),
(31, 'education-courses', 11, NULL, 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (устройство железнодорожных и трамвайных путей)', '', '', 'stroitelstvo-rekonstrukciya-kapitalnyiy-remont-obektov-kapitalnogo-stroitelstva-ustroiystvo-jeleznodorojnyh-i-tramvaiynyh-puteiy', 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (устройство железнодорожных и трамвайных путей)', '2014-10-29 14:43:57', '2014-10-31 15:26:10'),
(32, 'education-courses', 12, NULL, 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (устройство подземных сооружений, осуществление специальных земляных и буровзрывных работ при строительстве)', '', '', 'stroitelstvo-rekonstrukciya-kapitalnyiy-remont-obektov-kapitalnogo-stroitelstva-ustroiystvo-podzemnyh-soorujeniiy-osushestvlenie-specialnyh-zemlyanyh-i-burovzryvnyh-rabot-pri-stroitelstve', 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (устройство подземных сооружений, осуществление специальных земляных и буровзрывных работ при строительстве)', '2014-10-29 15:16:51', '2014-10-31 15:35:59'),
(33, 'education-courses', 13, NULL, 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (устройство мостов, эстакад и путепроводов)', '', '', 'stroitelstvo-rekonstrukciya-kapitalnyiy-remont-obektov-kapitalnogo-stroitelstva-ustroiystvo-mostov-stakad-i-puteprovodov', 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (устройство мостов, эстакад и путепроводов)', '2014-10-29 15:21:49', '2014-10-31 15:37:20'),
(34, 'education-courses', 14, NULL, 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (выполнение гидротехнических, водолазных работ)', '', '', 'stroitelstvo-rekonstrukciya-kapitalnyiy-remont-obektov-kapitalnogo-stroitelstva-vypolnenie-gidrotehnicheskih-vodolaznyh-rabot', 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (выполнение гидротехнических, водолазных работ)', '2014-10-29 15:27:53', '2014-10-31 15:39:09'),
(35, 'education-courses', 15, NULL, 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (устройство промышленных печей и дымовых труб)', '', '', 'stroitelstvo-rekonstrukciya-kapitalnyiy-remont-obektov-kapitalnogo-stroitelstva-ustroiystvo-promyshlennyh-pecheiy-i-dymovyh-trub', 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (устройство промышленных печей и дымовых труб)', '2014-10-29 15:34:16', '2014-10-31 15:46:56'),
(36, 'education-courses', 16, NULL, 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (осуществление строительного контроля)', '', '', 'stroitelstvo-rekonstrukciya-kapitalnyiy-remont-obektov-kapitalnogo-stroitelstva-osushestvlenie-stroitelnogo-kontrolya', 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (осуществление строительного контроля)', '2014-10-29 15:39:26', '2014-10-31 16:30:00'),
(37, 'education-courses', 17, NULL, 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (организация строительства)', '', '', 'stroitelstvo-rekonstrukciya-kapitalnyiy-remont-obektov-kapitalnogo-stroitelstva-organizaciya-stroitelstva', 'Строительство, реконструкция, капитальный ремонт объектов капитального строительства (организация строительства)', '2014-10-29 15:43:16', '2014-10-31 16:33:50');

-- --------------------------------------------------------

--
-- Структура таблицы `sessions`
--

DROP TABLE IF EXISTS `sessions`;
CREATE TABLE IF NOT EXISTS `sessions` (
  `id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `payload` text COLLATE utf8_unicode_ci NOT NULL,
  `last_activity` int(11) NOT NULL,
  UNIQUE KEY `sessions_id_unique` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `sessions`
--

INSERT INTO `sessions` (`id`, `payload`, `last_activity`) VALUES
('149a5505c4528ca0ecc8d986291120e34a700cec', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiNmhDVjJwUDBRcWVYZ0pzcHhsM0JnRmxka1B2VlgxNFdlaEV6dTVaeSI7czo1OiJmbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjM4OiJsb2dpbl84MmU1ZDJjNTZiZGQwODExMzE4ZjBjZjA3OGI3OGJmYyI7czoyOiI0OSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MTg5MDQwODI7czoxOiJjIjtpOjE0MTg5MDAyMDM7czoxOiJsIjtzOjE6IjAiO319', 1418904082),
('3e40caa574706e19ebcbb18645b6fdd1fd17c5a7', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoieHVxdkJMcEJVR2VaNzVrcGJqTGh3TVVyYVdrWkFPdFpkRTM5dzV2cCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MTg5MTEyOTk7czoxOiJjIjtpOjE0MTg5MTEyOTk7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1418911303),
('4985b0cad43e1af22494cd96a109eec45b561122', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiOExHam9JZGU4NGlCdW9USGRaMDZoSFdqaWVxUjZJeDdTeTU2NzRSdiI7czoyMjoiUEhQREVCVUdCQVJfU1RBQ0tfREFUQSI7YTowOnt9czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MTg4OTk2NjA7czoxOiJjIjtpOjE0MTg4OTk2NjA7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1418899666),
('5c3c0db0b4f0a5d5ca12a0ff2f5a8f56dd12ba4a', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiOFpwOTg3ZVkzSVM0TlRSelNrOUlKUDIzczRNQW05VEJDZUgyRGVJayI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MTg5MDAyMDI7czoxOiJjIjtpOjE0MTg5MDAyMDI7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1418900202),
('6564184cbcad29d70d6a5f0f103ea389a1b77cf0', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiRk1qb3p6clFHSVB4ZHpKRWVQejhyVzBibnRBSGlRVU9ReXo3NlcyMyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MTg5MTAxOTI7czoxOiJjIjtpOjE0MTg5MTAxOTI7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1418910195),
('6dbf602fb4cf610c4566a7d3fec35fb2df46f22a', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiN0t6WGVjaUV4OUs0Mmd1QlJHWHhqTXZhVWlLRWl6d3lsNWlqSUFucyI7czoyMjoiUEhQREVCVUdCQVJfU1RBQ0tfREFUQSI7YTowOnt9czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MTg4OTY1MDg7czoxOiJjIjtpOjE0MTg4OTY1MDg7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1418896508),
('90308e5cbdb0311a583b3a4626ca1d8893bafa51', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoieEpTSHZaN1l3Tm15bjhDNlRhc3VOVnVuMlNvMEo0TFpiZkNjZkdZdyI7czoyMjoiUEhQREVCVUdCQVJfU1RBQ0tfREFUQSI7YTowOnt9czo1OiJmbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjk6Il9zZjJfbWV0YSI7YTozOntzOjE6InUiO2k6MTQxODg5MzEwMjtzOjE6ImMiO2k6MTQxODg5MzA3MztzOjE6ImwiO3M6MToiMCI7fX0=', 1418893102),
('a8ebc124c6a740ea7e9fe5d0f7bfd2bbd792b276', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoibjlMMHAzd1JFUnhmSnV4UnpQZkxzOUUwUGx4TDBHeU5hM2hWSnhLMCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MTg5MTE2ODQ7czoxOiJjIjtpOjE0MTg5MTE2ODQ7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1418911685),
('b1efa2782bf5b3f509011de8b77dc0420b838bcc', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiUXMzajJHR2FmTzJiaWtUbUgxUEF3YU9zQzdwbUxiRTF2ekswUmpvOSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MTg5MTAwNjI7czoxOiJjIjtpOjE0MTg5MTAwNjI7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1418910062),
('e755fe7c5cf37ca82f654b0ff5fc53c891ca4cd1', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiYXZxRjl3MW1tdDZENzk0NWY5eUluZ3owTFVaV2E2VVZQVlowb3hzVyI7czo1OiJmbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjM4OiJsb2dpbl84MmU1ZDJjNTZiZGQwODExMzE4ZjBjZjA3OGI3OGJmYyI7czoxOiIyIjtzOjk6Il9zZjJfbWV0YSI7YTozOntzOjE6InUiO2k6MTQxODg5OTg2NDtzOjE6ImMiO2k6MTQxODg5OTgxODtzOjE6ImwiO3M6MToiMCI7fX0=', 1418899864),
('f05e078540aa7306cdaf870b58c3d25b076001f9', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiRU9IdjdvTGZZOXVxVkJtNUI5bE4xNFBJczJyaGFWa09vUEdCU1hWbCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MTg5MTIwMzM7czoxOiJjIjtpOjE0MTg5MTIwMzM7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1418912037),
('f0b9bbc6a71c71fff450659acdebf2342518581c', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiWGFwNTdHZHVXaEVSQmVVZHE5MUc0OThCTlNuOGdaZEVzdzlPT0lhYiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MTg5MTEzMTc7czoxOiJjIjtpOjE0MTg5MTEzMTc7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1418911320),
('f7461021b7cba444969d5ca55346c03cdfa67ace', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiTHR5SUVWS2pZQlViQTBjdDZ3UDFuT3NPYWlVWHdXdU96NFUyZ3VLOCI7czo1OiJmbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjk6Il9zZjJfbWV0YSI7YTozOntzOjE6InUiO2k6MTQxODkwNTU0NTtzOjE6ImMiO2k6MTQxODkwNTU0MTtzOjE6ImwiO3M6MToiMCI7fX0=', 1418905545);

-- --------------------------------------------------------

--
-- Структура таблицы `settings`
--

DROP TABLE IF EXISTS `settings`;
CREATE TABLE IF NOT EXISTS `settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `value` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `settings`
--

INSERT INTO `settings` (`id`, `name`, `value`, `created_at`, `updated_at`) VALUES
(1, 'language', 'ru', '2014-10-29 08:18:38', '2014-10-29 08:18:38');

-- --------------------------------------------------------

--
-- Структура таблицы `storages`
--

DROP TABLE IF EXISTS `storages`;
CREATE TABLE IF NOT EXISTS `storages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `module` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `value` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `storages_module_index` (`module`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `tests`
--

DROP TABLE IF EXISTS `tests`;
CREATE TABLE IF NOT EXISTS `tests` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `course_id` int(10) unsigned DEFAULT NULL,
  `chapter_id` int(10) unsigned DEFAULT NULL,
  `order` int(10) unsigned DEFAULT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `active` tinyint(1) unsigned DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `tests_course_id_index` (`course_id`),
  KEY `tests_chapter_id_index` (`chapter_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=8 ;

--
-- Дамп данных таблицы `tests`
--

INSERT INTO `tests` (`id`, `course_id`, `chapter_id`, `order`, `title`, `description`, `active`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 0, 'Промежуточное тестирование', '', 1, '2014-11-06 16:53:18', '2014-11-06 16:53:18'),
(2, 1, 0, 0, 'Итоговое тестирование', '', 1, '2014-11-06 16:58:18', '2014-11-06 16:58:18'),
(3, 2, 0, 0, 'Итоговое тестирование', '', 1, '2014-11-06 17:29:30', '2014-11-06 17:29:30'),
(4, 4, 10, 0, 'Промежуточное тестирование', '', 1, '2014-11-28 14:30:40', '2014-11-28 14:30:40'),
(5, 4, 0, 0, 'Итоговое тестирование', '', 1, '2014-12-02 12:30:00', '2014-12-02 12:30:00'),
(6, 2, 4, 0, 'Промежуточное тестирование', '', 1, '2014-12-05 10:19:30', '2014-12-05 10:19:30'),
(7, 9, 26, 0, 'Промежуточное тестирование', '', 1, '2014-12-15 08:42:40', '2014-12-15 08:42:40');

-- --------------------------------------------------------

--
-- Структура таблицы `tests_answers`
--

DROP TABLE IF EXISTS `tests_answers`;
CREATE TABLE IF NOT EXISTS `tests_answers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `test_id` int(10) unsigned DEFAULT NULL,
  `test_question_id` int(10) unsigned DEFAULT NULL,
  `order` int(10) unsigned DEFAULT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `correct` int(10) unsigned DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `tests_answers_test_id_index` (`test_id`),
  KEY `tests_answers_test_question_id_index` (`test_question_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=23 ;

--
-- Дамп данных таблицы `tests_answers`
--

INSERT INTO `tests_answers` (`id`, `test_id`, `test_question_id`, `order`, `title`, `description`, `correct`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 1, 'Ответ №', '<p>\n	   Крокодил Гена\n</p>', 0, '2014-11-06 16:53:36', '2014-12-04 14:18:54'),
(2, 1, 1, 2, 'Ответ №', '<p>\n	 Старуха Шапокляк\n</p>', 0, '2014-11-06 16:53:41', '2014-11-06 16:56:06'),
(3, 1, 1, 3, 'Ответ №', '<p>\n	 Крыска Лариска\n</p>', 0, '2014-11-06 16:53:46', '2014-11-06 16:56:16'),
(4, 1, 1, 4, 'Ответ №', '<p>\n	<span style="background-color: initial;">Депутат Госдумы Евгений Федоров, предлодживший сделать внутрироссийский интернет "Чебурашка" </span>\n</p>', 1, '2014-11-06 16:53:51', '2014-12-04 14:19:39'),
(5, 2, 2, 1, 'Ответ №', '<p>\n	<em>Голубое</em>\n</p>', 1, '2014-11-06 16:58:43', '2014-11-06 16:58:43'),
(6, 2, 2, 2, 'Ответ №', '<p>\n	Серо-буро-козюливое\n</p>', 0, '2014-11-06 16:58:59', '2014-11-06 16:58:59'),
(7, 2, 2, 3, 'Ответ №', '<p>\n	ГЫГЫ, конечно, цвета Радуги!\n</p>', 0, '2014-11-06 16:59:18', '2014-11-06 16:59:18'),
(8, 3, 3, 1, 'Ответ №', '<p>\n	11\n</p>', 0, '2014-11-06 17:30:11', '2014-11-06 17:30:11'),
(9, 3, 3, 2, 'Ответ №', '<p>\n	 12\n</p>', 1, '2014-11-06 17:30:16', '2014-11-06 17:30:32'),
(10, 3, 3, 3, 'Ответ №', '<p>\n	13\n</p>', 0, '2014-11-06 17:30:24', '2014-11-06 17:30:24'),
(11, 4, 4, 1, 'Ответ №', '<p>\n	вариант\n</p>', 1, '2014-11-28 14:31:35', '2014-11-28 14:31:35'),
(12, 4, 4, 2, 'Ответ №', '<p>\n	Строительство, реконструкция, капитальный ремонт объектов капитального строительства (возведение каменных, металлических и деревянных строительных конструкций)\n</p>', 0, '2014-11-28 14:31:51', '2014-11-28 16:54:38'),
(13, 5, 5, 1, 'Ответ №', '<p>\n	Верный вариант\n</p>', 1, '2014-12-02 12:30:30', '2014-12-02 12:30:30'),
(14, 5, 5, 2, 'Ответ №', '<p>\n	Неверный вариант\n</p>', 0, '2014-12-02 12:30:40', '2014-12-02 12:30:40'),
(15, 1, 1, 5, 'Ответ №', '', 0, '2014-12-04 14:19:26', '2014-12-04 14:19:26'),
(16, 6, 6, 1, 'Ответ №', '<p>\n	Верный ответ\n</p>', 1, '2014-12-05 10:20:07', '2014-12-05 10:20:07'),
(17, 6, 6, 2, 'Ответ №', '<p>\n	Неверный ответ\n</p>', 0, '2014-12-05 10:20:21', '2014-12-05 10:20:21'),
(18, 6, 7, 1, 'Ответ №', '<p>\n	Неверный ответ\n</p>', 0, '2014-12-05 10:23:15', '2014-12-05 10:23:15'),
(19, 6, 7, 2, 'Ответ №', '<p>\n	Второй неверный ответ\n</p>', 0, '2014-12-05 10:23:26', '2014-12-05 10:23:26'),
(20, 6, 7, 3, 'Ответ №', '<p>\n	Верный\n</p>', 1, '2014-12-05 10:23:39', '2014-12-05 10:23:39'),
(21, 7, 8, 1, 'Ответ №', '<p>\n	Неверный\n</p>', 0, '2014-12-15 08:43:02', '2014-12-15 08:43:02'),
(22, 7, 8, 2, 'Ответ №', '<p>\n	Верный\n</p>', 1, '2014-12-15 08:43:11', '2014-12-15 08:43:11');

-- --------------------------------------------------------

--
-- Структура таблицы `tests_questions`
--

DROP TABLE IF EXISTS `tests_questions`;
CREATE TABLE IF NOT EXISTS `tests_questions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `test_id` int(10) unsigned DEFAULT NULL,
  `order` int(10) unsigned DEFAULT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `tests_questions_test_id_index` (`test_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=9 ;

--
-- Дамп данных таблицы `tests_questions`
--

INSERT INTO `tests_questions` (`id`, `test_id`, `order`, `title`, `description`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 'Вопрос №', '<p>\n	Кто был лучшим другом Чебурашки?\n</p>', '2014-11-06 16:53:29', '2014-11-06 16:55:46'),
(2, 2, 1, 'Вопрос №', '<p>\n	Какого цвета небо?\n</p>', '2014-11-06 16:58:33', '2014-11-06 16:58:33'),
(3, 3, 1, 'Вопрос №', '<p>\n	Сколько подвигов совершил Геракл?\n</p>', '2014-11-06 17:29:49', '2014-11-06 17:29:49'),
(4, 4, 1, 'Вопрос №', '<p>\n	    БС-03. Строительство, реконструкция, капитальный ремонт объектов капитального строительства (возведение каменных, металлических и деревянных строительных конструкций)\n</p>\n', '2014-11-28 14:31:16', '2014-11-28 16:54:01'),
(5, 5, 1, 'Вопрос №', '<p>\n	Единственный вопрос\n</p>', '2014-12-02 12:30:16', '2014-12-02 12:30:16'),
(6, 6, 1, 'Вопрос №', '<p>\n	Первый вопрос\n</p>', '2014-12-05 10:19:43', '2014-12-05 10:19:43'),
(7, 6, 2, 'Вопрос №', '<p>\n	Второй вопрос\n</p>', '2014-12-05 10:23:04', '2014-12-05 10:23:04'),
(8, 7, 1, 'Вопрос №', '<p>\n	Первый вопрос\n</p>', '2014-12-15 08:42:53', '2014-12-15 08:42:53');

-- --------------------------------------------------------

--
-- Структура таблицы `uploads`
--

DROP TABLE IF EXISTS `uploads`;
CREATE TABLE IF NOT EXISTS `uploads` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `path` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `original_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `filesize` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mimetype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mime1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mime2` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `module` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `unit_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `uploads_mime1_index` (`mime1`),
  KEY `uploads_mime2_index` (`mime2`),
  KEY `uploads_module_index` (`module`),
  KEY `uploads_unit_id_index` (`unit_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=145 ;

--
-- Дамп данных таблицы `uploads`
--

INSERT INTO `uploads` (`id`, `path`, `original_name`, `filesize`, `mimetype`, `mime1`, `mime2`, `module`, `unit_id`, `created_at`, `updated_at`) VALUES
(1, '/uploads/files/1414585001_1598.pdf', 'Модуль №1.pdf', '197636', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 12:16:41', '2014-10-29 12:16:41'),
(2, '/uploads/files/1414585051_1558.pdf', 'Модуль №2.pdf', '123765', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 12:17:31', '2014-10-29 12:17:31'),
(3, '/uploads/files/1414585095_1159.pdf', 'Модуль №3.pdf', '164951', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 12:18:15', '2014-10-29 12:18:15'),
(4, '/uploads/files/1414585158_1027.pdf', 'Модуль №4.pdf', '202256', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 12:19:18', '2014-10-29 12:19:18'),
(5, '/uploads/files/1414585237_1373.pdf', 'Модуль №5.pdf', '941149', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 12:20:37', '2014-10-29 12:20:37'),
(6, '/uploads/files/1414585269_1728.pdf', 'Модуль №6.pdf', '217317', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 12:21:09', '2014-10-29 12:21:09'),
(7, '/uploads/files/1414585340_1760.pdf', 'Модуль №7.pdf', '254896', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 12:22:20', '2014-10-29 12:22:20'),
(8, '/uploads/files/1414585366_1981.pdf', 'Модуль №8.pdf', '236257', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 12:22:46', '2014-10-29 12:22:46'),
(9, '/uploads/files/1414586098_1969.pdf', 'Модуль №1.pdf', '197636', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 12:34:58', '2014-10-29 12:34:58'),
(10, '/uploads/files/1414586120_1359.pdf', 'Модуль №2.pdf', '123765', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 12:35:20', '2014-10-29 12:35:20'),
(11, '/uploads/files/1414586140_1480.pdf', 'Модуль №3.pdf', '164951', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 12:35:40', '2014-10-29 12:35:40'),
(12, '/uploads/files/1414586167_1599.pdf', 'Модуль №4.pdf', '202256', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 12:36:07', '2014-10-29 12:36:07'),
(13, '/uploads/files/1414586257_1257.pdf', 'Модуль №5.pdf', '478376', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 12:37:37', '2014-10-29 12:37:37'),
(14, '/uploads/files/1414586317_1551.pdf', 'Модуль №6.pdf', '217317', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 12:38:37', '2014-10-29 12:38:37'),
(15, '/uploads/files/1414586403_1338.pdf', 'Модуль №7.pdf', '254896', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 12:40:03', '2014-10-29 12:40:03'),
(16, '/uploads/files/1414586434_1599.pdf', 'Модуль №8.pdf', '236257', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 12:40:34', '2014-10-29 12:40:34'),
(17, '/uploads/files/1414586549_1556.pdf', 'Модуль №1.pdf', '197636', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 12:42:29', '2014-10-29 12:42:29'),
(18, '/uploads/files/1414586567_1723.pdf', 'Модуль №2.pdf', '123765', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 12:42:47', '2014-10-29 12:42:47'),
(19, '/uploads/files/1414586585_1184.pdf', 'Модуль №3.pdf', '164951', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 12:43:05', '2014-10-29 12:43:05'),
(20, '/uploads/files/1414586637_1615.pdf', 'Модуль №4.pdf', '202256', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 12:43:57', '2014-10-29 12:43:57'),
(21, '/uploads/files/1414586687_1311.pdf', 'Модуль №5.pdf', '308775', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 12:44:47', '2014-10-29 12:44:47'),
(22, '/uploads/files/1414586711_1336.pdf', 'Модуль №6.pdf', '217317', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 12:45:11', '2014-10-29 12:45:11'),
(23, '/uploads/files/1414586795_1697.pdf', 'Модуль №7.pdf', '254896', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 12:46:35', '2014-10-29 12:46:35'),
(24, '/uploads/files/1414586818_1830.pdf', 'Модуль №8.pdf', '236257', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 12:46:58', '2014-10-29 12:46:58'),
(25, '/uploads/files/1414587305_1773.pdf', 'Модуль №1.pdf', '197636', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 12:55:05', '2014-10-29 12:55:05'),
(26, '/uploads/files/1414587360_1455.pdf', 'Модуль №2.pdf', '123765', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 12:56:00', '2014-10-29 12:56:00'),
(27, '/uploads/files/1414587387_1752.pdf', 'Модуль №3.pdf', '164951', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 12:56:27', '2014-10-29 12:56:27'),
(28, '/uploads/files/1414587460_1393.pdf', 'Модуль №4.pdf', '202256', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 12:57:40', '2014-10-29 12:57:40'),
(29, '/uploads/files/1414587523_1836.pdf', 'Модуль №5.pdf', '411330', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 12:58:43', '2014-10-29 12:58:43'),
(30, '/uploads/files/1414588603_1177.pdf', 'Модуль №6.pdf', '217317', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 13:16:43', '2014-10-29 13:16:43'),
(31, '/uploads/files/1414588688_1599.pdf', 'Модуль №7.pdf', '254896', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 13:18:08', '2014-10-29 13:18:08'),
(32, '/uploads/files/1414588726_1546.pdf', 'Модуль №8.pdf', '236257', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 13:18:46', '2014-10-29 13:18:46'),
(33, '/uploads/files/1414588925_1958.pdf', 'Модуль №1.pdf', '197636', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 13:22:05', '2014-10-29 13:22:05'),
(34, '/uploads/files/1414589295_1999.pdf', 'Модуль №2.pdf', '123765', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 13:28:15', '2014-10-29 13:28:15'),
(35, '/uploads/files/1414589315_1880.pdf', 'Модуль №3.pdf', '164951', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 13:28:35', '2014-10-29 13:28:35'),
(36, '/uploads/files/1414589339_1427.pdf', 'Модуль №4.pdf', '202256', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 13:28:59', '2014-10-29 13:28:59'),
(37, '/uploads/files/1414589409_1454.pdf', 'Модуль №5.pdf', '327316', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 13:30:09', '2014-10-29 13:30:09'),
(38, '/uploads/files/1414589460_1652.pdf', 'Модуль №6.pdf', '217317', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 13:31:00', '2014-10-29 13:31:00'),
(39, '/uploads/files/1414589544_1153.pdf', 'Модуль №7.pdf', '254896', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 13:32:24', '2014-10-29 13:32:24'),
(40, '/uploads/files/1414589563_1800.pdf', 'Модуль №8.pdf', '236257', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 13:32:43', '2014-10-29 13:32:43'),
(41, '/uploads/files/1414589949_1244.pdf', 'Модуль №1.pdf', '197636', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 13:39:09', '2014-10-29 13:39:09'),
(42, '/uploads/files/1414589972_1548.pdf', 'Модуль №2.pdf', '123765', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 13:39:32', '2014-10-29 13:39:32'),
(43, '/uploads/files/1414589992_1851.pdf', 'Модуль №3.pdf', '164951', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 13:39:52', '2014-10-29 13:39:52'),
(44, '/uploads/files/1414590018_1150.pdf', 'Модуль №4.pdf', '202256', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 13:40:18', '2014-10-29 13:40:18'),
(45, '/uploads/files/1414590116_1354.pdf', 'Модуль №5.pdf', '283368', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 13:41:56', '2014-10-29 13:41:56'),
(46, '/uploads/files/1414590145_1039.pdf', 'Модуль №6.pdf', '217317', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 13:42:25', '2014-10-29 13:42:25'),
(47, '/uploads/files/1414590207_1031.pdf', 'Модуль №7.pdf', '254896', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 13:43:27', '2014-10-29 13:43:27'),
(48, '/uploads/files/1414590228_1544.pdf', 'Модуль №8.pdf', '236257', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 13:43:48', '2014-10-29 13:43:48'),
(49, '/uploads/files/1414591203_1895.pdf', 'Модуль №1.pdf', '197636', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 14:00:03', '2014-10-29 14:00:03'),
(50, '/uploads/files/1414591229_1181.pdf', 'Модуль №2.pdf', '123765', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 14:00:29', '2014-10-29 14:00:29'),
(51, '/uploads/files/1414591250_1303.pdf', 'Модуль №3.pdf', '164951', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 14:00:50', '2014-10-29 14:00:50'),
(52, '/uploads/files/1414591278_1915.pdf', 'Модуль №4.pdf', '202256', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 14:01:18', '2014-10-29 14:01:18'),
(53, '/uploads/files/1414591345_1888.pdf', 'Модуль №5.pdf', '295506', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 14:02:25', '2014-10-29 14:02:25'),
(54, '/uploads/files/1414591380_1927.pdf', 'Модуль №6.pdf', '217317', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 14:03:00', '2014-10-29 14:03:00'),
(55, '/uploads/files/1414591455_1886.pdf', 'Модуль №7.pdf', '254896', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 14:04:15', '2014-10-29 14:04:15'),
(56, '/uploads/files/1414591478_1096.pdf', 'Модуль №8.pdf', '236257', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 14:04:38', '2014-10-29 14:04:38'),
(57, '/uploads/files/1414591620_1996.pdf', 'Модуль №1.pdf', '197636', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 14:07:00', '2014-10-29 14:07:00'),
(58, '/uploads/files/1414591649_1373.pdf', 'Модуль №2.pdf', '123765', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 14:07:29', '2014-10-29 14:07:29'),
(59, '/uploads/files/1414592130_1389.pdf', 'Модуль №3.pdf', '164951', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 14:15:30', '2014-10-29 14:15:30'),
(60, '/uploads/files/1414592208_1320.pdf', 'Модуль №4.pdf', '202256', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 14:16:48', '2014-10-29 14:16:48'),
(61, '/uploads/files/1414592359_1012.pdf', 'Модуль №5.pdf', '430875', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 14:19:19', '2014-10-29 14:19:19'),
(62, '/uploads/files/1414592389_1825.pdf', 'Модуль №6.pdf', '217317', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 14:19:49', '2014-10-29 14:19:49'),
(63, '/uploads/files/1414592462_1829.pdf', 'Модуль №7.pdf', '254896', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 14:21:02', '2014-10-29 14:21:02'),
(64, '/uploads/files/1414592483_1829.pdf', 'Модуль №8.pdf', '236257', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 14:21:23', '2014-10-29 14:21:23'),
(65, '/uploads/files/1414592686_1059.pdf', 'Модуль №1.pdf', '197636', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 14:24:46', '2014-10-29 14:24:46'),
(66, '/uploads/files/1414592725_1447.pdf', 'Модуль №2.pdf', '123765', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 14:25:25', '2014-10-29 14:25:25'),
(67, '/uploads/files/1414592835_1685.pdf', 'Модуль №3.pdf', '164951', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 14:27:15', '2014-10-29 14:27:15'),
(68, '/uploads/files/1414592876_1527.pdf', 'Модуль №4.pdf', '202256', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 14:27:56', '2014-10-29 14:27:56'),
(69, '/uploads/files/1414592937_1427.pdf', 'Модуль №5.pdf', '343905', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 14:28:57', '2014-10-29 14:28:57'),
(70, '/uploads/files/1414592964_1966.pdf', 'Модуль №6.pdf', '217317', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 14:29:24', '2014-10-29 14:29:24'),
(71, '/uploads/files/1414593007_1273.pdf', 'Модуль №7.pdf', '254896', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 14:30:07', '2014-10-29 14:30:07'),
(72, '/uploads/files/1414593035_1418.pdf', 'Модуль №8.pdf', '236257', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 14:30:35', '2014-10-29 14:30:35'),
(73, '/uploads/files/1414593321_1726.pdf', 'Модуль №1.pdf', '197636', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 14:35:21', '2014-10-29 14:35:21'),
(74, '/uploads/files/1414593355_1302.pdf', 'Модуль №2.pdf', '123765', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 14:35:55', '2014-10-29 14:35:55'),
(75, '/uploads/files/1414593373_1280.pdf', 'Модуль №3.pdf', '164951', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 14:36:13', '2014-10-29 14:36:13'),
(76, '/uploads/files/1414593401_1421.pdf', 'Модуль №4.pdf', '202256', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 14:36:41', '2014-10-29 14:36:41'),
(77, '/uploads/files/1414593488_1409.pdf', 'Модуль №5.pdf', '447106', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 14:38:08', '2014-10-29 14:38:08'),
(78, '/uploads/files/1414593555_1432.pdf', 'Модуль №6.pdf', '217317', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 14:39:16', '2014-10-29 14:39:16'),
(79, '/uploads/files/1414593618_1848.pdf', 'Модуль №7.pdf', '254896', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 14:40:18', '2014-10-29 14:40:18'),
(80, '/uploads/files/1414593650_1788.pdf', 'Модуль №8.pdf', '236257', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 14:40:50', '2014-10-29 14:40:50'),
(81, '/uploads/files/1414594272_1720.pdf', 'Модуль №1.pdf', '197636', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 14:51:12', '2014-10-29 14:51:12'),
(82, '/uploads/files/1414595135_1099.pdf', 'Модуль №2.pdf', '123765', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:05:35', '2014-10-29 15:05:35'),
(83, '/uploads/files/1414595540_1128.pdf', 'Модуль №3.pdf', '164951', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:12:20', '2014-10-29 15:12:20'),
(84, '/uploads/files/1414595558_1992.pdf', 'Модуль №4.pdf', '202256', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:12:38', '2014-10-29 15:12:38'),
(85, '/uploads/files/1414595608_1855.pdf', 'Модуль №5.pdf', '342725', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:13:28', '2014-10-29 15:13:28'),
(86, '/uploads/files/1414595632_1707.pdf', 'Модуль №6.pdf', '217317', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:13:52', '2014-10-29 15:13:52'),
(87, '/uploads/files/1414595669_1940.pdf', 'Модуль №7.pdf', '254896', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:14:29', '2014-10-29 15:14:29'),
(88, '/uploads/files/1414595748_1615.pdf', 'Модуль №8.pdf', '236257', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:15:48', '2014-10-29 15:15:48'),
(89, '/uploads/files/1414595859_1905.pdf', 'Модуль №1.pdf', '197636', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:17:39', '2014-10-29 15:17:39'),
(90, '/uploads/files/1414595878_1528.pdf', 'Модуль №2.pdf', '123765', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:17:58', '2014-10-29 15:17:58'),
(91, '/uploads/files/1414595892_1566.pdf', 'Модуль №3.pdf', '164951', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:18:12', '2014-10-29 15:18:12'),
(92, '/uploads/files/1414595910_1452.pdf', 'Модуль №4.pdf', '202256', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:18:30', '2014-10-29 15:18:30'),
(93, '/uploads/files/1414595969_1752.pdf', 'Модуль №5.pdf', '299241', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:19:29', '2014-10-29 15:19:29'),
(94, '/uploads/files/1414595988_1438.pdf', 'Модуль №6.pdf', '217317', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:19:48', '2014-10-29 15:19:48'),
(95, '/uploads/files/1414596028_1327.pdf', 'Модуль №7.pdf', '254896', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:20:28', '2014-10-29 15:20:28'),
(96, '/uploads/files/1414596047_1695.pdf', 'Модуль №8.pdf', '236257', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:20:47', '2014-10-29 15:20:47'),
(97, '/uploads/files/1414596149_1496.pdf', 'Модуль №1.pdf', '197636', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:22:29', '2014-10-29 15:22:29'),
(98, '/uploads/files/1414596164_1410.pdf', 'Модуль №2.pdf', '123765', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:22:44', '2014-10-29 15:22:44'),
(99, '/uploads/files/1414596181_1475.pdf', 'Модуль №3.pdf', '164951', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:23:01', '2014-10-29 15:23:01'),
(100, '/uploads/files/1414596198_1020.pdf', 'Модуль №4.pdf', '202256', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:23:18', '2014-10-29 15:23:18'),
(101, '/uploads/files/1414596310_1992.pdf', 'Модуль №5.pdf', '308572', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:25:10', '2014-10-29 15:25:10'),
(102, '/uploads/files/1414596334_1700.pdf', 'Модуль №6.pdf', '217317', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:25:34', '2014-10-29 15:25:34'),
(103, '/uploads/files/1414596379_1613.pdf', 'Модуль №7.pdf', '254896', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:26:19', '2014-10-29 15:26:19'),
(104, '/uploads/files/1414596400_1870.pdf', 'Модуль №8.pdf', '236257', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:26:40', '2014-10-29 15:26:40'),
(105, '/uploads/files/1414596532_1518.pdf', 'Модуль №1.pdf', '197636', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:28:52', '2014-10-29 15:28:52'),
(106, '/uploads/files/1414596563_1953.pdf', 'Модуль №2.pdf', '123765', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:29:23', '2014-10-29 15:29:23'),
(107, '/uploads/files/1414596604_1513.pdf', 'Модуль №3.pdf', '164951', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:30:04', '2014-10-29 15:30:04'),
(108, '/uploads/files/1414596641_1953.pdf', 'Модуль №4.pdf', '202256', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:30:41', '2014-10-29 15:30:41'),
(109, '/uploads/files/1414596689_1601.pdf', 'Модуль №5.pdf', '292690', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:31:29', '2014-10-29 15:31:29'),
(110, '/uploads/files/1414596726_1396.pdf', 'Модуль №6.pdf', '217317', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:32:06', '2014-10-29 15:32:06'),
(111, '/uploads/files/1414596761_1217.pdf', 'Модуль №7.pdf', '254896', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:32:41', '2014-10-29 15:32:41'),
(112, '/uploads/files/1414596778_1239.pdf', 'Модуль №8.pdf', '236257', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:32:58', '2014-10-29 15:32:58'),
(113, '/uploads/files/1414596916_1158.pdf', 'Модуль №1.pdf', '197636', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:35:16', '2014-10-29 15:35:16'),
(114, '/uploads/files/1414596935_1283.pdf', 'Модуль №2.pdf', '123765', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:35:35', '2014-10-29 15:35:35'),
(115, '/uploads/files/1414596948_1188.pdf', 'Модуль №3.pdf', '164951', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:35:48', '2014-10-29 15:35:48'),
(116, '/uploads/files/1414596964_1359.pdf', 'Модуль №4.pdf', '202256', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:36:04', '2014-10-29 15:36:04'),
(117, '/uploads/files/1414597027_1184.pdf', 'Модуль №5.pdf', '281618', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:37:07', '2014-10-29 15:37:07'),
(118, '/uploads/files/1414597052_1211.pdf', 'Модуль №6.pdf', '217317', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:37:32', '2014-10-29 15:37:32'),
(119, '/uploads/files/1414597090_1343.pdf', 'Модуль №7.pdf', '254896', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:38:10', '2014-10-29 15:38:10'),
(120, '/uploads/files/1414597111_1341.pdf', 'Модуль №8.pdf', '236257', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:38:31', '2014-10-29 15:38:31'),
(121, '/uploads/files/1414597224_1582.pdf', 'Модуль №1.pdf', '197636', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:40:24', '2014-10-29 15:40:24'),
(122, '/uploads/files/1414597249_1263.pdf', 'Модуль №2.pdf', '123765', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:40:49', '2014-10-29 15:40:49'),
(123, '/uploads/files/1414597266_1594.pdf', 'Модуль №3.pdf', '164951', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:41:06', '2014-10-29 15:41:06'),
(124, '/uploads/files/1414597288_1642.pdf', 'Модуль №4.pdf', '217195', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:41:28', '2014-10-29 15:41:28'),
(125, '/uploads/files/1414597304_1386.pdf', 'Модуль №5.pdf', '254654', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:41:44', '2014-10-29 15:41:44'),
(126, '/uploads/files/1414597350_1492.pdf', 'Модуль №6.pdf', '948731', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:42:30', '2014-10-29 15:42:30'),
(127, '/uploads/files/1414597446_1722.pdf', 'Модуль №1.pdf', '197636', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:44:06', '2014-10-29 15:44:06'),
(128, '/uploads/files/1414597464_1125.pdf', 'Модуль №2.pdf', '165118', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:44:24', '2014-10-29 15:44:24'),
(129, '/uploads/files/1414597481_1073.pdf', 'Модуль №3.pdf', '202298', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:44:41', '2014-10-29 15:44:41'),
(130, '/uploads/files/1414597496_1605.pdf', 'Модуль №4.pdf', '217195', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:44:56', '2014-10-29 15:44:56'),
(131, '/uploads/files/1414597565_1103.pdf', 'Модуль №5.pdf', '254654', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:46:05', '2014-10-29 15:46:05'),
(132, '/uploads/files/1414597581_1710.pdf', 'Модуль №6.pdf', '314912', 'application/pdf', 'application', 'pdf', NULL, NULL, '2014-10-29 15:46:21', '2014-10-29 15:46:21'),
(136, 'uploads/orders/contract-017-14.pdf', 'contract-017-14.pdf', '44077', 'application/pdf', 'application', 'pdf', 'ordering', 26, '2014-12-11 11:03:29', '2014-12-11 11:03:29'),
(137, 'uploads/orders/invoice-017-14.pdf', 'contract-017-14.pdf', '37277', 'application/pdf', 'application', 'pdf', 'ordering', 26, '2014-12-11 11:03:29', '2014-12-11 11:03:29'),
(138, 'uploads/orders/act-017-14.pdf', 'contract-017-14.pdf', '53282', 'application/pdf', 'application', 'pdf', 'ordering', 26, '2014-12-11 11:03:29', '2014-12-11 11:03:29'),
(139, 'uploads/orders/contract-001-14.pdf', 'contract-001-14.pdf', '44056', 'application/pdf', 'application', 'pdf', 'ordering', 1, '2014-12-11 16:20:39', '2014-12-11 16:20:39'),
(140, 'uploads/orders/invoice-001-14.pdf', 'contract-001-14.pdf', '37372', 'application/pdf', 'application', 'pdf', 'ordering', 1, '2014-12-11 16:20:39', '2014-12-11 16:20:39'),
(141, 'uploads/orders/act-001-14.pdf', 'contract-001-14.pdf', '53339', 'application/pdf', 'application', 'pdf', 'ordering', 1, '2014-12-11 16:20:39', '2014-12-11 16:20:39'),
(142, 'uploads/orders/contract-020-14.pdf', 'contract-020-14.pdf', '44047', 'application/pdf', 'application', 'pdf', 'ordering', 29, '2014-12-12 09:15:21', '2014-12-12 09:15:21'),
(143, 'uploads/orders/invoice-020-14.pdf', 'contract-020-14.pdf', '37325', 'application/pdf', 'application', 'pdf', 'ordering', 29, '2014-12-12 09:15:21', '2014-12-12 09:15:21'),
(144, 'uploads/orders/act-020-14.pdf', 'contract-020-14.pdf', '53287', 'application/pdf', 'application', 'pdf', 'ordering', 29, '2014-12-12 09:15:22', '2014-12-12 09:15:22');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `group_id` smallint(5) unsigned DEFAULT '0',
  `name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `surname` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `active` smallint(5) unsigned DEFAULT '0',
  `password` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `photo` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `thumbnail` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `temporary_code` varchar(25) COLLATE utf8_unicode_ci DEFAULT NULL,
  `code_life` bigint(20) DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=50 ;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `group_id`, `name`, `surname`, `email`, `active`, `password`, `photo`, `thumbnail`, `temporary_code`, `code_life`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 1, 'Администратор', '', 'admin@techvuz.ru', 1, '$2y$10$GPtYyNgMs1WtT6KPPl373.I1K0cLLuvlZTrjCLnamhzkOalG1HDEu', '', '', '', 0, 'PnpMt6V08xtbgmYQQpN6PfZfPAVHIuknKh4Hq7xe7dQSwmqyt223k7XKma37', '2014-10-29 08:18:38', '2014-12-18 07:50:29'),
(2, 3, 'Модератор', '', 'moder@techvuz.ru', 1, '$2y$10$FoyyWv5KcoTJY2QfC4o6uuqGYjl0hwtAzi.o.6ny8INNwLB1SHMV6', '', '', '', 0, 'tvxhvUIn3KdiXUnqSyVHJ19qEWlIea30VihGMyis4pU0yHYGauqU3K2rSP7u', '2014-10-29 08:18:38', '2014-12-16 13:22:23'),
(3, 4, 'Максим', 'Папушенко', 'firma-proverka-1@yandex.ru', 1, '$2y$10$pufU3rVbTWSfMvalHsyGWulmB8ZeEwdjQhkw2bCH9aC6V2BBwb3x2', '', '', '', 0, 'hb8Rp92Ppi83H4aemtkOkODkYULFHMFHXc9qaPTQutf4wE0o5WwhSn3VEnFT', '2014-11-06 14:14:42', '2014-12-11 16:19:10'),
(4, 5, 'Владимир', 'Сорбат', 'shumeev.pasha@yandex.ru', 1, '$2y$10$sVfZmTEsWnabfKJcyHm8L.pu1.3OSBLA0Nsg8VaY3Q22vni7//kLK', '', '', '', 0, 'XctNmuglGmZdcBru7F1kcTSCCzwwfgQG0M8t87DeEtXOzk7QbcQvNu2eDunY', '2014-11-06 15:47:23', '2014-12-09 12:34:53'),
(5, 4, 'Владимир', 'Харсеев', 'vkharseev11@gmail.com', 1, '$2y$10$cURNE69bmaAH8DvVyN3PDOnx.TyrFogCOuhUIIiVtG8LiUaEVJS1O', '', '', '', 0, 'uUGkJPQFRXka7LHDTmsyHwu60c3Nli9wxzMDi0PfvrLdFYf47y33eEVRgwv2', '2014-11-07 14:20:03', '2014-11-11 14:25:44'),
(6, 5, 'Владимир', 'Харсеев', 'vk1@grapheme.ru', 1, '$2y$10$W7M2SybnwoFxzG6AJX/tb..v2wtLUj94UorPMjgwrpTiugi57HE/C', '', '', '', 0, 'JGQdkOS5oFpfBqDb7o2fubQL6YM1JgvCdWczSEBoZRgr8Wv53HfjOWFSfUq4', '2014-11-07 14:20:57', '2014-12-01 10:42:00'),
(7, 4, '', 'Петруха', 'sm@grphm.ru', 0, '$2y$10$YGjGM/4LvIanV/UO.tqisukeUlJ9Vj1VTzbG7pAWZ8uyS5T1QEJ1G', '', '', '', 0, 'ECDjaBoUwBRbMiVMooHldY8pZXXjjQYtHsQADoO9qedKiXcersvxEz3CJhB1', '2014-11-26 13:13:29', '2014-12-08 13:30:57'),
(8, 4, '', '0', 'sm@mfsa.ru', 1, '$2y$10$z7yX4EgK1qCXwSVUcV8u7OXxoCvP01Hnp/trGBwcxccFZ8tzP4o0O', '', '', '', 0, 'T2ttezDkw813YXHI0yKAhSE4CGbjic6XKKItiHcLSDKpLBLIkAm9El89nYke', '2014-11-26 13:18:36', '2014-12-18 08:58:11'),
(9, 5, 'Иван', 'Иванов', 'ivanich@mail.ru', 1, '$2y$10$d3GeMBOoCl1lZr4vV4uAKeBPSSHZVsK95MTfu8ZCvJUSrh/L4XbxW', '', '', '', 0, NULL, '2014-11-26 13:31:14', '2014-11-26 13:32:37'),
(10, 4, 'Владимир', 'Харсеев', 'vkharseev1@gmail.com', 2, '$2y$10$PuxjR0YmRnlzxdiIaXpqSuBskspx4Fet6y7J4p3gdZu2NwHowPHw2', '', '', 'oHFYVXwSLqSSFiGuhF3S3m5V', 1417509654, 'WEvi9sMFB3BFNKxx4GaaE9g9GFXhuR7FjdTzDaWbtGAQUKkxZgyx0G2UWOuV', '2014-11-27 08:40:54', '2014-12-01 11:40:58'),
(11, 5, 'Аркадий', 'Помидоров', 'pomidor@mfsa.ru', 1, '$2y$10$UF8WNjGnWu1H7GmyZZaNLeNnGsqDbp15/VD.m6ZwrZXJmh9JAdl/G', '', '', '', 0, 'XfHkMzGidaTy2tnRtefQ0r303z4WjK1lT05EEB6sSf8dMmku5cQyuDZ66MFl', '2014-11-27 13:38:59', '2014-12-15 07:11:48'),
(12, 5, 'Анатолий', 'Огурцов', 'oguretz@mfsa.ru', 1, '$2y$10$tojLdSo3cHiR.bwrdvP7WefpQh4cO5BWFXI6EiUqxieqbrhicTmsy', '', '', '', 0, 'cXcJkgVZnRUluXs2vahJcmTd5fcPAnvXQ8IlsFyUBbWZ7pOfEhQkeQHcdsNG', '2014-11-28 15:02:12', '2014-12-11 11:41:42'),
(13, 4, '', 'Test', 'Test@test.ru', 2, '$2y$10$IgE.RzCZcBsJizwSGsDC4u1DOpnTHfCTm3K55MU7z9jdC7ix.QeXq', '', '', '2QUXXU0d7YnbHa16BY19IgKL', 1417872857, 'csXnVoPgSkBGuV8ixxJtVX3H5br697fRaIZiZaSHK2OZ2y9NrVfrzgXRuUrr', '2014-12-01 13:34:17', '2014-12-01 13:37:57'),
(15, 4, 'Владимир', 'Харсеев', 'vkharseev-2@gmail.com', 1, '$2y$10$U0GlqYTjeadsKBqSVqC7R.P6zBntw2fvGLD.M1UL8S.LC6gXZKcqi', '', '', '', 0, 'DAM7S2KRpY0L8blGCYJvUkeqa3i6v6YoHAvrL4QfohrshTUR3brAorpU3940', '2014-12-02 09:01:41', '2014-12-12 08:02:32'),
(16, 4, 'Алена', 'Нихаева', 'tezis16@gmail.com', 2, '$2y$10$OlH7q92HokeHOK5hb0MEt.FI4cBIunfnitYYSXivu08Uwa3w1Din.', '', '', 'BHw5gG1VjIMOyKhC7YO0LGnK', 1417957722, NULL, '2014-12-02 13:08:42', '2014-12-02 13:08:42'),
(17, 5, 'Игорь', 'Жуков', 'tezis16@gmail.ru', 2, '$2y$10$EnEK2EdmIC3J.5QjntMPF.PAaJ5UvE2mqcfzvgORVXHgLJlgF1fTG', '', '', 'LhFEHfvovjBVaYcCANlsPyip', 1417958150, NULL, '2014-12-02 13:15:50', '2014-12-02 13:15:50'),
(18, 5, 'Алексей', 'Бирючинский', '16tezis@gmail.com', 2, '$2y$10$FOI1lEgXQLFt.LIgXEYdhuhDS21q9/Z8DjqetUDg.Qs86Fc3oZIIm', '', '', '4fJOiniqFQhhGkSDERG9FCs5', 1417958496, NULL, '2014-12-02 13:21:36', '2014-12-02 13:21:36'),
(19, 4, 'И.И.', 'Иванов', 'firma-proverka-2@yandex.ru', 1, '$2y$10$8kqPxEyEG4bLMlalLdLoieLpeCpVyAyRhMndxUJzryYPH/n6WEnK6', '', '', '', 0, '6DZ9xSdHpTyIdebtTKxlCe7JwzgSllI1N3VxJViOlbgBzwtu3jtmSjYlU7Lg', '2014-12-02 21:08:50', '2014-12-03 09:58:10'),
(20, 5, 'АнгелА', 'Анеглова', 'angela.angelowa@yandex.ru', 1, '$2y$10$PjeLPmFkq/ZMb.LUaea9R.JlIkfBmElu6nYk2lhXfkhzA3NWeiA.e', '', '', '', 0, 'JHwSew9x2D5MSXFOYhCHEUX4JHa2x6rlmoaOC1Nib3kXwWgm0zQoH9UwyOSa', '2014-12-02 21:21:09', '2014-12-02 23:15:34'),
(21, 5, 'Павел', 'Шумеев', 'shuma_01@mail.ru', 1, '$2y$10$ALlQysiOZEMuoFNd5ZWDtuA2GEfusV.D2ElKt3yOby1fRV2P9l/l.', '', '', '', 0, 'VnyFyVS6vurBigJbuViSTrLnM5KDY6t1Ikz1BsL361GY2kJPULmRUdNbUUOF', '2014-12-02 21:28:35', '2014-12-02 21:30:32'),
(22, 5, 'Сергей', 'Баклажанов', 'baklajan@mfsa.ru', 1, '$2y$10$VN/yamVbdY/w6UwO9A0lwe3TUVzX1.hNjHuSV4qbKDtNVnAgol4RO', '', '', '', 0, 'Mg07fwLNWk51bpHSWOPberW4s5b1wW4ijuWITcxqfXqcSOzyWuWj30kd8G4J', '2014-12-03 09:35:50', '2014-12-03 10:06:43'),
(23, 5, 'Иван', 'Иванов', 'vk-1@grapheme.ru', 1, '$2y$10$xMnnu94dKOy6UWGC665GnOXqVmKztJvGcRaNz5I69r4dygj6mib/K', '', '', '', 0, '8rBXilIvkVOwrh9nb0PE4v4JvrC46c6oPlDXxlCLgWtvpKKOHDTfBda6eGJn', '2014-12-03 10:23:26', '2014-12-11 11:02:04'),
(25, 4, 'наименование', 'Полное', 'eeee@mfsa.ru', 2, '$2y$10$3itLvhU.GRD9MZWvd2zphe96FUd2w89k0PG2yNB8gkWf/vQWm.Ozy', '', '', 'mm7YE2oqVtqqnde3xDwSBuUz', 1418122021, 'faRLVV2MW65qwFenhIWjSMYn868DJdyySenKBgNJCYKvwzxLmS0cuwB63uCl', '2014-12-04 10:47:01', '2014-12-04 11:06:06'),
(27, 4, '', 'test', 'test@mfsa.ru', 2, '$2y$10$TXm1sfXsd551Vezv4VfDR.WR32M3.zAkH5m8Ntqsy3/LKdaVImWfa', '', '', '8X9dqolSNdICMT1enhpLqUhp', 1418129016, 'SR3ddt3WuP4peIYH9t1TOPFm2Y3wb1ecHKRnNZsuz5FcCeBAgkMoVpdMozeJ', '2014-12-04 12:43:36', '2014-12-04 14:03:18'),
(28, 5, 'Иван', 'Иванов', '06@techvuz.ru', 2, '$2y$10$2ffdVZhoI9YcGSeyOS/Sg.93Egzue/I7GF0YM7AamhGvSlN7FwiIS', '', '', 'BAMIeGt3Eq6sKoDwn1gbRLyv', 1418132833, NULL, '2014-12-04 13:47:13', '2014-12-04 13:47:13'),
(29, 6, 'Дарья', 'Шаповалова', 'GraCompany@yandex.ru', 1, '$2y$10$ABDGjudwZ.RFRVsaIjrLtOJYjIUXtexnWmSnG5PWQSaZbJ3BXmnBO', '', '', '', 0, 'VREVB77Uo4nMpV9FT3QrpNEMFeKTJbZB1xgIQ3kPPKEv9XRMTdSdYP6JzNOb', '2014-12-08 13:18:29', '2014-12-08 13:25:53'),
(30, 4, 'Сергей', 'Петров', 'firma-proverka-3@yandex.ru', 1, '$2y$10$whSNJFlHJ8DacA/ZN7Tnh.aBSacRhxdvPz.SRkwWvgbcqJMJ5UUMK', '', '', '', 0, '4rcCO8dmEzPR7PqWEGUv3cdtQgm0c01CDmp0503vdxHxlLiijwZ9PERFzatT', '2014-12-10 16:03:46', '2014-12-11 11:42:14'),
(31, 4, '', 'hgggggggggggggg', 'GGGGGGGGGG@MAIL.RU', 2, '$2y$10$uHJ0P2zsG4JyPLH4r6a1kejOqIzzX7/qAQW/O.u01SNv93fDZfz7u', '', '', 'YvcVevSfvuMPlOEOLwj3sTEJ', 1418659896, 'JxBdMVl9ZqYoeTMAdumAX6H4HYRZrVK7QgI34PIGlpMdzUAqL6NYcc5yRgNJ', '2014-12-10 16:11:36', '2014-12-10 16:14:00'),
(32, 5, '', 'пррррррррррggggggggggg', 'andrej.kotovasya@yandex.ru', 1, '$2y$10$q8Cc/MW8/VghzkaYB2O/eup9SDgORRRX5QdXGJPe0yrb3Yexapt3O', '', '', '', 0, 'pjpATmPMUnRUfsskxewPBUyra9Uzzfn8toc3NmaGbLaM5XADRgWFLcFAsMBx', '2014-12-10 16:28:17', '2014-12-11 11:01:49'),
(33, 5, 'Андрей', 'Тищенко', 'noudpo10@yandex.ru', 2, '$2y$10$ru8LYeEy07Tff48Q7XmZEOIfWusGXBIn1MF5Kyeiak6PPkxGt6RYm', '', '', '6TtPfwJH3idZKQyjOYzHK0cZ', 1418661951, NULL, '2014-12-10 16:45:51', '2014-12-10 16:45:51'),
(34, 4, '', 'ghhhhhhhhhhh45756666666', 'noudpo3@mail.ru', 2, '$2y$10$Z2HXhHqGRanwYuLzy72jFO1FgIoJCtw0GvMVTLo8Ftfg6DP1nj68u', '', '', 'kgP3suBjFFYcGcpUOyD38GbU', 1418710166, 'mqJsH2fVirJogdv1aWeKrkjfqiQh6XGC3h1zlvSSROjok7nUW6MHDncdvdPv', '2014-12-11 06:09:26', '2014-12-11 06:13:51'),
(35, 5, 'Питерсикий', 'Володя', '9846980@techvuz.ru', 2, '$2y$10$B8zh7pCP5I4UFeRPd7XasOueblU1mevyfSCFYrYORLNthmkit9SWa', '', '', 'p28SCQ6vVcEJq7lMHGTdnqgj', 1418726401, 'oBlB0bFZAEXrZrGjT0GnE1GxTWdoVW964FIngGb9FAfxIcubzSAPoig9OO7Q', '2014-12-11 10:40:01', '2014-12-11 11:42:53'),
(36, 5, 'Питерсикий', 'Володя', 'vk9846980@techvuz.ru', 2, '$2y$10$4brbiMhNtizzhi5Zd1KOmumtHVcPxQ7WqaFV1yl7h.XpTEA4MJxTK', '', '', 'ERfhulMZhHYLLPsN7BicgU3R', 1418730163, 'a7G82bxBUrBJS6i7DY8edy9cNzlpYD9UVDRTsx6iKVeUERrtZlNWx5bH2oHi', '2014-12-11 11:42:43', '2014-12-12 08:10:43'),
(37, 5, 'Андрей', 'Самойлов', 'andrey@grapheme.ru', 1, '$2y$10$rhjfImJWX4NJEzOoqtkm1OY/Z0L305YhUtIEbOp9wmJMKeRrpQtEm', '', '', '', 0, 'sdcUOZbeTwGXGpKEsyrdeLADH1QkmqPpBhY3CMNLFxt9uTF88Uiq84KsHuiY', '2014-12-11 11:43:10', '2014-12-11 11:47:06'),
(38, 4, 'рщшкеорщкшеро', 'шкгщшкоеоатрол', 'company@mfsa.ru', 1, '$2y$10$NARLbaBSmyn0uz7cromiPuPRw1GwYXOkURK1X27VKLUp/SeImnxQW', '', '', '', 0, 'L72wI16zp54ezm49v8gmkfWTfRJohroLmHyKCK0Hj9pGxm4x6JEijus6nt8h', '2014-12-11 10:29:29', '2014-12-15 07:42:07'),
(39, 5, 'Ивану', 'Иванову', 'ivv@mfsa.ru', 1, '$2y$10$U3BW3LRd0EboLcP311mV2urQ38KhTrE.yJctCOJjH6xwJxAlvv.IC', '', '', '', 0, '7bfjeeYHJu31vYHuZ1y64wemgWQlqB7UUxFajpTZDwZOBv2Jx4lVXxJXMx3R', '2014-12-11 10:39:20', '2014-12-11 10:41:19'),
(40, 5, 'Ивану', 'Иванову', 'ivvv@mfsa.ru', 2, '$2y$10$vO9ytPJKhXs/h09MJ.stF.xbjGabEMqWoLcL6PQN7mQbWpcjRPMdC', '', '', 'NSO0mTNUw5KdahhajlBLQVPO', 1418737454, NULL, '2014-12-11 10:44:14', '2014-12-11 10:44:14'),
(41, 4, 'Владимир', 'Харсеев', 'vkharseev-org@gmail.com', 1, '$2y$10$jUC0HJhekgcz4R9Cr0ioXOGvqz3zBeVl87xtdFR//mFa.Qm4oUVF.', '', '', '', 0, 'YPzgDCWbLy98BKp9W6qVWnmmxx7JlVNvRVe6sSjSBE9IqfrgHjz7SpnDI1bz', '2014-12-12 08:55:51', '2014-12-16 09:32:10'),
(42, 5, '', 'Володя', 'vk@grapheme.ru', 2, '$2y$10$EuYIXXiNNBfDlEHUvhhfU.Ic4SMEDCMatfFq7Zrim92456yCQejTu', '', '', 'dp4m80uFVglPUmRhgUFAnMoZ', 1418817915, 'NOMCti1jHnwlhfM98rlWxA3bAfS8ETIMUHFElFlPOc23AhOYzPle1OkIl1uu', '2014-12-12 09:05:15', '2014-12-12 09:15:38'),
(43, 4, 'аеоаео', 'ыпвероео', 'drgdr@xn.ru', 2, '$2y$10$5VjHOX3ZOdUYBHCv6y0QUO6dAzGJWD6t5EIaSwkQWovmMUAHswlzm', '', '', 'zeDHvq6lzkwVm8ORlu0sYqH4', 1419072376, 'UsQCqGoRDjoEZm469KgC5ls7MWHCRrGx33tlC2w1QWvxoJpYsDWJFk3C71kP', '2014-12-15 07:46:16', '2014-12-15 07:46:26'),
(44, 4, 'Виктор', 'Емельянин', 'roga@mfsa.ru', 1, '$2y$10$5oijD6Pc0b/2a3FTOLNu7ehzWFFfh7okgP.iCPxw/dYItwYRC2nyi', '', '', '', 0, 'QXiqpBTZVW3pv0VWC8SmbR01FyvN6F9lsNJN9MVwo4u31wNlAx2TEsij7neR', '2014-12-15 07:52:40', '2014-12-15 08:16:19'),
(45, 5, 'Анатолий', 'Кулебякин', 'Kuleb@mfsa.ru', 1, '$2y$10$giZYYcAxSK6yfKLEDpKN4edwjD.sJpJaSxWU/ul4LOmD6apESx4im', '', '', '', 0, 'IOhgMnRGicaTZk7JBMFb92AsoPGzKgNL5jlYilHSE01z5XZu0uWmOHSYcnky', '2014-12-15 07:57:38', '2014-12-15 10:57:22'),
(46, 5, '', 'fut6ujr', 'gift@mfsa.ru', 1, '$2y$10$IuPfpYOjqIbpp0I5JuuzFu6OYnpsD8pVqsIeTBW4A4OB8IAOe6klS', '', '', '', 0, 'b3RQkV6ko2Sy4gsTwKby9j4NSqRdidh2Tz1Gxaqrtio0ys9tovYBrx07rPMB', '2014-12-15 08:03:43', '2014-12-15 08:09:16'),
(47, 5, '', '6757r6yrt', '232323@32432443.ru', 2, '$2y$10$8z6ZxsM0hE6dd3GJ6LVNk.p4.7ya7UyIE6qbj/.g.gIoAhT9sefIa', '', '', 'uAvmkKKuJR3RfahR8sKGNoUQ', 1419073922, NULL, '2014-12-15 08:12:02', '2014-12-15 08:12:02'),
(48, 6, 'Владимир', 'Харсеев', 'vkharseev@gmail.com', 2, '$2y$10$5a5OyUih/jgbsVnK0GIW2OtFCxaL7Q..L.7CmC6ttZ3asNvA9.HKy', '', '', 'WEdPKiaCUd4FVhx2ujk86NiQ', 1419165274, NULL, '2014-12-16 09:34:34', '2014-12-16 09:34:34'),
(49, 5, 'Игорь', 'Картошкин', 'potato@mfsa.ru', 2, '$2y$10$PEWJmifw3d/p1BKf1HAenOa0IJtDeyUy2/o1RdHn2SDdo9VsY.wXm', '', '', 'YRmVDvn00w8it2NuDXjuj02f', 1419335886, NULL, '2014-12-18 08:58:06', '2014-12-18 08:58:06');

-- --------------------------------------------------------

--
-- Дублирующая структура для представления `users_individuals`
--
DROP VIEW IF EXISTS `users_individuals`;
CREATE TABLE IF NOT EXISTS `users_individuals` (
`id` int(10) unsigned
,`email` varchar(100)
,`active` smallint(5) unsigned
,`created_at` timestamp
,`individual_id` int(10) unsigned
,`fio` varchar(160)
,`fio_rod` varchar(160)
,`passport_seria` varchar(10)
,`passport_number` varchar(10)
,`passport_data` varchar(200)
,`passport_date` varchar(20)
,`code` varchar(50)
,`postaddress` varchar(255)
,`phone` varchar(40)
,`position` varchar(255)
,`education` varchar(255)
,`document_education` varchar(255)
,`specialty` varchar(255)
,`educational_institution` varchar(255)
,`discount` tinyint(4)
,`moderator_approve` tinyint(1)
);
-- --------------------------------------------------------

--
-- Дублирующая структура для представления `users_listeners`
--
DROP VIEW IF EXISTS `users_listeners`;
CREATE TABLE IF NOT EXISTS `users_listeners` (
`id` int(10) unsigned
,`email` varchar(100)
,`active` smallint(5) unsigned
,`created_at` timestamp
,`listener_id` int(10) unsigned
,`organization_id` int(10) unsigned
,`fio` varchar(160)
,`fio_dat` varchar(160)
,`position` varchar(255)
,`postaddress` varchar(255)
,`phone` varchar(40)
,`education` varchar(255)
,`education_document_data` varchar(255)
,`educational_institution` varchar(255)
,`specialty` varchar(255)
);
-- --------------------------------------------------------

--
-- Дублирующая структура для представления `users_organizations`
--
DROP VIEW IF EXISTS `users_organizations`;
CREATE TABLE IF NOT EXISTS `users_organizations` (
`id` int(10) unsigned
,`email` varchar(100)
,`active` smallint(5) unsigned
,`created_at` timestamp
,`organization_id` int(10) unsigned
,`title` varchar(255)
,`fio_manager` varchar(160)
,`fio_manager_rod` varchar(160)
,`manager` varchar(255)
,`statutory` varchar(255)
,`inn` varchar(40)
,`ogrn` varchar(40)
,`kpp` varchar(40)
,`postaddress` varchar(255)
,`uraddress` varchar(255)
,`account_type_id` smallint(5) unsigned
,`account_number` varchar(40)
,`account_kor_number` varchar(40)
,`bank` varchar(255)
,`bik` varchar(40)
,`name` varchar(100)
,`phone` varchar(40)
,`discount` tinyint(4)
,`moderator_approve` tinyint(1)
,`account_type` varchar(50)
);
-- --------------------------------------------------------

--
-- Структура таблицы `user_download_lectures`
--

DROP TABLE IF EXISTS `user_download_lectures`;
CREATE TABLE IF NOT EXISTS `user_download_lectures` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `lecture_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `user_download_lectures_user_id_index` (`user_id`),
  KEY `user_download_lectures_lecture_id_index` (`lecture_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=73 ;

--
-- Дамп данных таблицы `user_download_lectures`
--

INSERT INTO `user_download_lectures` (`id`, `user_id`, `lecture_id`, `created_at`, `updated_at`) VALUES
(1, 23, 1, '2014-12-04 16:26:06', '2014-12-04 16:26:06'),
(2, 23, 4, '2014-12-04 16:26:10', '2014-12-04 16:26:10'),
(3, 11, 9, '2014-12-05 11:23:52', '2014-12-05 11:23:52'),
(4, 11, 127, '2014-12-05 17:03:14', '2014-12-05 17:03:14'),
(5, 11, 128, '2014-12-05 17:15:02', '2014-12-05 17:15:02'),
(6, 11, 129, '2014-12-05 17:15:18', '2014-12-05 17:15:18'),
(7, 11, 130, '2014-12-05 17:17:51', '2014-12-05 17:17:51'),
(8, 11, 131, '2014-12-05 17:17:57', '2014-12-05 17:17:57'),
(9, 11, 132, '2014-12-05 17:18:06', '2014-12-05 17:18:06'),
(10, 11, 10, '2014-12-05 17:18:50', '2014-12-05 17:18:50'),
(11, 11, 11, '2014-12-05 17:19:11', '2014-12-05 17:19:11'),
(12, 11, 12, '2014-12-05 17:19:11', '2014-12-05 17:19:11'),
(13, 11, 13, '2014-12-05 17:19:11', '2014-12-05 17:19:11'),
(14, 11, 14, '2014-12-05 17:19:11', '2014-12-05 17:19:11'),
(15, 11, 15, '2014-12-05 17:19:11', '2014-12-05 17:19:11'),
(16, 11, 16, '2014-12-05 17:19:11', '2014-12-05 17:19:11'),
(17, 4, 9, '2014-12-09 12:33:55', '2014-12-09 12:33:55'),
(18, 4, 10, '2014-12-09 12:33:55', '2014-12-09 12:33:55'),
(19, 4, 11, '2014-12-09 12:33:55', '2014-12-09 12:33:55'),
(20, 4, 12, '2014-12-09 12:33:55', '2014-12-09 12:33:55'),
(21, 4, 13, '2014-12-09 12:33:55', '2014-12-09 12:33:55'),
(22, 4, 14, '2014-12-09 12:33:55', '2014-12-09 12:33:55'),
(23, 4, 15, '2014-12-09 12:33:55', '2014-12-09 12:33:55'),
(24, 4, 16, '2014-12-09 12:33:55', '2014-12-09 12:33:55'),
(25, 32, 1, '2014-12-11 06:35:48', '2014-12-11 06:35:48'),
(26, 32, 2, '2014-12-11 06:35:48', '2014-12-11 06:35:48'),
(27, 32, 3, '2014-12-11 06:35:48', '2014-12-11 06:35:48'),
(28, 32, 4, '2014-12-11 06:35:48', '2014-12-11 06:35:48'),
(29, 32, 5, '2014-12-11 06:35:48', '2014-12-11 06:35:48'),
(30, 32, 6, '2014-12-11 06:35:48', '2014-12-11 06:35:48'),
(31, 32, 7, '2014-12-11 06:35:48', '2014-12-11 06:35:48'),
(32, 32, 8, '2014-12-11 06:35:48', '2014-12-11 06:35:48'),
(33, 23, 9, '2014-12-11 10:55:22', '2014-12-11 10:55:22'),
(34, 23, 10, '2014-12-11 10:55:22', '2014-12-11 10:55:22'),
(35, 23, 11, '2014-12-11 10:55:22', '2014-12-11 10:55:22'),
(36, 23, 12, '2014-12-11 10:55:22', '2014-12-11 10:55:22'),
(37, 23, 13, '2014-12-11 10:55:22', '2014-12-11 10:55:22'),
(38, 23, 14, '2014-12-11 10:55:22', '2014-12-11 10:55:22'),
(39, 23, 15, '2014-12-11 10:55:22', '2014-12-11 10:55:22'),
(40, 23, 16, '2014-12-11 10:55:22', '2014-12-11 10:55:22'),
(41, 23, 17, '2014-12-11 10:56:03', '2014-12-11 10:56:03'),
(42, 23, 18, '2014-12-11 10:56:03', '2014-12-11 10:56:03'),
(43, 23, 19, '2014-12-11 10:56:03', '2014-12-11 10:56:03'),
(44, 23, 20, '2014-12-11 10:56:03', '2014-12-11 10:56:03'),
(45, 23, 21, '2014-12-11 10:56:03', '2014-12-11 10:56:03'),
(46, 23, 22, '2014-12-11 10:56:03', '2014-12-11 10:56:03'),
(47, 23, 23, '2014-12-11 10:56:03', '2014-12-11 10:56:03'),
(48, 23, 24, '2014-12-11 10:56:03', '2014-12-11 10:56:03'),
(49, 35, 1, '2014-12-11 11:03:04', '2014-12-11 11:03:04'),
(50, 35, 2, '2014-12-11 11:03:04', '2014-12-11 11:03:04'),
(51, 35, 3, '2014-12-11 11:03:04', '2014-12-11 11:03:04'),
(52, 35, 4, '2014-12-11 11:03:04', '2014-12-11 11:03:04'),
(53, 35, 5, '2014-12-11 11:03:04', '2014-12-11 11:03:04'),
(54, 35, 6, '2014-12-11 11:03:04', '2014-12-11 11:03:04'),
(55, 35, 7, '2014-12-11 11:03:04', '2014-12-11 11:03:04'),
(56, 35, 8, '2014-12-11 11:03:04', '2014-12-11 11:03:04'),
(57, 36, 1, '2014-12-12 08:09:58', '2014-12-12 08:09:58'),
(58, 42, 9, '2014-12-12 09:10:55', '2014-12-12 09:10:55'),
(59, 45, 65, '2014-12-15 08:22:54', '2014-12-15 08:22:54'),
(60, 45, 66, '2014-12-15 08:22:54', '2014-12-15 08:22:54'),
(61, 45, 67, '2014-12-15 08:22:54', '2014-12-15 08:22:54'),
(62, 45, 68, '2014-12-15 08:22:54', '2014-12-15 08:22:54'),
(63, 45, 69, '2014-12-15 08:22:54', '2014-12-15 08:22:54'),
(64, 45, 70, '2014-12-15 08:22:54', '2014-12-15 08:22:54'),
(65, 45, 71, '2014-12-15 08:22:54', '2014-12-15 08:22:54'),
(66, 45, 72, '2014-12-15 08:22:54', '2014-12-15 08:22:54'),
(67, 45, 127, '2014-12-15 08:23:38', '2014-12-15 08:23:38'),
(68, 45, 128, '2014-12-15 08:23:40', '2014-12-15 08:23:40'),
(69, 45, 129, '2014-12-15 08:23:40', '2014-12-15 08:23:40'),
(70, 45, 130, '2014-12-15 08:23:40', '2014-12-15 08:23:40'),
(71, 45, 131, '2014-12-15 08:23:40', '2014-12-15 08:23:40'),
(72, 45, 132, '2014-12-15 08:23:40', '2014-12-15 08:23:40');

-- --------------------------------------------------------

--
-- Структура таблицы `user_settings`
--

DROP TABLE IF EXISTS `user_settings`;
CREATE TABLE IF NOT EXISTS `user_settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `slug` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `value` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `user_settings_user_id_index` (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=10 ;

--
-- Дамп данных таблицы `user_settings`
--

INSERT INTO `user_settings` (`id`, `user_id`, `slug`, `value`, `created_at`, `updated_at`) VALUES
(1, 2, 'dashboard-target-notification-block', '0', '2014-12-01 11:41:48', '2014-12-02 15:24:36'),
(2, 8, 'dashboard-target-notification-block', '0', '2014-12-02 11:54:07', '2014-12-02 15:25:10'),
(3, 19, 'dashboard-target-notification-block', '0', '2014-12-02 21:15:18', '2014-12-02 21:15:18'),
(4, 15, 'dashboard-target-notification-block', '0', '2014-12-03 10:22:42', '2014-12-03 10:22:42'),
(5, 3, 'dashboard-target-notification-block', '0', '2014-12-04 13:56:52', '2014-12-04 13:56:52'),
(6, 30, 'dashboard-target-notification-block', '0', '2014-12-10 16:14:00', '2014-12-10 16:14:00'),
(7, 38, 'dashboard-target-notification-block', '0', '2014-12-11 10:30:05', '2014-12-11 10:30:05'),
(8, 41, 'dashboard-target-notification-block', '0', '2014-12-12 09:02:47', '2014-12-12 09:02:47'),
(9, 44, 'dashboard-target-notification-block', '0', '2014-12-15 07:53:26', '2014-12-15 07:53:26');

-- --------------------------------------------------------

--
-- Структура таблицы `videos`
--

DROP TABLE IF EXISTS `videos`;
CREATE TABLE IF NOT EXISTS `videos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `embed` text COLLATE utf8_unicode_ci,
  `image_id` int(11) DEFAULT NULL,
  `module` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `unit_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `videos_module_index` (`module`),
  KEY `videos_unit_id_index` (`unit_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура для представления `users_individuals`
--
DROP TABLE IF EXISTS `users_individuals`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `users_individuals` AS select `users`.`id` AS `id`,`users`.`email` AS `email`,`users`.`active` AS `active`,`users`.`created_at` AS `created_at`,`individuals`.`id` AS `individual_id`,`individuals`.`fio` AS `fio`,`individuals`.`fio_rod` AS `fio_rod`,`individuals`.`passport_seria` AS `passport_seria`,`individuals`.`passport_number` AS `passport_number`,`individuals`.`passport_data` AS `passport_data`,`individuals`.`passport_date` AS `passport_date`,`individuals`.`code` AS `code`,`individuals`.`postaddress` AS `postaddress`,`individuals`.`phone` AS `phone`,`individuals`.`position` AS `position`,`individuals`.`education` AS `education`,`individuals`.`document_education` AS `document_education`,`individuals`.`specialty` AS `specialty`,`individuals`.`educational_institution` AS `educational_institution`,`individuals`.`discount` AS `discount`,`individuals`.`moderator_approve` AS `moderator_approve` from (`users` left join `individuals` on((`users`.`id` = `individuals`.`user_id`))) where (`users`.`group_id` = 6);

-- --------------------------------------------------------

--
-- Структура для представления `users_listeners`
--
DROP TABLE IF EXISTS `users_listeners`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `users_listeners` AS select `users`.`id` AS `id`,`users`.`email` AS `email`,`users`.`active` AS `active`,`users`.`created_at` AS `created_at`,`listeners`.`id` AS `listener_id`,`listeners`.`organization_id` AS `organization_id`,`listeners`.`fio` AS `fio`,`listeners`.`fio_dat` AS `fio_dat`,`listeners`.`position` AS `position`,`listeners`.`postaddress` AS `postaddress`,`listeners`.`phone` AS `phone`,`listeners`.`education` AS `education`,`listeners`.`education_document_data` AS `education_document_data`,`listeners`.`educational_institution` AS `educational_institution`,`listeners`.`specialty` AS `specialty` from (`listeners` left join `users` on((`users`.`id` = `listeners`.`user_id`))) where (`users`.`group_id` = 5);

-- --------------------------------------------------------

--
-- Структура для представления `users_organizations`
--
DROP TABLE IF EXISTS `users_organizations`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `users_organizations` AS select `users`.`id` AS `id`,`users`.`email` AS `email`,`users`.`active` AS `active`,`users`.`created_at` AS `created_at`,`organizations`.`id` AS `organization_id`,`organizations`.`title` AS `title`,`organizations`.`fio_manager` AS `fio_manager`,`organizations`.`fio_manager_rod` AS `fio_manager_rod`,`organizations`.`manager` AS `manager`,`organizations`.`statutory` AS `statutory`,`organizations`.`inn` AS `inn`,`organizations`.`ogrn` AS `ogrn`,`organizations`.`kpp` AS `kpp`,`organizations`.`postaddress` AS `postaddress`,`organizations`.`uraddress` AS `uraddress`,`organizations`.`account_type` AS `account_type_id`,`organizations`.`account_number` AS `account_number`,`organizations`.`account_kor_number` AS `account_kor_number`,`organizations`.`bank` AS `bank`,`organizations`.`bik` AS `bik`,`organizations`.`name` AS `name`,`organizations`.`phone` AS `phone`,`organizations`.`discount` AS `discount`,`organizations`.`moderator_approve` AS `moderator_approve`,`account_types`.`title` AS `account_type` from ((`organizations` left join `users` on((`users`.`id` = `organizations`.`user_id`))) join `account_types` on((`organizations`.`account_type` = `account_types`.`id`))) where (`users`.`group_id` = 4);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
